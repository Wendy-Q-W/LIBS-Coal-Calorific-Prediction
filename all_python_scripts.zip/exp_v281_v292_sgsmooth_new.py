"""
exp_v281_v292_sgsmooth_new.py
Only run new SG smoothing variant experiments (V281-V292).
Import infrastructure from exp_v260_v270_tree_models.py
"""
import os, sys, io, zipfile, json
import numpy as np
import pandas as pd
from datetime import datetime

# Import everything from the tree model script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exp_v260_v270_tree_models as base

OUTPUT_DIR = base.OUTPUT_DIR
SUBMIT_TEMPLATE = base.SUBMIT_TEMPLATE


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


if __name__ == '__main__':
    V96_ZIP = 'submit_v96_blend_v74_v72_7525.zip'
    v96 = load_existing_submission(V96_ZIP)
    v96_arr = np.array(v96.values) if v96 is not None else None
    
    results = {}
    
    experiments = [
        # (vid, desc, kwargs)
        ('v281_sgsmooth_w7_o2_snv_a005_linear',
         "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)),
        
        ('v282_sgsmooth_w9_snv_a005_linear',
         "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='sg_smooth_w9', use_pca=True, use_two_stage=True)),
        
        ('v283_sgsmooth_w7_o2_snv_a005_isotonic',
         "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + isotonic.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='isotonic',
              preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)),
        
        ('v284_sgsmooth_w9_snv_a005_isotonic',
         "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + isotonic.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='isotonic',
              preprocessing='sg_smooth_w9', use_pca=True, use_two_stage=True)),
        
        ('v285_sgsmooth_w11_snv_a005_linear',
         "SG smoothing (w11, order2) + SNV + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='sg_smooth_w11', use_pca=True, use_two_stage=True)),
        
        ('v286_sgsmooth_w5_snv_a003_linear',
         "SG smoothing (w5) + SNV + Ridge a=0.03 + linear. Lower alpha.",
         dict(model_type='ridge', ridge_alpha=0.03, calibration='linear',
              preprocessing='sg_smooth', use_pca=True, use_two_stage=True)),
        
        ('v287_sgsmooth_w5_snv_a01_isotonic',
         "SG smoothing (w5) + SNV + Ridge a=0.1 + isotonic. V63 equivalent.",
         dict(model_type='ridge', ridge_alpha=0.1, calibration='isotonic',
              preprocessing='sg_smooth', use_pca=True, use_two_stage=True)),
        
        ('v288_sgsmooth_w7_o2_snv_a003_linear',
         "SG smoothing (w7, order2) + SNV + Ridge a=0.03 + linear.",
         dict(model_type='ridge', ridge_alpha=0.03, calibration='linear',
              preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)),
        
        ('v289_snv_then_sg_w5_a005_linear',
         "SNV + SG smooth (w5, reverse order) + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='snv_then_sg', use_pca=True, use_two_stage=True)),
        
        ('v290_snv_then_sg_w7_a005_linear',
         "SNV + SG smooth (w7, reverse order) + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='snv_then_sg_w7', use_pca=True, use_two_stage=True)),
        
        ('v291_sgsmooth_w7_o1_snv_a005_linear',
         "SG smoothing (w7, order1=linear) + SNV + Ridge a=0.05 + linear.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='sg_smooth_w7_o1', use_pca=True, use_two_stage=True)),
        
        ('v292_area_norm_a005_linear',
         "Area normalization + Ridge a=0.05 + linear. Alternative scatter correction.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='linear',
              preprocessing='area_norm', use_pca=True, use_two_stage=True)),
    ]
    
    for vid, desc, kwargs in experiments:
        print(f"\n{'=' * 70}")
        print(f"  {vid}: {desc}")
        print(f"{'=' * 70}")
        
        try:
            out_zip, global_cv = base.run_experiment(vid, desc, **kwargs)
            
            # Correlation with V96
            sub = load_existing_submission(f"submit_{vid}.zip")
            if sub is not None and v96_arr is not None:
                arr = np.array(sub.values)
                corr = np.corrcoef(v96_arr, arr)[0, 1]
                mae = np.mean(np.abs(arr - v96_arr))
                print(f"  CV={global_cv:.2f}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                results[vid] = {'cv': global_cv, 'corr_v96': corr, 'mae_v96': mae}
            else:
                results[vid] = {'cv': global_cv}
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            results[vid] = {'error': str(e)}
    
    # Summary
    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  {'Variant':45s}  {'CV':>7s}  {'corr(V96)':>10s}  {'MAE':>7s}")
    print(f"  {'-' * 75}")
    
    # Also include V263 (already done) for comparison
    v263 = load_existing_submission('submit_v263_sgsmooth_w5_snv_ridge_a005_linear.zip')
    if v263 is not None and v96_arr is not None:
        v263_arr = np.array(v263.values)
        v263_corr = np.corrcoef(v96_arr, v263_arr)[0, 1]
        v263_mae = np.mean(np.abs(v263_arr - v96_arr))
        print(f"  {'V263_sgsmooth_w5 (reference)':45s}  {'170.13':>7s}  {v263_corr:10.6f}  {v263_mae:7.2f}  ***")
    
    for vid in sorted(results.keys()):
        r = results[vid]
        if 'cv' in r:
            cv = r['cv']
            corr = r.get('corr_v96', 0)
            mae = r.get('mae_v96', 0)
            marker = ' ***' if cv < 170 else (' **' if cv < 172 else '')
            print(f"  {vid:45s}  {cv:7.2f}  {corr:10.6f}  {mae:7.2f}{marker}")
        else:
            print(f"  {vid:45s}  ERROR: {r.get('error', 'unknown')}")
    
    # Find best
    valid = {k: v for k, v in results.items() if 'cv' in v}
    if valid:
        best = min(valid.items(), key=lambda x: x[1]['cv'])
        print(f"\n  Best: {best[0]} CV={best[1]['cv']:.2f} corr={best[1].get('corr_v96', 0):.6f}")
        
        # Generate blends for top 3 models
        print(f"\n{'=' * 70}")
        print("  BLEND GENERATION")
        print(f"{'=' * 70}")
        
        sorted_models = sorted(valid.items(), key=lambda x: x[1]['cv'])
        top_models = sorted_models[:5]
        print(f"  Top 5 by CV:")
        for vid, r in top_models:
            print(f"    {vid}: CV={r['cv']:.2f} corr={r.get('corr_v96', 0):.6f}")
        
        V63 = 'submit_v63_isotonic.zip'
        V72 = 'submit_v72_isotonic_a005.zip'
        
        def pack_blend(vid_name, components, desc):
            subs = {}
            for name, w in components:
                sub = load_existing_submission(name)
                if sub is None:
                    print(f"  ERROR: {name} not found")
                    return None
                subs[name] = sub
            all_preds = {}
            for idx in subs[components[0][0]].index:
                val = sum(w * subs[name][idx] for name, w in components)
                all_preds[idx] = float(val)
            template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
            template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
            template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
            out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
            template.to_csv(out_csv, index=False, encoding='utf-8-sig')
            readme = f"# LIBS\n\n**版本**: {vid_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
            readme_path = os.path.join(OUTPUT_DIR, "README.md")
            with open(readme_path, 'w', encoding='utf-8') as f:
                f.write(readme)
            out_zip = os.path.join(OUTPUT_DIR, f"submit_{vid_name}.zip")
            with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.write(out_csv, "submit/submit.csv")
                zf.write(readme_path, "submit/README.md")
            print(f"  [OK] {out_zip}")
            return out_zip
        
        for vid, r in top_models[:3]:
            vid_zip = f"submit_{vid}.zip"
            corr = r.get('corr_v96', 0)
            if corr > 0.99:
                # V96 + this model
                pack_blend(f"v300_blend_v96_{vid[:3]}_9010",
                           [(V96_ZIP, 0.9), (vid_zip, 0.1)],
                           f"V96(90%) + {vid}(10%). CV={r['cv']:.2f}")
                pack_blend(f"v301_blend_v96_{vid[:3]}_8020",
                           [(V96_ZIP, 0.8), (vid_zip, 0.2)],
                           f"V96(80%) + {vid}(20%). CV={r['cv']:.2f}")
                # V74 structure: this model + V63
                pack_blend(f"v302_blend_{vid[:3]}_v63_5050",
                           [(vid_zip, 0.5), (V63, 0.5)],
                           f"{vid}(50%) + V63(50%). V74 structure.")
                # V96 structure: (this+V63) + V72
                pack_blend(f"v303_blend_{vid[:3]}_v63_v72",
                           [(vid_zip, 0.375), (V63, 0.375), (V72, 0.25)],
                           f"{vid}(37.5%) + V63(37.5%) + V72(25%). V96 structure.")
    
    print("\n  Done.")
