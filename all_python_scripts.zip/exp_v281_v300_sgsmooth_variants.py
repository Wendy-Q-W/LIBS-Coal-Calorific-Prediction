"""
exp_v281_v300_sgsmooth_variants.py
SG smoothing (V263, CV=170.13) is the most promising preprocessing change.
Explore different window sizes, polynomial orders, and alternative scatter corrections.
Also try combining SG smoothing with different alpha values.
"""
import os, sys, json, io, zipfile, warnings, time
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from scipy.stats import median_abs_deviation
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import GroupKFold
warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(_HERE, "data")
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
N_SEEDS = 100

# -------------------------------------------------------------------
# Data loading
# -------------------------------------------------------------------
def load_data():
    train_df = pd.read_csv(os.path.join(DATA_DIR, "train_features.csv"))
    test_df = pd.read_csv(os.path.join(DATA_DIR, "test_features.csv"))
    spectral_cols = [c for c in train_df.columns if c.startswith('wave_')]
    X_train = train_df[spectral_cols].values.astype(np.float64)
    X_test = test_df[spectral_cols].values.astype(np.float64)
    y_train = train_df['发热量'].values.astype(np.float64)
    groups_train = train_df['煤种'].values
    groups_test = test_df['煤种'].values
    names_test = test_df['名称'].values
    return X_train, X_test, y_train, groups_train, groups_test, names_test, train_df, test_df

# -------------------------------------------------------------------
# Preprocessing
# -------------------------------------------------------------------
def apply_snv(X):
    mean = X.mean(axis=1, keepdims=True)
    std = X.std(axis=1, keepdims=True)
    std[std < 1e-8] = 1.0
    return (X - mean) / std

def apply_sg_smooth(X, window=5, order=2):
    """Apply Savitzky-Golay smoothing to each spectrum."""
    return np.array([savgol_filter(X[i], window_length=window, polyorder=order) for i in range(X.shape[0])])

def apply_msc(X, reference=None):
    """Multiplicative Scatter Correction."""
    if reference is None:
        reference = X.mean(axis=0)
    corrected = np.zeros_like(X)
    for i in range(X.shape[0]):
        fit = np.polyfit(reference, X[i], 1)
        corrected[i] = (X[i] - fit[1]) / fit[0]
    return corrected

def apply_area_norm(X):
    """Area normalization: divide each spectrum by its sum."""
    area = X.sum(axis=1, keepdims=True)
    area[area < 1e-8] = 1.0
    return X / area

def apply_minmax(X):
    """Min-max normalization to [0, 1]."""
    mn = X.min(axis=1, keepdims=True)
    mx = X.max(axis=1, keepdims=True)
    rng = mx - mn
    rng[rng < 1e-8] = 1.0
    return (X - mn) / rng

def apply_snv_plus_sg(X, window=5, order=2):
    """SNV first, then SG smoothing."""
    X_snv = apply_snv(X)
    return np.array([savgol_filter(X_snv[i], window_length=window, polyorder=order) for i in range(X_snv.shape[0])])

# -------------------------------------------------------------------
# Feature extraction
# -------------------------------------------------------------------
def extract_hand_features(X_raw, X_proc):
    """Extract hand-crafted features from raw and processed spectra."""
    n_samples = X_raw.shape[0]
    n_wavelengths = X_raw.shape[1]
    
    # Statistical features from processed spectra
    mean = X_proc.mean(axis=1)
    std = X_proc.std(axis=1)
    median = np.median(X_proc, axis=1)
    mad = median_abs_deviation(X_proc, axis=1)
    skew = pd.DataFrame(X_proc).skew(axis=1).values
    kurt = pd.DataFrame(X_proc).kurtosis(axis=1).values
    q25 = np.percentile(X_proc, 25, axis=1)
    q75 = np.percentile(X_proc, 75, axis=1)
    iqr = q75 - q25
    max_val = X_proc.max(axis=1)
    min_val = X_proc.min(axis=1)
    rng = max_val - min_val
    sum_abs = np.abs(X_proc).sum(axis=1)
    mean_abs = np.abs(X_proc).mean(axis=1)
    
    # Spectral line integrals (key coal elements)
    # C I 247.86, C I 193.09, Si I 288.16, Al I 396.15, Fe I 438.35
    # Ca II 393.37, Ca II 396.85, Mg II 280.27, Na I 589.59, K I 766.49, H 656.28
    line_centers = [193, 248, 288, 393, 397, 438, 517, 589, 656, 767, 770]
    line_integrals = []
    line_rel_intensities = []
    for lc in line_centers:
        idx = np.argmin(np.abs(np.arange(n_wavelengths) - lc))
        window = 5
        lo = max(0, idx - window)
        hi = min(n_wavelengths, idx + window + 1)
        integral = X_raw[:, lo:hi].sum(axis=1)
        line_integrals.append(integral)
        total = X_raw.sum(axis=1)
        total[total < 1e-8] = 1.0
        line_rel_intensities.append(integral / total)
    
    # Ratios
    c_247 = line_integrals[1]
    c_193 = line_integrals[0]
    ca_393 = line_integrals[3]
    ca_397 = line_integrals[4]
    si_288 = line_integrals[2]
    al_397 = line_integrals[4]
    ratios = [
        c_247 / (ca_393 + 1e-8),
        c_247 / (si_288 + 1e-8),
        c_247 / (al_397 + 1e-8),
        ca_393 / (si_288 + 1e-8),
    ]
    
    features = np.column_stack([
        mean, std, median, mad, skew, kurt, q25, q75, iqr,
        max_val, min_val, rng, sum_abs, mean_abs,
    ] + line_integrals + line_rel_intensities + ratios)
    
    # Replace inf/nan
    features = np.nan_to_num(features, nan=0.0, posinf=1e8, neginf=-1e8)
    return features

# -------------------------------------------------------------------
# Pipeline
# -------------------------------------------------------------------
def run_pipeline(X_train, X_test, y_train, groups_train, groups_test,
                 preprocess_fn, alpha=0.05, calibration='linear', n_seeds=N_SEEDS):
    """Run the full pipeline with given preprocessing function."""
    # Preprocess
    X_train_proc = preprocess_fn(X_train)
    X_test_proc = preprocess_fn(X_test)
    
    # PCA
    pca = PCA(n_components=30, random_state=42)
    X_train_pca = pca.fit_transform(X_train_proc)
    X_test_pca = pca.transform(X_test_proc)
    
    # Hand features
    hand_train = extract_hand_features(X_train, X_train_proc)
    hand_test = extract_hand_features(X_test, X_test_proc)
    
    # Combine
    X_train_combined = np.column_stack([X_train_pca, hand_train])
    X_test_combined = np.column_stack([X_test_pca, hand_test])
    
    # Standardize
    scaler = StandardScaler()
    X_train_combined = scaler.fit_transform(X_train_combined)
    X_test_combined = scaler.transform(X_test_combined)
    
    # Two-stage Ridge with seed ensemble
    unique_coals = np.unique(groups_train)
    
    # OOF predictions
    oof_preds = np.zeros(len(X_train))
    test_preds_seeds = []
    
    gkf = GroupKFold(n_splits=5)
    
    for seed in range(n_seeds):
        np.random.seed(seed)
        test_preds = np.zeros(len(X_test))
        
        for train_idx, val_idx in gkf.split(X_train_combined, y_train, groups_train):
            X_tr, X_val = X_train_combined[train_idx], X_train_combined[val_idx]
            y_tr, y_val = y_train[train_idx], y_train[val_idx]
            g_tr = groups_train[train_idx]
            
            # Stage 1: per-coal Ridge
            stage1_train = np.zeros(len(X_tr))
            stage1_val = np.zeros(len(X_val))
            stage1_test = np.zeros(len(X_test))
            
            for coal in unique_coals:
                mask_tr = g_tr == coal
                mask_test = groups_test == coal
                
                if mask_tr.sum() < 5:
                    # Use global model
                    model = Ridge(alpha=alpha, random_state=seed)
                    model.fit(X_tr, y_tr)
                    stage1_train[mask_tr] = model.predict(X_tr[mask_tr])
                    stage1_val[val_idx[np.isin(groups_train[val_idx], coal)]] = model.predict(
                        X_val[np.isin(groups_train[val_idx], coal)])
                    if mask_test.sum() > 0:
                        stage1_test[mask_test] = model.predict(X_test_combined[mask_test])
                    continue
                
                model = Ridge(alpha=alpha, random_state=seed)
                model.fit(X_tr[mask_tr], y_tr[mask_tr])
                stage1_train[mask_tr] = model.predict(X_tr[mask_tr])
                
                # Validation
                val_mask_coal = groups_train[val_idx] == coal
                if val_mask_coal.sum() > 0:
                    stage1_val[val_idx[val_mask_coal]] = model.predict(X_val[val_mask_coal])
                
                # Test
                if mask_test.sum() > 0:
                    stage1_test[mask_test] = model.predict(X_test_combined[mask_test])
            
            # Stage 2: global Ridge on stage1 predictions
            model2 = Ridge(alpha=alpha, random_state=seed)
            model2.fit(stage1_train.reshape(-1, 1), y_tr)
            
            val_pred = model2.predict(stage1_val.reshape(-1, 1))
            oof_preds[val_idx] += val_pred / n_seeds
            
            test_pred = model2.predict(stage1_test.reshape(-1, 1))
            test_preds_seeds.append(test_pred)
    
    # Median aggregation
    test_preds_arr = np.array(test_preds_seeds)
    test_pred_median = np.median(test_preds_arr, axis=0)
    
    # Shrinkage to coal mean
    coal_means = {}
    for coal in unique_coals:
        mask = groups_train == coal
        coal_means[coal] = y_train[mask].mean()
    
    for i in range(len(test_pred_median)):
        coal = groups_test[i]
        if coal in coal_means:
            test_pred_median[i] = 0.95 * test_pred_median[i] + 0.05 * coal_means[coal]
    
    # Calibration
    if calibration == 'linear':
        # Per-coal linear calibration
        for coal in unique_coals:
            mask = groups_train == coal
            if mask.sum() < 5:
                continue
            # Use OOF predictions for calibration
            coal_oof = oof_preds[mask]
            coal_y = y_train[mask]
            if len(coal_oof) > 1 and np.std(coal_oof) > 1e-8:
                a, b = np.polyfit(coal_oof, coal_y, 1)
            else:
                a, b = 1.0, 0.0
            # Apply to test
            test_mask = groups_test == coal
            if test_mask.sum() > 0:
                test_pred_median[test_mask] = a * test_pred_median[test_mask] + b
    elif calibration == 'isotonic':
        for coal in unique_coals:
            mask = groups_train == coal
            if mask.sum() < 5:
                continue
            coal_oof = oof_preds[mask]
            coal_y = y_train[mask]
            if len(coal_oof) > 1:
                iso = IsotonicRegression(out_of_bounds='clip')
                iso.fit(coal_oof, coal_y)
                test_mask = groups_test == coal
                if test_mask.sum() > 0:
                    test_pred_median[test_mask] = iso.predict(test_pred_median[test_mask])
    
    # CV RMSE
    cv_rmse = np.sqrt(np.mean((oof_preds - y_train) ** 2))
    
    return test_pred_median, cv_rmse, oof_preds

# -------------------------------------------------------------------
# Submission
# -------------------------------------------------------------------
def pack_submission(variant_name, all_preds, feature_desc, cv_rmse):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n**CV-RMSE**: {cv_rmse:.2f}\n\n{feature_desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip

def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]

def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc, 0.0)

# -------------------------------------------------------------------
# Main
# -------------------------------------------------------------------
if __name__ == '__main__':
    from datetime import datetime
    print("Loading data...")
    X_train, X_test, y_train, groups_train, groups_test, names_test, train_df, test_df = load_data()
    print(f"  Train: {X_train.shape}, Test: {X_test.shape}")
    print(f"  Coals: {np.unique(groups_train)}")
    
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values) if v96 is not None else None
    
    results = {}
    
    # =============================================
    # SG smoothing variants: different window sizes
    # =============================================
    experiments = [
        # (vid, preprocess_fn, alpha, calibration, description)
        ('v281_sgsmooth_w7_snv_a005_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=7, order=2)),
         0.05, 'linear',
         "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + linear. Larger window."),
        
        ('v282_sgsmooth_w9_snv_a005_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=9, order=2)),
         0.05, 'linear',
         "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + linear. Even larger window."),
        
        ('v283_sgsmooth_w7_snv_a005_isotonic',
         lambda X: apply_snv(apply_sg_smooth(X, window=7, order=2)),
         0.05, 'isotonic',
         "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + isotonic."),
        
        ('v284_sgsmooth_w9_snv_a005_isotonic',
         lambda X: apply_snv(apply_sg_smooth(X, window=9, order=2)),
         0.05, 'isotonic',
         "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + isotonic."),
        
        ('v285_sgsmooth_w11_snv_a005_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=11, order=2)),
         0.05, 'linear',
         "SG smoothing (w11, order2) + SNV + Ridge a=0.05 + linear. Very large window."),
        
        # SG smoothing + different alpha
        ('v286_sgsmooth_w5_snv_a003_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=5, order=2)),
         0.03, 'linear',
         "SG smoothing (w5) + SNV + Ridge a=0.03 + linear. Lower alpha."),
        
        ('v287_sgsmooth_w5_snv_a01_isotonic',
         lambda X: apply_snv(apply_sg_smooth(X, window=5, order=2)),
         0.1, 'isotonic',
         "SG smoothing (w5) + SNV + Ridge a=0.1 + isotonic. V63 equivalent."),
        
        ('v288_sgsmooth_w7_snv_a003_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=7, order=2)),
         0.03, 'linear',
         "SG smoothing (w7) + SNV + Ridge a=0.03 + linear. Lower alpha + larger window."),
        
        # Alternative scatter corrections
        ('v289_msc_a005_linear',
         lambda X: apply_msc(X),
         0.05, 'linear',
         "MSC (Multiplicative Scatter Correction) + Ridge a=0.05 + linear. Alternative to SNV."),
        
        ('v290_msc_a005_isotonic',
         lambda X: apply_msc(X),
         0.05, 'isotonic',
         "MSC + Ridge a=0.05 + isotonic."),
        
        ('v291_msc_sgsmooth_w5_a005_linear',
         lambda X: apply_msc(apply_sg_smooth(X, window=5, order=2)),
         0.05, 'linear',
         "SG smooth + MSC + Ridge a=0.05 + linear. Combined denoising."),
        
        # SNV + SG (reverse order: SNV first, then SG)
        ('v292_snv_sgsmooth_w5_a005_linear',
         lambda X: apply_snv_plus_sg(X, window=5, order=2),
         0.05, 'linear',
         "SNV + SG smooth (reverse order) + Ridge a=0.05 + linear."),
        
        ('v293_snv_sgsmooth_w7_a005_linear',
         lambda X: apply_snv_plus_sg(X, window=7, order=2),
         0.05, 'linear',
         "SNV + SG smooth w7 (reverse order) + Ridge a=0.05 + linear."),
        
        # Area normalization
        ('v294_area_norm_a005_linear',
         lambda X: apply_area_norm(X),
         0.05, 'linear',
         "Area normalization + Ridge a=0.05 + linear. Alternative scatter correction."),
        
        # SG smoothing order 3 (cubic)
        ('v295_sgsmooth_w7_o3_snv_a005_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=7, order=3)),
         0.05, 'linear',
         "SG smoothing (w7, order3=cubic) + SNV + Ridge a=0.05 + linear."),
        
        # SG smoothing order 1 (linear)
        ('v296_sgsmooth_w7_o1_snv_a005_linear',
         lambda X: apply_snv(apply_sg_smooth(X, window=7, order=1)),
         0.05, 'linear',
         "SG smoothing (w7, order1=linear) + SNV + Ridge a=0.05 + linear."),
    ]
    
    for vid, preprocess_fn, alpha, calibration, desc in experiments:
        print(f"\n{'=' * 70}")
        print(f"  {vid}: {desc}")
        print(f"{'=' * 70}")
        
        try:
            t0 = time.time()
            test_pred, cv_rmse, oof_preds = run_pipeline(
                X_train, X_test, y_train, groups_train, groups_test,
                preprocess_fn, alpha=alpha, calibration=calibration, n_seeds=N_SEEDS
            )
            elapsed = time.time() - t0
            
            # Pack submission
            all_preds = {}
            for i, name in enumerate(names_test):
                all_preds[name] = float(test_pred[i])
            
            pack_submission(vid, all_preds, desc, cv_rmse)
            
            # Correlation with V96
            if v96_arr is not None:
                corr = np.corrcoef(v96_arr, test_pred)[0, 1]
                mae = np.mean(np.abs(test_pred - v96_arr))
                print(f"  CV-RMSE: {cv_rmse:.2f}  corr(V96): {corr:.6f}  MAE: {mae:.2f}  Time: {elapsed:.1f}s")
                results[vid] = {'cv': cv_rmse, 'corr_v96': corr, 'mae_v96': mae}
            else:
                print(f"  CV-RMSE: {cv_rmse:.2f}  Time: {elapsed:.1f}s")
                results[vid] = {'cv': cv_rmse}
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            results[vid] = {'error': str(e)}
    
    # Summary
    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  {'Variant':45s}  {'CV':>7s}  {'corr(V96)':>10s}  {'MAE':>7s}")
    print(f"  {'-' * 75}")
    for vid in sorted(results.keys()):
        r = results[vid]
        if 'cv' in r:
            cv = r['cv']
            corr = r.get('corr_v96', 0)
            mae = r.get('mae_v96', 0)
            marker = ' ***' if cv < 172 else (' **' if cv < 175 else '')
            print(f"  {vid:45s}  {cv:7.2f}  {corr:10.6f}  {mae:7.2f}{marker}")
        else:
            print(f"  {vid:45s}  ERROR: {r.get('error', 'unknown')}")
    
    # Find best
    valid = {k: v for k, v in results.items() if 'cv' in v}
    if valid:
        best = min(valid.items(), key=lambda x: x[1]['cv'])
        print(f"\n  Best: {best[0]} CV={best[1]['cv']:.2f} corr={best[1].get('corr_v96', 0):.6f}")
        
        # Generate blends for top models
        print(f"\n{'=' * 70}")
        print("  BLEND GENERATION")
        print(f"{'=' * 70}")
        
        # Sort by CV
        sorted_models = sorted(valid.items(), key=lambda x: x[1]['cv'])
        top_models = sorted_models[:5]
        print(f"  Top 5 by CV:")
        for vid, r in top_models:
            print(f"    {vid}: CV={r['cv']:.2f} corr={r.get('corr_v96', 0):.6f}")
        
        # Generate blends of V96 with top SG smooth variants
        V96_ZIP = 'submit_v96_blend_v74_v72_7525.zip'
        V63 = 'submit_v63_isotonic.zip'
        V72 = 'submit_v72_isotonic_a005.zip'
        
        blends_to_gen = []
        for vid, r in top_models[:3]:
            vid_zip = f"submit_{vid}.zip"
            corr = r.get('corr_v96', 0)
            if corr > 0.99:  # Safe to blend
                # V96 + this model at various ratios
                blends_to_gen.append((
                    f"v300_blend_v96_{vid.split('_')[0]}_9010",
                    [(V96_ZIP, 0.9), (vid_zip, 0.1)],
                    f"V96(90%) + {vid}(10%). CV={r['cv']:.2f}"
                ))
                blends_to_gen.append((
                    f"v301_blend_v96_{vid.split('_')[0]}_8020",
                    [(V96_ZIP, 0.8), (vid_zip, 0.2)],
                    f"V96(80%) + {vid}(20%). CV={r['cv']:.2f}"
                ))
                # V74 structure: this model + V63, then + V72
                blends_to_gen.append((
                    f"v302_blend_{vid.split('_')[0]}_v63_5050",
                    [(vid_zip, 0.5), (V63, 0.5)],
                    f"{vid}(50%) + V63(50%). V74 structure with SG smooth."
                ))
        
        for vid_name, components, desc in blends_to_gen:
            print(f"\n  {vid_name}: {desc}")
            pack_blend(vid_name, components, desc)
    
    print("\n  Done.")
