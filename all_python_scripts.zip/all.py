"""
LIBS 煤炭弹筒发热量预测 — 单文件版 (V17-Ridge01)

V17d双重CV验证发现:
  Ridge固定alpha=0.1 在 GroupKFold CV (降8.83) 和时间外推CV (降24.01) 上同时改善。
  根因: RidgeCV在训练fold内自动选alpha(常选50/500), 在分布偏移下过度收缩;
        固定小alpha(0.1)接近OLS, 对分布偏移更鲁棒。
  这是V11b以来首次在双重CV上同时改善的方案。

V16实验结论(已排除):
  - ElasticNet(0.15,0.95) 时间外推CV=273.63(降32.88) 但线上=288.26(升9.17)
  - L1重(l1=0.95≈Lasso)的硬稀疏化在分布偏移下极不稳定

V14实验结论(已排除):
  - 扩展化学计量比(11维) CV=161.51 但线上=280.58 (退化1.49)
  - LightGBM 严重过拟合(CV=240)

运行方式: python all.py

架构:
  1. 加载标签 + 光谱
  2. 按煤种分别训练两阶段 Ridge(alpha=0.1) 回归
  3. 大样本煤种(>11批次): 100种子 GroupKFold 集成
     小样本煤种(≤11批次): LOOCV 确定性
  4. 测试集推理 + 打包 submit.zip
"""

import os
import sys
import re
import glob
import zipfile
import warnings
from datetime import datetime

import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

# ═══════════════════════════════════════════════════════════════════════════════
# 配置 (原 config.py)
# ═══════════════════════════════════════════════════════════════════════════════

_HERE = os.path.dirname(os.path.abspath(__file__))

TRAIN_DIR       = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR       = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR        = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR      = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤',
    '赵固二矿中煤矿',
    '中马矿中煤矿',
    '九里山矿中煤矿',
    '煤场混煤',
]

AUX_COLS = ['全水分', '灰分', '氢', '硫']

# V19: 主元素(C/H/O/N)窗口×5, 金属线保持原始宽度
# 双重CV验证: GK -3.25, TE -39.76 (V19d), 线上=250.64
# V21新增谱线实验失败: 双重CV改善但线上253.89(升3.25), 已回退V19
KEY_LINES = {
    'C':   (247.86, 10.0),   # ×5: 2.0→10.0
    'H':   (656.3,  15.0),   # ×5: 3.0→15.0
    'O':   (777.2,  15.0),   # ×5: 3.0→15.0
    'N':   (742.4,  10.0),   # ×5: 2.0→10.0
    'Ca':  (422.7,  2.0),
    'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),
    'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),
    'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX           = 30
RANDOM_STATE        = 42
ALPHAS              = [1.0, 10.0, 50.0, 100.0, 500.0, 1000.0, 5000.0, 10000.0]
SMALL_BATCH_THRESHOLD = 11

# V16: ElasticNet 参数 (时间外推CV最优)
EN_ALPHA     = 0.15
EN_L1_RATIO  = 0.95
SUBMISSION_VERSION = "v28-timeweight"
SUBMISSION_AUTHOR  = "ATIpiu"

# V17: 固定 Ridge alpha (双重CV验证最优)
RIDGE_ALPHA = 0.1

N_ENSEMBLE_SEEDS = 100
ENSEMBLE_SEEDS   = list(range(N_ENSEMBLE_SEEDS))

# V28: 时间加权样本权重 (val_month=12, circular distance)
# 测试集全部来自12月, 给训练样本按循环月份距离12月赋指数衰减权重
# 只对大样本煤种(九里山tau=20, 煤场混煤tau=30)启用, 小样本煤种保持V19
TIME_WEIGHT_ENABLED = True
TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}


# ═══════════════════════════════════════════════════════════════════════════════
# 数据加载 (原 src/data.py)
# ═══════════════════════════════════════════════════════════════════════════════

def read_spectrum_csv(filepath):
    """解析单条光谱 CSV，前5行为元数据，跳过。"""
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    """从批次名中提取月份 (如 '赵固一矿豫焦末煤11月15日' -> 11)。"""
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    """计算指数衰减时间权重 (循环月份距离)。
    
    给离 val_month 更近的样本更高权重。
    """
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)  # 循环距离
    time_diff = diff * 30  # 近似天数
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()  # 归一化: 平均权重=1
    return weights


def load_labels():
    """读取训练集标签 Excel，返回 label_map 和 aux_map。"""
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key]   = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    """读取某煤种下所有批次的光谱数据，返回 dict。"""
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None

    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0

    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue

        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q   = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None

        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True

        if batch_has_data:
            batch_idx += 1

    if not raw_spectra:
        return None

    # 提取每个样本的月份 (V28: 时间加权)
    months = np.array([extract_month(n) for n in names], dtype=int)

    return {
        'spectra':   raw_spectra,
        'names':     names,
        'targets':   np.array(targets)     if targets     else None,
        'aux':       np.array(aux_targets) if aux_targets else None,
        'groups':    np.array(groups),
        'n_batches': batch_idx,
        'months':    months,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 特征工程 (原 src/features.py)
# ═══════════════════════════════════════════════════════════════════════════════

def line_integral(wl, inten, center_nm, halfwin_nm):
    """对窗口内强度求和。"""
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    """从一条光谱提取三层特征 (V11b配置: 17维统计 + 4维比值)。"""
    total      = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv      = np.diff(inten_norm)
    deriv2     = np.diff(inten_norm, 2)

    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)),
        float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(),  float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)

    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32
    )
    lrel = labs / total

    # labs顺序: C(0), H(1), O(2), N(3), Ca(4), Ca2(5), Mg(6), Al(7), Si(8), Fe(9), Na(10),
    #            Ca3(11), Ti(12), Sr(13)
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum  = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum,
        labs[1] / ash_sum,
        labs[0] / ash_sum,
        labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    """批量计算特征，原地填充 data 字典。"""
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []

    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features(wl, inten)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)

    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)

    data['stats'] = np.array(stats_list)
    data['labs']  = np.array(labs_list)
    data['lrel']  = np.array(lrel_list)
    data['rats']  = np.array(rats_list)

    return inorm_mat


def build_feature_matrix(data, n_batches,
                         scaler_spec=None, pca=None, scaler_hand=None, fit=True):
    """构建 [PCA(归一化光谱)] + [手工特征] 矩阵。"""
    inorm_mat = compute_features(data)

    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ═══════════════════════════════════════════════════════════════════════════════
# 模型 (原 src/model.py)
# ═══════════════════════════════════════════════════════════════════════════════

def get_cv_splits(groups, n_batches, seed=None):
    """批次数 ≤ 阈值用 LOOCV，否则用 GroupKFold(5折)。"""
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def aggregate_to_batch(preds, names):
    """同批次多条光谱 → 取中位数。"""
    grouped = {}
    for p, n in zip(preds, names):
        grouped.setdefault(n, []).append(p)
    return {k: float(np.median(v)) for k, v in grouped.items()}


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    """网格搜索收缩权重 w，最小化 OOF-RMSE。"""
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def _make_model():
    """创建 Ridge 模型实例 (V17: 固定alpha=0.1)。"""
    return Ridge(alpha=RIDGE_ALPHA)


def _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                   sample_weights=None):
    """两阶段: Stage1 OOF + Stage2，对所有煤种搜收缩w。
    
    sample_weights: 可选的样本权重数组 (V28: 时间加权)。
    若提供, 在 Ridge.fit 中传入 sample_weight。
    """
    # Stage1: 光谱 → 辅助指标 (OOF)
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)

    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = _make_model()
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx],
                      sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    # Stage2: [光谱特征 + 预测辅助指标] → 发热量
    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []

    for tr_idx, val_idx in splits:
        m2 = _make_model()
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx],
                   sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred   = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]

        fold_se = []
        for bg in np.unique(val_groups):
            mask   = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))

    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)
    cv_rmse = cv_rmse_shrunk

    final_model = _make_model()
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models':  aux_models,
        'scaler_s2':   scaler_s2,
        'final_model': final_model,
        'cv_rmse':     cv_rmse,
        'cv_rmse_raw': cv_rmse_raw,
        'shrink_w':    best_w,
    }


def train_coal_model(coal_type, train_data):
    """训练某煤种的两阶段模型。大样本100种子集成，小样本LOOCV。"""
    y         = train_data['targets']
    aux       = train_data['aux']
    groups    = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())

    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    # V28: 时间加权样本权重 (仅大样本煤种)
    sample_weights = None
    if TIME_WEIGHT_ENABLED and not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        months = train_data.get('months')
        if months is not None and len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                             sample_weights=sample_weights)

        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条光谱  "
              f"Q={y.min():.0f}~{y.max():.0f}  (LOOCV)")
        print(f"    CV-RMSE: raw={run['cv_rmse_raw']:.2f}  "
              f"shrunk={run['cv_rmse']:.2f}  w={run['shrink_w']:.2f}")
        print(f"    Ridge alpha: {run['final_model'].alpha:.2f}")

        return {
            'spec_scalers': (scaler_spec, pca, scaler_hand),
            'ensemble':     [run],
            'coal_mean':    coal_mean,
            'cv_rmse':      run['cv_rmse'],
            'is_small':     True,
        }
    else:
        runs = []
        cv_rmses = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                                 sample_weights=sample_weights)
            runs.append(run)
            cv_rmses.append(run['cv_rmse'])

        cv_mean = float(np.mean(cv_rmses))
        cv_std  = float(np.std(cv_rmses))

        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w

        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条光谱  "
              f"Q={y.min():.0f}~{y.max():.0f}  ({N_ENSEMBLE_SEEDS}种子集成)")
        print(f"    CV-RMSE: {cv_mean:.2f} ± {cv_std:.2f}  "
              f"(min={min(cv_rmses):.2f}, max={max(cv_rmses):.2f})  w={avg_w:.2f}")
        print(f"    Ridge alpha: {runs[0]['final_model'].alpha:.2f}")

        return {
            'spec_scalers': (scaler_spec, pca, scaler_hand),
            'ensemble':     runs,
            'coal_mean':    coal_mean,
            'cv_rmse':      cv_mean,
            'is_small':     False,
        }


def predict_coal(coal_type, test_data, model_dict):
    """对某煤种的测试批次做推理，返回 {批次名: 预测发热量}。"""
    scaler_spec, pca, scaler_hand = model_dict['spec_scalers']
    coal_mean = model_dict['coal_mean']
    ensemble  = model_dict['ensemble']

    X_spec = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca, scaler_hand=scaler_hand,
        fit=False)

    all_batch_preds = []

    for run in ensemble:
        aux_models  = run['aux_models']
        scaler_s2   = run['scaler_s2']
        final_model = run['final_model']
        shrink_w    = run['shrink_w']

        pred_aux = np.zeros((len(test_data['spectra']), len(AUX_COLS)), dtype=np.float32)
        for col_idx, col_name in enumerate(AUX_COLS):
            m = aux_models.get(col_name)
            if m is not None:
                pred_aux[:, col_idx] = m.predict(X_spec)

        X_s2       = scaler_s2.transform(np.nan_to_num(np.hstack([X_spec, pred_aux])))
        preds      = final_model.predict(X_s2)
        batch_pred = aggregate_to_batch(preds, test_data['names'])

        if shrink_w < 1.0:
            batch_pred = {
                k: shrink_w * v + (1 - shrink_w) * coal_mean
                for k, v in batch_pred.items()
            }

        all_batch_preds.append(batch_pred)

    batch_names = list(all_batch_preds[0].keys())
    final_pred  = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        final_pred[name] = float(np.mean(vals))

    return final_pred


# ═══════════════════════════════════════════════════════════════════════════════
# 提交打包 (原 src/submit.py)
# ═══════════════════════════════════════════════════════════════════════════════

def build_readme(cv_results, global_cv_rmse):
    """生成方案介绍 Markdown。"""
    table_rows = "\n".join(
        f"| {ct} | {rmse:.2f} |"
        for ct, rmse in cv_results.items()
    )
    return f"""# LIBS 煤炭发热量预测 — 方案介绍

**版本**: {SUBMISSION_VERSION}
**作者**: {SUBMISSION_AUTHOR}
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

---

## 方法概述

基于 LIBS（激光诱导击穿光谱）光谱数据，预测煤炭发热量（kcal/kg）。

### 两阶段回归框架

```
LIBS 光谱 (7305维)
      │
      ▼
  Stage 1: Ridge(alpha=0.1) 回归 × 4
      │  预测辅助指标: 全水分 / 灰分 / 氢 / 硫
      │  (OOF 预测，防止数据泄露)
      ▼
  Stage 2: Ridge(alpha=0.1) 回归
      │  输入: [光谱特征] + [预测辅助指标]
      ▼
  发热量 Q (kcal/kg)
```

### 特征工程

| 特征类型 | 维度 | 说明 |
|---|---|---|
| PCA 降维光谱 | 最多30维 | 归一化强度 → StandardScaler → PCA |
| 统计特征 | 17维 | 均值/方差/偏度/峰度/熵/分位数/导数统计 |
| 谱线积分 (绝对) | 11维 | C/H/O/N/Ca/Ca2/Mg/Al/Si/Fe/Na |
| 谱线积分 (相对) | 11维 | 谱线积分 / 总强度 |
| 物理比值 | 4维 | 可燃/灰分、H/灰分、C/灰分、H/C |

### 集成策略

- 大样本煤种(>11批次): {N_ENSEMBLE_SEEDS}种子 GroupKFold 集成
- 小样本煤种(≤11批次): LOOCV 确定性
- 均值收缩: 预测值向煤种均值收缩，OOF 搜索最优权重

---

## 本次提交 CV-RMSE

| 煤种 | CV-RMSE |
|---|---|
{table_rows}
| **全局** | **{global_cv_rmse:.2f}** |
"""


def pack_submission(all_preds, cv_results, global_cv_rmse):
    """生成 submit.csv 和 submit.zip。"""
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)

    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  警告: {len(missing)} 个批次缺少预测，用均值填充: {missing}")
        fallback = sum(all_preds.values()) / len(all_preds)
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(fallback)

    csv_path = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"\n  [OK] {csv_path}")
    print(template.to_string(index=False))

    readme_content = build_readme(cv_results, global_cv_rmse)
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)

    zip_path = os.path.join(OUTPUT_DIR, "submit.zip")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(csv_path,    arcname="submit/submit.csv")
        zf.write(readme_path, arcname="submit/README.md")

    print(f"  [OK] {zip_path}")
    print(f"     内含: submit/submit.csv  +  submit/README.md")
    return zip_path


# ═══════════════════════════════════════════════════════════════════════════════
# 主入口 (原 train.py)
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("Step 1: 加载标签")
    label_map, aux_map = load_labels()
    print(f"  标签总数: {len(label_map)}")

    print("\n" + "=" * 60)
    print("Step 2: 两阶段训练（分煤种）")

    models     = {}
    cv_results = {}

    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None or train_data['n_batches'] == 0:
            print(f"\n  [{coal_type}] 未找到训练数据，跳过")
            continue

        model_dict = train_coal_model(coal_type, train_data)
        models[coal_type]     = model_dict
        cv_results[coal_type] = model_dict['cv_rmse']

    global_cv_rmse = float(np.mean(list(cv_results.values())))
    print(f"\n{'=' * 60}")
    print(f"全局 CV-RMSE: {global_cv_rmse:.2f}")

    print("\n" + "=" * 60)
    print("Step 3: 测试集推理")

    all_preds = {}
    for coal_type in COAL_TYPES:
        if coal_type not in models:
            continue
        test_data = load_coal_spectra(TEST_DIR, coal_type, label_map=None, aux_map=None)
        if test_data is None or len(test_data['spectra']) == 0:
            print(f"  [{coal_type}] 无测试数据")
            continue
        bp = predict_coal(coal_type, test_data, models[coal_type])
        all_preds.update(bp)

    print("\n  预测结果:")
    for name, pred in sorted(all_preds.items()):
        print(f"    {name}: {pred:.2f}")

    print("\n" + "=" * 60)
    print("Step 4: 生成提交文件")
    pack_submission(all_preds, cv_results, global_cv_rmse)
    print("\n完成！提交文件在 output/submit.zip")


if __name__ == "__main__":
    main()
