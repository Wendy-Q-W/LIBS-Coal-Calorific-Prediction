"""
exp_v45_adversarial.py
Phase 1: Adversarial Validation System

TE-CV has become an anti-correlated indicator (V39 TE=267->online 230,
V42 TE=266->231.74, V44 TE=260->236.50). We need a NEW validation strategy.

Core idea:
1. Train a classifier to distinguish train(0) vs test(1) spectra
2. Get test-likeness probability for each training sample
3. Use most test-like training batches as validation set (AV-CV)
4. Use test-likeness as sample weights (AV-weighted)

This directly measures the ACTUAL train->test distribution shift,
rather than TE-CV's proxy (temporal split).

Uses same V39 feature pipeline: SNV for PCA + total norm for hand features.
"""
import os, sys, re, glob, warnings, json
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupKFold, StratifiedGroupKFold
from sklearn.metrics import roc_auc_score
from scipy.stats import skew, kurtosis, entropy as scipy_entropy

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30

# ── Data loading (same as all_snv.py) ───────────────────────────────────────

def read_spectrum_csv(filepath):
    """Parse spectrum CSV — same robust method as all_snv.py."""
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def load_labels():
    label_map, aux_map = {}, {}
    for coal in COAL_TYPES:
        fp = os.path.join(LABEL_DIR, f"{coal}.xlsx")
        if not os.path.exists(fp): continue
        df = pd.read_excel(fp)
        for _, row in df.iterrows():
            name = str(row['名称']).strip()
            q = float(row['发热量(Q)'])
            label_map[(coal, name)] = q
            aux = {
                '全水分': float(row.get('全水分', np.nan)),
                '灰分':   float(row.get('灰分', np.nan)),
                '氢':     float(row.get('氢', np.nan)),
                '硫':     float(row.get('硫', np.nan)),
            }
            aux_map[(coal, name)] = aux
    return label_map, aux_map

def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None, is_train=True):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir): return None
    spectra, names, targets, auxs, groups, months = [], [], [], [], [], []
    batch_idx = 0
    for batch_dir in sorted(os.listdir(coal_dir)):
        full = os.path.join(coal_dir, batch_dir)
        if not os.path.isdir(full): continue
        date_part = batch_dir.replace(coal_type, '').strip()
        month = extract_month(date_part)
        csvs = sorted(glob.glob(os.path.join(full, "*.csv")))
        if not csvs: continue
        for csv_path in csvs:
            wl, inten = read_spectrum_csv(csv_path)
            if wl is None: continue
            spectra.append((wl, inten))
            names.append(date_part)
            groups.append(batch_idx)
            months.append(month)
            if is_train and label_map:
                key = (coal_type, date_part)
                targets.append(label_map.get(key, np.nan))
                if aux_map and key in aux_map:
                    auxs.append(aux_map[key])
                else:
                    auxs.append({'全水分': np.nan, '灰分': np.nan, '氢': np.nan, '硫': np.nan})
        batch_idx += 1
    return {
        'spectra': spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': auxs, 'groups': np.array(groups),
        'n_batches': batch_idx, 'months': np.array(months),
    }

# ── Feature extraction (V39 pipeline) ──────────────────────────────────────

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0

def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total

    # SNV (for PCA input)
    snv = (inten - inten.mean()) / (inten.std() + 1e-8)

    # Stats (17)
    d1 = np.diff(inten_norm)
    d2 = np.diff(d1)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        d1.std(), np.abs(d1).mean(),
        d2.std(), np.abs(d2).mean(),
    ], dtype=np.float32)

    # Line integrals (11)
    labs = np.array([line_integral(wl, inten, c, w) for c, w in KEY_LINES.values()],
                    dtype=np.float32)

    # Relative line integrals (11)
    lrel = labs / (total + 1e-8)

    # Physical ratios (4)
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum  = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum,
        labs[1] / ash_sum,
        labs[0] / ash_sum,
        labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    return snv, stats, labs, lrel, rats

def compute_features(data):
    spectra = data['spectra']
    n = len(spectra)
    min_len = min(len(s[1]) for s in spectra)

    snv_list, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in spectra:
        inten_c = inten[:min_len].copy()
        wl_c = wl[:min_len].copy()
        snv, stats, labs, lrel, rats = spectrum_features(wl_c, inten_c)
        # Clean any NaN/Inf
        snv = np.nan_to_num(snv, nan=0.0, posinf=0.0, neginf=0.0)
        stats = np.nan_to_num(stats, nan=0.0, posinf=0.0, neginf=0.0)
        labs = np.nan_to_num(labs, nan=0.0, posinf=0.0, neginf=0.0)
        lrel = np.nan_to_num(lrel, nan=0.0, posinf=0.0, neginf=0.0)
        rats = np.nan_to_num(rats, nan=0.0, posinf=0.0, neginf=0.0)
        snv_list.append(snv)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)

    snv_mat = np.array(snv_list, dtype=np.float32)
    hand_feats = np.hstack([np.array(stats_list), np.array(labs_list),
                            np.array(lrel_list), np.array(rats_list)])
    hand_feats = np.nan_to_num(hand_feats, nan=0.0, posinf=0.0, neginf=0.0)

    return snv_mat, hand_feats

def build_feature_matrix(snv_mat, hand_feats, scaler_spec=None, pca=None, scaler_final=None, fit=True):
    if fit:
        scaler_spec = StandardScaler()
        snv_scaled = scaler_spec.fit_transform(snv_mat)
        n_comp = min(N_PCA_MAX, snv_scaled.shape[0] - 1, snv_scaled.shape[1])
        pca = PCA(n_components=n_comp, random_state=42)
        snv_pca = pca.fit_transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        scaler_final = StandardScaler()
        X = scaler_final.fit_transform(X)
        return X, scaler_spec, pca, scaler_final
    else:
        snv_scaled = scaler_spec.transform(snv_mat)
        snv_pca = pca.transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        X = scaler_final.transform(X)
        return X

# ── Adversarial Validation ─────────────────────────────────────────────────

def adversarial_validation():
    print("=" * 70)
    print("Phase 1: Adversarial Validation System")
    print("=" * 70)

    label_map, aux_map = load_labels()

    all_results = {}

    for coal in COAL_TYPES:
        print(f"\n{'─' * 50}")
        print(f"  [{coal}]")
        print(f"{'─' * 50}")

        train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map, is_train=True)
        test_data  = load_coal_spectra(TEST_DIR, coal, is_train=False)
        if train_data is None or test_data is None:
            print(f"  SKIP: data not found")
            continue

        # Compute features
        train_snv, train_hand = compute_features(train_data)
        test_snv, test_hand = compute_features(test_data)

        # Fit PCA on train only, transform both
        X_train, sc_spec, pca, sc_final = build_feature_matrix(
            train_snv, train_hand, fit=True)
        X_test = build_feature_matrix(
            test_snv, test_hand, sc_spec, pca, sc_final, fit=False)

        # Labels: train=0, test=1
        y_adv = np.concatenate([np.zeros(len(X_train)), np.ones(len(X_test))])
        X_adv = np.vstack([X_train, X_test])

        # Groups: train batches + test batches
        n_train_batches = train_data['n_batches']
        n_test_batches = test_data['n_batches']
        adv_groups = np.concatenate([
            train_data['groups'],
            test_data['groups'] + n_train_batches
        ])

        # Train classifier with GroupKFold CV
        n_splits = min(5, n_train_batches + n_test_batches)
        if n_splits < 2:
            print(f"  Too few batches for CV")
            continue

        gkf = GroupKFold(n_splits=n_splits)
        clf = LogisticRegression(C=1.0, max_iter=1000, random_state=42)

        oof_probs = np.zeros(len(y_adv))
        auc_scores = []

        for tr_idx, val_idx in gkf.split(X_adv, groups=adv_groups):
            # Skip folds where validation set has only one class
            if len(np.unique(y_adv[val_idx])) < 2:
                continue
            clf.fit(X_adv[tr_idx], y_adv[tr_idx])
            probs = clf.predict_proba(X_adv[val_idx])[:, 1]
            oof_probs[val_idx] = probs
            auc = roc_auc_score(y_adv[val_idx], probs)
            auc_scores.append(auc)

        overall_auc = roc_auc_score(y_adv, oof_probs)
        print(f"  Train spectra: {len(X_train)} ({n_train_batches} batches)")
        print(f"  Test spectra:  {len(X_test)} ({n_test_batches} batches)")
        print(f"  AUC: {overall_auc:.4f} (folds: {np.mean(auc_scores):.4f} +/- {np.std(auc_scores):.4f})")

        # Get test-likeness for train samples only
        train_testlike = oof_probs[:len(X_train)]

        # Per-batch aggregation (median test-likeness per batch)
        batch_groups = train_data['groups']
        batch_names = np.array(train_data['names'])
        batch_months = train_data['months']

        batch_testlike = {}
        for b in range(n_train_batches):
            mask = batch_groups == b
            if mask.sum() == 0: continue
            tl = np.median(train_testlike[mask])
            name = batch_names[mask][0]
            month = batch_months[mask][0]
            batch_testlike[b] = {
                'name': name, 'month': int(month),
                'testlike': float(tl),
                'n_spectra': int(mask.sum()),
                'target': float(train_data['targets'][mask][0]) if train_data['targets'] is not None else None,
            }

        # Sort by test-likeness (most test-like first)
        sorted_batches = sorted(batch_testlike.values(), key=lambda x: x['testlike'], reverse=True)

        print(f"\n  Batch test-likeness ranking (top 5 most test-like):")
        for i, b in enumerate(sorted_batches[:5]):
            print(f"    {i+1}. {b['name']:20s}  month={b['month']}  "
                  f"tl={b['testlike']:.4f}  Q={b['target']:.0f}" if b['target'] else
                  f"    {i+1}. {b['name']:20s}  month={b['month']}  tl={b['testlike']:.4f}")

        print(f"\n  Batch test-likeness ranking (bottom 5 least test-like):")
        for i, b in enumerate(sorted_batches[-5:]):
            print(f"    {len(sorted_batches)-4+i}. {b['name']:20s}  month={b['month']}  "
                  f"tl={b['testlike']:.4f}  Q={b['target']:.0f}" if b['target'] else
                  f"    {len(sorted_batches)-4+i}. {b['name']:20s}  month={b['month']}  tl={b['testlike']:.4f}")

        # Per-month analysis
        month_tls = {}
        for b in batch_testlike.values():
            m = b['month']
            if m not in month_tls:
                month_tls[m] = []
            month_tls[m].append(b['testlike'])

        print(f"\n  Per-month test-likeness:")
        for m in sorted(month_tls.keys()):
            tls = month_tls[m]
            print(f"    Month {m:2d}: mean_tl={np.mean(tls):.4f}  std={np.std(tls):.4f}  n_batches={len(tls)}")

        # ── AV-CV: Use most test-like batches as validation ──
        # Strategy: Leave top-K test-like batches out as validation
        n_val = max(1, n_train_batches // 5)  # ~20% as validation
        val_batch_ids = set(b_idx for b_idx, b in
                           sorted(enumerate(batch_testlike.values()),
                                  key=lambda x: x[1]['testlike'], reverse=True)[:n_val])

        # Compute AV-CV RMSE
        targets = train_data['targets']
        if targets is not None:
            # Use V39 model (Ridge alpha=0.1, two-stage) on AV-CV split
            train_mask = np.array([g not in val_batch_ids for g in batch_groups])
            val_mask = ~train_mask

            if train_mask.sum() > 0 and val_mask.sum() > 0:
                # Train on non-val batches, predict val batches
                X_tr = X_train[train_mask]
                y_tr = targets[train_mask]
                X_val = X_train[val_mask]
                y_val = targets[val_mask]

                # Simple Ridge (no two-stage, no time weighting — just raw AV-CV)
                ridge = Ridge(alpha=0.1)
                ridge.fit(X_tr, y_tr)
                val_preds = ridge.predict(X_val)

                # Batch-level aggregation
                val_batch_ids_arr = batch_groups[val_mask]
                val_names_arr = np.array(batch_names)[val_mask]
                unique_val_batches = np.unique(val_batch_ids_arr)

                batch_preds, batch_trues = [], []
                for vb in unique_val_batches:
                    vmask = val_batch_ids_arr == vb
                    batch_preds.append(np.median(val_preds[vmask]))
                    batch_trues.append(y_val[vmask][0])

                batch_preds = np.array(batch_preds)
                batch_trues = np.array(batch_trues)
                av_rmse = np.sqrt(np.mean((batch_preds - batch_trues) ** 2))

                # Also compute GK-CV for comparison
                gk = GroupKFold(n_splits=min(5, n_train_batches))
                gk_preds = np.zeros(len(targets))
                for tr_idx, val_idx in gk.split(X_train, groups=batch_groups):
                    r = Ridge(alpha=0.1)
                    r.fit(X_train[tr_idx], targets[tr_idx])
                    gk_preds[val_idx] = r.predict(X_train[val_idx])

                # GK batch-level
                gk_batch_preds, gk_batch_trues = [], []
                for b in range(n_train_batches):
                    bmask = batch_groups == b
                    gk_batch_preds.append(np.median(gk_preds[bmask]))
                    gk_batch_trues.append(targets[bmask][0])
                gk_rmse = np.sqrt(np.mean((np.array(gk_batch_preds) - np.array(gk_batch_trues)) ** 2))

                # Also TE-CV if possible
                te_rmse = None
                te_months_set = set()
                for b in batch_testlike.values():
                    if b['month'] in [1, 2, 3]:
                        te_months_set.add(b['month'])
                if te_months_set:
                    te_val_mask = np.array([batch_testlike[g]['month'] in [1,2,3]
                                           if g in batch_testlike else False
                                           for g in batch_groups])
                    te_train_mask = ~te_val_mask
                    if te_train_mask.sum() > 0 and te_val_mask.sum() > 0:
                        r_te = Ridge(alpha=0.1)
                        r_te.fit(X_train[te_train_mask], targets[te_train_mask])
                        te_preds = r_te.predict(X_train[te_val_mask])

                        te_batch_ids = batch_groups[te_val_mask]
                        te_batch_preds, te_batch_trues = [], []
                        for tb in np.unique(te_batch_ids):
                            tmask = te_batch_ids == tb
                            te_batch_preds.append(np.median(te_preds[tmask]))
                            te_batch_trues.append(targets[te_val_mask][tmask][0])
                        te_rmse = np.sqrt(np.mean((np.array(te_batch_preds) - np.array(te_batch_trues)) ** 2))

                print(f"\n  CV Comparison (simple Ridge, no two-stage):")
                print(f"    GK-CV RMSE:  {gk_rmse:.2f}  (in-distribution)")
                if te_rmse is not None:
                    print(f"    TE-CV RMSE:  {te_rmse:.2f}  (temporal, now anti-correlated)")
                print(f"    AV-CV RMSE:  {av_rmse:.2f}  (test-like validation)")

        # Store sample weights (test-likeness as weight)
        # Higher weight = more test-like = should be emphasized in training
        sample_weights = train_testlike / (1 - train_testlike + 1e-8)
        sample_weights = np.clip(sample_weights, 0.1, 10.0)
        sample_weights = sample_weights / sample_weights.mean()

        all_results[coal] = {
            'auc': float(overall_auc),
            'batch_testlike': {str(k): v for k, v in batch_testlike.items()},
            'sample_weights': sample_weights.tolist(),
            'n_train': len(X_train),
            'n_test': len(X_test),
        }

    # Save results
    out_path = os.path.join(_HERE, "adversarial_validation_results.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        # Can't serialize numpy arrays in sample_weights, convert
        serializable = {}
        for coal, res in all_results.items():
            serializable[coal] = {
                'auc': res['auc'],
                'n_train': res['n_train'],
                'n_test': res['n_test'],
                'batch_testlike': res['batch_testlike'],
                'sample_weights': res['sample_weights'],
            }
        json.dump(serializable, f, ensure_ascii=False, indent=2)

    print(f"\n{'=' * 70}")
    print(f"Results saved to: {out_path}")
    print(f"{'=' * 70}")

    # Summary table
    print(f"\nSummary:")
    print(f"{'Coal':25s} {'AUC':>6s} {'N_train':>8s} {'N_test':>7s}")
    print(f"{'─' * 50}")
    for coal, res in all_results.items():
        print(f"{coal:25s} {res['auc']:6.4f} {res['n_train']:8d} {res['n_test']:7d}")

    return all_results

if __name__ == '__main__':
    adversarial_validation()
