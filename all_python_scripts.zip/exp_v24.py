"""V24: Drift Injection -- 方向三: 训练时模拟分布偏移

基线: V19 Ridge(0.1)+PCA(30)+主元素窗口x5 -> GK=273.08, TE=240.20, 线上=250.64

思路: 既然问题是训练集和测试集分布不同, 那就让模型在训练时就"见过"偏移后的数据。
在原始光谱层面注入4类漂移:
  1. 波长平移 (np.roll, +/-1-2采样点) -- 模拟仪器校准漂移
  2. 强度缩放 (+/-5-10%) -- 模拟激光能量波动
  3. 基线倾斜 (+/-slope) -- 模拟背景辐射变化
  4. 高斯噪声 (1-2% std) -- 模拟等离子体波动

每类漂移的每个参数值生成一份副本, 叠加而非组合 (避免维度爆炸)。
增强后的训练集 -> 特征工程 -> PCA -> Ridge, 模型和验证流程不变。

验证标准: TE-CV改善且GK-CV不恶化 -> 考虑提交
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
    extract_month, compute_features_custom, oof_ridge,
)


def augment_data(data, shifts=None, scales=None, slopes=None, noises=None,
                 rng_seed=42):
    """Augment training spectra with drift variants (additive, not multiplicative).

    Each shift/scale/slope/noise value creates one copy of all spectra.
    Total copies = len(shifts) + len(scales) + len(slopes) + len(noises)
    Total data = (1 + total_copies) x original
    """
    shifts = shifts or []
    scales = scales or []
    slopes = slopes or []
    noises = noises or []

    orig_spectra = data['spectra']
    orig_targets = data['targets']
    orig_aux     = data['aux']
    orig_groups  = data['groups']
    orig_names   = data['names']
    n = len(orig_spectra)

    new_spectra = list(orig_spectra)
    new_targets = list(orig_targets) if orig_targets is not None else None
    new_aux     = [orig_aux[i] for i in range(n)] if orig_aux is not None else None
    new_groups  = list(orig_groups)
    new_names   = list(orig_names)

    rng = np.random.RandomState(rng_seed)

    def _append(i, inten_new):
        wl_orig = orig_spectra[i][0]
        new_spectra.append((wl_orig, inten_new))
        if new_targets is not None: new_targets.append(orig_targets[i])
        if new_aux     is not None: new_aux.append(orig_aux[i])
        new_groups.append(orig_groups[i])
        new_names.append(orig_names[i])

    # 1. Wavelength shift
    for s in shifts:
        for i in range(n):
            _append(i, np.roll(orig_spectra[i][1], s))

    # 2. Intensity scaling
    for sc in scales:
        for i in range(n):
            _append(i, (orig_spectra[i][1] * sc).astype(np.float32))

    # 3. Baseline tilt
    for sl in slopes:
        for i in range(n):
            inten = orig_spectra[i][1]
            baseline = sl * np.arange(len(inten), dtype=np.float32)
            _append(i, inten + baseline)

    # 4. Gaussian noise
    for nl in noises:
        for i in range(n):
            inten = orig_spectra[i][1]
            noise = rng.normal(0, nl * inten.std(), inten.shape).astype(np.float32)
            _append(i, inten + noise)

    return {
        'spectra':   new_spectra,
        'names':     np.array(new_names),
        'targets':   np.array(new_targets) if new_targets is not None else None,
        'aux':       np.array(new_aux)     if new_aux     is not None else None,
        'groups':    np.array(new_groups),
        'n_batches': data['n_batches'],
    }


def _build_fm(inorm_mat, hand_feats, n_batches, n_pca_max=30):
    """StandardScaler -> PCA -> hstack hand feats -> StandardScaler"""
    sc = StandardScaler()
    ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    X = np.hstack([sp, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler()
    X = sh.fit_transform(X)
    return X


def gkfold_cv_aug(coal, aug_params):
    """GroupKFold CV with augmented data (all data augmented)."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None

    td_aug = augment_data(td, **aug_params)

    inorm_mat, td2 = compute_features_custom(td_aug, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    X = _build_fm(inorm_mat, hand_feats, td_aug['n_batches'])

    y      = td_aug['targets']
    aux    = td_aug['aux']
    groups = td_aug['groups']
    nb     = td_aug['n_batches']
    coal_mean = float(y.mean())

    if nb <= SMALL_BATCH_THRESHOLD:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits, RIDGE_ALPHA)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(10):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits, RIDGE_ALPHA)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_aug(coal, aug_params):
    """Time extrapolation CV with augmented training data only."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None

    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)

    # Compute features for all original data (for val)
    inorm_all, td_all = compute_features_custom(td, KEY_LINES, 'total')
    hand_all = np.hstack([td_all['stats'], td_all['labs'], td_all['lrel'], td_all['rats']])
    min_len = inorm_all.shape[1]

    # Time split
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    train_idx = np.where(tm)[0]
    val_idx   = np.where(vm)[0]

    # Build train subset -> augment
    td_train = {
        'spectra':   [td['spectra'][i] for i in train_idx],
        'names':     names_arr[train_idx],
        'targets':   y[train_idx],
        'aux':       aux[train_idx],
        'groups':    groups[train_idx],
        'n_batches': nb,
    }
    td_train_aug = augment_data(td_train, **aug_params)

    # Augmented train features
    inorm_tr, td_tr2 = compute_features_custom(td_train_aug, KEY_LINES, 'total')
    inorm_tr = inorm_tr[:, :min_len]  # align length
    hand_tr  = np.hstack([td_tr2['stats'], td_tr2['labs'], td_tr2['lrel'], td_tr2['rats']])

    # Original val features
    inorm_va = inorm_all[vm]
    hand_va  = hand_all[vm]

    # StandardScaler (fit on augmented train)
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_tr)
    spec_va = sc.transform(inorm_va)

    # PCA (fit on augmented train)
    n_pca = min(N_PCA_MAX, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)

    # Combine with hand features
    X_tr = np.hstack([sp_tr, hand_tr])
    X_va = np.hstack([sp_va, hand_va])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)

    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)

    # Augmented y, aux
    y_tr_aug   = td_train_aug['targets']
    aux_tr_aug = td_train_aug['aux']
    coal_mean  = float(y_tr_aug.mean())

    # Stage 1: aux
    pa_tr = np.zeros((len(y_tr_aug), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(val_idx), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux_tr_aug[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya))
            pa_va[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya)
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)

    # Stage 2: Q
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y_tr_aug)
    vp = m2.predict(X2_va)

    # Batch aggregation
    vg2 = groups[val_idx]
    vy  = y[val_idx]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(vy[mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def run_config(name, **aug_params):
    t0 = time.time()
    print(f"\n{'=' * 55}\n  {name}\n{'=' * 55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_aug(coal, aug_params)
        if r is None:
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_aug(coal, aug_params)
        if r is None:
            continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time() - t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # -- Baseline --
    results['baseline'] = run_config("V19 baseline (no aug)")

    # -- Single drift type --
    results['shift1']  = run_config("Shift+/-1",      shifts=[-1, 1])
    results['shift2']  = run_config("Shift+/-2",      shifts=[-2, -1, 1, 2])
    results['scale5']  = run_config("Scale+/-5%",     scales=[0.95, 1.05])
    results['scale10'] = run_config("Scale+/-10%",    scales=[0.9, 0.95, 1.05, 1.1])

    # -- Combined drift --
    results['s1_sc5']  = run_config("Shift+/-1+Scale+/-5%",
                                    shifts=[-1, 1], scales=[0.95, 1.05])
    results['s2_sc10'] = run_config("Shift+/-2+Scale+/-10%",
                                    shifts=[-2, -1, 1, 2], scales=[0.9, 0.95, 1.05, 1.1])

    # -- All drift types --
    results['all_small'] = run_config(
        "All small",
        shifts=[-1, 1], scales=[0.95, 1.05],
        slopes=[-0.001, 0.001], noises=[0.01])
    results['all_med'] = run_config(
        "All medium",
        shifts=[-2, -1, 1, 2], scales=[0.9, 0.95, 1.05, 1.1],
        slopes=[-0.002, -0.001, 0.001, 0.002], noises=[0.01, 0.02])

    # -- Summary --
    print(f"\n{'=' * 60}")
    print("  V24: Drift Injection -- Dual CV Summary")
    print(f"{'=' * 60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None:
            continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
