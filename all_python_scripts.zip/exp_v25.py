"""V25: CORAL Domain Adaptation -- 方向一: 特征分布对齐

基线: V19 Ridge(0.1)+PCA(30)+主元素窗口x5 -> GK=273.08, TE=240.20, 线上=250.64

思路: 将测试集(时间外推中的val)的PCA特征协方差对齐到训练集(train),
      使测试集特征分布更接近训练集, 减小分布偏移的影响。

CORAL: A = Cs^{1/2} @ Ct^{-1/2}, X_target_aligned = (X_target - mean_t) @ A.T + mean_s

在CV中的防泄露使用:
  - 时间外推CV: train=早期批次, val=晚期批次
    PCA在train上fit, transform两个fold
    CORAL: source=train的PCA特征, target=val的PCA特征, 对齐val
    Ridge在对齐后的train上训练, 预测对齐后的val
  - GroupKFold CV: train折和val折同理
    PCA在train折上fit, transform两个折
    CORAL: source=train折PCA特征, target=val折PCA特征, 对齐val折
    Ridge在对齐后的train折上训练, 预测对齐后的val折

关键: CORAL只改变val的特征, 不改变train的特征 -> GK不应恶化, TE可能改善

注意: 之前的实验中PCA是在全量数据上fit的(防泄露不严格), 
      本实验中CORAL需要在split内fit PCA -> 两种模式都测
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from scipy.linalg import sqrtm
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
    extract_month, compute_features_custom,
)


def coral_transform(X_source, X_target, reg=1e-5):
    """CORAL: align X_target covariance to X_source covariance.
    
    Returns aligned X_target with source mean.
    """
    d = X_source.shape[1]
    Cs = np.cov(X_source, rowvar=False) + reg * np.eye(d)
    Ct = np.cov(X_target, rowvar=False) + reg * np.eye(d)
    
    # A = Cs^{1/2} @ Ct^{-1/2}
    Cs_sqrt = sqrtm(Cs)
    # Ct^{-1/2} = inv(sqrtm(Ct))
    Ct_sqrt = sqrtm(Ct)
    Ct_inv_sqrt = np.linalg.inv(Ct_sqrt)
    A = Cs_sqrt @ Ct_inv_sqrt
    
    # Clean up imaginary parts from numerical errors
    A = np.real(A)
    
    mean_s = X_source.mean(axis=0)
    mean_t = X_target.mean(axis=0)
    X_target_aligned = (X_target - mean_t) @ A.T + mean_s
    return X_target_aligned


def coral_transform_safe(X_source, X_target, reg=1e-3):
    """CORAL with higher regularization for numerical stability."""
    return coral_transform(X_source, X_target, reg=reg)


def _extract_pca_features(inorm_mat, hand_feats, train_mask, val_mask,
                           n_pca_max=30, coral_mode='none', coral_reg=1e-5):
    """Build PCA+hand features for train and val, optionally with CORAL alignment.
    
    coral_mode: 'none' = no alignment
                'pca'  = align PCA features only (before hstack with hand feats)
                'full' = align full feature vector (PCA + hand feats)
    """
    # StandardScaler on spectra (fit on train)
    sc_spec = StandardScaler()
    spec_tr = sc_spec.fit_transform(inorm_mat[train_mask])
    spec_va = sc_spec.transform(inorm_mat[val_mask])
    
    # PCA (fit on train)
    n_pca = min(n_pca_max, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    pca_tr = pca.fit_transform(spec_tr)
    pca_va = pca.transform(spec_va)
    
    # Hand features
    hand_tr = hand_feats[train_mask]
    hand_va = hand_feats[val_mask]
    
    if coral_mode == 'pca':
        # Align PCA features only
        pca_va = coral_transform(pca_tr, pca_va, reg=coral_reg)
    elif coral_mode == 'full':
        # Align after hstack
        X_tr = np.hstack([pca_tr, hand_tr])
        X_va = np.hstack([pca_va, hand_va])
        X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
        X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
        X_va = coral_transform(X_tr, X_va, reg=coral_reg)
        # StandardScaler on full features
        sc_all = StandardScaler()
        X_tr = sc_all.fit_transform(X_tr)
        X_va = sc_all.transform(X_va)
        return X_tr, X_va
    
    # Default: hstack + StandardScaler
    X_tr = np.hstack([pca_tr, hand_tr])
    X_va = np.hstack([pca_va, hand_va])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)
    return X_tr, X_va


def oof_ridge_coral(X_tr, y_tr, aux_tr, groups_tr, splits_tr, alpha,
                     X_val_full=None, y_val_full=None, aux_val_full=None, groups_val_full=None):
    """OOF Ridge with CORAL applied per-fold.
    
    If X_val_full is None: standard OOF (no CORAL needed, CORAL was done externally)
    Otherwise: for each split, apply CORAL to the val fold within this split
    """
    op, ot = [], []
    for tr_idx, va_idx in splits_tr:
        # CORAL already applied in X_tr construction if using full-fit PCA
        # Here we do per-fold CORAL on the already-split data
        pa = np.zeros_like(aux_tr, dtype=np.float32)
        for ci in range(aux_tr.shape[1]):
            ya = aux_tr[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = Ridge(alpha=alpha)
            m1.fit(X_tr[tr_idx], ya[tr_idx])
            pa[va_idx, ci] = m1.predict(X_tr[va_idx])
        X2t = np.nan_to_num(np.hstack([X_tr[tr_idx], pa[tr_idx]]))
        X2v = np.nan_to_num(np.hstack([X_tr[va_idx], pa[va_idx]]))
        m2 = Ridge(alpha=alpha)
        m2.fit(X2t, y_tr[tr_idx])
        vp = m2.predict(X2v)
        vg = groups_tr[va_idx]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk])))
            ot.append(float(y_tr[va_idx][mk][0]))
    return op, ot


def gkfold_cv_coral(coal, coral_mode='none', coral_reg=1e-5, n_seeds=10):
    """GroupKFold CV with per-fold CORAL alignment.
    
    For each fold:
      1. Split train/val
      2. Fit PCA on train, transform both
      3. Apply CORAL: align val PCA to train PCA
      4. Ridge on aligned train, predict aligned val
    """
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None

    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    y = td['targets']
    aux = td['aux']
    groups = td['groups']
    nb = td['n_batches']
    coal_mean = float(y.mean())
    
    is_small = nb <= SMALL_BATCH_THRESHOLD
    
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        all_op, all_ot = [], []
        for tr_idx, va_idx in splits:
            X_tr, X_va = _extract_pca_features(
                inorm_mat, hand_feats, tr_idx, va_idx,
                coral_mode=coral_mode, coral_reg=coral_reg)
            
            # Stage 1: aux OOF
            pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
            pa_va = np.zeros((len(va_idx), aux.shape[1]), dtype=np.float32)
            for ci in range(aux.shape[1]):
                ya = aux[:, ci]
                if np.isnan(ya).any():
                    pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                    pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                    continue
                m1 = Ridge(alpha=RIDGE_ALPHA)
                m1.fit(X_tr, ya[tr_idx])
                pa_tr[:, ci] = m1.predict(X_tr)
                pa_va[:, ci] = m1.predict(X_va)
            
            # Stage 2: Q
            X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
            X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
            m2 = Ridge(alpha=RIDGE_ALPHA)
            m2.fit(X2_tr, y[tr_idx])
            vp = m2.predict(X2_va)
            vg = groups[va_idx]
            for bg in np.unique(vg):
                mk = vg == bg
                all_op.append(float(np.median(vp[mk])))
                all_ot.append(float(y[va_idx][mk][0]))
        
        w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            all_op, all_ot = [], []
            for tr_idx, va_idx in splits:
                X_tr, X_va = _extract_pca_features(
                    inorm_mat, hand_feats, tr_idx, va_idx,
                    coral_mode=coral_mode, coral_reg=coral_reg)
                
                pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
                pa_va = np.zeros((len(va_idx), aux.shape[1]), dtype=np.float32)
                for ci in range(aux.shape[1]):
                    ya = aux[:, ci]
                    if np.isnan(ya).any():
                        pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                        pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                        continue
                    m1 = Ridge(alpha=RIDGE_ALPHA)
                    m1.fit(X_tr, ya[tr_idx])
                    pa_tr[:, ci] = m1.predict(X_tr)
                    pa_va[:, ci] = m1.predict(X_va)
                
                X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
                X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
                m2 = Ridge(alpha=RIDGE_ALPHA)
                m2.fit(X2_tr, y[tr_idx])
                vp = m2.predict(X2_va)
                vg = groups[va_idx]
                for bg in np.unique(vg):
                    mk = vg == bg
                    all_op.append(float(np.median(vp[mk])))
                    all_ot.append(float(y[va_idx][mk][0]))
            
            w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_coral(coal, coral_mode='none', coral_reg=1e-5):
    """Time extrapolation CV with CORAL alignment."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)
    
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    # Time split
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    train_mask = tm
    val_mask = vm
    
    X_tr, X_va = _extract_pca_features(
        inorm_mat, hand_feats, train_mask, val_mask,
        coral_mode=coral_mode, coral_reg=coral_reg)
    
    y_tr = y[train_mask]
    y_va = y[val_mask]
    aux_tr = aux[train_mask]
    coal_mean = float(y_tr.mean())
    
    # Stage 1: aux
    pa_tr = np.zeros((len(y_tr), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y_va), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[train_mask]))
            pa_va[:, ci] = float(np.nanmean(ya[train_mask]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya[train_mask])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    
    # Stage 2: Q
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y_tr)
    vp = m2.predict(X2_va)
    
    vg2 = groups[val_mask]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(y_va[mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def run_config(name, coral_mode='none', coral_reg=1e-5):
    t0 = time.time()
    print(f"\n{'=' * 55}\n  {name}\n{'=' * 55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_coral(coal, coral_mode=coral_mode, coral_reg=coral_reg)
        if r is None:
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_coral(coal, coral_mode=coral_mode, coral_reg=coral_reg)
        if r is None:
            continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time() - t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # -- Baseline (no CORAL, per-fold PCA) --
    results['baseline'] = run_config("Baseline (per-fold PCA, no CORAL)")

    # -- CORAL on PCA features only --
    results['coral_pca_r1e-5'] = run_config("CORAL PCA-only reg=1e-5", 
                                             coral_mode='pca', coral_reg=1e-5)
    results['coral_pca_r1e-3'] = run_config("CORAL PCA-only reg=1e-3",
                                             coral_mode='pca', coral_reg=1e-3)
    results['coral_pca_r1e-1'] = run_config("CORAL PCA-only reg=1e-1",
                                             coral_mode='pca', coral_reg=1e-1)

    # -- CORAL on full features (PCA + hand) --
    results['coral_full_r1e-5'] = run_config("CORAL full reg=1e-5",
                                               coral_mode='full', coral_reg=1e-5)
    results['coral_full_r1e-3'] = run_config("CORAL full reg=1e-3",
                                               coral_mode='full', coral_reg=1e-3)
    results['coral_full_r1e-1'] = run_config("CORAL full reg=1e-1",
                                               coral_mode='full', coral_reg=1e-1)

    # -- Summary --
    print(f"\n{'=' * 60}")
    print("  V25: CORAL Domain Adaptation -- Dual CV Summary")
    print(f"{'=' * 60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None:
            continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
