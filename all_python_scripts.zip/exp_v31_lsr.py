"""
exp_v31_lsr.py
方向一: 谱线形态比率 (Line Shape Ratio, LSR) - Peak/Area ratio
方向二: 波长局部标准化 (Local Normalization per window)
基于V28配置,双重CV验证。
"""
import os, re, glob, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 5.0),
    'H':   (656.30, 7.5),
    'O':   (777.20, 7.5),
    'N':   (742.40, 5.0),
    'Ca':  (422.70, 1.0),
    'Ca2': (393.40, 1.0),
    'Mg':  (285.20, 1.0),
    'Al':  (308.20, 1.0),
    'Si':  (288.20, 1.0),
    'Fe':  (438.40, 1.5),
    'Na':  (589.00, 0.75),
}

N_PCA_MAX = 30
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 100
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def compute_lsr(wl, inten, key_lines):
    """Peak/Area ratio for each key line. High=sharp, low=broad(self-absorption)."""
    lsr = np.zeros(len(key_lines), dtype=np.float32)
    for i, (name, (center, halfwin)) in enumerate(key_lines.items()):
        mask = (wl >= center - halfwin) & (wl <= center + halfwin)
        if mask.sum() < 3:
            lsr[i] = 0.0
            continue
        win_inten = inten[mask]
        peak = float(win_inten.max())
        area = float(win_inten.sum())
        if area > 1e-6:
            lsr[i] = peak / area
        else:
            lsr[i] = 0.0
    return lsr


def compute_fwhm(wl, inten, center_nm, halfwin_nm):
    """Approximate FWHM."""
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    if mask.sum() < 5:
        return 0.0
    win_wl = wl[mask]
    win_inten = inten[mask]
    peak = win_inten.max()
    half_max = peak / 2.0
    above = win_inten >= half_max
    if above.sum() < 2:
        return 0.0
    idx_above = np.where(above)[0]
    fwhm = float(win_wl[idx_above[-1]] - win_wl[idx_above[0]])
    return fwhm if fwhm > 0 else 0.0


def compute_pfr(wl, inten, key_lines):
    """Peak/FWHM ratio for each key line."""
    pfr = np.zeros(len(key_lines), dtype=np.float32)
    for i, (name, (center, halfwin)) in enumerate(key_lines.items()):
        mask = (wl >= center - halfwin) & (wl <= center + halfwin)
        if mask.sum() < 5:
            pfr[i] = 0.0
            continue
        peak = float(inten[mask].max())
        fwhm = compute_fwhm(wl, inten, center, halfwin)
        if fwhm > 1e-6:
            pfr[i] = peak / fwhm
        else:
            pfr[i] = 0.0
    return pfr


def spectrum_features(wl, inten, use_lsr=False, use_pfr=False, use_local_norm=False):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)

    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)

    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total

    if use_local_norm:
        labs_local = np.zeros(len(KEY_LINES), dtype=np.float32)
        for i, (name, (center, halfwin)) in enumerate(KEY_LINES.items()):
            mask = (wl >= center - halfwin) & (wl <= center + halfwin)
            if mask.sum() < 3:
                labs_local[i] = 0.0
                continue
            win_inten = inten[mask]
            w_mean = win_inten.mean()
            w_std = win_inten.std()
            if w_std > 1e-8:
                labs_local[i] = float((win_inten.max() - w_mean) / w_std)
            else:
                labs_local[i] = 0.0
        labs = labs_local

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    feats = [stats, labs, lrel, rats]

    if use_lsr:
        feats.append(compute_lsr(wl, inten, KEY_LINES))
    if use_pfr:
        feats.append(compute_pfr(wl, inten, KEY_LINES))

    return inten_norm, feats


def compute_features(data, use_lsr=False, use_pfr=False, use_local_norm=False):
    raw_spectra = data['spectra']
    inorms, feat_lists = [], []
    for wl, inten in raw_spectra:
        inorm, feats = spectrum_features(
            wl, inten, use_lsr=use_lsr, use_pfr=use_pfr, use_local_norm=use_local_norm)
        inorms.append(inorm)
        feat_lists.append(feats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    n_feats = len(feat_lists[0])
    stacked = []
    for fi in range(n_feats):
        stacked.append(np.array([fl[fi] for fl in feat_lists], dtype=np.float32))
    data['_feats'] = stacked
    return inorm_mat


def build_feature_matrix(data, n_batches,
                         scaler_spec=None, pca=None, scaler_hand=None, fit=True,
                         use_lsr=False, use_pfr=False, use_local_norm=False):
    inorm_mat = compute_features(
        data, use_lsr=use_lsr, use_pfr=use_pfr, use_local_norm=use_local_norm)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))
    hand_feats = np.hstack(data['_feats'])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                   sample_weights=None):
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)

    final_model = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def train_coal_gk(coal_type, train_data, **feat_kwargs):
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    X_spec, _, _, _ = build_feature_matrix(
        train_data, n_batches, fit=True, **feat_kwargs)
    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        months = train_data.get('months')
        if months is not None and len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                             sample_weights=sample_weights)
        return run, is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                                 sample_weights=sample_weights)
            runs.append(run)
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_coal_te(coal_type, train_data, **feat_kwargs):
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    months = train_data['months']
    X_spec, _, _, _ = build_feature_matrix(
        train_data, n_batches, fit=True, **feat_kwargs)

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sw = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)
        sample_weights = sw

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    predicted_aux_val = np.zeros((len(val_idx), len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_val[:, col_idx] = float(np.nanmean(y_aux[tr_idx]))
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights)
        else:
            m.fit(X_spec[tr_idx], y_aux[tr_idx])
        predicted_aux_val[:, col_idx] = m.predict(X_spec[val_idx])

    X_s2_tr = np.nan_to_num(np.hstack([X_spec[tr_idx], aux[tr_idx, :]]))
    X_s2_val = np.nan_to_num(np.hstack([X_spec[val_idx], predicted_aux_val]))
    scaler_s2 = StandardScaler()
    X_s2_tr_s = scaler_s2.fit_transform(X_s2_tr)
    X_s2_val_s = scaler_s2.transform(X_s2_val)

    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sample_weights)
    else:
        m2.fit(X_s2_tr_s, y[tr_idx])

    val_pred = m2.predict(X_s2_val_s)
    val_groups = groups[val_idx]

    oof_preds, oof_true = [], []
    for bg in np.unique(val_groups):
        mask = val_groups == bg
        if mask.sum() == 0:
            continue
        true_q = float(y[val_idx][mask][0])
        pred_q = float(np.median(val_pred[mask]))
        oof_preds.append(pred_q)
        oof_true.append(true_q)

    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w, 'coal_mean': coal_mean,
    }


def gk_cv_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    else:
        return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


def run_experiment(label_map, aux_map, config_name, **feat_kwargs):
    print(f"\n{'='*70}")
    print(f"  {config_name}")
    print(f"{'='*70}")
    gk_results = {}
    te_results = {}
    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None or train_data['n_batches'] == 0:
            continue
        n_batches = train_data['n_batches']
        runs, is_small = train_coal_gk(coal_type, train_data, **feat_kwargs)
        gk_rmse = gk_cv_rmse(runs, is_small)
        gk_results[coal_type] = gk_rmse
        te_result = train_coal_te(coal_type, train_data, **feat_kwargs)
        te_rmse = te_result['rmse_shrunk'] if te_result else None
        te_results[coal_type] = te_rmse
        te_str = f"TE={te_rmse:.2f}" if te_rmse else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b  GK={gk_rmse:.2f}  {te_str}")
    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {config_name}")
    print(f"     GK-Avg={gk_avg:.2f}  TE-Avg={te_avg:.2f}")
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V31: Line Shape Ratio + Local Normalization Experiments")
    print("=" * 70)
    label_map, aux_map = load_labels()

    gk_v28, te_v28 = run_experiment(label_map, aux_map, "V28 Baseline")
    gk_lsr, te_lsr = run_experiment(
        label_map, aux_map, "V31a: +LSR (Peak/Area, +11d)", use_lsr=True)
    gk_pfr, te_pfr = run_experiment(
        label_map, aux_map, "V31b: +PFR (Peak/FWHM, +11d)", use_pfr=True)
    gk_both, te_both = run_experiment(
        label_map, aux_map, "V31c: +LSR+PFR (+22d)", use_lsr=True, use_pfr=True)
    gk_ln, te_ln = run_experiment(
        label_map, aux_map, "V31d: Local Norm (replace labs)", use_local_norm=True)
    gk_ln_lsr, te_ln_lsr = run_experiment(
        label_map, aux_map, "V31e: Local Norm + LSR",
        use_local_norm=True, use_lsr=True)

    print(f"\n{'='*70}")
    print("SUMMARY (GK / TE)")
    print(f"{'='*70}")
    print(f"  V28 Baseline:      GK={gk_v28:.2f}  TE={te_v28:.2f}")
    print(f"  +LSR (Peak/Area):  GK={gk_lsr:.2f}  TE={te_lsr:.2f}  "
          f"(dGK={gk_lsr-gk_v28:+.2f}, dTE={te_lsr-te_v28:+.2f})")
    print(f"  +PFR (Peak/FWHM):  GK={gk_pfr:.2f}  TE={te_pfr:.2f}  "
          f"(dGK={gk_pfr-gk_v28:+.2f}, dTE={te_pfr-te_v28:+.2f})")
    print(f"  +LSR+PFR:          GK={gk_both:.2f}  TE={te_both:.2f}  "
          f"(dGK={gk_both-gk_v28:+.2f}, dTE={te_both-te_v28:+.2f})")
    print(f"  Local Norm:        GK={gk_ln:.2f}  TE={te_ln:.2f}  "
          f"(dGK={gk_ln-gk_v28:+.2f}, dTE={te_ln-te_v28:+.2f})")
    print(f"  Local Norm + LSR:  GK={gk_ln_lsr:.2f}  TE={te_ln_lsr:.2f}  "
          f"(dGK={gk_ln_lsr-gk_v28:+.2f}, dTE={te_ln_lsr-te_v28:+.2f})")


if __name__ == "__main__":
    main()
