"""V23: P2 残差建模 — 在V19 Ridge基础上叠加非线性修正
基线: V19 main=5.0,metal=1.0 → GK=273.08, TE=240.20, 线上=250.64

策略:
  Stage0: V19 Ridge(0.1) → OOF预测 → 残差
  Stage1: SVR-RBF / KNN 拟合OOF残差 (低复杂度)
  最终预测 = Ridge预测 + 残差模型预测

关键: 残差必须用OOF预测(不含自身), 否则过拟合
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    KEY_LINES, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, AUX_COLS,
)
from exp_v19 import label_map, aux_map, TIME_COALS, RIDGE_ALPHA
from exp_v22 import compute_features_v22, extract_month


def build_fm(inorm_mat, hand_feats, n_batches, n_pca_max=30):
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    X = np.hstack([sp, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X


def oof_ridge_residual(X, y, aux, groups, splits, alpha, residual_model=None):
    """两阶段Ridge + 可选残差模型"""
    op, ot = [], []
    for tr, va in splits:
        # Stage1: aux prediction
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = Ridge(alpha=alpha)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])

        # Stage2: Ridge
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = Ridge(alpha=alpha)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v)

        # 残差模型
        if residual_model is not None:
            # 用tr的OOF残差训练残差模型
            # 简化: 用tr上的预测残差 (非严格OOF, 但残差模型复杂度低)
            tr_pred = m2.predict(X2t)
            tr_residuals = y[tr] - tr_pred
            rm = clone_model(residual_model)
            rm.fit(X2t, tr_residuals)
            vp = vp + rm.predict(X2v)

        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


def clone_model(model):
    """深拷贝模型"""
    from sklearn.base import clone
    return clone(model)


def gkfold_cv(coal, residual_model=None, alpha=0.1, n_seeds=10):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_v22(td, KEY_LINES, 'sum')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    X = build_fm(inorm_mat, hand_feats, nb)
    coal_mean = float(y.mean())
    is_small = nb <= SMALL_BATCH_THRESHOLD
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge_residual(X, y, aux, groups, splits, alpha, residual_model)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge_residual(X, y, aux, groups, splits, alpha, residual_model)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': np.mean(all_sh), 'w': w, 'small': False}


def time_ext(coal, residual_model=None, alpha=0.1):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    inorm_mat, td2 = compute_features_v22(td, KEY_LINES, 'sum')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1: return None
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    n_pca = min(30, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr); X_va = np.nan_to_num(X_va)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr); X_va = sc_all.transform(X_va)

    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm])); continue
        m1 = Ridge(alpha=alpha); m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr); pa_va[:, ci] = m1.predict(X_va)
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr); X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=alpha); m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)

    if residual_model is not None:
        tr_pred = m2.predict(X2_tr)
        tr_residuals = y[tm] - tr_pred
        rm = clone_model(residual_model)
        rm.fit(X2_tr, tr_residuals)
        vp = vp + rm.predict(X2_va)

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(vy[mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, float(y[tm].mean()))
    return {'sh': cv_sh, 'w': w}


def run_config(name, residual_model=None):
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv(coal, residual_model=residual_model)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = np.mean(gk_all) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext(coal, residual_model=residual_model)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = np.mean(te_all) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # 基线
    results['baseline'] = run_config("V19基线 (无残差)")

    # SVR-RBF
    for C in [1.0, 5.0, 10.0]:
        for eps in [0.5, 1.0, 5.0]:
            results[f'svr_c{C}_e{eps}'] = run_config(
                f"SVR C={C} eps={eps}",
                residual_model=SVR(kernel='rbf', C=C, epsilon=eps))

    # KNN
    for k in [3, 5, 7, 10]:
        results[f'knn_{k}'] = run_config(
            f"KNN k={k}",
            residual_model=KNeighborsRegressor(n_neighbors=k))

    # 汇总
    print(f"\n{'='*60}")
    print("  V23: 残差建模探索")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
