"""
exp_v33_batch_level.py
批次级聚合实验: 将同一批次的多条光谱先聚合为"超级光谱", 再做PCA+Ridge.

核心改动:
  V28: 光谱级训练(每条光谱一行, Q_day重复) → 预测时median聚合
  V33: 批次级训练(每批次一行超级光谱) → 直接输出批次预测

聚合策略:
  - mean_norm: 先归一化每条光谱, 再取批次均值
  - trim_mean_norm: 先归一化, 再截尾均值(去10%两端)
  - median_norm: 先归一化, 再取批次中位数

与V28完全相同的双重CV评估: GK-CV + TE-CV
"""
import os, re, glob, warnings, time, copy
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

# V19窗口: 主元素×5
KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.30, 15.0),
    'O':   (777.20, 15.0), 'N':   (742.40, 10.0),
    'Ca':  (422.70, 2.0),  'Ca2': (393.40, 2.0),
    'Mg':  (285.20, 2.0),  'Al':  (308.20, 2.0),
    'Si':  (288.20, 2.0),  'Fe':  (438.40, 3.0),
    'Na':  (589.00, 1.5),
}

RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra_raw(data_root, coal_type, label_map=None, aux_map=None):
    """加载光谱, 按批次组织."""
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None

    batches = []  # list of {name, spectra, q, aux, month}
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue

        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None

        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_spectra = []
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is not None:
                batch_spectra.append((wl, inten))

        if batch_spectra:
            batches.append({
                'name': batch_folder,
                'spectra': batch_spectra,
                'q': q,
                'aux': aux,
                'month': extract_month(batch_folder),
            })

    if not batches:
        return None
    return batches


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    """从一条光谱提取特征."""
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)

    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)

    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def aggregate_batch_spectra(batch, mode='mean_norm'):
    """将一个批次的多条光谱聚合为一条超级光谱.
    
    mode:
      mean_norm: 归一化每条 -> 取均值
      trim_mean_norm: 归一化每条 -> 截尾均值(去10%)
      median_norm: 归一化每条 -> 逐波长取中位数
      mean_raw: 直接对原始强度取均值 -> 再归一化
    """
    spectra = batch['spectra']
    wl = spectra[0][0]

    if mode == 'mean_raw':
        # 直接对原始强度取均值
        all_inten = np.array([s[1] for s in spectra])
        super_inten = all_inten.mean(axis=0)
        # 用超级光谱做特征提取
        inorm, stats, labs, lrel, rats = spectrum_features(wl, super_inten)
        return inorm, stats, labs, lrel, rats

    # 先归一化每条, 再聚合
    norm_spectra = []
    for _, inten in spectra:
        total = inten.sum() + 1e-8
        norm_spectra.append(inten / total)

    norm_mat = np.array(norm_spectra)  # (n_spectra, n_wavelength)

    if mode == 'mean_norm':
        super_norm = norm_mat.mean(axis=0)
    elif mode == 'trim_mean_norm':
        n = norm_mat.shape[0]
        if n <= 2:
            super_norm = norm_mat.mean(axis=0)
        else:
            trim = max(1, n // 10)
            sorted_mat = np.sort(norm_mat, axis=0)
            super_norm = sorted_mat[trim:n-trim].mean(axis=0)
    elif mode == 'median_norm':
        super_norm = np.median(norm_mat, axis=0)
    else:
        super_norm = norm_mat.mean(axis=0)

    # 从超级归一化光谱提取特征
    # 重新构造一个 "伪原始强度" 用于特征提取
    # super_norm 已经是归一化的, total≈1
    super_inten = super_norm * (len(spectra))  # 缩放回合理量级
    inorm, stats, labs, lrel, rats = spectrum_features(wl, super_inten)
    # 但 inorm 应该就是 super_norm 本身
    inorm = super_norm.astype(np.float32)
    return inorm, stats, labs, lrel, rats


def build_batch_dataset(batches, mode='mean_norm', n_pca_max=30):
    """从批次列表构建批次级特征矩阵.
    
    返回:
      X_spec: PCA降维后的光谱特征 (n_batches, n_pca)
      hand_feats: 手工特征 (n_batches, n_hand)
      y: 发热量 (n_batches,)
      aux: 辅助指标 (n_batches, 4)
      batch_groups: 批次ID (n_batches,)
      months: 月份 (n_batches,)
      n_batches: 批次数
    """
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    y_list, aux_list, months_list = [], [], []

    for i, batch in enumerate(batches):
        inorm, stats, labs, lrel, rats = aggregate_batch_spectra(batch, mode)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
        if batch['q'] is not None:
            y_list.append(batch['q'])
        if batch['aux'] is not None:
            aux_list.append([batch['aux'][c] for c in AUX_COLS])
        months_list.append(batch['month'])

    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    hand_feats = np.hstack([
        np.array(stats_list), np.array(labs_list),
        np.array(lrel_list), np.array(rats_list),
    ])

    y = np.array(y_list) if y_list else None
    aux = np.array(aux_list) if aux_list else None
    months = np.array(months_list, dtype=int)
    n_batches = len(batches)
    batch_groups = np.arange(n_batches)

    # PCA
    scaler_spec = StandardScaler()
    spec_scaled = scaler_spec.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    spec_pca = pca.fit_transform(spec_scaled)

    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    scaler_hand = StandardScaler()
    X = scaler_hand.fit_transform(X)

    return {
        'X_spec': X, 'y': y, 'aux': aux,
        'groups': batch_groups, 'months': months,
        'n_batches': n_batches,
        'scaler_spec': scaler_spec, 'pca': pca, 'scaler_hand': scaler_hand,
    }


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def train_batch_ridge_gk(dataset, coal_type):
    """批次级 GK-CV 训练."""
    X = dataset['X_spec']
    y = dataset['y']
    aux = dataset['aux']
    groups = dataset['groups']
    n_batches = dataset['n_batches']
    months = dataset['months']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    def _run_one(splits):
        # Stage 1: aux OOF
        aux_oof = np.zeros_like(aux, dtype=np.float32)
        aux_models = {}
        for ci, col_name in enumerate(AUX_COLS):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                aux_oof[:, ci] = float(np.nanmean(ya))
                aux_models[col_name] = None
                continue
            m1 = Ridge(alpha=RIDGE_ALPHA)
            oof = np.zeros(len(ya))
            for tr, va in splits:
                if sample_weights is not None:
                    m1.fit(X[tr], ya[tr], sample_weight=sample_weights[tr])
                else:
                    m1.fit(X[tr], ya[tr])
                oof[va] = m1.predict(X[va])
            aux_oof[:, ci] = oof
            if sample_weights is not None:
                m1.fit(X, ya, sample_weight=sample_weights)
            else:
                m1.fit(X, ya)
            aux_models[col_name] = m1

        # Stage 2
        X_s2 = np.hstack([X, aux_oof])
        scaler_s2 = StandardScaler()
        X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

        oof_preds, oof_true, fold_rmses = [], [], []
        for tr, va in splits:
            m2 = Ridge(alpha=RIDGE_ALPHA)
            if sample_weights is not None:
                m2.fit(X_s2[tr], y[tr], sample_weight=sample_weights[tr])
            else:
                m2.fit(X_s2[tr], y[tr])
            vp = m2.predict(X_s2[va])
            # 批次级: 每行就是一个批次, 直接取预测值
            for j, idx in enumerate(va):
                oof_preds.append(float(vp[j]))
                oof_true.append(float(y[idx]))
            fold_se = [(float(y[idx]) - float(vp[j])) ** 2 for j, idx in enumerate(va)]
            fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

        cv_raw = float(np.mean(fold_rmses))
        best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)

        final_model = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            final_model.fit(X_s2, y, sample_weight=sample_weights)
        else:
            final_model.fit(X_s2, y)

        return {
            'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw,
            'shrink_w': best_w, 'oof_preds': np.array(oof_preds),
            'oof_true': np.array(oof_true),
        }

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _run_one(splits)
        return run, is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run_one(splits))
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_batch_ridge_te(dataset, coal_type):
    """批次级 TE-CV: 10/11月训练, 1/2/3月验证."""
    X = dataset['X_spec']
    y = dataset['y']
    aux = dataset['aux']
    groups = dataset['groups']
    months = dataset['months']
    n_batches = dataset['n_batches']
    coal_mean = float(y.mean())

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sw = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)
        sample_weights = sw

    # Stage 1: aux
    pred_aux_val = np.zeros((len(val_idx), len(AUX_COLS)), dtype=np.float32)
    pred_aux_tr = np.zeros((len(tr_idx), len(AUX_COLS)), dtype=np.float32)
    for ci, col_name in enumerate(AUX_COLS):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pred_aux_val[:, ci] = float(np.nanmean(ya[tr_mask]))
            pred_aux_tr[:, ci] = float(np.nanmean(ya[tr_mask]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m1.fit(X[tr_idx], ya[tr_idx], sample_weight=sample_weights)
        else:
            m1.fit(X[tr_idx], ya[tr_idx])
        pred_aux_val[:, ci] = m1.predict(X[val_idx])
        pred_aux_tr[:, ci] = m1.predict(X[tr_idx])

    X_s2_tr = np.nan_to_num(np.hstack([X[tr_idx], pred_aux_tr]))
    X_s2_val = np.nan_to_num(np.hstack([X[val_idx], pred_aux_val]))
    scaler_s2 = StandardScaler()
    X_s2_tr = scaler_s2.fit_transform(X_s2_tr)
    X_s2_val = scaler_s2.transform(X_s2_val)

    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        m2.fit(X_s2_tr, y[tr_idx], sample_weight=sample_weights)
    else:
        m2.fit(X_s2_tr, y[tr_idx])

    val_pred = m2.predict(X_s2_val)
    oof_preds = val_pred.tolist()
    oof_true = y[val_idx].tolist()

    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w,
    }


def gk_cv_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    else:
        return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


def run_experiment(label_map, aux_map, config_name, agg_mode='mean_norm', n_pca_max=30):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {config_name}")
    print(f"{'='*70}", flush=True)

    gk_results = {}
    te_results = {}
    for coal_type in COAL_TYPES:
        batches = load_coal_spectra_raw(TRAIN_DIR, coal_type, label_map, aux_map)
        if batches is None or len(batches) == 0:
            continue
        n_batches = len(batches)
        dataset = build_batch_dataset(batches, mode=agg_mode, n_pca_max=n_pca_max)
        n_spec_total = sum(len(b['spectra']) for b in batches)

        # GK-CV
        runs, is_small = train_batch_ridge_gk(dataset, coal_type)
        gk_rmse = gk_cv_rmse(runs, is_small)
        gk_results[coal_type] = gk_rmse

        # TE-CV
        te_result = train_batch_ridge_te(dataset, coal_type)
        te_rmse = te_result['rmse_shrunk'] if te_result else None
        te_results[coal_type] = te_rmse

        tag = "LOOCV" if is_small else f"{N_ENSEMBLE_SEEDS}seed"
        te_str = f"TE={te_rmse:.2f}" if te_rmse else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b/{n_spec_total}s  "
              f"GK={gk_rmse:.2f}  {te_str}  ({tag})", flush=True)

    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {config_name}")
    print(f"     GK-Avg={gk_avg:.2f}  TE-Avg={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V33: Batch-Level Aggregation Experiments")
    print("  Core change: aggregate spectra to batch-level BEFORE PCA+Ridge")
    print("=" * 70)

    label_map, aux_map = load_labels()

    results = {}

    # V33a: 不同聚合策略 (PCA=30)
    for mode in ['mean_norm', 'trim_mean_norm', 'median_norm', 'mean_raw']:
        results[f'V33_{mode}_pca30'] = run_experiment(
            label_map, aux_map, f"Batch-level {mode} PCA=30",
            agg_mode=mode, n_pca_max=30)

    # V33b: PCA维数扫描 (用最优聚合策略)
    # 先用mean_norm跑不同PCA
    for npc in [10, 15, 20]:
        results[f'V33_mean_norm_pca{npc}'] = run_experiment(
            label_map, aux_map, f"Batch-level mean_norm PCA={npc}",
            agg_mode='mean_norm', n_pca_max=npc)

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY (GK / TE)")
    print(f"{'='*70}")
    # V28 baseline for reference
    print(f"  {'V28 baseline (ref)':30s}  {'GK~163':>8s}  {'TE~282':>8s}")
    print(f"  {'config':30s}  {'GK':>8s}  {'TE':>8s}")
    for name, (gk, te) in results.items():
        print(f"  {name:30s}  {gk:8.2f}  {te:8.2f}")


if __name__ == "__main__":
    main()
