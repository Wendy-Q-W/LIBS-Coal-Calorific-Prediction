"""
exp_v446_v460_pipeline_tuning.py
Tune pipeline internal parameters to find CV-gap improvements.
All experiments use a=0.05 + isotonic (the proven optimal config).
Only change one parameter at a time to isolate effects.

Key insight: a=0.05 iso is the unique global optimum (CV=172, gap=25, online=197).
Goal: find a pipeline tweak that reduces CV or gap without breaking corr.
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exp_v260_v270_tree_models as base
from exp_v260_v270_tree_models import run_experiment, PIPELINE_CONFIG

if __name__ == '__main__':
    experiments = [
        # === Ensemble aggregation variants ===
        ('v446_ens_median', {
            'batch_agg': 'median', 'ensemble_agg': 'median', 'fixed_shrink_w': None
        }, 'a=0.05 iso + ensemble median (instead of mean). More robust to outlier seeds.'),

        ('v447_ens_trim', {
            'batch_agg': 'median', 'ensemble_agg': 'trim_mean', 'fixed_shrink_w': None
        }, 'a=0.05 iso + ensemble trimmed mean (20% trim). Between mean and median.'),

        # === Batch aggregation variants ===
        ('v448_batch_mean', {
            'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
        }, 'a=0.05 iso + batch mean (instead of median). Less robust, more unbiased.'),

        ('v449_batch_trim', {
            'batch_agg': 'trim_mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
        }, 'a=0.05 iso + batch trimmed mean. Between mean and median.'),

        # === Fixed shrinkage weights ===
        ('v450_shrink095', {
            'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': 0.95
        }, 'a=0.05 iso + fixed shrinkage w=0.95. Less shrinkage than OOF-optimized.'),

        ('v451_shrink090', {
            'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': 0.90
        }, 'a=0.05 iso + fixed shrinkage w=0.90. Even less shrinkage.'),

        ('v452_shrink085', {
            'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': 0.85
        }, 'a=0.05 iso + fixed shrinkage w=0.85. Minimal shrinkage.'),

        ('v453_shrink100', {
            'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': 1.0
        }, 'a=0.05 iso + no shrinkage (w=1.0). Raw predictions.'),

        # === Combined: batch_mean + ens_median ===
        ('v454_bmean_emedian', {
            'batch_agg': 'mean', 'ensemble_agg': 'median', 'fixed_shrink_w': None
        }, 'a=0.05 iso + batch mean + ensemble median. Both aggregation changes.'),

        # === Combined: batch_trim + ens_trim ===
        ('v455_btrim_etrim', {
            'batch_agg': 'trim_mean', 'ensemble_agg': 'trim_mean', 'fixed_shrink_w': None
        }, 'a=0.05 iso + batch trim + ensemble trim. Both trimmed.'),

        # === Combined: fixed shrink + ens_median ===
        ('v456_shrink095_ensmed', {
            'batch_agg': 'median', 'ensemble_agg': 'median', 'fixed_shrink_w': 0.95
        }, 'a=0.05 iso + shrink 0.95 + ensemble median. Combined robustness.'),

        # === Linear calibration variants (for comparison) ===
        ('v457_bmean_linear', {
            'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
        }, 'a=0.05 linear + batch mean. Test batch aggregation with linear calib.'),

        # === Fixed shrinkage with linear ===
        ('v458_shrink095_linear', {
            'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': 0.95
        }, 'a=0.05 linear + fixed shrinkage w=0.95.'),
    ]

    results = {}
    for vid, config, desc in experiments:
        # Update global config
        base.PIPELINE_CONFIG.update(config)
        # Determine calibration from description
        calib = 'isotonic'
        if 'linear' in desc.lower() and 'iso' not in desc.lower().split('+')[1].strip():
            calib = 'linear'
        # Actually, let's be explicit
        calib = 'linear' if 'linear' in vid else 'isotonic'
        
        print(f"\n{'='*70}")
        print(f"  {vid}: {desc}")
        print(f"  Config: {config}")
        print(f"  Calibration: {calib}")
        print(f"{'='*70}")
        
        _, cv = run_experiment(
            vid, desc,
            ridge_alpha=0.05,
            calibration=calib,
            preprocessing='snv',
            use_pca=True,
        )
        results[vid] = cv
        print(f"  CV={cv:.2f}")

    # Reset config
    base.PIPELINE_CONFIG.update({
        'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
    })

    print(f"\n{'='*70}")
    print("  SUMMARY")
    print(f"{'='*70}")
    for vid, cv in results.items():
        print(f"  {vid:30s}  CV={cv:.2f}")
