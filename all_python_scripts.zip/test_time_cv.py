"""V11b+全收缩 时间外推CV测试"""
import sys, os, re, warnings
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from config import ALPHAS, AUX_COLS, COAL_TYPES, TRAIN_DIR
from src.data import load_labels, load_coal_spectra
from src.features import build_feature_matrix
from src.model import find_best_shrinkage

label_map, aux_map = load_labels()

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def stage1_stage2_oof(X_spec, y, aux, groups, splits):
    """跑两阶段OOF，返回 batch_preds, batch_trues"""
    oof_p, oof_t = [], []
    for tr_idx, val_idx in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya))
                continue
            m1 = RidgeCV(alphas=ALPHAS)
            m1.fit(X_spec[tr_idx], ya[tr_idx])
            pa[val_idx, ci] = m1.predict(X_spec[val_idx])
        X2_tr = np.hstack([X_spec[tr_idx], pa[tr_idx]])
        X2_val = np.hstack([X_spec[val_idx], pa[val_idx]])
        m2 = RidgeCV(alphas=ALPHAS)
        m2.fit(X2_tr, y[tr_idx])
        vp = m2.predict(X2_val)
        vg = groups[val_idx]
        for bg in np.unique(vg):
            mask = vg == bg
            oof_p.append(float(np.median(vp[mask])))
            oof_t.append(float(y[val_idx][mask][0]))
    return oof_p, oof_t

def time_extrapolation(coal):
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None
    y = train_data['targets']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    aux = train_data['aux']
    coal_mean = float(y.mean())
    names = train_data['names']

    X_spec, _, _, _ = build_feature_matrix(train_data, n_batches, fit=True)
    is_small = n_batches <= 11

    # 搜 w
    if is_small:
        dummy = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(dummy, dummy, groups))
        oof_p, oof_t = stage1_stage2_oof(X_spec, y, aux, groups, splits)
        w, _ = find_best_shrinkage(oof_p, oof_t, coal_mean)
    else:
        ws = []
        for seed in range(30):
            dummy = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=seed)
            splits = list(gkf.split(dummy, dummy, groups))
            oof_p, oof_t = stage1_stage2_oof(X_spec, y, aux, groups, splits)
            w_s, _ = find_best_shrinkage(oof_p, oof_t, coal_mean)
            ws.append(w_s)
        w = float(np.mean(ws))

    # 时间外推
    unique_batches = np.unique(groups)
    batch_to_month = {}
    for g in unique_batches:
        mask = groups == g
        idx = np.where(mask)[0][0]
        batch_to_month[g] = extract_month(names[idx])

    train_g = set(g for g in unique_batches if batch_to_month[g] in {10, 11})
    val_g   = set(g for g in unique_batches if batch_to_month[g] in {1, 2, 3})

    if len(train_g) < 3 or len(val_g) < 1:
        return {'w': w, 'coal_mean': coal_mean, 'is_small': is_small}

    train_mask = np.array([g in train_g for g in groups])
    val_mask   = np.array([g in val_g for g in groups])

    # 两阶段时间外推
    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya))
            continue
        m1 = RidgeCV(alphas=ALPHAS)
        m1.fit(X_spec[train_mask], ya[train_mask])
        pa[:, ci] = m1.predict(X_spec)

    X2 = np.hstack([X_spec, pa])
    sc = StandardScaler()
    X2 = sc.fit_transform(np.nan_to_num(X2))
    m2 = RidgeCV(alphas=ALPHAS)
    m2.fit(X2[train_mask], y[train_mask])
    vp = m2.predict(X2[val_mask])

    vg = groups[val_mask]
    vy = y[val_mask]
    bp, bt = [], []
    for bg in np.unique(vg):
        mask = vg == bg
        bp.append(float(np.median(vp[mask])))
        bt.append(float(vy[mask][0]))

    cv_raw = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bp)])))
    bl = [w * p + (1-w) * coal_mean for p in bp]
    cv_shrunk = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))

    return {'cv_raw': cv_raw, 'cv_shrunk': cv_shrunk, 'w': w,
            'coal_mean': coal_mean, 'is_small': is_small}

print('=== V11b+全收缩: 时间外推CV ===')
all_raw, all_shrunk = [], []
for coal in COAL_TYPES:
    r = time_extrapolation(coal)
    if r is None:
        continue
    tag = 'small' if r['is_small'] else 'large'
    if 'cv_raw' in r:
        all_raw.append(r['cv_raw'])
        all_shrunk.append(r['cv_shrunk'])
        print(f"  [{coal}] ({tag}) raw={r['cv_raw']:.2f}  shrunk={r['cv_shrunk']:.2f}  w={r['w']:.2f}  mean={r['coal_mean']:.0f}")
    else:
        print(f"  [{coal}] ({tag}) w={r['w']:.2f}  mean={r['coal_mean']:.0f}  (no time split)")

if all_raw:
    print(f"  >> avg raw={np.mean(all_raw):.2f}  avg shrunk={np.mean(all_shrunk):.2f}")
