"""
gen_v560_v575_surgical_expand.py
V538=196.37 is best. V546(+九里山)=197.09 (九里山 hurts +0.72).
V548(all best)=196.95, so V548-V546=-0.14 means 赵固一→V63+赵固二→V72+煤场混煤→V63 HELPS.

Strategy: V538 + individual coal additions (NO 九里山) to find which help.
"""
import os, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
pred_col = '预测发热量_MJ_KG'

def load_template():
    return pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')

def load_pred(zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(zip_path): return None
    with zipfile.ZipFile(zip_path, 'r') as zf:
        csv_name = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(csv_name) as f:
            return pd.read_csv(f, encoding='utf-8-sig')

def save_zip(df, zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', csv_buf.getvalue())
    return zip_path

def corr(v1, v2): return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("SURGICAL EXPAND FROM V538 (196.37) — NO 九里山")
    print("=" * 70)

    template = load_template()
    template['coal'] = template['名称'].apply(
        lambda n: next((ct for ct in COAL_TYPES if ct in str(n)), 'unknown'))
    masks = {ct: (template['coal'] == ct).values for ct in COAL_TYPES}

    v61 = load_pred('submit_v61_a005_bias.zip')[pred_col].values
    v63 = load_pred('submit_v63_isotonic.zip')[pred_col].values
    v72 = load_pred('submit_v72_isotonic_a005.zip')[pred_col].values
    v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')[pred_col].values

    zm = masks['中马矿中煤矿']
    zg1 = masks['赵固一矿豫焦末煤']
    zg2 = masks['赵固二矿中煤矿']
    jl = masks['九里山矿中煤矿']
    mc = masks['煤场混煤']

    # V538 baseline = V96 with 中马矿→V72
    v538 = v96.copy()
    v538[zm] = v72[zm]

    results = []

    def gen(name, pred, desc):
        c = corr(pred, v96)
        m = np.mean(np.abs(pred - v96))
        df_out = template.copy()
        df_out[pred_col] = pred
        save_zip(df_out, f'submit_{name}.zip')
        results.append((name, c, m, desc))
        print(f"  {name}: corr={c:.6f}, MAE={m:.2f} — {desc}")

    # === Individual coal additions on top of V538 ===

    # V560: V538 + 赵固一→V63 (7 batches)
    p = v538.copy(); p[zg1] = v63[zg1]
    gen('v560_v538_zhao1_v63', p, "V538+赵固一→V63")

    # V561: V538 + 赵固二→V72 (9 batches)
    p = v538.copy(); p[zg2] = v72[zg2]
    gen('v561_v538_zhao2_v72', p, "V538+赵固二→V72")

    # V562: V538 + 煤场混煤→V63 (14 batches)
    p = v538.copy(); p[mc] = v63[mc]
    gen('v562_v538_meichang_v63', p, "V538+煤场混煤→V63")

    # === Pairwise additions ===

    # V563: V538 + 赵固一→V63 + 赵固二→V72 (11 batches)
    p = v538.copy(); p[zg1] = v63[zg1]; p[zg2] = v72[zg2]
    gen('v563_v538_zhao1v63_zhao2v72', p, "V538+赵固一→V63+赵固二→V72")

    # V564: V538 + 赵固一→V63 + 煤场混煤→V63 (16 batches)
    p = v538.copy(); p[zg1] = v63[zg1]; p[mc] = v63[mc]
    gen('v564_v538_zhao1v63_meichangv63', p, "V538+赵固一→V63+煤场混煤→V63")

    # V565: V538 + 赵固二→V72 + 煤场混煤→V63 (18 batches)
    p = v538.copy(); p[zg2] = v72[zg2]; p[mc] = v63[mc]
    gen('v565_v538_zhao2v72_meichangv63', p, "V538+赵固二→V72+煤场混煤→V63")

    # === Triple addition (the key candidate) ===

    # V566: V538 + 赵固一→V63 + 赵固二→V72 + 煤场混煤→V63 (NO 九里山, 20 batches)
    p = v538.copy(); p[zg1] = v63[zg1]; p[zg2] = v72[zg2]; p[mc] = v63[mc]
    gen('v566_v538_3coal_no_jiuli', p, "V538+赵固一→V63+赵固二→V72+煤场混煤→V63 (NO九里山)")

    # === Blended versions (safer) ===

    # V567: V538 + 20% of 3-coal addition (blended, safer)
    v566 = v538.copy(); v566[zg1] = v63[zg1]; v566[zg2] = v72[zg2]; v566[mc] = v63[mc]
    p = 0.8 * v538 + 0.2 * v566
    gen('v567_v538_v566_8020', p, "V538+V566 80/20 (gentle 3-coal)")

    # V568: V538 + 50% of 3-coal addition
    p = 0.5 * v538 + 0.5 * v566
    gen('v568_v538_v566_5050', p, "V538+V566 50/50")

    # === Alternative: try V63 for 九里山 instead of V72 ===
    # V546 failed with V72 for 九里山. Maybe V63 works better?

    # V569: V538 + 九里山→V63 (11 batches)
    p = v538.copy(); p[jl] = v63[jl]
    gen('v569_v538_jiuli_v63', p, "V538+九里山→V63 (not V72!)")

    # V570: V538 + 九里山→V63 + 3-coal (24 batches, all except 九里山 uses V63)
    p = v538.copy(); p[jl] = v63[jl]; p[zg1] = v63[zg1]; p[zg2] = v72[zg2]; p[mc] = v63[mc]
    gen('v570_v538_jiuli_v63_3coal', p, "V538+九里山→V63+3coal")

    # === Try V61 replacement for 九里山 (V61 OOF=117, better than V96 but worse than V72) ===
    # V571: V538 + 九里山→V61 (11 batches)
    p = v538.copy(); p[jl] = v61[jl]
    gen('v571_v538_jiuli_v61', p, "V538+九里山→V61")

    # === Blended 九里山 (partial replacement) ===
    # V572: V538 + 九里山 = 50% V96 + 50% V72 (gentle 九里山)
    p = v538.copy(); p[jl] = 0.5 * v96[jl] + 0.5 * v72[jl]
    gen('v572_v538_jiuli_5050', p, "V538+九里山 50/50 V96/V72")

    # V573: V538 + 九里山 = 80% V96 + 20% V72 (very gentle)
    p = v538.copy(); p[jl] = 0.8 * v96[jl] + 0.2 * v72[jl]
    gen('v573_v538_jiuli_8020', p, "V538+九里山 80/20 V96/V72")

    # === Summary ===
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr)")
    print("=" * 70)
    print(f"{'Variant':<35} {'corr':<12} {'MAE':<8} {'Description'}")
    print("-" * 90)
    for name, c, m, desc in sorted(results, key=lambda x: -x[1]):
        print(f"{name:<35} {c:.6f}     {m:.2f}   {desc}")

    print("\n--- Known online scores ---")
    print("  V96  = 196.98 (baseline)")
    print("  V538 = 196.37 (中马→V72, BEST)")
    print("  V546 = 197.09 (中马+九里→V72, 九里 HURTS +0.72)")
    print("  V548 = 196.95 (all best, 3coal helps -0.14 vs V546)")
    print("  V555 = 196.67 (V96+V538 80/20)")
    print("")
    print("  KEY: V548-V546 = -0.14 => 3coal (赵固一→V63+赵固二→V72+煤场混煤→V63) HELPS")
    print("  V566 = V538 + 3coal (no 九里山) => expect ~196.37 - 0.14 = ~196.23")
    print("  V562 = V538 + 煤场混煤→V63 only =>煤场 has 9 batches, most impact")

if __name__ == '__main__':
    main()
