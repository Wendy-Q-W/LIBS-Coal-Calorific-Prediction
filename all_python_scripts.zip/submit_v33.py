"""
submit_v33.py — 批次级聚合提交脚本

V33架构: 光谱先按批次聚合为"超级光谱" -> PCA(30) -> 两阶段Ridge
与V28唯一区别: PCA在批次级(70样本)而非光谱级(1000+样本)

双重CV:
  GK-Avg=275.89  TE-Avg=275.67  (V28: GK=163.32 TE=281.62)
  TE改善-5.95, 但GK恶化+112.57

线上验证: 测试集全部来自12月, GK-CV低估了批次级对12月外推的改善
"""
import os, re, glob, warnings, zipfile
from datetime import datetime
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.30, 15.0),
    'O':   (777.20, 15.0), 'N':   (742.40, 10.0),
    'Ca':  (422.70, 2.0),  'Ca2': (393.40, 2.0),
    'Mg':  (285.20, 2.0),  'Al':  (308.20, 2.0),
    'Si':  (288.20, 2.0),  'Fe':  (438.40, 3.0),
    'Na':  (589.00, 1.5),
}

RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 100
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


# ═══════════════════════════════════════════════════════════════════════════════
# Data loading
# ═══════════════════════════════════════════════════════════════════════════════

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_batches(data_root, coal_type, label_map=None, aux_map=None):
    """加载某煤种数据, 按批次组织 (训练集带标签, 测试集不带)."""
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    batches = []
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_spectra = []
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is not None:
                batch_spectra.append((wl, inten))
        if batch_spectra:
            batches.append({
                'name': batch_folder,
                'spectra': batch_spectra,
                'q': q,
                'aux': aux,
                'month': extract_month(batch_folder),
            })
    if not batches:
        return None
    return batches


# ═══════════════════════════════════════════════════════════════════════════════
# Feature extraction
# ═══════════════════════════════════════════════════════════════════════════════

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def aggregate_batch_to_super(batch, mode='mean_norm'):
    """聚合一个批次的多条光谱为一条超级归一化光谱."""
    spectra = batch['spectra']
    wl = spectra[0][0]
    norm_spectra = []
    for _, inten in spectra:
        total = inten.sum() + 1e-8
        norm_spectra.append(inten / total)
    norm_mat = np.array(norm_spectra)
    if mode == 'mean_norm':
        super_norm = norm_mat.mean(axis=0)
    elif mode == 'trim_mean_norm':
        n = norm_mat.shape[0]
        if n <= 2:
            super_norm = norm_mat.mean(axis=0)
        else:
            trim = max(1, n // 10)
            sorted_mat = np.sort(norm_mat, axis=0)
            super_norm = sorted_mat[trim:n-trim].mean(axis=0)
    elif mode == 'median_norm':
        super_norm = np.median(norm_mat, axis=0)
    else:
        super_norm = norm_mat.mean(axis=0)
    return wl, super_norm


def build_batch_matrix(batches, mode='mean_norm'):
    """构建批次级特征矩阵."""
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    y_list, aux_list, months_list, names_list = [], [], [], []
    for batch in batches:
        wl, super_norm = aggregate_batch_to_super(batch, mode)
        super_inten = super_norm * len(batch['spectra'])
        _, stats, labs, lrel, rats = spectrum_features(wl, super_inten)
        inorms.append(super_norm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
        if batch['q'] is not None:
            y_list.append(batch['q'])
        if batch['aux'] is not None:
            aux_list.append([batch['aux'][c] for c in AUX_COLS])
        months_list.append(batch['month'])
        names_list.append(batch['name'])
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    hand_feats = np.hstack([
        np.array(stats_list), np.array(labs_list),
        np.array(lrel_list), np.array(rats_list),
    ])
    y = np.array(y_list) if y_list else None
    aux = np.array(aux_list) if aux_list else None
    months = np.array(months_list, dtype=int)
    return inorm_mat, hand_feats, y, aux, months, names_list


def build_feature_matrix_fit(inorm_mat, hand_feats, n_batches, n_pca_max=30):
    """Fit PCA+StandardScaler on batch-level features."""
    scaler_spec = StandardScaler()
    spec_scaled = scaler_spec.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    spec_pca = pca.fit_transform(spec_scaled)
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    scaler_hand = StandardScaler()
    X = scaler_hand.fit_transform(X)
    return X, scaler_spec, pca, scaler_hand


def build_feature_matrix_transform(inorm_mat, hand_feats, scaler_spec, pca, scaler_hand):
    """Transform using fitted scalers."""
    spec_scaled = scaler_spec.transform(inorm_mat)
    spec_pca = pca.transform(spec_scaled)
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    return scaler_hand.transform(X)


# ═══════════════════════════════════════════════════════════════════════════════
# CV + training
# ═══════════════════════════════════════════════════════════════════════════════

def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                   sample_weights=None):
    """两阶段 Ridge: Stage1 aux OOF, Stage2 Q prediction."""
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, fold_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        for j, idx in enumerate(val_idx):
            oof_batch_preds.append(float(val_pred[j]))
            oof_batch_true.append(float(y[idx]))
        fold_se = [(float(y[idx]) - float(val_pred[j])) ** 2 for j, idx in enumerate(val_idx)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(fold_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_mean)

    final_model = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
    }


def train_coal_model(coal_type, batches):
    """训练某煤种的批次级模型."""
    n_batches = len(batches)
    inorm_mat, hand_feats, y, aux, months, names = build_batch_matrix(batches, 'mean_norm')
    groups = np.arange(n_batches)
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix_fit(
        inorm_mat, hand_feats, n_batches)

    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                             sample_weights=sample_weights)
        n_spec = sum(len(b['spectra']) for b in batches)
        print(f"\n  [{coal_type}]  {n_batches}批次/{n_spec}条光谱  "
              f"Q={y.min():.0f}~{y.max():.0f}  (LOOCV)")
        print(f"    CV-RMSE: raw={run['cv_rmse_raw']:.2f}  "
              f"shrunk={run['cv_rmse']:.2f}  w={run['shrink_w']:.2f}")
        return {
            'scaler_spec': scaler_spec, 'pca': pca, 'scaler_hand': scaler_hand,
            'ensemble': [run], 'coal_mean': coal_mean,
            'cv_rmse': run['cv_rmse'], 'is_small': True,
        }
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                                 sample_weights=sample_weights)
            runs.append(run)
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        cv_mean = float(np.mean([r['cv_rmse'] for r in runs]))
        cv_std = float(np.std([r['cv_rmse'] for r in runs]))
        n_spec = sum(len(b['spectra']) for b in batches)
        print(f"\n  [{coal_type}]  {n_batches}批次/{n_spec}条光谱  "
              f"Q={y.min():.0f}~{y.max():.0f}  ({N_ENSEMBLE_SEEDS}种子集成)")
        print(f"    CV-RMSE: {cv_mean:.2f} ± {cv_std:.2f}  w={avg_w:.2f}")
        return {
            'scaler_spec': scaler_spec, 'pca': pca, 'scaler_hand': scaler_hand,
            'ensemble': runs, 'coal_mean': coal_mean,
            'cv_rmse': cv_mean, 'is_small': False,
        }


def predict_coal(coal_type, test_batches, model_dict):
    """对测试集做推理."""
    scaler_spec = model_dict['scaler_spec']
    pca = model_dict['pca']
    scaler_hand = model_dict['scaler_hand']
    coal_mean = model_dict['coal_mean']
    ensemble = model_dict['ensemble']

    inorm_mat, hand_feats, _, _, _, names = build_batch_matrix(test_batches, 'mean_norm')
    X_spec = build_feature_matrix_transform(inorm_mat, hand_feats, scaler_spec, pca, scaler_hand)

    all_batch_preds = []
    for run in ensemble:
        aux_models = run['aux_models']
        scaler_s2 = run['scaler_s2']
        final_model = run['final_model']
        shrink_w = run['shrink_w']

        pred_aux = np.zeros((len(X_spec), len(AUX_COLS)), dtype=np.float32)
        for col_idx, col_name in enumerate(AUX_COLS):
            m = aux_models.get(col_name)
            if m is not None:
                pred_aux[:, col_idx] = m.predict(X_spec)

        X_s2 = scaler_s2.transform(np.nan_to_num(np.hstack([X_spec, pred_aux])))
        preds = final_model.predict(X_s2)

        batch_pred = {}
        for i, name in enumerate(names):
            v = float(preds[i])
            if shrink_w < 1.0:
                v = shrink_w * v + (1 - shrink_w) * coal_mean
            batch_pred[name] = v
        all_batch_preds.append(batch_pred)

    batch_names = list(all_batch_preds[0].keys())
    final_pred = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        final_pred[name] = float(np.mean(vals))
    return final_pred


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("V33 Batch-Level Submission (mean_norm + PCA30 + Ridge)")
    print("  Architecture: spectra -> batch aggregate -> PCA -> 2-stage Ridge")
    print("=" * 60)

    print("\nStep 1: 加载标签")
    label_map, aux_map = load_labels()
    print(f"  标签总数: {len(label_map)}")

    print("\n" + "=" * 60)
    print("Step 2: 批次级训练 (分煤种)")
    models = {}
    cv_results = {}
    for coal_type in COAL_TYPES:
        batches = load_batches(TRAIN_DIR, coal_type, label_map, aux_map)
        if batches is None or len(batches) == 0:
            print(f"\n  [{coal_type}] 未找到训练数据，跳过")
            continue
        model_dict = train_coal_model(coal_type, batches)
        models[coal_type] = model_dict
        cv_results[coal_type] = model_dict['cv_rmse']

    global_cv_rmse = float(np.mean(list(cv_results.values())))
    print(f"\n{'=' * 60}")
    print(f"全局 CV-RMSE: {global_cv_rmse:.2f}")

    print("\n" + "=" * 60)
    print("Step 3: 测试集推理")
    all_preds = {}
    for coal_type in COAL_TYPES:
        if coal_type not in models:
            continue
        test_batches = load_batches(TEST_DIR, coal_type, label_map=None, aux_map=None)
        if test_batches is None or len(test_batches) == 0:
            print(f"  [{coal_type}] 无测试数据")
            continue
        bp = predict_coal(coal_type, test_batches, models[coal_type])
        all_preds.update(bp)
        print(f"  [{coal_type}] {len(bp)} 个批次预测完成")

    print("\n  预测结果:")
    for name, pred in sorted(all_preds.items()):
        print(f"    {name}: {pred:.2f}")

    print("\n" + "=" * 60)
    print("Step 4: 生成提交文件")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  警告: {len(missing)} 个批次缺少预测，用均值填充: {missing}")
        fallback = sum(all_preds.values()) / len(all_preds)
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(fallback)

    csv_path = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"\n  [OK] {csv_path}")

    # README
    table_rows = "\n".join(
        f"| {ct} | {rmse:.2f} |"
        for ct, rmse in cv_results.items()
    )
    readme = f"""# LIBS 煤炭发热量预测 — V33 批次级聚合

**版本**: v33-batch-level
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 架构改动

V28: 光谱级训练 (每条光谱一行, Q_day重复) -> 预测时median聚合
V33: 批次级训练 (先聚合为超级光谱, 70样本) -> 直接输出批次预测

聚合策略: mean_norm (先归一化每条光谱, 再取批次均值)
降维: PCA(30) + 两阶段 Ridge(alpha=0.1)
时间加权: 九里山tau=20, 煤场混煤tau=30

## CV-RMSE

| 煤种 | CV-RMSE |
|---|---|
{table_rows}
| **全局** | **{global_cv_rmse:.2f}** |

## 双重CV对比 (V33实验)

| 指标 | V28 | V33 |
|---|---|---|
| GK-Avg | 163.32 | 275.89 |
| TE-Avg | 281.62 | 275.67 |
"""
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)

    zip_path = os.path.join(OUTPUT_DIR, "submit.zip")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(csv_path, arcname="submit/submit.csv")
        zf.write(readme_path, arcname="submit/README.md")
    print(f"  [OK] {zip_path}")
    print(f"  内含: submit/submit.csv + submit/README.md")
    print("\n完成！提交文件在 output/submit.zip")


if __name__ == "__main__":
    main()
