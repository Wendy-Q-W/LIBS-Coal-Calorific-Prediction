"""Fix correlations and generate all missing blends."""
import zipfile, io, pandas as pd, numpy as np, os
from datetime import datetime

OUTPUT_DIR = 'C:/2-Competition Area/基于现场LIBS光谱的煤炭弹筒发热量预测挑战赛/LIBS_project/LIBS/output'
SUBMIT_TEMPLATE = os.path.join(OUTPUT_DIR, '..', 'submit_sample', 'submit', 'submit.csv')

def load_sub(name):
    fname = os.path.join(OUTPUT_DIR, f'submit_{name}.zip')
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']

def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_sub(name)
        if sub is None:
            print(f'  ERROR: {name} not found')
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, 'submit.csv')
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f'# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n{desc}\n'
    readme_path = os.path.join(OUTPUT_DIR, 'README.md')
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f'submit_{variant_name}.zip')
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, 'submit/submit.csv')
        zf.write(readme_path, 'submit/README.md')
    print(f'  [OK] {variant_name}')
    return out_zip

# New preprocessing models
new_models = {
    'V181': ('v181_msc_a005_linear', 174.76),
    'V182': ('v182_area_norm_a005_linear', 154.95),
    'V183': ('v183_vector_norm_a005_linear', 165.43),
    'V184': ('v184_deriv1_a005_linear', 170.87),
    'V185': ('v185_msc_a005_isotonic', 174.76),
    'V186': ('v186_mean_center_a005_linear', 150.78),
}

ref_models = {
    'V61': 'v61_a005_bias',
    'V63': 'v63_isotonic',
    'V72': 'v72_isotonic_a005',
    'V96': 'v96_blend_v74_v72_7525',
    'V74': 'v74_blend_v61_v63_5050',
}

subs = {}
for short, name in {**ref_models, **{k: v[0] for k, v in new_models.items()}}.items():
    s = load_sub(name)
    if s is not None:
        subs[short] = s
    else:
        print(f'  {short}: NOT FOUND ({name})')

# Correlation analysis
print()
print('=== Correlation of new preprocessing models ===')
for short, (name, cv) in new_models.items():
    if short not in subs:
        continue
    arr = np.array(subs[short].values)
    corrs = {}
    for ref in ['V96', 'V61', 'V63', 'V72', 'V74']:
        if ref in subs:
            c = np.corrcoef(arr, np.array(subs[ref].values))[0, 1]
            corrs[ref] = c
    min_corr = min(corrs.values())
    min_ref = min(corrs, key=corrs.get)
    safe = 170 <= cv <= 195
    blend_ok = 'YES' if (safe and corrs.get('V96', 1.0) < 0.995) else 'NO'
    
    parts = f'{short:>8} CV={cv:>8.2f}'
    for ref in ['V96', 'V61', 'V63', 'V72', 'V74']:
        if ref in corrs:
            parts += f'  corr({ref})={corrs[ref]:.6f}'
    parts += f'  min={min_corr:.6f}({min_ref})  [{blend_ok}]'
    print(parts)

# Full matrix
print()
print('=== Full correlation matrix ===')
keys = list(subs.keys())
header = '         '
for k in keys:
    header += f'{k:>8}'
print(header)
for k1 in keys:
    row = f'{k1:>8}'
    for k2 in keys:
        c = np.corrcoef(subs[k1], subs[k2])[0,1]
        row += f'{c:>8.4f}'
    print(row)

# Generate blends for safe models with low correlation
print()
print('=== Generating blends ===')

v96 = subs.get('V96')

# V181 (MSC) blends
if 'V181' in subs and v96 is not None:
    corr = np.corrcoef(np.array(v96.values), np.array(subs['V181'].values))[0,1]
    print(f'V181 (MSC, CV=174.76, corr={corr:.4f}):')
    if corr < 0.995:
        for w96, w181, vid in [(0.90, 0.10, 'v196'), (0.80, 0.20, 'v197')]:
            desc = f'V96 {w96*100:.0f}% + V181 {w181*100:.0f}%. V181=MSC preprocessing (CV=174.76, corr={corr:.4f}).'
            print(f'  {vid}: V96 {w96*100:.0f}% + V181 {w181*100:.0f}%')
            pack_blend(f'{vid}_blend_v96_v181_{int(w96*100)}{int(w181*100)}',
                       [('v96_blend_v74_v72_7525', w96), ('v181_msc_a005_linear', w181)],
                       desc)
    else:
        print(f'  corr too high ({corr:.4f}), skip')

# V184 (deriv1) blends
if 'V184' in subs and v96 is not None:
    corr = np.corrcoef(np.array(v96.values), np.array(subs['V184'].values))[0,1]
    print(f'V184 (deriv1, CV=170.87, corr={corr:.4f}):')
    if corr < 0.995:
        for w96, w184, vid in [(0.90, 0.10, 'v198'), (0.80, 0.20, 'v199')]:
            desc = f'V96 {w96*100:.0f}% + V184 {w184*100:.0f}%. V184=first derivative (CV=170.87, corr={corr:.4f}).'
            print(f'  {vid}: V96 {w96*100:.0f}% + V184 {w184*100:.0f}%')
            pack_blend(f'{vid}_blend_v96_v184_{int(w96*100)}{int(w184*100)}',
                       [('v96_blend_v74_v72_7525', w96), ('v184_deriv1_a005_linear', w184)],
                       desc)
    else:
        print(f'  corr too high ({corr:.4f}), skip')

# V181 with V63
if 'V181' in subs and 'V63' in subs:
    corr_v63 = np.corrcoef(np.array(subs['V63'].values), np.array(subs['V181'].values))[0,1]
    print(f'corr(V63, V181) = {corr_v63:.6f}')
    if corr_v63 < 0.99:
        for w63, w181, vid in [(0.80, 0.20, 'v200')]:
            desc = f'V63 {w63*100:.0f}% + V181 {w181*100:.0f}%. corr={corr_v63:.4f}.'
            print(f'  {vid}: V63 {w63*100:.0f}% + V181 {w181*100:.0f}%')
            pack_blend(f'{vid}_blend_v63_v181_{int(w63*100)}{int(w181*100)}',
                       [('v63_isotonic', w63), ('v181_msc_a005_linear', w181)],
                       desc)

# V184 with V63
if 'V184' in subs and 'V63' in subs:
    corr_v63 = np.corrcoef(np.array(subs['V63'].values), np.array(subs['V184'].values))[0,1]
    print(f'corr(V63, V184) = {corr_v63:.6f}')
    if corr_v63 < 0.99:
        for w63, w184, vid in [(0.80, 0.20, 'v201')]:
            desc = f'V63 {w63*100:.0f}% + V184 {w184*100:.0f}%. corr={corr_v63:.4f}.'
            print(f'  {vid}: V63 {w63*100:.0f}% + V184 {w184*100:.0f}%')
            pack_blend(f'{vid}_blend_v63_v184_{int(w63*100)}{int(w184*100)}',
                       [('v63_isotonic', w63), ('v184_deriv1_a005_linear', w184)],
                       desc)

# Fine-grained V74+V72 ratios
print()
print('=== Fine-grained V74+V72 ratio scan ===')
v74_name = 'v74_blend_v61_v63_5050'
v72_name = 'v72_isotonic_a005'
v74 = load_sub(v74_name)
v72 = load_sub(v72_name)
if v74 is not None and v72 is not None:
    for w74, w72, vid in [(0.72, 0.28, 'v187'), (0.73, 0.27, 'v188'),
                           (0.77, 0.23, 'v189'), (0.78, 0.22, 'v190')]:
        desc = f'V74 {w74*100:.0f}% + V72 {w72*100:.0f}%. Fine scan around V96(75/25)=196.98.'
        print(f'  {vid}: V74 {w74*100:.0f}% + V72 {w72*100:.0f}%')
        pack_blend(f'{vid}_blend_v74_v72_{int(w74*100)}{int(w72*100)}',
                   [(v74_name, w74), (v72_name, w72)],
                   desc)
else:
    print(f'  V74 found: {v74 is not None}, V72 found: {v72 is not None}')

# Three-way weight optimization
print()
print('=== Three-way V61+V63+V72 weight optimization ===')
for w61, w63, w72_val, vid in [(0.35, 0.35, 0.30, 'v191'), (0.40, 0.40, 0.20, 'v192'),
                                (0.30, 0.30, 0.40, 'v193'), (0.45, 0.35, 0.20, 'v194'),
                                (0.35, 0.45, 0.20, 'v195')]:
    desc = f'3-way: V61({w61*100:.0f}%) + V63({w63*100:.0f}%) + V72({w72_val*100:.0f}%).'
    print(f'  {vid}: V61 {w61*100:.0f}% + V63 {w63*100:.0f}% + V72 {w72_val*100:.0f}%')
    pack_blend(f'{vid}_blend_3way_v61_v63_v72_{int(w61*100)}{int(w63*100)}{int(w72_val*100)}',
               [('v61_a005_bias', w61), ('v63_isotonic', w63), ('v72_isotonic_a005', w72_val)],
               desc)

# V181 + V74 (replace V72)
print()
print('=== V74 + V181 (replace V72 with MSC model) ===')
if v74 is not None and 'V181' in subs:
    corr_v74 = np.corrcoef(np.array(v74.values), np.array(subs['V181'].values))[0,1]
    print(f'corr(V74, V181) = {corr_v74:.6f}')
    for w74, w181, vid in [(0.90, 0.10, 'v202'), (0.85, 0.15, 'v203')]:
        desc = f'V74 {w74*100:.0f}% + V181 {w181*100:.0f}%. V181 replaces V72 (corr={corr_v74:.4f} vs V72 corr=0.998).'
        print(f'  {vid}: V74 {w74*100:.0f}% + V181 {w181*100:.0f}%')
        pack_blend(f'{vid}_blend_v74_v181_{int(w74*100)}{int(w181*100)}',
                   [(v74_name, w74), ('v181_msc_a005_linear', w181)],
                   desc)

# V184 + V74
print()
print('=== V74 + V184 (replace V72 with deriv1 model) ===')
if v74 is not None and 'V184' in subs:
    corr_v74 = np.corrcoef(np.array(v74.values), np.array(subs['V184'].values))[0,1]
    print(f'corr(V74, V184) = {corr_v74:.6f}')
    for w74, w184, vid in [(0.90, 0.10, 'v204'), (0.85, 0.15, 'v205')]:
        desc = f'V74 {w74*100:.0f}% + V184 {w184*100:.0f}%. V184 replaces V72 (corr={corr_v74:.4f}).'
        print(f'  {vid}: V74 {w74*100:.0f}% + V184 {w184*100:.0f}%')
        pack_blend(f'{vid}_blend_v74_v184_{int(w74*100)}{int(w184*100)}',
                   [(v74_name, w74), ('v184_deriv1_a005_linear', w184)],
                   desc)

print()
print('=== All done ===')
