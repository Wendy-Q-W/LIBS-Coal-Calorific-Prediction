"""
exp_v162_v175_pipeline_variants.py

V146(PCA-only) online=282.70, gap=120. Removing hand features = disaster.
V105(BR) online=261.90, gap=110. Changing model type = disaster.
All low-corr variants have terrible online scores.

Strategy: Stay within V61's proven pipeline (SNV+PCA+hand features+two-stage Ridge).
Make SMALL changes that might shift prediction pattern enough for corr<0.99
while keeping CV in 170-185 safe zone.

V162: PCA(15) + hand features (fewer spectral components)
V163: PCA(20) + hand features
V164: PCA(40) + hand features (more components)
V165: Only hand features, no PCA (pure domain knowledge)
V166: Detrended SNV (remove linear trend before SNV)
V167: alpha=0.03 + isotonic (between V61 and V63)
V168: alpha=0.07 + isotonic
V169: alpha=0.05 + isotonic + no bias (V72 variant)
V170: Enhanced hand features (add C/H, C/O, ash/volatile ratios)
"""
import os, sys, re, glob, warnings, io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten, enhanced=False):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    
    if enhanced:
        # Add physically meaningful ratios
        c_line = labs[0] + 1e-8  # C
        h_line = labs[1] + 1e-8  # H
        o_line = labs[2] + 1e-8  # O
        n_line = labs[3] + 1e-8  # N
        ca_line = labs[4] + labs[5] + 1e-8  # Ca + Ca2
        fe_line = labs[9] + 1e-8  # Fe
        si_line = labs[7] + 1e-8  # Si
        al_line = labs[8] + 1e-8  # Al (index 8 is Al)
        mg_line = labs[6] + 1e-8  # Mg (index 6)
        
        enhanced_rats = np.array([
            c_line / h_line,       # C/H ratio
            c_line / o_line,       # C/O ratio
            h_line / o_line,       # H/O ratio
            c_line / n_line,       # C/N ratio
            ca_line / fe_line,     # Ca/Fe ratio
            si_line / al_line,     # Si/Al ratio
            (c_line + h_line) / (o_line + n_line),  # organic/inorganic
            ash_sum / (comb_sum + 1e-8),  # ash/combustible
            np.log1p(c_line),      # log C
            np.log1p(h_line),      # log H
        ], dtype=np.float32)
        return inten_norm, stats, labs, lrel, np.concatenate([rats, enhanced_rats])
    
    return inten_norm, stats, labs, lrel, rats


def compute_features(data, enhanced=False):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        # SNV or detrended SNV
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(snv)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten, enhanced=enhanced)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def compute_features_detrended(data):
    """Detrended SNV: remove linear trend then SNV"""
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        # Remove linear trend
        n = len(inten)
        x = np.arange(n, dtype=np.float32)
        coeffs = np.polyfit(x, inten, 1)
        trend = np.polyval(coeffs, x)
        detrended = inten - trend
        # Then SNV
        snv = (detrended - detrended.mean()) / (detrended.std() + 1e-8)
        spec_mats.append(snv)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=30, use_pca=True, use_hand=True):
    spec_mat = data.get('_spec_mat')
    
    if use_pca:
        if fit:
            scaler_spec = StandardScaler()
            spec_scaled = scaler_spec.fit_transform(spec_mat)
            n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
            n_pca = max(1, n_pca)
            pca = PCA(n_components=n_pca, random_state=42)
            spec_pca = pca.fit_transform(spec_scaled)
        else:
            spec_pca = pca.transform(scaler_spec.transform(spec_mat))
    else:
        spec_pca = np.zeros((spec_mat.shape[0], 0), dtype=np.float32)
    
    if use_hand:
        hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
        X = np.hstack([spec_pca, hand_feats]) if use_pca else hand_feats
    else:
        X = spec_pca
    
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def batch_aggregate(preds_mask, method='median'):
    if method == 'median':
        return float(np.median(preds_mask))
    elif method == 'mean':
        return float(np.mean(preds_mask))
    elif method == 'trimmed':
        n = len(preds_mask)
        if n <= 2:
            return float(np.mean(preds_mask))
        k = max(1, n // 5)
        sorted_p = np.sort(preds_mask)
        return float(np.mean(sorted_p[k:-k]))
    return float(np.median(preds_mask))


def find_best_shrinkage(oof_preds, oof_true, coal_center, force_w=None):
    if force_w is not None:
        blended = force_w * np.array(oof_preds) + (1 - force_w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        return force_w, rmse
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.05,
                  aggregation='median', force_shrink_w=None,
                  use_two_stage=True):
    def fit_ridge(m, X_tr, y_tr, sw=None):
        if sw is not None:
            m.fit(X_tr, y_tr, sample_weight=sw)
        else:
            m.fit(X_tr, y_tr)

    if use_two_stage:
        aux_models = {}
        predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
        for col_idx, col_name in enumerate(AUX_COLS):
            y_aux = aux[:, col_idx]
            if np.isnan(y_aux).any():
                predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
                aux_models[col_name] = None
                continue
            m = Ridge(alpha=ridge_alpha)
            oof = np.zeros(len(y_aux))
            for tr_idx, val_idx in splits:
                fit_ridge(m, X[tr_idx], y_aux[tr_idx], sample_weights[tr_idx] if sample_weights is not None else None)
                oof[val_idx] = m.predict(X[val_idx])
            predicted_aux_oof[:, col_idx] = oof
            m_full = Ridge(alpha=ridge_alpha)
            fit_ridge(m_full, X, y_aux, sample_weights)
            aux_models[col_name] = m_full
        X_s2 = np.hstack([X, predicted_aux_oof])
    else:
        aux_models = {}
        X_s2 = X.copy()

    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha)
        fit_ridge(m2, X_s2[tr_idx], y[tr_idx], sample_weights[tr_idx] if sample_weights is not None else None)
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask], aggregation)
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_center, force_w=force_shrink_w)

    final_model = Ridge(alpha=ridge_alpha)
    fit_ridge(final_model, X_s2, y, sample_weights)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center, aggregation='median'):
    n_test = len(X_test)
    use_two_stage = len(run['aux_models']) > 0
    if use_two_stage:
        pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
        for col_idx, col_name in enumerate(AUX_COLS):
            m = run['aux_models'].get(col_name)
            if m is not None:
                pred_aux[:, col_idx] = m.predict(X_test)
        X_test_s = run['scaler_s2'].transform(
            np.nan_to_num(np.hstack([X_test, pred_aux])))
    else:
        X_test_s = run['scaler_s2'].transform(np.nan_to_num(X_test))
    preds = run['final_model'].predict(X_test_s)
    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = batch_aggregate(preds[mask], aggregation)
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


def train_and_predict_coal(coal, label_map, aux_map,
                           ridge_alpha=0.05, calibration='linear',
                           n_pca_max=30, use_pca=True, use_hand=True,
                           aggregation='median', preprocessing='snv',
                           enhanced_features=False, force_shrink_w=None,
                           use_two_stage=True):
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    if preprocessing == 'detrended_snv':
        spec_mat = compute_features_detrended(train_data)
    else:
        spec_mat = compute_features(train_data, enhanced=enhanced_features)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True, n_pca_max=n_pca_max,
        use_pca=use_pca, use_hand=use_hand)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(
            X, y, aux, groups, splits, coal_center, n_batches,
            sample_weights, ridge_alpha, aggregation, force_shrink_w,
            use_two_stage)
        runs.append(run)

    if is_small:
        r = runs[0]
        print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
              f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
    else:
        cv_rmses = [r['cv_rmse'] for r in runs]
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
              f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])

    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
        print(f"    Bias: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)

    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    if preprocessing == 'detrended_snv':
        test_spec_mat = compute_features_detrended(test_data)
    else:
        test_spec_mat = compute_features(test_data, enhanced=enhanced_features)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False,
        n_pca_max=n_pca_max, use_pca=use_pca, use_hand=use_hand)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center, aggregation)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))
        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])
        test_preds[name] = pred_val

    return {'cv_rmse': cv_rmse, 'test_preds': test_preds}


def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n\n"
    readme += "## CV-RMSE\n\n| 煤种 | CV-RMSE |\n|---|---|\n"
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        csv_content = zf.read('submit/submit.csv')
        df = pd.read_csv(io.BytesIO(csv_content), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, {}, desc)


def run_experiment(vid, desc, **kwargs):
    print(f"\n{'=' * 70}")
    print(f"  {vid}: {desc}")
    print(f"{'=' * 70}")
    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}
    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map, **kwargs)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")
    return pack_submission(vid, all_preds, cv_results, desc)


if __name__ == '__main__':
    results = {}

    # V162: PCA(15) + hand features
    _, cv = run_experiment(
        'v162_pca15_a005_linear',
        "PCA(15) + hand features. Fewer spectral components, keep domain knowledge.",
        ridge_alpha=0.05, calibration='linear', n_pca_max=15, use_pca=True, use_hand=True)
    results['v162'] = cv

    # V163: PCA(20) + hand features
    _, cv = run_experiment(
        'v163_pca20_a005_linear',
        "PCA(20) + hand features. Moderate spectral components.",
        ridge_alpha=0.05, calibration='linear', n_pca_max=20, use_pca=True, use_hand=True)
    results['v163'] = cv

    # V164: Only hand features, no PCA
    _, cv = run_experiment(
        'v164_hand_only_a005_linear',
        "Only hand features, no PCA. Pure domain knowledge approach.",
        ridge_alpha=0.05, calibration='linear', use_pca=False, use_hand=True)
    results['v164'] = cv

    # V165: Detrended SNV + PCA(30) + hand features
    _, cv = run_experiment(
        'v165_detrended_snv_a005_linear',
        "Detrended SNV (remove linear trend then SNV) + PCA(30) + hand features.",
        ridge_alpha=0.05, calibration='linear', n_pca_max=30,
        use_pca=True, use_hand=True, preprocessing='detrended_snv')
    results['v165'] = cv

    # V166: alpha=0.03 + isotonic
    _, cv = run_experiment(
        'v166_a003_isotonic',
        "alpha=0.03 + isotonic calibration. Between V61(0.05,linear) and V63(0.1,isotonic).",
        ridge_alpha=0.03, calibration='isotonic', n_pca_max=30,
        use_pca=True, use_hand=True)
    results['v166'] = cv

    # V167: alpha=0.07 + isotonic
    _, cv = run_experiment(
        'v167_a007_isotonic',
        "alpha=0.07 + isotonic calibration.",
        ridge_alpha=0.07, calibration='isotonic', n_pca_max=30,
        use_pca=True, use_hand=True)
    results['v167'] = cv

    # V168: Enhanced hand features (add physical ratios)
    _, cv = run_experiment(
        'v168_enhanced_features_a005_linear',
        "Enhanced hand features: add C/H, C/O, ash/combustible ratios + log transforms.",
        ridge_alpha=0.05, calibration='linear', n_pca_max=30,
        use_pca=True, use_hand=True, enhanced_features=True)
    results['v168'] = cv

    # V169: alpha=0.05 + isotonic + no bias (check if V72 variant differs)
    _, cv = run_experiment(
        'v169_a005_isotonic_nobias',
        "alpha=0.05 + isotonic + no linear bias. V72 variant without bias step.",
        ridge_alpha=0.05, calibration='isotonic', n_pca_max=30,
        use_pca=True, use_hand=True)
    results['v169'] = cv

    # Summary
    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Baselines:")
    print(f"    V61 (alpha=0.05, linear):     CV=172.15  Online=203.21  gap=31")
    print(f"    V63 (alpha=0.1, isotonic):    CV=183.50  Online=203.60  gap=20")
    print(f"    V72 (alpha=0.05, isotonic):   CV=??      Online=??")
    print(f"    V96 (V74+V72 75/25):          Online=196.98 (BEST)")
    print(f"    V105 (BayesianRidge):         CV=151.98  Online=261.90  gap=110")
    print(f"    V146 (PCA-only):              CV=162.76  Online=282.70  gap=120")
    print()
    for name, cv in results.items():
        if 165 <= cv <= 195:
            status = "SAFE"
        elif cv < 165:
            status = "OVERFIT?"
        else:
            status = "UNDERFIT?"
        print(f"    {name}: CV={cv:.2f}  [{status}]")
    print()

    # Correlation analysis with V96 and V61
    print("  Correlation analysis:")
    v96 = load_existing_submission('submit_v96_blend_v74_v72_7525.zip')
    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')
    v72 = load_existing_submission('submit_v72_isotonic_a005.zip')
    refs = {'V96': v96, 'V61': v61, 'V63': v63, 'V72': v72}
    
    for vid, cv in results.items():
        sub = load_existing_submission(f'submit_{vid}.zip')
        if sub is None:
            continue
        sub_arr = np.array(sub.values)
        corrs = {}
        for ref_name, ref in refs.items():
            if ref is not None:
                ref_arr = np.array(ref.values)
                c = np.corrcoef(ref_arr, sub_arr)[0, 1]
                corrs[ref_name] = c
        
        corr_v96 = corrs.get('V96', 1.0)
        corr_v61 = corrs.get('V61', 1.0)
        min_corr = min(corrs.values())
        min_ref = min(corrs, key=corrs.get)
        
        blend_ok = "BLEND OK" if (165 <= cv <= 195 and corr_v96 < 0.995) else "SKIP"
        print(f"    {vid}: CV={cv:.2f}  corr(V96)={corr_v96:.4f}  corr(V61)={corr_v61:.4f}  "
              f"min_corr={min_corr:.4f}({min_ref})  [{blend_ok}]")

    # Auto-generate blends for promising models
    print()
    print("  Auto-generating blends for promising models (CV 170-195, corr(V96)<0.995)...")
    if v96 is not None:
        v96_arr = np.array(v96.values)
        for vid, cv in results.items():
            if not (170 <= cv <= 195):
                print(f"    {vid}: CV={cv:.2f} outside 170-195 range, skip")
                continue
            sub = load_existing_submission(f'submit_{vid}.zip')
            if sub is None:
                continue
            sub_arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, sub_arr)[0, 1]
            if corr >= 0.995:
                print(f"    {vid}: corr={corr:.4f} too high, skip")
                continue
            
            print(f"    {vid}: CV={cv:.2f}, corr={corr:.4f} -> GENERATING BLENDS")
            v96_name = 'v96_blend_v74_v72_7525'
            for w96, w_new in [(0.90, 0.10), (0.80, 0.20), (0.70, 0.30)]:
                blend_name = f'{vid}_blend_v96_{vid}_{int(w96*100)}{int(w_new*100)}'
                desc = f"V96 {w96*100:.0f}% + {vid} {w_new*100:.0f}%. CV={cv:.2f}, corr={corr:.4f}."
                pack_blend(blend_name,
                           [(v96_name, w96), (vid, w_new)],
                           desc)
    print("\n  Done.")
