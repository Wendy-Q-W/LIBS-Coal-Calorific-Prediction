"""
exp_v30_truncate_bias.py
方向一: 极端时间截断 (Only-November / Only-Oct+Nov)
方向三: 线性偏差校正 (Bias Correction)
"""
import os, sys, re, glob, warnings, copy
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 5.0),
    'H':   (656.30, 7.5),
    'O':   (777.20, 7.5),
    'N':   (742.40, 5.0),
    'Ca':  (422.70, 1.0),
    'Ca2': (393.40, 1.0),
    'Mg':  (285.20, 1.0),
    'Al':  (308.20, 1.0),
    'Si':  (288.20, 1.0),
    'Fe':  (438.40, 1.5),
    'Na':  (589.00, 0.75),
}

N_PCA_MAX = 30
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 100
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))

TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤': 30,
}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None,
                      month_filter=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        month = extract_month(date_str)
        if month_filter is not None and month not in month_filter:
            continue
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features(wl, inten)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return inorm_mat


def build_feature_matrix(data, n_batches,
                         scaler_spec=None, pca=None, scaler_hand=None, fit=True):
    inorm_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                   sample_weights=None):
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)

    final_model = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def train_coal_gk(coal_type, train_data):
    """GroupKFold CV (V28 baseline)."""
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)
    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        months = train_data.get('months')
        if months is not None and len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                             sample_weights=sample_weights)
        return run, is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                                 sample_weights=sample_weights)
            runs.append(run)
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_coal_te(coal_type, train_data):
    """Time extrapolation CV: train on 10/11月, validate on 1/2/3月."""
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    months = train_data['months']
    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    # Apply time weighting on training samples
    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sw = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)
        # Normalize so mean=1
        sample_weights = sw

    # Stage 1: aux OOF on TE split
    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    aux_models = {}
    predicted_aux_val = np.zeros((len(val_idx), len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_val[:, col_idx] = float(np.nanmean(y_aux[tr_idx]))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights)
        else:
            m.fit(X_spec[tr_idx], y_aux[tr_idx])
        predicted_aux_val[:, col_idx] = m.predict(X_spec[val_idx])
        aux_models[col_name] = m

    # Stage 2: train uses true aux for tr subset, val uses predicted aux
    X_s2_tr = np.hstack([X_spec[tr_idx], aux[tr_idx, :]])
    X_s2_tr = np.nan_to_num(X_s2_tr)
    X_s2_val = np.hstack([X_spec[val_idx], predicted_aux_val])
    X_s2_val = np.nan_to_num(X_s2_val)

    scaler_s2 = StandardScaler()
    X_s2_tr_s = scaler_s2.fit_transform(X_s2_tr)
    X_s2_val_s = scaler_s2.transform(X_s2_val)

    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sample_weights)
    else:
        m2.fit(X_s2_tr_s, y[tr_idx])

    val_pred = m2.predict(X_s2_val_s)
    val_groups = groups[val_idx]

    oof_preds, oof_true = [], []
    for bg in np.unique(val_groups):
        mask = val_groups == bg
        if mask.sum() == 0:
            continue
        true_q = float(y[val_idx][mask][0])
        pred_q = float(np.median(val_pred[mask]))
        oof_preds.append(pred_q)
        oof_true.append(true_q)

    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)

    # Raw RMSE
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))

    # With shrinkage
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)

    return {
        'oof_preds': oof_preds,
        'oof_true': oof_true,
        'rmse_raw': rmse_raw,
        'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w,
        'coal_mean': coal_mean,
    }


def gk_cv_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    else:
        return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


def collect_gk_oof(runs_or_run, is_small):
    """Collect OOF predictions from GK-CV."""
    if is_small:
        return runs_or_run['oof_preds'], runs_or_run['oof_true']
    else:
        # Average across seeds (same batches)
        all_preds = [r['oof_preds'] for r in runs_or_run]
        all_true = [r['oof_true'] for r in runs_or_run]
        # They should be same length and same order
        avg_preds = np.mean(all_preds, axis=0)
        return avg_preds, all_true[0]


def main():
    print("=" * 70)
    print("Experiment: V30 - Truncation + Bias Correction")
    print("=" * 70)

    label_map, aux_map = load_labels()

    # ================================================================
    # Part 1: V28 Baseline GK-CV + TE-CV
    # ================================================================
    print("\n" + "=" * 70)
    print("Part 1: V28 Baseline (GK-CV + TE-CV)")
    print("=" * 70)

    v28_gk_results = {}
    v28_te_results = {}
    v28_gk_oof = {}

    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None or train_data['n_batches'] == 0:
            print(f"  [{coal_type}] No data, skip")
            continue

        n_batches = train_data['n_batches']
        print(f"\n  [{coal_type}] {n_batches} batches, {len(train_data['targets'])} spectra")

        # GK-CV
        runs, is_small = train_coal_gk(coal_type, train_data)
        gk_rmse = gk_cv_rmse(runs, is_small)
        v28_gk_results[coal_type] = gk_rmse
        gk_pred, gk_true = collect_gk_oof(runs, is_small)
        v28_gk_oof[coal_type] = (gk_pred, gk_true)
        print(f"    GK-CV: {gk_rmse:.2f}  ({'LOOCV' if is_small else '100-seed'})")

        # TE-CV
        te_result = train_coal_te(coal_type, train_data)
        if te_result is not None:
            v28_te_results[coal_type] = te_result
            print(f"    TE-CV: raw={te_result['rmse_raw']:.2f}  "
                  f"shrunk={te_result['rmse_shrunk']:.2f}  w={te_result['shrink_w']:.2f}")
        else:
            print(f"    TE-CV: N/A (no 10/11 or 1/2/3 month data)")

    gk_avg = float(np.mean(list(v28_gk_results.values())))
    te_rmses = [r['rmse_shrunk'] for r in v28_te_results.values()]
    te_avg = float(np.mean(te_rmses)) if te_rmses else 0
    print(f"\n  V28 Baseline: GK={gk_avg:.2f}  TE={te_avg:.2f}")

    # ================================================================
    # Part 2: Extreme Time Truncation
    # ================================================================
    print("\n" + "=" * 70)
    print("Part 2: Extreme Time Truncation")
    print("=" * 70)

    truncation_configs = [
        ("Only-Nov (11)", {11}),
        ("Oct+Nov (10,11)", {10, 11}),
        ("Oct+Nov+Jan (10,11,1)", {10, 11, 1}),
    ]

    for config_name, month_set in truncation_configs:
        print(f"\n  --- {config_name} ---")
        trunc_gk = {}
        trunc_te = {}

        for coal_type in COAL_TYPES:
            train_data = load_coal_spectra(
                TRAIN_DIR, coal_type, label_map, aux_map, month_filter=month_set)
            if train_data is None or train_data['n_batches'] == 0:
                print(f"    [{coal_type}] No data after filter, skip")
                continue

            n_batches = train_data['n_batches']
            if n_batches < 3:
                print(f"    [{coal_type}] Only {n_batches} batches, skip")
                continue

            # GK-CV (no time weighting since we're filtering by month)
            runs, is_small = train_coal_gk(coal_type, train_data)
            gk_rmse = gk_cv_rmse(runs, is_small)
            trunc_gk[coal_type] = gk_rmse
            print(f"    [{coal_type}] {n_batches}b  GK={gk_rmse:.2f}")

        if trunc_gk:
            avg = float(np.mean(list(trunc_gk.values())))
            print(f"    >> {config_name} GK-Avg: {avg:.2f}  "
                  f"(V28 baseline: {gk_avg:.2f})")
        else:
            print(f"    >> {config_name}: No valid results")

    # ================================================================
    # Part 3: Linear Bias Correction
    # ================================================================
    print("\n" + "=" * 70)
    print("Part 3: Linear Bias Correction (on GK-CV OOF)")
    print("=" * 70)

    # Collect all OOF predictions across coal types
    all_pred = []
    all_true = []
    for coal_type in COAL_TYPES:
        if coal_type in v28_gk_oof:
            p, t = v28_gk_oof[coal_type]
            all_pred.extend(p.tolist())
            all_true.extend(t.tolist())
            print(f"  [{coal_type}] {len(p)} batches  "
                  f"bias={np.mean(p - t):.2f}  "
                  f"ratio={np.mean(p)/np.mean(t):.4f}")

    all_pred = np.array(all_pred)
    all_true = np.array(all_true)

    # Global bias correction
    lr = LinearRegression()
    lr.fit(all_pred.reshape(-1, 1), all_true)
    a, b = lr.coef_[0], lr.intercept_
    corrected = a * all_pred + b
    rmse_before = float(np.sqrt(np.mean((all_pred - all_true) ** 2)))
    rmse_after = float(np.sqrt(np.mean((corrected - all_true) ** 2)))
    print(f"\n  Global Bias Correction:")
    print(f"    a={a:.4f}  b={b:.2f}")
    print(f"    RMSE: {rmse_before:.2f} -> {rmse_after:.2f}  "
          f"(diff={rmse_after - rmse_before:.2f})")

    # Per-coal-type bias correction
    print(f"\n  Per-Coal-Type Bias Correction:")
    pc_before_total = []
    pc_after_total = []
    for coal_type in COAL_TYPES:
        if coal_type not in v28_gk_oof:
            continue
        p, t = v28_gk_oof[coal_type]
        if len(p) < 3:
            print(f"    [{coal_type}] Only {len(p)} batches, skip (too few for fit)")
            continue
        lr = LinearRegression()
        lr.fit(p.reshape(-1, 1), t)
        a_c, b_c = lr.coef_[0], lr.intercept_
        corr = a_c * p + b_c
        rmse_b = float(np.sqrt(np.mean((p - t) ** 2)))
        rmse_a = float(np.sqrt(np.mean((corr - t) ** 2)))
        print(f"    [{coal_type}] a={a_c:.4f} b={b_c:.2f}  "
              f"RMSE: {rmse_b:.2f} -> {rmse_a:.2f}  (diff={rmse_a - rmse_b:.2f})")
        pc_before_total.extend((p - t).tolist())
        pc_after_total.extend((corr - t).tolist())

    # ================================================================
    # Part 4: Bias Correction on TE-CV
    # ================================================================
    print("\n" + "=" * 70)
    print("Part 4: Bias Correction on TE-CV OOF")
    print("=" * 70)

    te_all_pred = []
    te_all_true = []
    for coal_type, te_r in v28_te_results.items():
        te_all_pred.extend(te_r['oof_preds'].tolist())
        te_all_true.extend(te_r['oof_true'].tolist())

    te_all_pred = np.array(te_all_pred)
    te_all_true = np.array(te_all_true)

    lr = LinearRegression()
    lr.fit(te_all_pred.reshape(-1, 1), te_all_true)
    a_te, b_te = lr.coef_[0], lr.intercept_
    corr_te = a_te * te_all_pred + b_te
    rmse_te_before = float(np.sqrt(np.mean((te_all_pred - te_all_true) ** 2)))
    rmse_te_after = float(np.sqrt(np.mean((corr_te - te_all_true) ** 2)))
    print(f"  TE-CV Global: a={a_te:.4f}  b={b_te:.2f}")
    print(f"    RMSE: {rmse_te_before:.2f} -> {rmse_te_after:.2f}  "
          f"(diff={rmse_te_after - rmse_te_before:.2f})")

    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print(f"  V28 Baseline:  GK={gk_avg:.2f}  TE={te_avg:.2f}")
    print(f"  Global BC (GK): {rmse_before:.2f} -> {rmse_after:.2f}")
    print(f"  Global BC (TE): {rmse_te_before:.2f} -> {rmse_te_after:.2f}")
    print(f"\n  NOTE: GK-CV bias correction may not transfer to test set")
    print(f"  (test set is Dec, GK-CV mixes all months)")


if __name__ == "__main__":
    main()
