"""
exp_v48_augment.py
Phase 3: Data Augmentation for LIBS Spectra

TE-CV and GK-CV are both anti-correlated now. No CV metric can guide us.
The ONLY path forward: augment training data to improve generalization,
then submit and let the leaderboard be the judge.

Augmentation strategies (physically motivated for LIBS):
1. Gaussian noise injection — simulates detector noise
2. Intensity scaling — simulates laser energy fluctuations (multiplicative)
3. Wavelength shift — simulates spectrometer calibration drift
4. Baseline shift — simulates continuum emission variation
5. Mixup — interpolate between spectra of same coal type

All augmentations applied at SPECTRUM level (before feature extraction).
Labels stay the same (augmented spectra share the original batch label).

Generate 3 submissions:
  V48a: Gaussian noise (sigma=0.01 * max_intensity)
  V48b: Intensity scaling (factor 0.9-1.1, 5x augmentation)
  V48c: Mixup (alpha=0.2, 2x augmentation)
"""
import os, sys, re, glob, warnings, json
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
import zipfile

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
RIDGE_ALPHA = 0.1
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}

# ── Data loading ───────────────────────────────────────────────────────────

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5: continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except:
        return None, None
    if not wl: return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights

def load_labels():
    label_map, aux_map = {}, {}
    for coal in COAL_TYPES:
        fp = os.path.join(LABEL_DIR, f"{coal}.xlsx")
        if not os.path.exists(fp): continue
        df = pd.read_excel(fp)
        for _, row in df.iterrows():
            name = str(row['名称']).strip()
            q = float(row['发热量(Q)'])
            label_map[(coal, name)] = q
            aux = {
                '全水分': float(row.get('全水分', np.nan)),
                '灰分':   float(row.get('灰分', np.nan)),
                '氢':     float(row.get('氢', np.nan)),
                '硫':     float(row.get('硫', np.nan)),
            }
            aux_map[(coal, name)] = aux
    return label_map, aux_map

def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None, is_train=True):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir): return None
    spectra, names, targets, auxs, groups, months = [], [], [], [], [], []
    batch_idx = 0
    for batch_dir in sorted(os.listdir(coal_dir)):
        full = os.path.join(coal_dir, batch_dir)
        if not os.path.isdir(full): continue
        date_part = batch_dir.replace(coal_type, '').strip()
        month = extract_month(date_part)
        csvs = sorted(glob.glob(os.path.join(full, "*.csv")))
        if not csvs: continue
        for csv_path in csvs:
            wl, inten = read_spectrum_csv(csv_path)
            if wl is None: continue
            spectra.append((wl, inten))
            names.append(date_part)
            groups.append(batch_idx)
            months.append(month)
            if is_train and label_map:
                key = (coal_type, date_part)
                targets.append(label_map.get(key, np.nan))
                if aux_map and key in aux_map:
                    auxs.append(aux_map[key])
                else:
                    auxs.append({'全水分': np.nan, '灰分': np.nan, '氢': np.nan, '硫': np.nan})
        batch_idx += 1
    return {
        'spectra': spectra, 'names': names,
        'targets': np.array(targets, dtype=np.float64) if targets else None,
        'aux': auxs, 'groups': np.array(groups),
        'n_batches': batch_idx, 'months': np.array(months),
    }

# ── Augmentation ───────────────────────────────────────────────────────────

def augment_noise(spectra, targets, auxs, groups, months, names, sigma_frac=0.01, n_aug=1):
    """Gaussian noise injection: I' = I + N(0, sigma * max(I))"""
    aug_spectra, aug_targets, aug_auxs, aug_groups, aug_months, aug_names = [], [], [], [], [], []
    for i, (wl, inten) in enumerate(spectra):
        for _ in range(n_aug):
            sigma = sigma_frac * inten.max()
            noise = np.random.normal(0, sigma, len(inten)).astype(np.float32)
            inten_aug = np.clip(inten + noise, 0, None).astype(np.float32)
            aug_spectra.append((wl, inten_aug))
            aug_targets.append(targets[i])
            aug_auxs.append(auxs[i])
            aug_groups.append(groups[i])
            aug_months.append(months[i])
            aug_names.append(names[i])
    return aug_spectra, np.array(aug_targets), aug_auxs, np.array(aug_groups), np.array(aug_months), aug_names

def augment_scaling(spectra, targets, auxs, groups, months, names, scale_range=(0.9, 1.1), n_aug=2):
    """Intensity scaling: I' = I * factor, factor ~ U(scale_range)"""
    aug_spectra, aug_targets, aug_auxs, aug_groups, aug_months, aug_names = [], [], [], [], [], []
    for i, (wl, inten) in enumerate(spectra):
        for _ in range(n_aug):
            factor = np.random.uniform(*scale_range)
            inten_aug = (inten * factor).astype(np.float32)
            aug_spectra.append((wl, inten_aug))
            aug_targets.append(targets[i])
            aug_auxs.append(auxs[i])
            aug_groups.append(groups[i])
            aug_months.append(months[i])
            aug_names.append(names[i])
    return aug_spectra, np.array(aug_targets), aug_auxs, np.array(aug_groups), np.array(aug_months), aug_names

def augment_mixup(spectra, targets, auxs, groups, months, names, alpha=0.2, n_aug=1):
    """Mixup: I' = lambda*I_a + (1-lambda)*I_b, lambda ~ Beta(alpha, alpha)
    Only mix spectra from same coal type (same batch group).
    """
    aug_spectra, aug_targets, aug_auxs, aug_groups, aug_months, aug_names = [], [], [], [], [], []
    n = len(spectra)
    for i in range(n):
        for _ in range(n_aug):
            # Pick a partner from the same batch
            same_batch = np.where(groups == groups[i])[0]
            if len(same_batch) <= 1:
                j = i
            else:
                j = np.random.choice(same_batch[same_batch != i])
            lam = np.random.beta(alpha, alpha)
            # Ensure lambda >= 0.5 (keep more of original)
            lam = max(lam, 1 - lam)
            wl = spectra[i][0]
            inten_mix = (lam * spectra[i][1] + (1 - lam) * spectra[j][1]).astype(np.float32)
            aug_spectra.append((wl, inten_mix))
            aug_targets.append(targets[i])  # Keep original label
            aug_auxs.append(auxs[i])
            aug_groups.append(groups[i])
            aug_months.append(months[i])
            aug_names.append(names[i])
    return aug_spectra, np.array(aug_targets), aug_auxs, np.array(aug_groups), np.array(aug_months), aug_names

# ── Feature extraction (V39 pipeline) ──────────────────────────────────────

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0

def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    snv = (inten - inten.mean()) / (inten.std() + 1e-8)

    d1 = np.diff(inten_norm)
    d2 = np.diff(d1)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        d1.std(), np.abs(d1).mean(),
        d2.std(), np.abs(d2).mean(),
    ], dtype=np.float32)

    labs = np.array([line_integral(wl, inten, c, w) for c, w in KEY_LINES.values()],
                    dtype=np.float32)
    lrel = labs / (total + 1e-8)

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum  = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    return snv, stats, labs, lrel, rats

def compute_features(spectra_list):
    min_len = min(len(s[1]) for s in spectra_list)
    snv_list, hand_list = [], []
    for wl, inten in spectra_list:
        inten_c = inten[:min_len].copy()
        wl_c = wl[:min_len].copy()
        snv, stats, labs, lrel, rats = spectrum_features(wl_c, inten_c)
        snv = np.nan_to_num(snv, nan=0.0, posinf=0.0, neginf=0.0)
        hand = np.concatenate([stats, labs, lrel, rats])
        hand = np.nan_to_num(hand, nan=0.0, posinf=0.0, neginf=0.0)
        snv_list.append(snv)
        hand_list.append(hand)
    return np.array(snv_list, dtype=np.float32), np.array(hand_list, dtype=np.float32)

def build_feature_matrix(snv_mat, hand_feats, fit=True, scaler_spec=None, pca=None, scaler_final=None):
    if fit:
        scaler_spec = StandardScaler()
        snv_scaled = scaler_spec.fit_transform(snv_mat)
        n_comp = min(N_PCA_MAX, snv_scaled.shape[0] - 1, snv_scaled.shape[1])
        pca = PCA(n_components=n_comp, random_state=42)
        snv_pca = pca.fit_transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        scaler_final = StandardScaler()
        X = scaler_final.fit_transform(X)
        return X, scaler_spec, pca, scaler_final
    else:
        snv_scaled = scaler_spec.transform(snv_mat)
        snv_pca = pca.transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        X = scaler_final.transform(X)
        return X

# ── Two-stage training (simplified from all_snv.py) ────────────────────────

def train_two_stage(X, y, aux_arr, groups, n_batches, sample_weights=None, seeds=[42]):
    """Two-stage training with optional ensemble. Returns final models + CV RMSE."""
    coal_mean = float(np.mean(y))
    n = len(y)

    # Fill NaN aux
    for j in range(aux_arr.shape[1]):
        col = aux_arr[:, j]
        mask = np.isnan(col)
        if mask.all():
            aux_arr[:, j] = 0.0
        elif mask.any():
            aux_arr[mask, j] = np.nanmean(col)

    all_runs = []
    for seed in seeds:
        if n_batches <= SMALL_BATCH_THRESHOLD:
            cv = LeaveOneGroupOut()
            splits = list(cv.split(X, y, groups))
        else:
            cv = GroupKFold(n_splits=5)
            splits = list(cv.split(X, y, groups))

        oof_preds = np.zeros(n)
        for tr_idx, val_idx in splits:
            # Stage 1
            aux_oof_val = np.zeros((len(val_idx), aux_arr.shape[1]))
            for j in range(aux_arr.shape[1]):
                m = Ridge(alpha=RIDGE_ALPHA)
                sw = sample_weights[tr_idx] if sample_weights is not None else None
                if sw is not None:
                    m.fit(X[tr_idx], aux_arr[tr_idx, j], sample_weight=sw)
                else:
                    m.fit(X[tr_idx], aux_arr[tr_idx, j])
                aux_oof_val[:, j] = m.predict(X[val_idx])

            # Stage 2
            X_s2_tr = np.hstack([X[tr_idx], aux_arr[tr_idx]])
            X_s2_val = np.hstack([X[val_idx], aux_oof_val])
            sc = StandardScaler()
            X_s2_tr_s = sc.fit_transform(X_s2_tr)
            X_s2_val_s = sc.transform(X_s2_val)

            m2 = Ridge(alpha=RIDGE_ALPHA)
            sw = sample_weights[tr_idx] if sample_weights is not None else None
            if sw is not None:
                m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sw)
            else:
                m2.fit(X_s2_tr_s, y[tr_idx])
            oof_preds[val_idx] = m2.predict(X_s2_val_s)

        # Batch RMSE
        batch_preds, batch_trues = [], []
        for b in range(n_batches):
            mask = groups == b
            if mask.sum() == 0: continue
            batch_preds.append(np.median(oof_preds[mask]))
            batch_trues.append(y[mask][0])
        batch_preds = np.array(batch_preds)
        batch_trues = np.array(batch_trues)
        rmse = np.sqrt(np.mean((batch_preds - batch_trues) ** 2))

        # Shrinkage
        best_w, best_rmse = 1.0, rmse
        for w in np.linspace(0, 1, 21):
            blended = w * batch_preds + (1 - w) * coal_mean
            r = np.sqrt(np.mean((blended - batch_trues) ** 2))
            if r < best_rmse:
                best_rmse = r
                best_w = w

        # Final model on all data
        aux_full = np.zeros((n, aux_arr.shape[1]))
        for j in range(aux_arr.shape[1]):
            m = Ridge(alpha=RIDGE_ALPHA)
            sw = sample_weights if sample_weights is not None else None
            if sw is not None:
                m.fit(X, aux_arr[:, j], sample_weight=sw)
            else:
                m.fit(X, aux_arr[:, j])
            aux_full[:, j] = m.predict(X)

        X_s2_full = np.hstack([X, aux_full])
        sc_full = StandardScaler()
        X_s2_full_s = sc_full.fit_transform(X_s2_full)
        m_final = Ridge(alpha=RIDGE_ALPHA)
        sw = sample_weights if sample_weights is not None else None
        if sw is not None:
            m_final.fit(X_s2_full_s, y, sample_weight=sw)
        else:
            m_final.fit(X_s2_full_s, y)

        all_runs.append({
            'scaler_s2': sc_full,
            'final_model': m_final,
            'cv_rmse': best_rmse,
            'cv_rmse_raw': rmse,
            'shrink_w': best_w,
            'coal_mean': coal_mean,
        })

    return all_runs

def predict_test(X_test, test_groups, n_test_batches, runs):
    """Predict test data using ensemble of runs."""
    all_batch_preds = []
    for run in runs:
        n_test = len(X_test)
        aux_test = np.zeros((n_test, 4))  # 0 = mean after standardization
        X_s2_test = np.hstack([X_test, aux_test])
        X_s2_test_s = run['scaler_s2'].transform(X_s2_test)
        preds = run['final_model'].predict(X_s2_test_s)

        batch_preds = []
        for b in range(n_test_batches):
            mask = test_groups == b
            if mask.sum() == 0:
                batch_preds.append(run['coal_mean'])
            else:
                bp = np.median(preds[mask])
                bp = run['shrink_w'] * bp + (1 - run['shrink_w']) * run['coal_mean']
                batch_preds.append(bp)
        all_batch_preds.append(batch_preds)

    return np.mean(all_batch_preds, axis=0)

# ── Main ───────────────────────────────────────────────────────────────────

def run_experiment(aug_name, aug_func, aug_kwargs):
    print(f"\n{'=' * 70}")
    print(f"  Augmentation: {aug_name}")
    print(f"  kwargs: {aug_kwargs}")
    print(f"{'=' * 70}")

    np.random.seed(42)
    label_map, aux_map = load_labels()

    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map, is_train=True)
        if train_data is None:
            print("    SKIP")
            continue

        n_batches = train_data['n_batches']
        n_orig = len(train_data['spectra'])
        y = train_data['targets']
        coal_mean = float(np.mean(y))

        # Apply augmentation
        aug_spectra, aug_targets, aug_auxs, aug_groups, aug_months, aug_names = aug_func(
            train_data['spectra'], y, train_data['aux'],
            train_data['groups'], train_data['months'], train_data['names'],
            **aug_kwargs
        )

        # Combine original + augmented
        all_spectra = list(train_data['spectra']) + list(aug_spectra)
        all_targets = np.concatenate([y, aug_targets])
        all_auxs = list(train_data['aux']) + list(aug_auxs)
        all_groups = np.concatenate([train_data['groups'], aug_groups])
        all_months = np.concatenate([train_data['months'], aug_months])

        # Convert aux
        aux_list = []
        for a in all_auxs:
            aux_list.append([a.get(col, np.nan) for col in AUX_COLS])
        aux_arr = np.array(aux_list, dtype=np.float32)

        # Features
        X, sc_spec, pca, sc_final = build_feature_matrix(*compute_features(all_spectra), fit=True)

        # Sample weights (time weighting only, applied to both orig + aug)
        sample_weights = None
        if coal in TIME_WEIGHT_TAU:
            tw = compute_time_weights(all_months, TEST_MONTH, TIME_WEIGHT_TAU[coal])
            sample_weights = tw

        is_small = n_batches <= SMALL_BATCH_THRESHOLD
        seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))

        runs = train_two_stage(X, all_targets, aux_arr, all_groups, n_batches, sample_weights, seeds)

        if is_small:
            r = runs[0]
            print(f"    N_orig={n_orig} -> N_aug={len(all_targets)}  "
                  f"CV-RMSE: raw={r['cv_rmse_raw']:.2f}  shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
        else:
            cv_rmses = [r['cv_rmse'] for r in runs]
            print(f"    N_orig={n_orig} -> N_aug={len(all_targets)}  "
                  f"CV-RMSE: {np.mean(cv_rmses):.2f} +/- {np.std(cv_rmses):.2f}")

        # Predict test
        test_data = load_coal_spectra(TEST_DIR, coal, is_train=False)
        if test_data is None:
            continue

        X_test = build_feature_matrix(*compute_features(test_data['spectra']),
                                      fit=False, scaler_spec=sc_spec, pca=pca, scaler_final=sc_final)
        preds = predict_test(X_test, test_data['groups'], test_data['n_batches'], runs)
        all_preds[coal] = preds
        cv_results[coal] = np.mean([r['cv_rmse'] for r in runs])

        # Print predictions
        test_names_arr = np.array(test_data['names'])
        test_batch_names = []
        for b in range(test_data['n_batches']):
            mask = test_data['groups'] == b
            if mask.sum() > 0:
                test_batch_names.append(test_names_arr[mask][0])
        for name, pred in zip(test_batch_names, preds):
            print(f"    {coal}{name}: {pred:.2f}")

    # Global CV
    all_cv = list(cv_results.values())
    global_cv = np.sqrt(np.mean([c**2 for c in all_cv]))
    print(f"\n  Global CV-RMSE: {global_cv:.2f}")

    # Pack submission
    template = pd.read_csv(SUBMIT_TEMPLATE)
    pred_map = {}
    for coal, preds in all_preds.items():
        test_data = load_coal_spectra(TEST_DIR, coal, is_train=False)
        test_names_arr = np.array(test_data['names'])
        for b in range(test_data['n_batches']):
            mask = test_data['groups'] == b
            if mask.sum() > 0:
                name = f"{coal}{test_names_arr[mask][0]}"
                pred_map[name] = preds[b]

    template['预测发热量_MJ_KG'] = template['名称'].map(pred_map).fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{aug_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")

    print(f"\n  [OK] {out_zip}")
    return out_zip

if __name__ == '__main__':
    # V48a: Gaussian noise (sigma=1% of max intensity)
    run_experiment('v48a_noise', augment_noise, {'sigma_frac': 0.01, 'n_aug': 1})

    # V48b: Intensity scaling (0.9-1.1, 2x augmentation)
    run_experiment('v48b_scale', augment_scaling, {'scale_range': (0.9, 1.1), 'n_aug': 2})

    # V48c: Mixup (alpha=0.2, 1x augmentation)
    run_experiment('v48c_mixup', augment_mixup, {'alpha': 0.2, 'n_aug': 1})
