"""
gen_v546_v560_percoal_expand.py
Expand V538 success: 中马矿→V72 broke 197 (196.37).
Now extend per-coal replacement to other coals based on OOF best model.

OOF validation results (10 seeds):
  中马矿:   V61=265, V63=197, V72=197 -> V72 (线上验证成功, 196.37)
  九里山:   V61=117, V63=51,  V72=48  -> V72 best
  赵固一矿: V61=75,  V63=31,  V72=36  -> V63 best
  赵固二矿: V61=108, V63=78,  V72=75  -> V72 best
  煤场混煤: V61=155, V63=110, V72=114 -> V63 best

Strategy: progressive expansion from V538 baseline.
"""
import os, sys, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")

COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']

def load_template():
    df = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')
    return df

def load_pred(zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(zip_path):
        print(f"  [WARN] {zip_name} not found")
        return None
    with zipfile.ZipFile(zip_path, 'r') as zf:
        csv_name = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(csv_name) as f:
            df = pd.read_csv(f, encoding='utf-8-sig')
    return df

def save_zip(df, zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', csv_buf.getvalue())
    return zip_path

def compute_corr(v1, v2):
    return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("PER-COAL EXPAND FROM V538 SUCCESS (196.37)")
    print("=" * 70)

    template = load_template()
    pred_col = '预测发热量_MJ_KG'

    def get_coal(name):
        for ct in COAL_TYPES:
            if ct in str(name):
                return ct
        return 'unknown'

    template['coal'] = template['名称'].apply(get_coal)
    coal_masks = {ct: (template['coal'] == ct).values for ct in COAL_TYPES}

    print("Coal distribution:")
    for ct in COAL_TYPES:
        print(f"  {ct}: {coal_masks[ct].sum()} batches")

    # Load base predictions
    v61_df = load_pred('submit_v61_a005_bias.zip')
    v63_df = load_pred('submit_v63_isotonic.zip')
    v72_df = load_pred('submit_v72_isotonic_a005.zip')
    v96_df = load_pred('submit_v96_blend_v74_v72_7525.zip')
    v538_df = load_pred('submit_v538_zhongma_v72_only.zip')

    if any(x is None for x in [v61_df, v63_df, v72_df, v96_df, v538_df]):
        print("ERROR: Missing base predictions")
        return

    v61 = v61_df[pred_col].values
    v63 = v63_df[pred_col].values
    v72 = v72_df[pred_col].values
    v96 = v96_df[pred_col].values
    v538 = v538_df[pred_col].values  # V538 = V96 with 中马矿→V72

    print(f"\nV538 vs V96 corr: {compute_corr(v538, v96):.6f}")
    print(f"V538 MAE from V96: {np.mean(np.abs(v538 - v96)):.2f}")

    # Verify V538 = V96 except 中马矿
    zhongma = coal_masks['中马矿中煤矿']
    non_zhongma = ~zhongma
    print(f"V538==V96 for non-中马矿: {np.allclose(v538[non_zhongma], v96[non_zhongma])}")
    print(f"V538==V72 for 中马矿: {np.allclose(v538[zhongma], v72[zhongma])}")

    results = []

    # === Progressive expansion from V538 ===

    # V546: V538 + 九里山→V72 (11 batches changed)
    jiulishan = coal_masks['九里山矿中煤矿']
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]      # 中马矿→V72 (V538 core)
    pred[jiulishan] = v72[jiulishan]  # 九里山→V72 (OOF best)
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v546_zhongma_jiuli_v72.zip')
    n_changed = zhongma.sum() + jiulishan.sum()
    results.append(('V546_zhongma+jiuli_v72', corr, mae, n_changed,
                     "中马矿+九里山→V72"))
    print(f"  V546: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 中马矿+九里山→V72")

    # V547: V538 + 九里山→V72 + 赵固二矿→V72 (15 batches)
    zhaogu2 = coal_masks['赵固二矿中煤矿']
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[jiulishan] = v72[jiulishan]
    pred[zhaogu2] = v72[zhaogu2]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v547_3coal_v72.zip')
    n_changed = zhongma.sum() + jiulishan.sum() + zhaogu2.sum()
    results.append(('V547_3coal_v72', corr, mae, n_changed,
                     "中马矿+九里山+赵固二矿→V72"))
    print(f"  V547: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 3 coal→V72")

    # V548: V538 + 九里山→V72 + 赵固二矿→V72 + 赵固一矿→V63 + 煤场混煤→V63 (all 26)
    zhaogu1 = coal_masks['赵固一矿豫焦末煤']
    meichang = coal_masks['煤场混煤']
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[jiulishan] = v72[jiulishan]
    pred[zhaogu2] = v72[zhaogu2]
    pred[zhaogu1] = v63[zhaogu1]    # V63 best for 赵固一矿
    pred[meichang] = v63[meichang]  # V63 best for 煤场混煤
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v548_allcoal_best.zip')
    results.append(('V548_allcoal_best', corr, mae, 26,
                     "All coal→per-coal OOF best"))
    print(f"  V548: corr={corr:.6f}, MAE={mae:.2f}, changed=26 — All coal→best")

    # V549: V538 + 九里山→V72 only (same as V546 but from V538 base, double check)
    # Already covered by V546

    # V550: All coal→V72 (most aggressive V72)
    pred = v72.copy()
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v550_all_v72.zip')
    results.append(('V550_all_v72', corr, mae, 26,
                     "All→V72 (pure V72)"))
    print(f"  V550: corr={corr:.6f}, MAE={mae:.2f}, changed=26 — All→V72")

    # V551: V538 + 九里山→V72 + 赵固一矿→V63 (13 batches, mix V72/V63)
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[jiulishan] = v72[jiulishan]
    pred[zhaogu1] = v63[zhaogu1]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v551_zhongma_jiuli_v72_zhao1_v63.zip')
    n_changed = zhongma.sum() + jiulishan.sum() + zhaogu1.sum()
    results.append(('V551_3coal_mixed', corr, mae, n_changed,
                     "中马矿+九里山→V72, 赵固一矿→V63"))
    print(f"  V551: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 3 coal mixed")

    # V552: V538 + 煤场混煤→V63 (14 batches)
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[meichang] = v63[meichang]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v552_zhongma_v72_meichang_v63.zip')
    n_changed = zhongma.sum() + meichang.sum()
    results.append(('V552_zhongma+meichang', corr, mae, n_changed,
                     "中马矿→V72, 煤场混煤→V63"))
    print(f"  V552: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 中马矿→V72, 煤场混煤→V63")

    # V553: V538 + 九里山→V72 + 煤场混煤→V63 (20 batches)
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[jiulishan] = v72[jiulishan]
    pred[meichang] = v63[meichang]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v553_zhongma_jiuli_v72_meichang_v63.zip')
    n_changed = zhongma.sum() + jiulishan.sum() + meichang.sum()
    results.append(('V553_3coal_mixed2', corr, mae, n_changed,
                     "中马矿+九里山→V72, 煤场混煤→V63"))
    print(f"  V553: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 3 coal mixed v2")

    # V554: V538 + 九里山→V72 + 赵固二矿→V72 + 煤场混煤→V63 (24 batches)
    pred = v96.copy()
    pred[zhongma] = v72[zhongma]
    pred[jiulishan] = v72[jiulishan]
    pred[zhaogu2] = v72[zhaogu2]
    pred[meichang] = v63[meichang]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v554_4coal_mixed.zip')
    n_changed = zhongma.sum() + jiulishan.sum() + zhaogu2.sum() + meichang.sum()
    results.append(('V554_4coal_mixed', corr, mae, n_changed,
                     "中马矿+九里山+赵固二矿→V72, 煤场混煤→V63"))
    print(f"  V554: corr={corr:.6f}, MAE={mae:.2f}, changed={n_changed} — 4 coal mixed")

    # V555: V96 + V538 blend 80/20 (safety net)
    pred = 0.8 * v96 + 0.2 * v538
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v555_v96_v538_8020.zip')
    results.append(('V555_v96_v538_8020', corr, mae, 5,
                     "V96+V538 80/20 (safety)"))
    print(f"  V555: corr={corr:.6f}, MAE={mae:.2f} — V96+V538 80/20")

    # V556: V96 + V538 blend 50/50
    pred = 0.5 * v96 + 0.5 * v538
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v556_v96_v538_5050.zip')
    results.append(('V556_v96_v538_5050', corr, mae, 5,
                     "V96+V538 50/50"))
    print(f"  V556: corr={corr:.6f}, MAE={mae:.2f} — V96+V538 50/50")

    # V557: V538 + 九里山→V72, blend with V96 90/10 (safety for 九里山 expansion)
    v546_pred = v96.copy()
    v546_pred[zhongma] = v72[zhongma]
    v546_pred[jiulishan] = v72[jiulishan]
    pred = 0.9 * v96 + 0.1 * v546_pred
    # Actually this doesn't make sense since V538 already has 中马矿→V72
    # Let me do: V538 90% + V546 10% (adds 10% of 九里山→V72 on top of V538)
    pred = 0.9 * v538 + 0.1 * v546_pred
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v557_v538_v546_9010.zip')
    results.append(('V557_v538_v546_9010', corr, mae, 11,
                     "V538+V546 90/10 (gentle 九里山)"))
    print(f"  V557: corr={corr:.6f}, MAE={mae:.2f} — V538+V546 90/10")

    # Summary sorted by corr (highest = safest)
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr descending)")
    print("=" * 70)
    print(f"{'Variant':<30} {'corr(V96)':<12} {'MAE':<8} {'N':<5} {'Description'}")
    print("-" * 90)
    for name, corr, mae, n, desc in sorted(results, key=lambda x: -x[1]):
        print(f"{name:<30} {corr:.6f}     {mae:.2f}   {n:<5} {desc}")

    # Expected online scores based on V538=196.37
    print("\n--- Expected online scores (based on V538=196.37 baseline) ---")
    print("  V538 changed 5 中马矿 batches -> -0.61 points (196.98->196.37)")
    print("  If 九里山 (6 batches, OOF V72 saves 22 vs V96's 70):")
    print("    V546: expect additional ~0.5-1.0 point drop -> ~195.4-195.9")
    print("  If all coals (26 batches, OOF total improvement ~56 points):")
    print("    V548: expect ~1.5-2.5 point drop -> ~193.9-194.9")
    print("  BUT: corr drops -> gap may increase. V538 corr=0.9994 gap≈25(?)")
    print("  Safety threshold: corr > 0.998 (gap < 50)")


if __name__ == '__main__':
    main()
