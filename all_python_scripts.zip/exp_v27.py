"""V27: PLS + MSC + Time-Weighted -- 方向二/三/四合并实验

基线: V19 Ridge(0.1)+PCA(30)+主元素窗口x5 -> GK=273.08, TE=240.20, 线上=250.64

方向四 (PLS): 有监督降维替代无监督PCA
  - PLS找的方向同时最大化X方差和X-Y协方差
  - 不容易被"漂移方向"污染
  - 扫描 n_components ∈ {10,15,20,25,30,40}

方向二 (MSC): Multiplicative Scatter Correction
  - 唯一未测的归一化方式(V19已用total, max/snv/minmax已排除)
  - 对齐到参考光谱(均值), 消除乘性+加性漂移

方向三 (Time-Weighted): 时间加权样本权重
  - 近期样本权重更高, 扫描 tau ∈ {14,30,60,90,180}

验证标准: 双重CV (GK不恶化 + TE改善)
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
    extract_month, compute_features_custom, build_fm, oof_ridge,
)


# ═══════════════════════════════════════════════════════════════════════════════
# MSC normalization
# ═══════════════════════════════════════════════════════════════════════════════

def msc_normalize(X_train, X_val=None):
    """Multiplicative Scatter Correction.
    
    Fit reference spectrum from X_train mean, then correct each spectrum
    by fitting a linear model to the reference and removing slope+intercept.
    """
    X_ref = X_train.mean(axis=0)
    
    def _correct(X):
        X_corr = np.zeros_like(X, dtype=np.float64)
        for i in range(X.shape[0]):
            # Linear fit: X[i] = slope * X_ref + intercept
            slope, intercept = np.polyfit(X_ref, X[i], 1)
            X_corr[i] = (X[i] - intercept) / (slope + 1e-8)
        return X_corr
    
    X_train_corr = _correct(X_train)
    if X_val is not None:
        X_val_corr = _correct(X_val)
        return X_train_corr, X_val_corr
    return X_train_corr


def msc_normalize_all(inorm_mat, train_mask=None, val_mask=None):
    """MSC normalize with proper train/val split."""
    if train_mask is None:
        # Apply to all (for full-data PCA mode like V19)
        return msc_normalize(inorm_mat)
    else:
        return msc_normalize(inorm_mat[train_mask], inorm_mat[val_mask])


# ═══════════════════════════════════════════════════════════════════════════════
# PLS-based feature extraction
# ═══════════════════════════════════════════════════════════════════════════════

def build_fm_pls(inorm_mat, hand_feats, y, n_batches, n_components=30, alpha=0.1):
    """Build feature matrix using PLS instead of PCA.
    
    PLS is supervised: finds directions that maximize X-Y covariance.
    Then hstack with hand features, StandardScaler, and return.
    """
    sc = StandardScaler()
    ss = sc.fit_transform(inorm_mat)
    n_comp = min(n_components, n_batches - 1, ss.shape[0] - 1)
    pls = PLSRegression(n_components=n_comp, scale=False)
    pls.fit(ss, y)
    sp = pls.transform(ss)
    X = np.hstack([sp, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler()
    X = sh.fit_transform(X)
    return X


def build_fm_msc(inorm_mat, hand_feats, n_batches, n_pca_max=30):
    """Build feature matrix with MSC pre-normalization + PCA."""
    inorm_msc = msc_normalize(inorm_mat.astype(np.float64))
    return build_fm(inorm_msc.astype(np.float32), hand_feats, n_batches, n_pca_max)


# ═══════════════════════════════════════════════════════════════════════════════
# CV functions for PLS
# ═══════════════════════════════════════════════════════════════════════════════

def oof_ridge_pls(X, y, aux, groups, splits, alpha, pls_model=None, hand_feats=None):
    """OOF Ridge with PLS features. PLS is fit per-fold on train data."""
    op, ot = [], []
    for tr, va in splits:
        # PLS per-fold (fit on train, transform both)
        sc_spec = StandardScaler()
        spec_tr = sc_spec.fit_transform(X[tr, :30] if X.shape[1] >= 30 else X[tr])  # placeholder
        # Actually, we need raw spectra for PLS, not pre-PCA'd features
        # This function is not used - PLS is handled in gkfold_cv_pls directly
        pass
    return op, ot


def gkfold_cv_pls(coal, n_pls=30, n_seeds=10):
    """GroupKFold CV with PLS + Ridge."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    coal_mean = float(y.mean())
    
    is_small = nb <= SMALL_BATCH_THRESHOLD
    
    def _run_fold(tr_idx, va_idx):
        # StandardScaler on spectra (fit on train)
        sc_spec = StandardScaler()
        spec_tr = sc_spec.fit_transform(inorm_mat[tr_idx])
        spec_va = sc_spec.transform(inorm_mat[va_idx])
        
        # PLS (fit on train)
        n_comp = min(n_pls, spec_tr.shape[0] - 1, spec_tr.shape[1])
        pls = PLSRegression(n_components=n_comp, scale=False)
        pls.fit(spec_tr, y[tr_idx])
        pls_tr = pls.transform(spec_tr)
        pls_va = pls.transform(spec_va)
        
        # Combine with hand features
        X_tr = np.hstack([pls_tr, hand_feats[tr_idx]])
        X_va = np.hstack([pls_va, hand_feats[va_idx]])
        X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
        X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
        sc_all = StandardScaler()
        X_tr = sc_all.fit_transform(X_tr)
        X_va = sc_all.transform(X_va)
        
        # Stage 1: aux
        pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
        pa_va = np.zeros((len(va_idx), aux.shape[1]), dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                continue
            m1 = Ridge(alpha=RIDGE_ALPHA)
            m1.fit(X_tr, ya[tr_idx])
            pa_tr[:, ci] = m1.predict(X_tr)
            pa_va[:, ci] = m1.predict(X_va)
        
        # Stage 2: Q
        X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
        X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
        m2 = Ridge(alpha=RIDGE_ALPHA)
        m2.fit(X2_tr, y[tr_idx])
        vp = m2.predict(X2_va)
        vg = groups[va_idx]
        ops, ots = [], []
        for bg in np.unique(vg):
            mk = vg == bg
            ops.append(float(np.median(vp[mk])))
            ots.append(float(y[va_idx][mk][0]))
        return ops, ots
    
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        all_op, all_ot = [], []
        for tr, va in splits:
            ops, ots = _run_fold(tr, va)
            all_op.extend(ops)
            all_ot.extend(ots)
        w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            all_op, all_ot = [], []
            for tr, va in splits:
                ops, ots = _run_fold(tr, va)
                all_op.extend(ops)
                all_ot.extend(ots)
            w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_pls(coal, n_pls=30):
    """Time extrapolation CV with PLS."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    
    # StandardScaler on spectra
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    
    # PLS (fit on train)
    n_comp = min(n_pls, spec_tr.shape[0] - 1, spec_tr.shape[1])
    pls = PLSRegression(n_components=n_comp, scale=False)
    pls.fit(spec_tr, y[tm])
    sp_tr = pls.transform(spec_tr)
    sp_va = pls.transform(spec_va)
    
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)
    
    coal_mean = float(y[tm].mean())
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)
    
    vg2 = groups[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(y[vm][mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


# ═══════════════════════════════════════════════════════════════════════════════
# CV functions for MSC
# ═══════════════════════════════════════════════════════════════════════════════

def gkfold_cv_msc(coal, n_pca_max=30, n_seeds=10):
    """GroupKFold CV with MSC normalization + PCA + Ridge."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    # Apply MSC to all spectra (using all-data reference)
    inorm_msc = msc_normalize(inorm_mat.astype(np.float64)).astype(np.float32)
    
    X = build_fm(inorm_msc, hand_feats, nb, n_pca_max)
    coal_mean = float(y.mean())
    is_small = nb <= SMALL_BATCH_THRESHOLD
    
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits, RIDGE_ALPHA)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits, RIDGE_ALPHA)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_msc(coal, n_pca_max=30):
    """Time extrapolation CV with MSC normalization."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    
    # MSC: fit reference on train, correct both
    inorm_tr_msc, inorm_va_msc = msc_normalize(
        inorm_mat[tm].astype(np.float64), inorm_mat[vm].astype(np.float64))
    inorm_tr_msc = inorm_tr_msc.astype(np.float32)
    inorm_va_msc = inorm_va_msc.astype(np.float32)
    
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_tr_msc)
    spec_va = sc.transform(inorm_va_msc)
    n_pca = min(n_pca_max, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)
    
    coal_mean = float(y[tm].mean())
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)
    
    vg2 = groups[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(y[vm][mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


# ═══════════════════════════════════════════════════════════════════════════════
# Run helpers
# ═══════════════════════════════════════════════════════════════════════════════

def run_pls(name, n_pls=30):
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_pls(coal, n_pls=n_pls)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_pls(coal, n_pls=n_pls)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


def run_msc(name):
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_msc(coal)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_msc(coal)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # ── Baseline (V19) ──
    # We know V19: GK=273.08, TE=240.20
    results['baseline'] = {'gk': 273.08, 'te': 240.20}
    print("  baseline: GK=273.08, TE=240.20 (V19, known)")

    # ── Direction 4: PLS scan ──
    for npc in [10, 15, 20, 25, 30, 40]:
        results[f'PLS({npc})'] = run_pls(f"PLS n_components={npc}", n_pls=npc)

    # ── Direction 2: MSC ──
    results['MSC'] = run_msc("MSC normalization + PCA(30)")

    # ── Summary ──
    print(f"\n{'='*60}")
    print("  V27: PLS + MSC -- Dual CV Summary")
    print(f"{'='*60}")
    base_gk = results['baseline']['gk']
    base_te = results['baseline']['te']
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
