"""
exp_v341_v350_calibration_diversity.py
Test new calibration methods: poly2, poly3, none, ridge_calib.
Key insight: calibration diversity reduces gap (V61 linear + V63 isotonic = V74 gap 25 < 31/20).
New calibration methods may provide additional diversity.
"""
import os, sys, io, zipfile, json
import numpy as np
import pandas as pd
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exp_v260_v270_tree_models as base

OUTPUT_DIR = base.OUTPUT_DIR
SUBMIT_TEMPLATE = base.SUBMIT_TEMPLATE


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc, cv_rmse=0.0):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n**CV-RMSE**: {cv_rmse:.2f}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    results = {}
    
    # ========================================
    # Part 1: New calibration methods with a=0.05
    # ========================================
    experiments = [
        ('v341_a005_poly2',
         "Ridge a=0.05 + polynomial degree 2 calibration. Between linear and isotonic.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='poly2',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v342_a005_poly3',
         "Ridge a=0.05 + polynomial degree 3 calibration. More flexible than poly2.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='poly3',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v343_a005_none',
         "Ridge a=0.05 + NO calibration. Raw predictions.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='none',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v344_a005_ridge_calib',
         "Ridge a=0.05 + Ridge calibration (alpha=1.0). Regularized linear calibration.",
         dict(model_type='ridge', ridge_alpha=0.05, calibration='ridge_calib',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        # Also try with a=0.1 (V63's alpha)
        ('v345_a01_poly2',
         "Ridge a=0.1 + polynomial degree 2 calibration. V63 equivalent with poly2.",
         dict(model_type='ridge', ridge_alpha=0.1, calibration='poly2',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v346_a01_poly3',
         "Ridge a=0.1 + polynomial degree 3 calibration.",
         dict(model_type='ridge', ridge_alpha=0.1, calibration='poly3',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v347_a01_none',
         "Ridge a=0.1 + NO calibration.",
         dict(model_type='ridge', ridge_alpha=0.1, calibration='none',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
        
        ('v348_a01_ridge_calib',
         "Ridge a=0.1 + Ridge calibration.",
         dict(model_type='ridge', ridge_alpha=0.1, calibration='ridge_calib',
              preprocessing='snv', use_pca=True, use_two_stage=True)),
    ]
    
    for vid, desc, kwargs in experiments:
        print(f"\n{'=' * 70}")
        print(f"  {vid}: {desc}")
        print(f"{'=' * 70}")
        
        try:
            out_zip, global_cv = base.run_experiment(vid, desc, **kwargs)
            
            sub = load_existing_submission(f"submit_{vid}.zip")
            if sub is not None and v96_arr is not None:
                arr = np.array(sub.values)
                corr = np.corrcoef(v96_arr, arr)[0, 1]
                mae = np.mean(np.abs(arr - v96_arr))
                print(f"  CV={global_cv:.2f}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                results[vid] = {'cv': global_cv, 'corr_v96': corr, 'mae_v96': mae}
            else:
                results[vid] = {'cv': global_cv}
        except Exception as e:
            print(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            results[vid] = {'error': str(e)}
    
    # Summary
    print(f"\n{'=' * 70}")
    print("  SUMMARY - CALIBRATION DIVERSITY")
    print(f"{'=' * 70}")
    print(f"  {'Variant':35s}  {'CV':>7s}  {'corr(V96)':>10s}  {'MAE':>7s}")
    print(f"  {'-' * 65}")
    
    # Reference models
    ref_models = [
        ('V61_a005_linear (ref)', V61, 172.15),
        ('V63_a01_isotonic (ref)', V63, 184.0),
        ('V72_a005_isotonic (ref)', V72, 178.0),
    ]
    for label, fname, cv in ref_models:
        sub = load_existing_submission(fname)
        if sub is not None:
            arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, arr)[0, 1]
            mae = np.mean(np.abs(arr - v96_arr))
            print(f"  {label:35s}  {cv:7.2f}  {corr:10.6f}  {mae:7.2f}")
    
    for vid in sorted(results.keys()):
        r = results[vid]
        if 'cv' in r:
            cv = r['cv']
            corr = r.get('corr_v96', 0)
            mae = r.get('mae_v96', 0)
            marker = ' ***' if cv < 170 else (' **' if cv < 175 else '')
            print(f"  {vid:35s}  {cv:7.2f}  {corr:10.6f}  {mae:7.2f}{marker}")
        else:
            print(f"  {vid:35s}  ERROR: {r.get('error', 'unknown')[:40]}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION - CALIBRATION DIVERSITY")
    print(f"{'=' * 70}")
    
    valid = {k: v for k, v in results.items() if 'cv' in v}
    
    # Generate blends of new calibration methods with existing models
    blends = []
    
    # 1. Each new calibration + V63 50/50 (V74 structure)
    for vid in ['v341', 'v342', 'v343', 'v344', 'v345', 'v346', 'v347', 'v348']:
        if vid in valid:
            vid_zip = f"submit_{vid}.zip"
            corr = valid[vid].get('corr_v96', 0)
            cv = valid[vid]['cv']
            if corr > 0.99:  # Safe to blend
                blends.append((
                    f"v350_blend_{vid}_v63_5050",
                    [(vid_zip, 0.5), (V63, 0.5)],
                    f"{vid}(50%) + V63(50%). V74 structure. CV={cv:.2f} corr={corr:.4f}"
                ))
    
    # 2. Each new calibration + V61 50/50
    for vid in ['v341', 'v342', 'v343', 'v344', 'v345', 'v346', 'v347', 'v348']:
        if vid in valid:
            vid_zip = f"submit_{vid}.zip"
            corr = valid[vid].get('corr_v96', 0)
            if corr > 0.99:
                blends.append((
                    f"v351_blend_{vid}_v61_5050",
                    [(vid_zip, 0.5), (V61, 0.5)],
                    f"{vid}(50%) + V61(50%). CV={valid[vid]['cv']:.2f}"
                ))
    
    # 3. New calibration + V63 + V72 (V96 structure)
    for vid in ['v341', 'v342', 'v343', 'v344']:
        if vid in valid:
            vid_zip = f"submit_{vid}.zip"
            corr = valid[vid].get('corr_v96', 0)
            if corr > 0.99:
                # V74 equivalent: new_calib + V63
                v74_eq = f"v350_blend_{vid}_v63_5050"
                blends.append((
                    f"v352_blend_{v74_eq}_v72_7525",
                    [(f"submit_{v74_eq}.zip", 0.75), (V72, 0.25)],
                    f"{v74_eq}(75%) + V72(25%). V96 structure."
                ))
    
    # 4. 4-way: new_calib + V61 + V63 + V72
    for vid in ['v341', 'v342', 'v343', 'v344']:
        if vid in valid:
            vid_zip = f"submit_{vid}.zip"
            corr = valid[vid].get('corr_v96', 0)
            if corr > 0.99:
                blends.append((
                    f"v353_blend_4way_{vid}",
                    [(vid_zip, 0.25), (V61, 0.25), (V63, 0.25), (V72, 0.25)],
                    f"4-way: {vid}(25%) + V61(25%) + V63(25%) + V72(25%)."
                ))
    
    # 5. V96 + new_calib at 90/10
    for vid in ['v341', 'v342', 'v343', 'v344']:
        if vid in valid:
            vid_zip = f"submit_{vid}.zip"
            corr = valid[vid].get('corr_v96', 0)
            if corr > 0.99:
                blends.append((
                    f"v354_blend_v96_{vid}_9010",
                    [(V96, 0.9), (vid_zip, 0.1)],
                    f"V96(90%) + {vid}(10%)."
                ))
    
    # 6. Multi-calibration blend: V61 + V63 + V341 + V342 (linear + iso + poly2 + poly3)
    if 'v341' in valid and 'v342' in valid:
        blends.append((
            "v355_blend_4calib_equal",
            [(V61, 0.25), (V63, 0.25), ('submit_v341_a005_poly2.zip', 0.25), ('submit_v342_a005_poly3.zip', 0.25)],
            "4-calibration equal: V61-linear(25%) + V63-iso(25%) + V341-poly2(25%) + V342-poly3(25%)."
        ))
        # + V72
        blends.append((
            "v356_blend_5calib_equal",
            [(V61, 0.20), (V63, 0.20), ('submit_v341_a005_poly2.zip', 0.20), ('submit_v342_a005_poly3.zip', 0.20), (V72, 0.20)],
            "5-calibration equal: V61 + V63 + V341-poly2 + V342-poly3 + V72, each 20%."
        ))
    
    # 7. V96 + 5calib at 80/20
    blends.append((
        "v357_blend_v96_5calib_8020",
        [(V96, 0.80), ('submit_v355_blend_4calib_equal.zip', 0.20)],
        "V96(80%) + V355-4calib(20%)."
    ))
    
    for vid_name, components, desc in blends:
        print(f"\n  {vid_name}: {desc}")
        pack_blend(vid_name, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_new = list(valid.keys()) + ['v350', 'v351', 'v352', 'v353', 'v354', 'v355', 'v356', 'v357']
    for vid in all_new:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
