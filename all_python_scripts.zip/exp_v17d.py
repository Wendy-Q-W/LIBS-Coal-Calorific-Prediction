"""V17d: GroupKFold CV 验证 Ridge alpha=0.1
对比: RidgeCV(ALPHAS原) vs RidgeCV(扩展含0.1) vs Ridge(a=0.1固定)
在 GroupKFold CV (5种子) + 时间外推CV 上双重验证
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()
TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']
ALPHAS_EXT = [0.01, 0.1, 0.5, 1.0, 5.0, 10.0, 50.0, 100.0, 500.0, 1000.0]


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def build_fm(data, n_batches):
    inorm_mat = compute_features(data)
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(N_PCA_MAX, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    hf = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([sp, hf])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X


def oof_ridge(X, y, aux, groups, splits, alphas, fixed_alpha=None):
    """RidgeCV or fixed-Ridge OOF"""
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            if fixed_alpha is not None:
                m1 = Ridge(alpha=fixed_alpha)
            else:
                m1 = RidgeCV(alphas=alphas)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        if fixed_alpha is not None:
            m2 = Ridge(alpha=fixed_alpha)
        else:
            m2 = RidgeCV(alphas=alphas)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


def gkfold_cv(coal, alphas=ALPHAS, fixed_alpha=None, n_seeds=10):
    """GroupKFold CV (多种子)"""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    X = build_fm(td, nb)
    coal_mean = float(y.mean())

    is_small = nb <= SMALL_BATCH_THRESHOLD
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits, alphas, fixed_alpha)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(ot, op)])))
        return {'raw': cv_raw, 'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits, alphas, fixed_alpha)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'raw': np.mean(all_sh), 'sh': np.mean(all_sh), 'w': w, 'small': False}


def time_ext(coal, alphas=ALPHAS, fixed_alpha=None):
    """时间外推CV"""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    inorm_mat = compute_features(data=td)
    hand_feats = np.hstack([td['stats'], td['labs'], td['lrel'], td['rats']])

    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    sc_spec = StandardScaler()
    spec_tr = sc_spec.fit_transform(inorm_mat[tm])
    spec_va = sc_spec.transform(inorm_mat[vm])
    n_pca = min(N_PCA_MAX, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)

    coal_mean = float(y[tm].mean())

    def mk():
        return Ridge(alpha=fixed_alpha) if fixed_alpha else RidgeCV(alphas=alphas)

    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = mk(); m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)

    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = mk(); m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(vy[mk_][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'raw': cv_raw, 'sh': cv_sh, 'w': w}


def run_config(name, alphas=ALPHAS, fixed_alpha=None):
    t0 = time.time()
    print(f"\n{'=' * 55}")
    print(f"  {name}")
    print(f"{'=' * 55}", flush=True)

    # GroupKFold CV (全5煤种)
    print("  [GroupKFold CV]", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv(coal, alphas=alphas, fixed_alpha=fixed_alpha)
        if r is None:
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"    [{coal}] raw={r['raw']:.2f} sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = np.mean(gk_all) if gk_all else 0
    print(f"  >> GroupKFold avg = {gk_avg:.2f}", flush=True)

    # 时间外推CV (3煤种)
    print("  [Time-ext CV]", flush=True)
    te_all = []
    for coal in TIME_COALS:
        r = time_ext(coal, alphas=alphas, fixed_alpha=fixed_alpha)
        if r is None:
            continue
        print(f"    [{coal}] raw={r['raw']:.1f} sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = np.mean(te_all) if te_all else 0
    print(f"  >> Time-ext avg = {te_avg:.2f}  ({time.time() - t0:.0f}s)", flush=True)

    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # 1. 基线: RidgeCV 原始 ALPHAS
    results['RidgeCV(orig)'] = run_config(
        "RidgeCV 原始ALPHAS [1,10,50,...10000]",
        alphas=ALPHAS)

    # 2. RidgeCV 扩展 ALPHAS (含0.01,0.1,0.5)
    results['RidgeCV(ext)'] = run_config(
        "RidgeCV 扩展ALPHAS [0.01,0.1,0.5,1,...,1000]",
        alphas=ALPHAS_EXT)

    # 3. Ridge 固定 alpha=0.1
    results['Ridge(a=0.1)'] = run_config(
        "Ridge 固定 alpha=0.1",
        fixed_alpha=0.1)

    # 4. Ridge 固定 alpha=0.5
    results['Ridge(a=0.5)'] = run_config(
        "Ridge 固定 alpha=0.5",
        fixed_alpha=0.5)

    # 汇总
    print(f"\n{'=' * 55}")
    print("  汇总 (双重CV对比)")
    print(f"{'=' * 55}")
    base_gk = results.get('RidgeCV(orig)', {}).get('gk', 999)
    base_te = results.get('RidgeCV(orig)', {}).get('te', 999)
    for name, val in results.items():
        if val is None:
            continue
        gk_diff = val['gk'] - base_gk
        te_diff = val['te'] - base_te
        gk_mark = "BETTER" if gk_diff < -0.5 else ("WORSE" if gk_diff > 0.5 else "~")
        te_mark = "BETTER" if te_diff < -0.5 else ("WORSE" if te_diff > 0.5 else "~")
        print(f"  {name:20s}: GK={val['gk']:.2f}({gk_diff:+.2f},{gk_mark})  "
              f"TE={val['te']:.2f}({te_diff:+.2f},{te_mark})")
