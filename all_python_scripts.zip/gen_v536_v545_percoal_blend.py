"""
gen_v536_v545_percoal_blend.py
Per-coal blend: use V63+V72 50/50 for 中马矿 (where V61 has OOF RMSE=265 vs V63=197),
keep V96 for other coals. Also test other per-coal variations.

OOF validation showed:
  中马矿: V61=265, V63=197, V72=197, V96=217 -> removing V61 saves 20 points
  九里山矿: V61=117, V63=51, V72=48, V96=70 -> V72 best, saves 22 points
  赵固一矿: V61=75, V63=31, V72=36, V96=44 -> V63 best, saves 13 points
  煤场混煤: V61=155, V63=110, V72=114, V96=121 -> V63 best, saves 11 points
  赵固二矿: V61=108, V63=78, V72=75, V96=85 -> V72 best, saves 10 points
"""
import os, sys, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")

# Test batch names (from submit template)
def load_template():
    df = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')
    return df

def load_pred(zip_name):
    """Load predictions from a zip file."""
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(zip_path):
        print(f"  [WARN] {zip_name} not found")
        return None
    with zipfile.ZipFile(zip_path, 'r') as zf:
        csv_name = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(csv_name) as f:
            df = pd.read_csv(f, encoding='utf-8-sig')
    return df

def save_zip(df, zip_name):
    """Save predictions to zip."""
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', csv_buf.getvalue())
    return zip_path

def compute_corr(v1, v2):
    """Pearson correlation between two prediction arrays."""
    return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("PER-COAL BLEND GENERATION")
    print("=" * 70)

    # Load template to get batch names
    template = load_template()
    print(f"Template: {len(template)} rows")
    print(f"Columns: {list(template.columns)}")
    print(f"Sample names:\n{template.iloc[:, 0].head(10).to_string()}")

    # Identify coal type from batch name
    COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
    
    def get_coal(name):
        for ct in COAL_TYPES:
            if ct in str(name):
                return ct
        return 'unknown'

    template['coal'] = template.iloc[:, 0].apply(get_coal)
    coal_counts = template['coal'].value_counts()
    print(f"\nCoal distribution:")
    for ct, cnt in coal_counts.items():
        print(f"  {ct}: {cnt} batches")

    # Load V61, V63, V72, V96 predictions
    v61_df = load_pred('submit_v61_a005_bias.zip')
    v63_df = load_pred('submit_v63_isotonic.zip')
    v72_df = load_pred('submit_v72_isotonic_a005.zip')
    v96_df = load_pred('submit_v96_blend_v74_v72_7525.zip')

    if any(x is None for x in [v61_df, v63_df, v72_df, v96_df]):
        print("ERROR: Missing base predictions")
        return

    # Get prediction values aligned with template
    pred_col = [c for c in v61_df.columns if '发热量' in c or 'calorific' in c.lower() or c == v61_df.columns[-1]][0]
    print(f"\nPrediction column: '{pred_col}'")

    v61 = v61_df[pred_col].values
    v63 = v63_df[pred_col].values
    v72 = v72_df[pred_col].values
    v96 = v96_df[pred_col].values

    # Verify V63=V72 for 中马矿 in test set
    zhongma_mask = template['coal'] == '中马矿中煤矿'
    print(f"\n中马矿 test batches: {zhongma_mask.sum()}")
    print(f"  V63: {v63[zhongma_mask]}")
    print(f"  V72: {v72[zhongma_mask]}")
    print(f"  V61: {v61[zhongma_mask]}")
    print(f"  V96: {v96[zhongma_mask]}")
    v63_v72_diff = np.abs(v63[zhongma_mask] - v72[zhongma_mask])
    print(f"  |V63-V72|: {v63_v72_diff}")
    print(f"  V63==V72 for 中马矿: {np.allclose(v63[zhongma_mask], v72[zhongma_mask])}")

    # Also check per-coal V61 vs V63 vs V72
    print("\n--- Per-coal test predictions ---")
    for ct in COAL_TYPES:
        mask = template['coal'] == ct
        if mask.sum() == 0: continue
        print(f"\n  {ct} ({mask.sum()} batches):")
        print(f"    V61: {v61[mask]}")
        print(f"    V63: {v63[mask]}")
        print(f"    V72: {v72[mask]}")
        print(f"    V96: {v96[mask]}")
        print(f"    V61-V63 diff: {v61[mask] - v63[mask]}")
        print(f"    V63-V72 diff: {v63[mask] - v72[mask]}")

    # Generate variants
    print("\n" + "=" * 70)
    print("GENERATING PER-COAL BLEND VARIANTS")
    print("=" * 70)

    results = []

    # V536: 中马矿 -> V63+V72 50/50, others V96
    pred = v96.copy()
    pred[zhongma_mask] = 0.5 * v63[zhongma_mask] + 0.5 * v72[zhongma_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v536_zhongma_v63v72_5050.zip')
    results.append(('V536_zhongma_5050', corr, mae, f"中马矿→V63+V72 50/50 ({zhongma_mask.sum()} batches)"))
    print(f"  V536: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→V63+V72 50/50")

    # V537: 中马矿 -> V63 only, others V96
    pred = v96.copy()
    pred[zhongma_mask] = v63[zhongma_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v537_zhongma_v63_only.zip')
    results.append(('V537_zhongma_v63', corr, mae, f"中马矿→V63 only ({zhongma_mask.sum()} batches)"))
    print(f"  V537: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→V63 only")

    # V538: 中马矿 -> V72 only, others V96
    pred = v96.copy()
    pred[zhongma_mask] = v72[zhongma_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v538_zhongma_v72_only.zip')
    results.append(('V538_zhongma_v72', corr, mae, f"中马矿→V72 only ({zhongma_mask.sum()} batches)"))
    print(f"  V538: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→V72 only")

    # V539: 中马矿+九里山矿 -> per-coal best (V63/V72), others V96
    jiulishan_mask = template['coal'] == '九里山矿中煤矿'
    pred = v96.copy()
    pred[zhongma_mask] = v63[zhongma_mask]  # V63 best for 中马矿
    pred[jiulishan_mask] = v72[jiulishan_mask]  # V72 best for 九里山矿
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    n_changed = zhongma_mask.sum() + jiulishan_mask.sum()
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v539_zhongma_jiuli_best.zip')
    results.append(('V539_2coal_best', corr, mae, f"中马矿→V63, 九里山→V72 ({n_changed} batches)"))
    print(f"  V539: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→V63, 九里山→V72 ({n_changed} batches)")

    # V540: All coals -> per-coal best model
    pred = v96.copy()
    pred[zhongma_mask] = v63[zhongma_mask]       # V63 best
    pred[jiulishan_mask] = v72[jiulishan_mask]    # V72 best
    zhaogu1_mask = template['coal'] == '赵固一矿豫焦末煤'
    pred[zhaogu1_mask] = v63[zhaogu1_mask]        # V63 best
    meichang_mask = template['coal'] == '煤场混煤'
    pred[meichang_mask] = v63[meichang_mask]      # V63 best
    zhaogu2_mask = template['coal'] == '赵固二矿中煤矿'
    pred[zhaogu2_mask] = v72[zhaogu2_mask]        # V72 best
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v540_allcoal_best.zip')
    results.append(('V540_allcoal_best', corr, mae, "All coals→per-coal best"))
    print(f"  V540: corr={corr:.6f}, MAE={mae:.2f} — All coals→per-coal best")

    # V541: V96 + V536 blend 80/20 (safe version)
    v536_pred = 0.5 * v63[zhongma_mask] + 0.5 * v72[zhongma_mask]
    pred = v96.copy()
    pred[zhongma_mask] = 0.8 * v96[zhongma_mask] + 0.2 * v536_pred
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v541_v96_v536_8020.zip')
    results.append(('V541_v96_v536_8020', corr, mae, "V96+V536 80/20 (safe)"))
    print(f"  V541: corr={corr:.6f}, MAE={mae:.2f} — V96+V536 80/20 (safe)")

    # V542: 中马矿 -> V63+V72 60/40 (more V63, less V72)
    pred = v96.copy()
    pred[zhongma_mask] = 0.6 * v63[zhongma_mask] + 0.4 * v72[zhongma_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v542_zhongma_v63v72_6040.zip')
    results.append(('V542_zhongma_6040', corr, mae, "中马矿→V63+V72 60/40"))
    print(f"  V542: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→V63+V72 60/40")

    # V543: 中马矿+九里山+煤场混煤 -> V63 (3 worst coals -> V63)
    pred = v96.copy()
    three_mask = zhongma_mask | jiulishan_mask | meichang_mask
    pred[three_mask] = v63[three_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v543_3coal_v63.zip')
    results.append(('V543_3coal_v63', corr, mae, f"3 worst coals→V63 ({three_mask.sum()} batches)"))
    print(f"  V543: corr={corr:.6f}, MAE={mae:.2f} — 3 worst coals→V63 ({three_mask.sum()} batches)")

    # V544: V96 with 中马矿 -> V63+V72 50/50, 九里山 -> V72 only (2 best improvements)
    pred = v96.copy()
    pred[zhongma_mask] = 0.5 * v63[zhongma_mask] + 0.5 * v72[zhongma_mask]
    pred[jiulishan_mask] = v72[jiulishan_mask]
    corr = compute_corr(pred, v96)
    mae = np.mean(np.abs(pred - v96))
    n_changed = zhongma_mask.sum() + jiulishan_mask.sum()
    df_out = template.copy()
    df_out[pred_col] = pred
    save_zip(df_out, 'submit_v544_zhongma_5050_jiuli_v72.zip')
    results.append(('V544_2coal_mixed', corr, mae, f"中马矿→50/50, 九里山→V72 ({n_changed} batches)"))
    print(f"  V544: corr={corr:.6f}, MAE={mae:.2f} — 中马矿→50/50, 九里山→V72 ({n_changed} batches)")

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"{'Variant':<25} {'corr(V96)':<12} {'MAE':<10} {'Description'}")
    print("-" * 80)
    for name, corr, mae, desc in sorted(results, key=lambda x: x[1]):
        print(f"{name:<25} {corr:.6f}     {mae:.2f}      {desc}")

    print("\n--- OOF-based expected improvement ---")
    print("  中马矿 V96 OOF=217, V63 OOF=197 -> improvement=20 (5 test batches)")
    print("  九里山 V96 OOF=70, V72 OOF=48 -> improvement=22 (? test batches)")
    print("  If improvement translates 1:1 to test set:")
    print("    V536 (中马矿 only): expected online ≈ 196.98 - 20*5/26 ≈ 193.1")
    print("    V539 (中马矿+九里山): expected online ≈ 196.98 - (20*5+22*?)/26")


if __name__ == '__main__':
    main()
