"""
exp_v212_v213_percoal_blend.py

Per-coal optimal V61:V63:V72 blend weights using OOF predictions.
Only runs the per-coal optimization part (skips PLS which had CV>260).
"""
import os, sys, re, glob, warnings, io, zipfile, pickle
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.optimize import minimize as sp_minimize
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data, preprocessing='snv'):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        if preprocessing == 'snv':
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
        elif preprocessing == 'deriv1':
            processed = np.diff(inten)
        elif preprocessing == 'deriv1_snv':
            d = np.diff(inten)
            processed = (d - d.mean()) / (d.std() + 1e-8)
        else:
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(processed)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=N_PCA_MAX):
    spec_mat = data.get('_spec_mat')
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_mat))
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    k = min(5, n_batches)
    if seed is not None:
        gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
    else:
        gkf = GroupKFold(n_splits=k)
    return list(gkf.split(dummy, dummy, groups))


def batch_aggregate(preds_mask):
    return float(np.median(preds_mask))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.05):
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m_full = Ridge(alpha=ridge_alpha)
        if sample_weights is not None:
            m_full.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m_full.fit(X, y_aux)
        aux_models[col_name] = m_full

    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask])
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_center)
    final_model = Ridge(alpha=ridge_alpha)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)
    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = batch_aggregate(preds[mask])
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


def train_and_predict_coal(coal, label_map, aux_map,
                           ridge_alpha=0.05, calibration='linear'):
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    spec_mat = compute_features(train_data, preprocessing='snv')
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                            sample_weights, ridge_alpha)
        runs.append(run)

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)

    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data, preprocessing='snv')
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))
        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])
        test_preds[name] = pred_val

    return {'cv_rmse': cv_rmse, 'test_preds': test_preds,
            'oof_preds': all_oof_p, 'oof_true': all_oof_t,
            'uncalibrated_test_preds': {n: float(np.mean([bp[n] for bp in all_batch_preds])) for n in batch_names}}


def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n\n"
    readme += "## CV-RMSE\n\n| 煤种 | CV-RMSE |\n|---|---|\n"
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, {}, desc)


if __name__ == '__main__':
    label_map, aux_map = load_labels()
    
    configs = {
        'V61': {'ridge_alpha': 0.05, 'calibration': 'linear'},
        'V63': {'ridge_alpha': 0.10, 'calibration': 'isotonic'},
        'V72': {'ridge_alpha': 0.05, 'calibration': 'isotonic'},
    }
    
    all_oof = {}
    all_test = {}
    
    for model_name, cfg in configs.items():
        print(f"\n{'=' * 70}")
        print(f"  Training {model_name} (alpha={cfg['ridge_alpha']}, cal={cfg['calibration']})")
        print(f"{'=' * 70}")
        for coal in COAL_TYPES:
            print(f"  [{coal}]")
            result = train_and_predict_coal(coal, label_map, aux_map, **cfg)
            if result is None:
                continue
            if coal not in all_oof:
                all_oof[coal] = {}
                all_test[coal] = {}
            all_oof[coal][model_name] = {
                'oof_preds': result['oof_preds'],
                'oof_true': result['oof_true'],
            }
            all_test[coal][model_name] = result['test_preds']
            print(f"    CV-RMSE: {result['cv_rmse']:.2f}")
    
    # V212: Per-coal optimal V61:V63:V72 weights via SLSQP
    print(f"\n{'=' * 70}")
    print("  V212: Per-coal optimal V61:V63:V72 blend")
    print(f"{'=' * 70}")
    
    optimal_weights_3 = {}
    all_blend_preds = {}
    cv_results_3 = {}
    
    for coal in COAL_TYPES:
        if coal not in all_oof:
            continue
        models = all_oof[coal]
        oof_true = models['V61']['oof_true']
        oof_v61 = models['V61']['oof_preds']
        oof_v63 = models['V63']['oof_preds']
        oof_v72 = models['V72']['oof_preds']
        
        oof_stack = np.column_stack([oof_v61, oof_v63, oof_v72])
        
        def rmse_loss(w):
            pred = oof_stack @ w
            return np.sqrt(np.mean((pred - oof_true) ** 2))
        
        n_models = 3
        cons = {'type': 'eq', 'fun': lambda w: w.sum() - 1}
        bounds = [(0, 1)] * n_models
        w0 = np.array([0.375, 0.375, 0.25])
        res = sp_minimize(rmse_loss, w0, method='SLSQP', bounds=bounds, constraints=cons)
        opt_weights = res.x
        
        opt_pred = oof_stack @ opt_weights
        opt_rmse = float(np.sqrt(np.mean((opt_pred - oof_true) ** 2)))
        
        v96_pred = oof_stack @ np.array([0.375, 0.375, 0.25])
        v96_rmse = float(np.sqrt(np.mean((v96_pred - oof_true) ** 2)))
        
        print(f"\n  [{coal}]")
        print(f"    V96 weights RMSE: {v96_rmse:.2f}")
        print(f"    Optimal RMSE:     {opt_rmse:.2f}")
        print(f"    Weights: V61={opt_weights[0]:.3f} V63={opt_weights[1]:.3f} V72={opt_weights[2]:.3f}")
        
        optimal_weights_3[coal] = opt_weights
        cv_results_3[coal] = opt_rmse
        
        for batch_name in all_test[coal]['V61']:
            pred = (opt_weights[0] * all_test[coal]['V61'][batch_name] +
                    opt_weights[1] * all_test[coal]['V63'][batch_name] +
                    opt_weights[2] * all_test[coal]['V72'][batch_name])
            all_blend_preds[batch_name] = pred
    
    pack_submission('v212_percoal_3way_optimal', all_blend_preds, cv_results_3,
                    "Per-coal optimal V61:V63:V72 weights via SLSQP on OOF.")
    
    # V213: Per-coal optimal V61:V63 (no V72)
    print(f"\n{'=' * 70}")
    print("  V213: Per-coal optimal V61:V63 blend")
    print(f"{'=' * 70}")
    
    optimal_weights_2 = {}
    all_blend_preds_2 = {}
    cv_results_2 = {}
    
    for coal in COAL_TYPES:
        if coal not in all_oof:
            continue
        models = all_oof[coal]
        oof_true = models['V61']['oof_true']
        oof_v61 = models['V61']['oof_preds']
        oof_v63 = models['V63']['oof_preds']
        
        oof_stack = np.column_stack([oof_v61, oof_v63])
        
        def rmse_loss_2(w):
            pred = oof_stack @ w
            return np.sqrt(np.mean((pred - oof_true) ** 2))
        
        n_models = 2
        cons = {'type': 'eq', 'fun': lambda w: w.sum() - 1}
        bounds = [(0, 1)] * n_models
        w0 = np.array([0.5, 0.5])
        res = sp_minimize(rmse_loss_2, w0, method='SLSQP', bounds=bounds, constraints=cons)
        opt_weights = res.x
        
        opt_pred = oof_stack @ opt_weights
        opt_rmse = float(np.sqrt(np.mean((opt_pred - oof_true) ** 2)))
        
        print(f"\n  [{coal}]")
        print(f"    Optimal RMSE: {opt_rmse:.2f}")
        print(f"    Weights: V61={opt_weights[0]:.3f} V63={opt_weights[1]:.3f}")
        
        optimal_weights_2[coal] = opt_weights
        cv_results_2[coal] = opt_rmse
        
        for batch_name in all_test[coal]['V61']:
            pred = (opt_weights[0] * all_test[coal]['V61'][batch_name] +
                    opt_weights[1] * all_test[coal]['V63'][batch_name])
            all_blend_preds_2[batch_name] = pred
    
    pack_submission('v213_percoal_v61_v63_optimal', all_blend_preds_2, cv_results_2,
                    "Per-coal optimal V61:V63 weights via SLSQP on OOF (no V72).")
    
    # V214: Per-coal stacking with Ridge meta-learner
    print(f"\n{'=' * 70}")
    print("  V214: Per-coal Ridge stacking meta-learner")
    print(f"{'=' * 70}")
    
    all_blend_preds_3 = {}
    cv_results_stack = {}
    
    for coal in COAL_TYPES:
        if coal not in all_oof:
            continue
        models = all_oof[coal]
        oof_true = models['V61']['oof_true']
        oof_v61 = models['V61']['oof_preds']
        oof_v63 = models['V63']['oof_preds']
        oof_v72 = models['V72']['oof_preds']
        
        oof_stack = np.column_stack([oof_v61, oof_v63, oof_v72])
        
        # Ridge meta-learner (allows negative weights and intercept)
        meta = Ridge(alpha=1.0)
        meta.fit(oof_stack, oof_true)
        stack_pred = meta.predict(oof_stack)
        stack_rmse = float(np.sqrt(np.mean((stack_pred - oof_true) ** 2)))
        
        print(f"\n  [{coal}]")
        print(f"    Stack RMSE: {stack_rmse:.2f}")
        print(f"    Coef: V61={meta.coef_[0]:.3f} V63={meta.coef_[1]:.3f} V72={meta.coef_[2]:.3f}")
        print(f"    Intercept: {meta.intercept_:.2f}")
        
        cv_results_stack[coal] = stack_rmse
        
        for batch_name in all_test[coal]['V61']:
            test_stack = np.array([
                all_test[coal]['V61'][batch_name],
                all_test[coal]['V63'][batch_name],
                all_test[coal]['V72'][batch_name]
            ])
            pred = float(meta.predict(test_stack.reshape(1, -1))[0])
            all_blend_preds_3[batch_name] = pred
    
    pack_submission('v214_percoal_ridge_stacking', all_blend_preds_3, cv_results_stack,
                    "Per-coal Ridge stacking meta-learner on V61/V63/V72 OOF predictions.")
    
    # V215: Global stacking (all coals pooled)
    print(f"\n{'=' * 70}")
    print("  V215: Global Ridge stacking")
    print(f"{'=' * 70}")
    
    all_oof_p, all_oof_t = [], []
    for coal in COAL_TYPES:
        if coal not in all_oof:
            continue
        models = all_oof[coal]
        oof_true = models['V61']['oof_true']
        oof_v61 = models['V61']['oof_preds']
        oof_v63 = models['V63']['oof_preds']
        oof_v72 = models['V72']['oof_preds']
        oof_stack = np.column_stack([oof_v61, oof_v63, oof_v72])
        all_oof_p.append(oof_stack)
        all_oof_t.append(oof_true)
    
    all_oof_p = np.vstack(all_oof_p)
    all_oof_t = np.concatenate(all_oof_t)
    
    meta = Ridge(alpha=1.0)
    meta.fit(all_oof_p, all_oof_t)
    stack_pred = meta.predict(all_oof_p)
    stack_rmse = float(np.sqrt(np.mean((stack_pred - all_oof_t) ** 2)))
    
    print(f"  Global stack RMSE: {stack_rmse:.2f}")
    print(f"  Coef: V61={meta.coef_[0]:.3f} V63={meta.coef_[1]:.3f} V72={meta.coef_[2]:.3f}")
    print(f"  Intercept: {meta.intercept_:.2f}")
    
    all_blend_preds_4 = {}
    for coal in COAL_TYPES:
        if coal not in all_test:
            continue
        for batch_name in all_test[coal]['V61']:
            test_stack = np.array([
                all_test[coal]['V61'][batch_name],
                all_test[coal]['V63'][batch_name],
                all_test[coal]['V72'][batch_name]
            ])
            pred = float(meta.predict(test_stack.reshape(1, -1))[0])
            all_blend_preds_4[batch_name] = pred
    
    pack_submission('v215_global_ridge_stacking', all_blend_preds_4, {'global': stack_rmse},
                    "Global Ridge stacking meta-learner on V61/V63/V72 OOF predictions.")
    
    # Summary and correlation
    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission('submit_v96_blend_v74_v72_7525.zip')
    if v96 is not None:
        v96_arr = np.array(v96.values)
        for vid in ['v206', 'v207', 'v212', 'v213', 'v214', 'v215']:
            sub = load_existing_submission(f'submit_{vid}.zip')
            if sub is None:
                continue
            sub_arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, sub_arr)[0, 1]
            print(f"  corr(V96, {vid}) = {corr:.6f}")
    
    print("\n  Done.")
