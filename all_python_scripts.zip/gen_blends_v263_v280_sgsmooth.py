"""
gen_blends_v263_v280_sgsmooth.py
SG smoothing (CV=170.13) is promising. Generate blends and check correlations.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V263 = 'submit_v263_sgsmooth_w5_snv_ridge_a005_linear.zip'
    V264 = 'submit_v264_sgsmooth_w5_snv_ridge_a005_isotonic.zip'
    V221 = 'submit_v221_a003_linear.zip'
    V218 = 'submit_v218_a015_isotonic.zip'
    V206 = 'submit_v206_deriv1_a005_isotonic.zip'
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    if v96 is None:
        print("V96 not found!")
        exit()
    v96_arr = np.array(v96.values)
    
    models_to_check = [
        ('V263_sgsmooth_linear', V263),
        ('V264_sgsmooth_isotonic', V264),
        ('V221_a003_linear', V221),
        ('V218_a015_isotonic', V218),
        ('V206_deriv1_isotonic', V206),
        ('V61_a005_linear', V61),
        ('V63_isotonic', V63),
        ('V72_isotonic_a005', V72),
        ('V74_blend', V74),
    ]
    
    for label, fname in models_to_check:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:30s} MISSING")
            continue
        arr = np.array(sub.values)
        corr_v96 = np.corrcoef(v96_arr, arr)[0, 1]
        mae_v96 = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:30s}  corr(V96)={corr_v96:.6f}  MAE={mae_v96:.2f}")
    
    # Also check V263 vs V61 (same model, different preprocessing)
    v263 = load_existing_submission(V263)
    v61 = load_existing_submission(V61)
    if v263 is not None and v61 is not None:
        corr = np.corrcoef(np.array(v263.values), np.array(v61.values))[0, 1]
        mae = np.mean(np.abs(np.array(v263.values) - np.array(v61.values)))
        print(f"\n  corr(V263_sgsmooth, V61_snv) = {corr:.6f}  MAE = {mae:.2f}")
    
    # V263 vs V184 (both CV~170, but different preprocessing)
    v184 = load_existing_submission('submit_v184_deriv1_a005_linear.zip')
    if v263 is not None and v184 is not None:
        corr = np.corrcoef(np.array(v263.values), np.array(v184.values))[0, 1]
        mae = np.mean(np.abs(np.array(v263.values) - np.array(v184.values)))
        print(f"  corr(V263_sgsmooth, V184_deriv1) = {corr:.6f}  MAE = {mae:.2f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION (SG smoothing)")
    print(f"{'=' * 70}")
    
    blends = [
        # V263 + V63 50/50 (V74 equivalent with SG smoothing)
        ('v266_blend_v263_v63_5050', [(V263, 0.5), (V63, 0.5)],
         "V263-sgsmooth(50%) + V63(50%). V74 equivalent with SG smoothing."),
        
        # V266 + V72 75/25 (V96 equivalent with SG smoothing)
        ('v267_blend_v266_v72_7525', [('submit_v266_blend_v263_v63_5050.zip', 0.75), (V72, 0.25)],
         "V266(75%) + V72(25%). V96 structure with SG smoothing."),
        
        # V96 + V263 at various ratios
        ('v268_blend_v96_v263_9010', [(V96, 0.9), (V263, 0.1)],
         "V96(90%) + V263-sgsmooth(10%)."),
        ('v269_blend_v96_v263_8020', [(V96, 0.8), (V263, 0.2)],
         "V96(80%) + V263-sgsmooth(20%)."),
        ('v270_blend_v96_v263_9505', [(V96, 0.95), (V263, 0.05)],
         "V96(95%) + V263-sgsmooth(5%)."),
        
        # V96 + V264 (isotonic version)
        ('v271_blend_v96_v264_9010', [(V96, 0.9), (V264, 0.1)],
         "V96(90%) + V264-sgsmooth-iso(10%)."),
        ('v272_blend_v96_v264_8020', [(V96, 0.8), (V264, 0.2)],
         "V96(80%) + V264-sgsmooth-iso(20%)."),
        
        # 3-way: V96 + V263 + V264 (linear + isotonic SG smoothing)
        ('v273_blend_v96_v263_v264', [(V96, 0.85), (V263, 0.075), (V264, 0.075)],
         "V96(85%) + V263-sgsmooth-lin(7.5%) + V264-sgsmooth-iso(7.5%)."),
        
        # 4-way: V74 + V263 + V264 + V72 (V96 with SG smoothing diversity)
        ('v274_blend_4way_sgsmooth', [(V74, 0.50), (V263, 0.15), (V264, 0.15), (V72, 0.20)],
         "4-way: V74(50%) + V263(15%) + V264(15%) + V72(20%). SG smoothing diversity."),
        
        # V263 + V221 (two low-CV models)
        ('v275_blend_v263_v221_5050', [(V263, 0.5), (V221, 0.5)],
         "V263-sgsmooth(50%) + V221-a003(50%). Two lowest CV models."),
        
        # V96 + V263 + V221 (3-way with two low-CV models)
        ('v276_blend_v96_v263_v221', [(V96, 0.80), (V263, 0.10), (V221, 0.10)],
         "V96(80%) + V263(10%) + V221(10%). Two low-CV additions."),
        
        # V96 + V267 (V96-sgsmooth equivalent)
        ('v277_blend_v96_v267_8020', [(V96, 0.8), ('submit_v267_blend_v266_v72_7525.zip', 0.2)],
         "V96(80%) + V267-sgsmooth-v96(20%)."),
        ('v278_blend_v96_v267_9010', [(V96, 0.9), ('submit_v267_blend_v266_v72_7525.zip', 0.1)],
         "V96(90%) + V267-sgsmooth-v96(10%)."),
        
        # V96 + V274 (4-way SG smooth)
        ('v279_blend_v96_v274_8020', [(V96, 0.8), ('submit_v274_blend_4way_sgsmooth.zip', 0.2)],
         "V96(80%) + V274-4way-sgsmooth(20%)."),
        
        # V263 + V63 60/40 (more weight on SG smoothing)
        ('v280_blend_v263_v63_6040', [(V263, 0.6), (V63, 0.4)],
         "V263-sgsmooth(60%) + V63(40%). More SG smoothing weight."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    key_blends = ['v266', 'v267', 'v268', 'v269', 'v270', 'v271', 'v272', 
                  'v273', 'v274', 'v275', 'v276', 'v277', 'v278', 'v279', 'v280']
    
    for vid in key_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
