"""
exp_v260_v270_tree_models.py

Tree-based models on hand features only. Genuinely different from Ridge.
Also SG smoothing preprocessing variants.
"""
import os, sys, re, glob, warnings, io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}

# Global config for pipeline tuning (can be overridden before run_experiment)
PIPELINE_CONFIG = {
    'batch_agg': 'median',      # 'median', 'mean', 'trim_mean'
    'ensemble_agg': 'mean',     # 'mean', 'median', 'trim_mean'
    'fixed_shrink_w': None,     # None = OOF-optimized, float = fixed weight
}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data, preprocessing='snv'):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        if preprocessing == 'snv':
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
        elif preprocessing == 'sg_smooth':
            # Savitzky-Golay smoothing (window=5, order=2)
            processed = sg_smooth(inten, window=5, order=2)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'sg_smooth_w7':
            processed = sg_smooth(inten, window=7, order=3)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'sg_smooth_w7_o2':
            processed = sg_smooth(inten, window=7, order=2)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'sg_smooth_w9':
            processed = sg_smooth(inten, window=9, order=2)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'sg_smooth_w11':
            processed = sg_smooth(inten, window=11, order=2)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'sg_smooth_w7_o1':
            processed = sg_smooth(inten, window=7, order=1)
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'area_norm':
            total = inten.sum() + 1e-8
            processed = inten / total
            processed = (processed - processed.mean()) / (processed.std() + 1e-8)
        elif preprocessing == 'snv_then_sg':
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
            processed = sg_smooth(processed, window=5, order=2)
        elif preprocessing == 'snv_then_sg_w7':
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
            processed = sg_smooth(processed, window=7, order=2)
        else:
            processed = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(processed)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def sg_smooth(y, window=5, order=2):
    """Savitzky-Golay smoothing without dependency on scipy.signal"""
    half = window // 2
    n = len(y)
    # Fit polynomial in sliding window
    result = y.copy()
    x = np.arange(-half, half + 1)
    # Precompute Vandermonde matrix
    A = np.vander(x, order + 1, increasing=True)
    pinv = np.linalg.pinv(A)
    coeffs = pinv[0]  # Coefficients for center point
    for i in range(half, n - half):
        window_data = y[i - half:i + half + 1]
        result[i] = np.dot(coeffs, window_data)
    # Handle edges: use first/last valid fit
    for i in range(half):
        # Use asymmetric window at start
        x_adj = np.arange(i, min(i + window, n))
        if len(x_adj) > order:
            A_adj = np.vander(x_adj - i, order + 1, increasing=True)
            pinv_adj = np.linalg.pinv(A_adj)
            result[i] = np.dot(pinv_adj[0], y[x_adj])
    for i in range(n - half, n):
        x_adj = np.arange(max(0, i - half), n)
        if len(x_adj) > order:
            A_adj = np.vander(x_adj - i, order + 1, increasing=True)
            pinv_adj = np.linalg.pinv(A_adj)
            result[i] = np.dot(pinv_adj[0], y[x_adj])
    return result


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=N_PCA_MAX, use_pca=True):
    spec_mat = data.get('_spec_mat')
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    
    if use_pca:
        if fit:
            scaler_spec = StandardScaler()
            spec_scaled = scaler_spec.fit_transform(spec_mat)
            n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
            n_pca = max(1, n_pca)
            pca = PCA(n_components=n_pca, random_state=42)
            spec_pca = pca.fit_transform(spec_scaled)
        else:
            spec_pca = pca.transform(scaler_spec.transform(spec_mat))
        X = np.hstack([spec_pca, hand_feats])
    else:
        X = hand_feats
    
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    k = min(5, n_batches)
    if seed is not None:
        gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
    else:
        gkf = GroupKFold(n_splits=k)
    return list(gkf.split(dummy, dummy, groups))


def batch_aggregate(preds_mask, method=None):
    if method is None:
        method = PIPELINE_CONFIG.get('batch_agg', 'median')
    if method == 'mean':
        return float(np.mean(preds_mask))
    elif method == 'trim_mean':
        n = len(preds_mask)
        k = max(1, n // 5)
        sorted_p = np.sort(preds_mask)
        return float(np.mean(sorted_p[k:-k])) if n > 2 * k else float(np.mean(preds_mask))
    else:
        return float(np.median(preds_mask))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    fixed_w = PIPELINE_CONFIG.get('fixed_shrink_w', None)
    if fixed_w is not None:
        blended = fixed_w * np.array(oof_preds) + (1 - fixed_w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        return fixed_w, rmse
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_gbr_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, use_two_stage=True):
    """Gradient Boosting with two-stage"""
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = GradientBoostingRegressor(
            n_estimators=100, max_depth=3, learning_rate=0.05,
            subsample=0.8, random_state=42, min_samples_leaf=5)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m_full = GradientBoostingRegressor(
            n_estimators=100, max_depth=3, learning_rate=0.05,
            subsample=0.8, random_state=42, min_samples_leaf=5)
        m_full.fit(X, y_aux)
        aux_models[col_name] = m_full

    if use_two_stage:
        X_s2 = np.hstack([X, predicted_aux_oof])
    else:
        X_s2 = X
    X_s2 = np.nan_to_num(X_s2)

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = GradientBoostingRegressor(
            n_estimators=200, max_depth=3, learning_rate=0.05,
            subsample=0.8, random_state=42, min_samples_leaf=5)
        m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask])
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_center)
    final_model = GradientBoostingRegressor(
        n_estimators=200, max_depth=3, learning_rate=0.05,
        subsample=0.8, random_state=42, min_samples_leaf=5)
    final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
        'use_two_stage': use_two_stage,
        'X_s2_cols': X_s2.shape[1],
    }


def train_rf_run(X, y, aux, groups, splits, coal_center, n_batches,
                 sample_weights=None, use_two_stage=True):
    """Random Forest with two-stage"""
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = RandomForestRegressor(
            n_estimators=200, max_depth=8, min_samples_leaf=3,
            random_state=42, n_jobs=-1)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m_full = RandomForestRegressor(
            n_estimators=200, max_depth=8, min_samples_leaf=3,
            random_state=42, n_jobs=-1)
        m_full.fit(X, y_aux)
        aux_models[col_name] = m_full

    if use_two_stage:
        X_s2 = np.hstack([X, predicted_aux_oof])
    else:
        X_s2 = X
    X_s2 = np.nan_to_num(X_s2)

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = RandomForestRegressor(
            n_estimators=300, max_depth=10, min_samples_leaf=2,
            random_state=42, n_jobs=-1)
        m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask])
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_center)
    final_model = RandomForestRegressor(
        n_estimators=300, max_depth=10, min_samples_leaf=2,
        random_state=42, n_jobs=-1)
    final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
        'use_two_stage': use_two_stage,
        'X_s2_cols': X_s2.shape[1],
    }


def train_ridge_run(X, y, aux, groups, splits, coal_center, n_batches,
                    sample_weights=None, ridge_alpha=0.05):
    """Standard Ridge two-stage (for reference)"""
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m_full = Ridge(alpha=ridge_alpha)
        if sample_weights is not None:
            m_full.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m_full.fit(X, y_aux)
        aux_models[col_name] = m_full

    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask])
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_center)
    final_model = Ridge(alpha=ridge_alpha)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
        'use_two_stage': True,
        'X_s2_cols': X_s2.shape[1],
        'is_ridge': True,
    }


def predict_test(X_test, test_data, run, coal_center, is_tree=False):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)
    
    if run.get('use_two_stage', True):
        X_test_s = np.hstack([X_test, pred_aux])
    else:
        X_test_s = X_test
    X_test_s = np.nan_to_num(X_test_s)
    
    if not is_tree and run.get('is_ridge', False):
        X_test_s = run['scaler_s2'].transform(X_test_s)
    
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = batch_aggregate(preds[mask])
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


def train_and_predict_coal(coal, label_map, aux_map,
                           model_type='ridge', ridge_alpha=0.05,
                           calibration='linear', preprocessing='snv',
                           use_pca=True, use_two_stage=True):
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    spec_mat = compute_features(train_data, preprocessing=preprocessing)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True, use_pca=use_pca)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    # For tree models, use fewer seeds (they're slower)
    if model_type == 'gbr':
        seeds = [42] if is_small else list(range(10))  # Only 10 seeds for GBR
    elif model_type == 'rf':
        seeds = [42] if is_small else list(range(10))  # Only 10 seeds for RF
    else:
        seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        if model_type == 'gbr':
            run = train_gbr_run(X, y, aux, groups, splits, coal_center, n_batches,
                                sample_weights, use_two_stage)
            run['is_tree'] = True
        elif model_type == 'rf':
            run = train_rf_run(X, y, aux, groups, splits, coal_center, n_batches,
                               sample_weights, use_two_stage)
            run['is_tree'] = True
        else:
            run = train_ridge_run(X, y, aux, groups, splits, coal_center, n_batches,
                                  sample_weights, ridge_alpha)
            run['is_tree'] = False
        runs.append(run)

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    # Average shrinkage weight for ensemble
    avg_w = float(np.mean([r['shrink_w'] for r in runs]))
    for r in runs:
        r['shrink_w'] = avg_w

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
        print(f"    Bias: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)
    elif calibration == 'poly2':
        coeffs = np.polyfit(all_oof_p, all_oof_t, 2)
        calibrator = ('poly2', coeffs)
        print(f"    Poly2: {coeffs}")
    elif calibration == 'poly3':
        coeffs = np.polyfit(all_oof_p, all_oof_t, 3)
        calibrator = ('poly3', coeffs)
        print(f"    Poly3: {coeffs}")
    elif calibration == 'none':
        calibrator = None
    elif calibration == 'ridge_calib':
        from sklearn.linear_model import Ridge as RidgeCalib
        rc = RidgeCalib(alpha=1.0)
        rc.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(rc.coef_[0]), float(rc.intercept_)
        calibrator = ('ridge_calib', a, b)
        print(f"    RidgeCalib: a={a:.4f}, b={b:.2f}")
    elif calibration == 'clip_linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        oof_min, oof_max = float(np.min(all_oof_p)), float(np.max(all_oof_p))
        calibrator = ('clip_linear', a, b, oof_min, oof_max)
        print(f"    ClipLinear: a={a:.4f}, b={b:.2f}, range=[{oof_min:.1f}, {oof_max:.1f}]")
    elif calibration == 'ridge_hi':
        from sklearn.linear_model import Ridge as RidgeCalib
        rc = RidgeCalib(alpha=100.0)
        rc.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(rc.coef_[0]), float(rc.intercept_)
        calibrator = ('ridge_hi', a, b)
        print(f"    RidgeHi(a=100): a={a:.4f}, b={b:.2f}")
    elif calibration == 'huber_calib':
        from sklearn.linear_model import HuberRegressor
        hr = HuberRegressor(epsilon=1.35, max_iter=200)
        hr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(hr.coef_[0]), float(hr.intercept_)
        calibrator = ('huber_calib', a, b)
        print(f"    HuberCalib: a={a:.4f}, b={b:.2f}")
    elif calibration == 'clip_linear_iso':
        # Isotonic within OOF range, linear extrapolation outside
        ir = IsotonicRegression(out_of_bounds='nan', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        oof_min, oof_max = float(np.min(all_oof_p)), float(np.max(all_oof_p))
        calibrator = ('clip_linear_iso', ir, a, b, oof_min, oof_max)
        print(f"    ClipLinearIso: linear a={a:.4f}, b={b:.2f}, iso in [{oof_min:.1f}, {oof_max:.1f}]")

    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data, preprocessing=preprocessing)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False, use_pca=use_pca)

    is_tree = model_type in ('gbr', 'rf')
    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center, is_tree=is_tree)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    ens_agg = PIPELINE_CONFIG.get('ensemble_agg', 'mean')
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        if ens_agg == 'median':
            pred_val = float(np.median(vals))
        elif ens_agg == 'trim_mean':
            n = len(vals)
            k = max(1, n // 5)
            sv = sorted(vals)
            pred_val = float(np.mean(sv[k:-k])) if n > 2 * k else float(np.mean(vals))
        else:
            pred_val = float(np.mean(vals))
        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])
            elif calibrator[0] == 'poly2':
                _, coeffs = calibrator
                pred_val = float(np.polyval(coeffs, pred_val))
            elif calibrator[0] == 'poly3':
                _, coeffs = calibrator
                pred_val = float(np.polyval(coeffs, pred_val))
            elif calibrator[0] == 'ridge_calib':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'clip_linear':
                _, a, b, oof_min, oof_max = calibrator
                raw = a * pred_val + b
                pred_val = float(np.clip(raw, oof_min, oof_max))
            elif calibrator[0] == 'ridge_hi':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'huber_calib':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'clip_linear_iso':
                _, ir, a, b, oof_min, oof_max = calibrator
                if pred_val < oof_min or pred_val > oof_max:
                    pred_val = a * pred_val + b
                else:
                    pred_val = float(ir.predict([pred_val])[0])
        test_preds[name] = pred_val

    return {'cv_rmse': cv_rmse, 'test_preds': test_preds,
            'oof_preds': all_oof_p, 'oof_true': all_oof_t}


def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n\n"
    readme += "## CV-RMSE\n\n| 煤种 | CV-RMSE |\n|---|---|\n"
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def run_experiment(vid, desc, **kwargs):
    print(f"\n{'=' * 70}")
    print(f"  {vid}: {desc}")
    print(f"{'=' * 70}")
    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}
    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map, **kwargs)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")
    return pack_submission(vid, all_preds, cv_results, desc)


if __name__ == '__main__':
    # V260: GBR on hand features only (no PCA, no two-stage)
    run_experiment(
        'v260_gbr_hand_only_notw_linear',
        "Gradient Boosting on hand features only, no PCA, no two-stage. Tree-based diversity.",
        model_type='gbr', calibration='linear', preprocessing='snv',
        use_pca=False, use_two_stage=False)
    
    # V261: GBR on PCA+hand features with two-stage
    run_experiment(
        'v261_gbr_full_twostage_linear',
        "GBR on PCA+hand features, two-stage. Full pipeline with tree model.",
        model_type='gbr', calibration='linear', preprocessing='snv',
        use_pca=True, use_two_stage=True)
    
    # V262: RF on hand features only
    run_experiment(
        'v262_rf_hand_only_notw_linear',
        "Random Forest on hand features only, no PCA, no two-stage.",
        model_type='rf', calibration='linear', preprocessing='snv',
        use_pca=False, use_two_stage=False)
    
    # V263: SG smoothing + Ridge (different preprocessing, same model)
    run_experiment(
        'v263_sgsmooth_w5_snv_ridge_a005_linear',
        "SG smoothing (w5, order2) + SNV + Ridge alpha=0.05 + linear. Smoother spectra.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='sg_smooth', use_pca=True, use_two_stage=True)
    
    # V264: SG smoothing + Ridge isotonic
    run_experiment(
        'v264_sgsmooth_w5_snv_ridge_a005_isotonic',
        "SG smoothing (w5, order2) + SNV + Ridge alpha=0.05 + isotonic.",
        model_type='ridge', ridge_alpha=0.05, calibration='isotonic',
        preprocessing='sg_smooth', use_pca=True, use_two_stage=True)
    
    # V265: GBR hand only + isotonic
    run_experiment(
        'v265_gbr_hand_only_notw_isotonic',
        "GBR on hand features only, isotonic calibration.",
        model_type='gbr', calibration='isotonic', preprocessing='snv',
        use_pca=False, use_two_stage=False)
    
    # === NEW: SG smoothing variants ===
    
    # V281: SG w7 order2 + linear
    run_experiment(
        'v281_sgsmooth_w7_o2_snv_a005_linear',
        "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)
    
    # V282: SG w9 order2 + linear
    run_experiment(
        'v282_sgsmooth_w9_snv_a005_linear',
        "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='sg_smooth_w9', use_pca=True, use_two_stage=True)
    
    # V283: SG w7 order2 + isotonic
    run_experiment(
        'v283_sgsmooth_w7_o2_snv_a005_isotonic',
        "SG smoothing (w7, order2) + SNV + Ridge a=0.05 + isotonic.",
        model_type='ridge', ridge_alpha=0.05, calibration='isotonic',
        preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)
    
    # V284: SG w9 order2 + isotonic
    run_experiment(
        'v284_sgsmooth_w9_snv_a005_isotonic',
        "SG smoothing (w9, order2) + SNV + Ridge a=0.05 + isotonic.",
        model_type='ridge', ridge_alpha=0.05, calibration='isotonic',
        preprocessing='sg_smooth_w9', use_pca=True, use_two_stage=True)
    
    # V285: SG w11 + linear
    run_experiment(
        'v285_sgsmooth_w11_snv_a005_linear',
        "SG smoothing (w11, order2) + SNV + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='sg_smooth_w11', use_pca=True, use_two_stage=True)
    
    # V286: SG w5 + a=0.03 + linear (lower alpha)
    run_experiment(
        'v286_sgsmooth_w5_snv_a003_linear',
        "SG smoothing (w5) + SNV + Ridge a=0.03 + linear. Lower alpha.",
        model_type='ridge', ridge_alpha=0.03, calibration='linear',
        preprocessing='sg_smooth', use_pca=True, use_two_stage=True)
    
    # V287: SG w5 + a=0.1 + isotonic (V63 equivalent)
    run_experiment(
        'v287_sgsmooth_w5_snv_a01_isotonic',
        "SG smoothing (w5) + SNV + Ridge a=0.1 + isotonic. V63 equivalent.",
        model_type='ridge', ridge_alpha=0.1, calibration='isotonic',
        preprocessing='sg_smooth', use_pca=True, use_two_stage=True)
    
    # V288: SG w7 + a=0.03 + linear
    run_experiment(
        'v288_sgsmooth_w7_o2_snv_a003_linear',
        "SG smoothing (w7, order2) + SNV + Ridge a=0.03 + linear.",
        model_type='ridge', ridge_alpha=0.03, calibration='linear',
        preprocessing='sg_smooth_w7_o2', use_pca=True, use_two_stage=True)
    
    # V289: SNV then SG w5 + linear (reverse order)
    run_experiment(
        'v289_snv_then_sg_w5_a005_linear',
        "SNV + SG smooth (w5, reverse order) + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='snv_then_sg', use_pca=True, use_two_stage=True)
    
    # V290: SNV then SG w7 + linear
    run_experiment(
        'v290_snv_then_sg_w7_a005_linear',
        "SNV + SG smooth (w7, reverse order) + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='snv_then_sg_w7', use_pca=True, use_two_stage=True)
    
    # V291: SG w7 order1 (linear filter) + linear
    run_experiment(
        'v291_sgsmooth_w7_o1_snv_a005_linear',
        "SG smoothing (w7, order1=linear) + SNV + Ridge a=0.05 + linear.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='sg_smooth_w7_o1', use_pca=True, use_two_stage=True)
    
    # V292: Area normalization + linear
    run_experiment(
        'v292_area_norm_a005_linear',
        "Area normalization + Ridge a=0.05 + linear. Alternative scatter correction.",
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocessing='area_norm', use_pca=True, use_two_stage=True)
    
    print("\n  Done.")
