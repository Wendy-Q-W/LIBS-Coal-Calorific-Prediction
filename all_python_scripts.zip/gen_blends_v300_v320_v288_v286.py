"""
gen_blends_v300_v320_v288_v286.py
Generate properly named blends for V288 (best, CV=162.63) and V286 (second, CV=163.41).
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    V288 = 'submit_v288_sgsmooth_w7_o2_snv_a003_linear.zip'
    V286 = 'submit_v286_sgsmooth_w5_snv_a003_linear.zip'
    V282 = 'submit_v282_sgsmooth_w9_snv_a005_linear.zip'
    V290 = 'submit_v290_snv_then_sg_w7_a005_linear.zip'
    V263 = 'submit_v263_sgsmooth_w5_snv_ridge_a005_linear.zip'
    V264 = 'submit_v264_sgsmooth_w5_snv_ridge_a005_isotonic.zip'
    V284 = 'submit_v284_sgsmooth_w9_snv_a005_isotonic.zip'
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V288_sg_w7_a003', V288, 162.63),
        ('V286_sg_w5_a003', V286, 163.41),
        ('V290_snv_sg_w7', V290, 167.59),
        ('V282_sg_w9_a005', V282, 168.92),
        ('V284_sg_w9_iso', V284, 168.92),
        ('V281_sg_w7_a005', 'submit_v281_sgsmooth_w7_o2_snv_a005_linear.zip', 169.04),
        ('V263_sg_w5_a005', V263, 170.13),
        ('V61_a005', V61, 172.15),
        ('V63_a01_iso', V63, 184.0),
        ('V72_iso_a005', V72, 178.0),
    ]
    
    for label, fname, cv in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  CV={cv:6.2f}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:25s}  CV={cv:6.2f}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === V288 (best, CV=162.63) blends ===
        
        # V288 + V63 50/50 (V74 equivalent with SG w7 + a=0.03)
        ('v304_blend_v288_v63_5050', [(V288, 0.5), (V63, 0.5)],
         "V288-sgsmooth-w7-a003(50%) + V63(50%). V74 equivalent. CV~162+184/2=173"),
        
        # V304 + V72 75/25 (V96 equivalent with SG w7 + a=0.03)
        ('v305_blend_v304_v72_7525', [('submit_v304_blend_v288_v63_5050.zip', 0.75), (V72, 0.25)],
         "V304(75%) + V72(25%). V96 structure with SG w7 + a=0.03."),
        
        # V305 + V72 77/23 (V189 equivalent)
        ('v306_blend_v304_v72_7723', [('submit_v304_blend_v288_v63_5050.zip', 0.77), (V72, 0.23)],
         "V304(77%) + V72(23%). V189 structure with SG w7 + a=0.03."),
        
        # V96 + V288 at various ratios
        ('v307_blend_v96_v288_9010', [(V96, 0.9), (V288, 0.1)],
         "V96(90%) + V288(10%). Small addition of best CV model."),
        ('v308_blend_v96_v288_8020', [(V96, 0.8), (V288, 0.2)],
         "V96(80%) + V288(20%). More weight on best CV model."),
        ('v309_blend_v96_v288_9505', [(V96, 0.95), (V288, 0.05)],
         "V96(95%) + V288(5%). Tiny addition."),
        
        # V96 + V305 (V96 + V96-SG-equivalent)
        ('v310_blend_v96_v305_8020', [(V96, 0.8), ('submit_v305_blend_v304_v72_7525.zip', 0.2)],
         "V96(80%) + V305-sgsmooth-v96(20%)."),
        ('v311_blend_v96_v305_9010', [(V96, 0.9), ('submit_v305_blend_v304_v72_7525.zip', 0.1)],
         "V96(90%) + V305-sgsmooth-v96(10%)."),
        
        # === V286 (second best, CV=163.41) blends ===
        
        # V286 + V63 50/50
        ('v312_blend_v286_v63_5050', [(V286, 0.5), (V63, 0.5)],
         "V286-sgsmooth-w5-a003(50%) + V63(50%). V74 equivalent."),
        
        # V312 + V72 75/25
        ('v313_blend_v312_v72_7525', [('submit_v312_blend_v286_v63_5050.zip', 0.75), (V72, 0.25)],
         "V312(75%) + V72(25%). V96 structure with SG w5 + a=0.03."),
        
        # V96 + V286
        ('v314_blend_v96_v286_9010', [(V96, 0.9), (V286, 0.1)],
         "V96(90%) + V286(10%)."),
        
        # === Multi-way blends ===
        
        # V96 + V288 + V286 (two best SG smooth models)
        ('v315_blend_v96_v288_v286', [(V96, 0.85), (V288, 0.075), (V286, 0.075)],
         "V96(85%) + V288(7.5%) + V286(7.5%). Two best SG smooth models."),
        
        # V96 + V305 + V313 (V96 + two SG-smooth V96 equivalents)
        ('v316_blend_v96_v305_v313', [(V96, 0.70), ('submit_v305_blend_v304_v72_7525.zip', 0.15), ('submit_v313_blend_v312_v72_7525.zip', 0.15)],
         "V96(70%) + V305(15%) + V313(15%). Two SG-smooth V96 equivalents."),
        
        # V189 + V288 (current best + best CV)
        ('v317_blend_v189_v288_9010', [(V189, 0.9), (V288, 0.1)],
         "V189(90%) + V288(10%). Current best + best CV."),
        
        # V288 + V284 (linear + isotonic, both SG smooth, low CV)
        ('v318_blend_v288_v284_5050', [(V288, 0.5), (V284, 0.5)],
         "V288(50%) + V284(50%). SG smooth linear+isotonic."),
        
        # 4-way: V288 + V286 + V63 + V72 (full SG smooth V96)
        ('v319_blend_4way_sg_a003', [(V288, 0.375), (V286, 0.125), (V63, 0.375), (V72, 0.25)],
         "4-way: V288(37.5%) + V286(12.5%) + V63(37.5%) + V72(25%). SG smooth V96."),
        
        # V288 + V63 60/40 (more SG smooth weight)
        ('v320_blend_v288_v63_6040', [(V288, 0.6), (V63, 0.4)],
         "V288(60%) + V63(40%). More SG smooth weight."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    key_blends = ['v304', 'v305', 'v306', 'v307', 'v308', 'v309', 'v310', 'v311',
                  'v312', 'v313', 'v314', 'v315', 'v316', 'v317', 'v318', 'v319', 'v320']
    
    for vid in key_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
