"""V25b: CORAL on V19's full-data PCA baseline

V25 showed per-fold PCA is much worse than V19's full-data PCA (TE 277.75 vs 240.20).
CORAL on per-fold PCA: TE improved -20 but still worse than V19 (257 vs 240).

This experiment: keep V19's full-data PCA (fit on all data), 
then apply CORAL to align val fold's features to train fold's features within OOF.
This combines shared PCA space + explicit covariance alignment.
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from scipy.linalg import sqrtm
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
    extract_month, compute_features_custom, build_fm, oof_ridge,
)


def coral_align(X_source, X_target, reg=1e-5):
    """Align X_target covariance to X_source. Returns aligned X_target."""
    d = X_source.shape[1]
    Cs = np.cov(X_source, rowvar=False) + reg * np.eye(d)
    Ct = np.cov(X_target, rowvar=False) + reg * np.eye(d)
    
    Cs_sqrt = np.real(sqrtm(Cs))
    Ct_inv_sqrt = np.real(np.linalg.inv(np.real(sqrtm(Ct))))
    A = Cs_sqrt @ Ct_inv_sqrt
    
    mean_s = X_source.mean(axis=0)
    mean_t = X_target.mean(axis=0)
    return (X_target - mean_t) @ A.T + mean_s


def gkfold_cv_coral_v19(coal, coral_mode='none', coral_reg=1e-5, n_seeds=10):
    """V19-style full-data PCA + optional CORAL per-fold."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    # V19 style: full-data PCA (fit on all data)
    X = build_fm(inorm_mat, hand_feats, td['n_batches'])
    
    y = td['targets']
    aux = td['aux']
    groups = td['groups']
    nb = td['n_batches']
    coal_mean = float(y.mean())
    
    is_small = nb <= SMALL_BATCH_THRESHOLD
    
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        all_op, all_ot = [], []
        for tr_idx, va_idx in splits:
            X_tr = X[tr_idx]
            X_va = X[va_idx]
            
            if coral_mode == 'pca':
                # CORAL on the full feature matrix (PCA + hand)
                X_va = coral_align(X_tr, X_va, reg=coral_reg)
            elif coral_mode == 'pca_only':
                # CORAL only on first n_pca columns (PCA part), keep hand feats unchanged
                n_pca = min(N_PCA_MAX, nb - 1)
                X_va_pca = coral_align(X_tr[:, :n_pca], X_va[:, :n_pca], reg=coral_reg)
                X_va = np.hstack([X_va_pca, X_va[:, n_pca:]])
            
            # Stage 1: aux
            pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
            pa_va = np.zeros((len(va_idx), aux.shape[1]), dtype=np.float32)
            for ci in range(aux.shape[1]):
                ya = aux[:, ci]
                if np.isnan(ya).any():
                    pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                    pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                    continue
                m1 = Ridge(alpha=RIDGE_ALPHA)
                m1.fit(X_tr, ya[tr_idx])
                pa_tr[:, ci] = m1.predict(X_tr)
                pa_va[:, ci] = m1.predict(X_va)
            
            X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
            X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
            m2 = Ridge(alpha=RIDGE_ALPHA)
            m2.fit(X2_tr, y[tr_idx])
            vp = m2.predict(X2_va)
            vg = groups[va_idx]
            for bg in np.unique(vg):
                mk = vg == bg
                all_op.append(float(np.median(vp[mk])))
                all_ot.append(float(y[va_idx][mk][0]))
        
        w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            all_op, all_ot = [], []
            for tr_idx, va_idx in splits:
                X_tr = X[tr_idx]
                X_va = X[va_idx]
                
                if coral_mode == 'pca':
                    X_va = coral_align(X_tr, X_va, reg=coral_reg)
                elif coral_mode == 'pca_only':
                    n_pca = min(N_PCA_MAX, nb - 1)
                    X_va_pca = coral_align(X_tr[:, :n_pca], X_va[:, :n_pca], reg=coral_reg)
                    X_va = np.hstack([X_va_pca, X_va[:, n_pca:]])
                
                pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
                pa_va = np.zeros((len(va_idx), aux.shape[1]), dtype=np.float32)
                for ci in range(aux.shape[1]):
                    ya = aux[:, ci]
                    if np.isnan(ya).any():
                        pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                        pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                        continue
                    m1 = Ridge(alpha=RIDGE_ALPHA)
                    m1.fit(X_tr, ya[tr_idx])
                    pa_tr[:, ci] = m1.predict(X_tr)
                    pa_va[:, ci] = m1.predict(X_va)
                
                X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
                X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
                m2 = Ridge(alpha=RIDGE_ALPHA)
                m2.fit(X2_tr, y[tr_idx])
                vp = m2.predict(X2_va)
                vg = groups[va_idx]
                for bg in np.unique(vg):
                    mk = vg == bg
                    all_op.append(float(np.median(vp[mk])))
                    all_ot.append(float(y[va_idx][mk][0]))
            
            w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_coral_v19(coal, coral_mode='none', coral_reg=1e-5):
    """V19-style time extrapolation CV with CORAL."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)
    
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    
    # Time split
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    
    # V19 style: fit PCA on train only, transform both
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    n_pca = min(N_PCA_MAX, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)
    
    # Apply CORAL
    if coral_mode == 'pca':
        X_va = coral_align(X_tr, X_va, reg=coral_reg)
    elif coral_mode == 'pca_only':
        X_va_pca = coral_align(X_tr[:, :n_pca], X_va[:, :n_pca], reg=coral_reg)
        X_va = np.hstack([X_va_pca, X_va[:, n_pca:]])
    
    y_tr = y[tm]
    y_va = y[vm]
    aux_tr = aux[tm]
    coal_mean = float(y_tr.mean())
    
    # Stage 1: aux
    pa_tr = np.zeros((len(y_tr), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y_va), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y_tr)
    vp = m2.predict(X2_va)
    
    vg2 = groups[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(y_va[mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def run_config(name, coral_mode='none', coral_reg=1e-5):
    t0 = time.time()
    print(f"\n{'=' * 55}\n  {name}\n{'=' * 55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_coral_v19(coal, coral_mode=coral_mode, coral_reg=coral_reg)
        if r is None:
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_coral_v19(coal, coral_mode=coral_mode, coral_reg=coral_reg)
        if r is None:
            continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time() - t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # Baseline = V19 (full-data PCA, no CORAL)
    results['baseline'] = run_config("V19 baseline (no CORAL)")

    # CORAL on full features (PCA+hand) - various reg
    for reg in [1e-5, 1e-3, 1e-1, 1.0]:
        results[f'coral_full_r{reg}'] = run_config(
            f"CORAL full reg={reg}", coral_mode='pca', coral_reg=reg)

    # CORAL on PCA part only
    for reg in [1e-5, 1e-3, 1e-1]:
        results[f'coral_pca_only_r{reg}'] = run_config(
            f"CORAL PCA-only reg={reg}", coral_mode='pca_only', coral_reg=reg)

    # Summary
    print(f"\n{'=' * 60}")
    print("  V25b: CORAL on V19 full-data PCA -- Dual CV Summary")
    print(f"{'=' * 60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None:
            continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
