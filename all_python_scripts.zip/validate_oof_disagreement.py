"""
validate_oof_disagreement.py
OOF validation: does high V61/V63/V72 disagreement correlate with high OOF error?
Imports pipeline functions from exp_v216_v230_alpha_sweep.py for correctness.
"""
import os, sys, glob, warnings, numpy as np, pandas as pd
from scipy.stats import spearmanr, pearsonr

warnings.filterwarnings('ignore')

# Import all pipeline functions from the existing script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exp_v216_v230_alpha_sweep as pipe

COAL_TYPES = pipe.COAL_TYPES
N_SEEDS = 10


def run_model_oof(coal, ridge_alpha, calibration, n_seeds=N_SEEDS):
    """Run pipeline for one coal, return OOF batch predictions."""
    label_map, aux_map = pipe.load_labels()
    train_data = pipe.load_coal_spectra(pipe.TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None: return None

    spec_mat = pipe.compute_features(train_data, preprocessing='snv')
    train_data['_spec_mat'] = spec_mat
    y = train_data['targets']; aux = train_data['aux']
    groups = train_data['groups']; n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = pipe.build_feature_matrix(
        train_data, n_batches, fit=True)

    is_small = n_batches <= pipe.SMALL_BATCH_THRESHOLD
    sample_weights = None
    if coal in pipe.TIME_WEIGHT_TAU:
        tau = pipe.TIME_WEIGHT_TAU[coal]; months = train_data['months']
        if len(months) == len(y):
            sample_weights = pipe.compute_time_weights(months, pipe.TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(n_seeds))
    all_oof_raw = []; all_oof_true = []; all_batch_names = []
    for seed in seeds:
        splits = pipe.get_cv_splits(groups, n_batches, seed=seed)
        run = pipe.train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                                 sample_weights, ridge_alpha)
        all_oof_raw.extend(run['oof_preds'])
        all_oof_true.extend(run['oof_true'])
        # We need batch names; train_one_run doesn't return them, so we reconstruct
        # from the splits
        for tr_idx, val_idx in splits:
            val_groups = groups[val_idx]
            for bg in np.unique(val_groups):
                all_batch_names.append(bg)

    oof_raw = np.array(all_oof_raw); oof_true = np.array(all_oof_true)
    batch_names = all_batch_names

    # Average across seeds for same batch
    unique_batches = sorted(set(batch_names))
    avg_raw = []; avg_true = []
    for bn in unique_batches:
        mask = [i for i, b in enumerate(batch_names) if b == bn]
        avg_raw.append(np.mean(oof_raw[mask]))
        avg_true.append(np.mean(oof_true[mask]))
    avg_raw = np.array(avg_raw); avg_true = np.array(avg_true)

    # Apply shrinkage (best_w from OOF)
    best_w, cv_rmse = pipe.find_best_shrinkage(avg_raw, avg_true, coal_center)
    shrunk = best_w * avg_raw + (1 - best_w) * coal_center

    # Apply calibration
    if calibration == 'linear':
        a, b = np.polyfit(shrunk, avg_true, 1)
        calib_pred = a * shrunk + b
    elif calibration == 'isotonic':
        from sklearn.isotonic import IsotonicRegression
        ir = IsotonicRegression()
        ir.fit(shrunk, avg_true)
        calib_pred = ir.predict(shrunk)
    else:
        calib_pred = shrunk

    return {
        'batch_names': unique_batches,
        'oof_calib': calib_pred,
        'oof_true': avg_true,
        'coal_center': coal_center,
        'cv_rmse': cv_rmse,
        'shrink_w': best_w,
    }


def main():
    print("=" * 70)
    print("OOF DISAGREEMENT VALIDATION")
    print("=" * 70)

    models = {
        'V61': {'alpha': 0.05, 'calib': 'linear'},
        'V63': {'alpha': 0.10, 'calib': 'isotonic'},
        'V72': {'alpha': 0.05, 'calib': 'isotonic'},
    }

    all_results = {}
    for coal in COAL_TYPES:
        print(f"\n--- {coal} ---")
        coal_results = {}
        for model_name, cfg in models.items():
            print(f"  Running {model_name} (alpha={cfg['alpha']}, calib={cfg['calib']})...")
            result = run_model_oof(coal, cfg['alpha'], cfg['calib'])
            if result is not None:
                coal_results[model_name] = result
                rmse = np.sqrt(np.mean((result['oof_calib'] - result['oof_true'])**2))
                print(f"    OOF RMSE: {rmse:.2f}, shrink_w={result['shrink_w']:.3f}")
        all_results[coal] = coal_results

    # Compute disagreement and error for each batch
    print("\n" + "=" * 70)
    print("DISAGREEMENT vs ERROR ANALYSIS")
    print("=" * 70)

    all_disagree = []; all_error = []; all_coal = []; all_batch = []
    all_v96_pred = []; all_true = []

    for coal, coal_results in all_results.items():
        if len(coal_results) < 3:
            print(f"  WARNING: {coal} has only {len(coal_results)} models, skipping")
            continue
        batch_names = coal_results['V61']['batch_names']
        for i, bn in enumerate(batch_names):
            preds = [coal_results[m]['oof_calib'][i] for m in ['V61', 'V63', 'V72']]
            true_val = coal_results['V61']['oof_true'][i]
            disagree = max(preds) - min(preds)
            v96_pred = 0.375 * preds[0] + 0.375 * preds[1] + 0.25 * preds[2]
            error = abs(v96_pred - true_val)
            all_disagree.append(disagree)
            all_error.append(error)
            all_coal.append(coal)
            all_batch.append(bn)
            all_v96_pred.append(v96_pred)
            all_true.append(true_val)

    all_disagree = np.array(all_disagree)
    all_error = np.array(all_error)
    all_v96_pred = np.array(all_v96_pred)
    all_true = np.array(all_true)

    print(f"\nTotal OOF batches: {len(all_disagree)}")
    if len(all_disagree) == 0:
        print("ERROR: No OOF batches found. Check label loading.")
        return

    print(f"Disagreement stats: mean={np.mean(all_disagree):.1f}, max={np.max(all_disagree):.1f}, median={np.median(all_disagree):.1f}")
    print(f"V96 OOF error stats: mean={np.mean(all_error):.1f}, max={np.max(all_error):.1f}")
    print(f"V96 OOF RMSE: {np.sqrt(np.mean((all_v96_pred - all_true)**2)):.2f}")

    # Correlation
    sp_corr, sp_p = spearmanr(all_disagree, all_error)
    pe_corr, pe_p = pearsonr(all_disagree, all_error)
    print(f"\nSpearman corr(disagreement, |error|): {sp_corr:.4f} (p={sp_p:.4f})")
    print(f"Pearson corr(disagreement, |error|): {pe_corr:.4f} (p={pe_p:.4f})")

    # Top-K analysis
    print("\n--- Top-10 disagreement batches (OOF) ---")
    sorted_idx = np.argsort(all_disagree)[::-1]
    for rank, idx in enumerate(sorted_idx[:10]):
        coal = all_coal[idx]
        bn = all_batch[idx]
        print(f"  #{rank+1}: {coal} {bn} | disagree={all_disagree[idx]:.1f} | "
              f"V96={all_v96_pred[idx]:.1f} | true={all_true[idx]:.1f} | "
              f"error={all_error[idx]:.1f}")

    # Simulate V510-style adjustment (shrink top-2 toward coal mean, 70%)
    print("\n--- Simulating V510-style (K=2, shrink=70%) ---")
    total_sse_orig = 0; total_sse_adj = 0; total_n = 0
    for coal, coal_results in all_results.items():
        if len(coal_results) < 3: continue
        preds_v61 = coal_results['V61']['oof_calib']
        preds_v63 = coal_results['V63']['oof_calib']
        preds_v72 = coal_results['V72']['oof_calib']
        true_vals = coal_results['V61']['oof_true']
        coal_center = coal_results['V61']['coal_center']

        v96_oof = 0.375 * preds_v61 + 0.375 * preds_v63 + 0.25 * preds_v72
        disagree = np.maximum(np.maximum(preds_v61, preds_v63), preds_v72) - \
                   np.minimum(np.minimum(preds_v61, preds_v63), preds_v72)

        orig_rmse = np.sqrt(np.mean((v96_oof - true_vals) ** 2))

        sorted_idx = np.argsort(disagree)[::-1]
        adjusted = v96_oof.copy()
        for idx in sorted_idx[:2]:
            adjusted[idx] = 0.3 * v96_oof[idx] + 0.7 * coal_center

        adj_rmse = np.sqrt(np.mean((adjusted - true_vals) ** 2))
        delta = adj_rmse - orig_rmse
        total_sse_orig += np.sum((v96_oof - true_vals) ** 2)
        total_sse_adj += np.sum((adjusted - true_vals) ** 2)
        total_n += len(v96_oof)

        # Show which batches were adjusted
        adjusted_batches = [coal_results['V61']['batch_names'][i] for i in sorted_idx[:2]]
        print(f"  {coal}: orig={orig_rmse:.2f} -> adj={adj_rmse:.2f} (delta={delta:+.2f})")
        for i in sorted_idx[:2]:
            bn = coal_results['V61']['batch_names'][i]
            print(f"    adjusted: {bn} | disagree={disagree[i]:.1f} | "
                  f"V96={v96_oof[i]:.1f} -> {adjusted[i]:.1f} | true={true_vals[i]:.1f} | "
                  f"orig_err={abs(v96_oof[i]-true_vals[i]):.1f} -> adj_err={abs(adjusted[i]-true_vals[i]):.1f}")

    overall_orig = np.sqrt(total_sse_orig / total_n)
    overall_adj = np.sqrt(total_sse_adj / total_n)
    print(f"\n  OVERALL: orig={overall_orig:.2f} -> adj={overall_adj:.2f} (delta={overall_adj-overall_orig:+.2f})")

    # Simulate V511-style (K=3, shrink=70%)
    print("\n--- Simulating V511-style (K=3, shrink=70%) ---")
    total_sse_orig = 0; total_sse_adj = 0; total_n = 0
    for coal, coal_results in all_results.items():
        if len(coal_results) < 3: continue
        preds_v61 = coal_results['V61']['oof_calib']
        preds_v63 = coal_results['V63']['oof_calib']
        preds_v72 = coal_results['V72']['oof_calib']
        true_vals = coal_results['V61']['oof_true']
        coal_center = coal_results['V61']['coal_center']

        v96_oof = 0.375 * preds_v61 + 0.375 * preds_v63 + 0.25 * preds_v72
        disagree = np.maximum(np.maximum(preds_v61, preds_v63), preds_v72) - \
                   np.minimum(np.minimum(preds_v61, preds_v63), preds_v72)

        orig_rmse = np.sqrt(np.mean((v96_oof - true_vals) ** 2))

        sorted_idx = np.argsort(disagree)[::-1]
        adjusted = v96_oof.copy()
        for idx in sorted_idx[:3]:
            adjusted[idx] = 0.3 * v96_oof[idx] + 0.7 * coal_center

        adj_rmse = np.sqrt(np.mean((adjusted - true_vals) ** 2))
        delta = adj_rmse - orig_rmse
        total_sse_orig += np.sum((v96_oof - true_vals) ** 2)
        total_sse_adj += np.sum((adjusted - true_vals) ** 2)
        total_n += len(v96_oof)

        print(f"  {coal}: orig={orig_rmse:.2f} -> adj={adj_rmse:.2f} (delta={delta:+.2f})")

    overall_orig = np.sqrt(total_sse_orig / total_n)
    overall_adj = np.sqrt(total_sse_adj / total_n)
    print(f"\n  OVERALL: orig={overall_orig:.2f} -> adj={overall_adj:.2f} (delta={overall_adj-overall_orig:+.2f})")

    # Also test different shrinkage levels
    print("\n--- Shrinkage level sweep (K=2) ---")
    for shrink_pct in [0.3, 0.5, 0.7, 0.9, 1.0]:
        total_sse = 0; total_n = 0
        for coal, coal_results in all_results.items():
            if len(coal_results) < 3: continue
            preds_v61 = coal_results['V61']['oof_calib']
            preds_v63 = coal_results['V63']['oof_calib']
            preds_v72 = coal_results['V72']['oof_calib']
            true_vals = coal_results['V61']['oof_true']
            coal_center = coal_results['V61']['coal_center']
            v96_oof = 0.375 * preds_v61 + 0.375 * preds_v63 + 0.25 * preds_v72
            disagree = np.maximum(np.maximum(preds_v61, preds_v63), preds_v72) - \
                       np.minimum(np.minimum(preds_v61, preds_v63), preds_v72)
            sorted_idx = np.argsort(disagree)[::-1]
            adjusted = v96_oof.copy()
            for idx in sorted_idx[:2]:
                adjusted[idx] = (1 - shrink_pct) * v96_oof[idx] + shrink_pct * coal_center
            total_sse += np.sum((adjusted - true_vals) ** 2)
            total_n += len(v96_oof)
        rmse = np.sqrt(total_sse / total_n)
        print(f"  shrink={shrink_pct:.0%}: RMSE={rmse:.2f}")

    print("\n" + "=" * 70)
    print("VALIDATION COMPLETE")
    print("=" * 70)


if __name__ == '__main__':
    main()
