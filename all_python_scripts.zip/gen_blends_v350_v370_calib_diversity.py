"""
gen_blends_v350_v370_calib_diversity.py
Generate blends of new calibration methods with V61/V63/V72/V96.
Key insight: V74 (linear+isotonic) gap=25 < V61 gap=31, V63 gap=20.
More calibration diversity may further reduce gap.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    V341 = 'submit_v341_a005_poly2.zip'
    V342 = 'submit_v342_a005_poly3.zip'
    V343 = 'submit_v343_a005_none.zip'
    V345 = 'submit_v345_a01_poly2.zip'
    V346 = 'submit_v346_a01_poly3.zip'
    V347 = 'submit_v347_a01_none.zip'
    V348 = 'submit_v348_a01_ridge_calib.zip'
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V61_linear', V61),
        ('V63_isotonic', V63),
        ('V72_iso_a005', V72),
        ('V341_poly2_a005', V341),
        ('V342_poly3_a005', V342),
        ('V343_none_a005', V343),
        ('V345_poly2_a01', V345),
        ('V346_poly3_a01', V346),
        ('V347_none_a01', V347),
        ('V348_ridgecal_a01', V348),
    ]
    
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:25s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === V342 (poly3, corr=0.9953) blends - closest to V96 ===
        
        # V342 + V63 50/50 (V74 structure with poly3)
        ('v350_blend_v342_v63_5050', [(V342, 0.5), (V63, 0.5)],
         "V342-poly3(50%) + V63(50%). V74 with poly3 instead of linear."),
        
        # V350 + V72 75/25 (V96 structure with poly3)
        ('v351_blend_v350_v72_7525', [('submit_v350_blend_v342_v63_5050.zip', 0.75), (V72, 0.25)],
         "V350(75%) + V72(25%). V96 structure with poly3."),
        
        # V96 + V342 at various ratios
        ('v352_blend_v96_v342_9010', [(V96, 0.9), (V342, 0.1)],
         "V96(90%) + V342-poly3(10%)."),
        ('v353_blend_v96_v342_8020', [(V96, 0.8), (V342, 0.2)],
         "V96(80%) + V342-poly3(20%)."),
        
        # === V341 (poly2, corr=0.9925) blends - more diversity ===
        
        # V341 + V63 50/50
        ('v354_blend_v341_v63_5050', [(V341, 0.5), (V63, 0.5)],
         "V341-poly2(50%) + V63(50%). V74 with poly2."),
        
        # V354 + V72 75/25
        ('v355_blend_v354_v72_7525', [('submit_v354_blend_v341_v63_5050.zip', 0.75), (V72, 0.25)],
         "V354(75%) + V72(25%). V96 structure with poly2."),
        
        # V96 + V341
        ('v356_blend_v96_v341_9010', [(V96, 0.9), (V341, 0.1)],
         "V96(90%) + V341-poly2(10%)."),
        
        # === Multi-calibration blends ===
        
        # 4-calib equal: V61 + V63 + V341 + V342
        ('v357_blend_4calib_equal', [(V61, 0.25), (V63, 0.25), (V341, 0.25), (V342, 0.25)],
         "4-calib equal: V61-linear(25%) + V63-iso(25%) + V341-poly2(25%) + V342-poly3(25%)."),
        
        # 5-calib equal: V61 + V63 + V341 + V342 + V72
        ('v358_blend_5calib_equal', [(V61, 0.20), (V63, 0.20), (V341, 0.20), (V342, 0.20), (V72, 0.20)],
         "5-calib equal: V61 + V63 + V341-poly2 + V342-poly3 + V72, each 20%."),
        
        # V96 + V357 (V96 + 4-calib diversity)
        ('v359_blend_v96_v357_8020', [(V96, 0.8), ('submit_v357_blend_4calib_equal.zip', 0.2)],
         "V96(80%) + V357-4calib(20%)."),
        ('v360_blend_v96_v357_9010', [(V96, 0.9), ('submit_v357_blend_4calib_equal.zip', 0.1)],
         "V96(90%) + V357-4calib(10%)."),
        
        # V96 + V358 (V96 + 5-calib diversity)
        ('v361_blend_v96_v358_8020', [(V96, 0.8), ('submit_v358_blend_5calib_equal.zip', 0.2)],
         "V96(80%) + V358-5calib(20%)."),
        
        # === V346 (a01_poly3, corr=0.9960) blends ===
        
        # V346 + V61 50/50 (mix a=0.1 poly3 with a=0.05 linear)
        ('v362_blend_v346_v61_5050', [(V346, 0.5), (V61, 0.5)],
         "V346-a01-poly3(50%) + V61-a005-linear(50%)."),
        
        # V362 + V72 75/25
        ('v363_blend_v362_v72_7525', [('submit_v362_blend_v346_v61_5050.zip', 0.75), (V72, 0.25)],
         "V362(75%) + V72(25%). V96 with a01-poly3."),
        
        # V96 + V346
        ('v364_blend_v96_v346_9010', [(V96, 0.9), (V346, 0.1)],
         "V96(90%) + V346-a01-poly3(10%)."),
        
        # === V343 (none, corr=0.9938) blends - raw predictions ===
        
        # V343 + V63 50/50
        ('v365_blend_v343_v63_5050', [(V343, 0.5), (V63, 0.5)],
         "V343-none(50%) + V63(50%). V74 with no calibration."),
        
        # V365 + V72 75/25
        ('v366_blend_v365_v72_7525', [('submit_v365_blend_v343_v63_5050.zip', 0.75), (V72, 0.25)],
         "V365(75%) + V72(25%). V96 with no calibration."),
        
        # V96 + V343
        ('v367_blend_v96_v343_9010', [(V96, 0.9), (V343, 0.1)],
         "V96(90%) + V343-none(10%)."),
        
        # === 6-calib super blend ===
        ('v368_blend_6calib_equal', [(V61, 0.15), (V63, 0.15), (V341, 0.15), (V342, 0.15), (V72, 0.15), (V346, 0.15)],
         "6-calib: V61+V63+V341-poly2+V342-poly3+V72+V346-a01-poly3, each 15%. Remaining 10% to V96."),
        # Fix: weights should sum to 1.0 - use 6 at 1/6 each
    ]
    
    # Fix v368 weights
    blends[-1] = ('v368_blend_6calib_equal', 
                  [(V61, 1/6), (V63, 1/6), (V341, 1/6), (V342, 1/6), (V72, 1/6), (V346, 1/6)],
                  "6-calib equal: V61+V63+V341-poly2+V342-poly3+V72+V346-a01-poly3, each 16.67%.")
    
    # V96 + V368
    blends.append(('v369_blend_v96_v368_8020', [(V96, 0.8), ('submit_v368_blend_6calib_equal.zip', 0.2)],
                   "V96(80%) + V368-6calib(20%)."))
    
    # V189 + V357 (current best + 4-calib diversity)
    blends.append(('v370_blend_v189_v357_8020', [(V189, 0.8), ('submit_v357_blend_4calib_equal.zip', 0.2)],
                   "V189(80%) + V357-4calib(20%). Current best + calibration diversity."))
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v350', 'v351', 'v352', 'v353', 'v354', 'v355', 'v356', 'v357',
                  'v358', 'v359', 'v360', 'v361', 'v362', 'v363', 'v364', 'v365',
                  'v366', 'v367', 'v368', 'v369', 'v370']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
