"""
gen_blends_v426_v445_isotonic_scan.py
Generate blends of isotonic alpha scan models.
Key: V417(a=0.03 iso) CV=164.28, V166=V73=V417 (verify).
If isotonic reduces gap by ~10 vs linear (V221 gap=38), V417 gap≈28, online≈192!
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    V166 = 'submit_v166_a003_isotonic.zip'
    V73 = 'submit_v73_isotonic_a003.zip'
    
    # New isotonic alpha scan models
    V416 = 'submit_v416_iso_a002.zip'  # CV=158.30
    V417 = 'submit_v417_iso_a003.zip'  # CV=164.28 (should = V166)
    V418 = 'submit_v418_iso_a004.zip'  # CV=168.72
    V419 = 'submit_v419_iso_a006.zip'  # CV=175.12
    V420 = 'submit_v420_iso_a008.zip'  # CV=179.67
    V421 = 'submit_v421_iso_a012.zip'  # CV=185.93
    V422 = 'submit_v422_iso_a015.zip'  # CV=188.80
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V61_linear_ref', V61),
        ('V63_isotonic_ref', V63),
        ('V72_iso_a005_ref', V72),
        ('V166_a003_iso', V166),
        ('V73_a003_iso', V73),
        ('V416_a002_iso', V416),
        ('V417_a003_iso', V417),
        ('V418_a004_iso', V418),
        ('V419_a006_iso', V419),
        ('V420_a008_iso', V420),
        ('V421_a012_iso', V421),
        ('V422_a015_iso', V422),
    ]
    
    corr_data = {}
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        corr_data[label] = (corr, mae, fname)
        print(f"  {label:25s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Verify V166 = V73 = V417
    print(f"\n  === Verify V166 = V73 = V417 ===")
    v166 = load_existing_submission(V166)
    v73 = load_existing_submission(V73)
    v417 = load_existing_submission(V417)
    if v166 is not None and v73 is not None:
        diff = np.max(np.abs(np.array(v166.values) - np.array(v73.values)))
        print(f"  max|V166 - V73| = {diff:.4f}")
    if v166 is not None and v417 is not None:
        diff = np.max(np.abs(np.array(v166.values) - np.array(v417.values)))
        print(f"  max|V166 - V417| = {diff:.4f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === V417/V166 (a=0.03 iso) blends - THE KEY CANDIDATE ===
        
        # V417 + V61 50/50 (V74 structure with a=0.03 iso)
        ('v426_blend_v417_v61_5050', [(V417, 0.5), (V61, 0.5)],
         "V417-a003-iso(50%) + V61-a005-lin(50%). V74 with low-alpha isotonic."),
        
        # V426 + V72 75/25 (V96 structure)
        ('v427_blend_v426_v72_7525', [('submit_v426_blend_v417_v61_5050.zip', 0.75), (V72, 0.25)],
         "V426(75%) + V72(25%). V96 structure with a003-iso."),
        
        # V417 + V63 50/50 (two isotonic calibrations, different alpha)
        ('v428_blend_v417_v63_5050', [(V417, 0.5), (V63, 0.5)],
         "V417-a003-iso(50%) + V63-a01-iso(50%). Two isotonic calibrations."),
        
        # V428 + V72 75/25
        ('v429_blend_v428_v72_7525', [('submit_v428_blend_v417_v63_5050.zip', 0.75), (V72, 0.25)],
         "V428(75%) + V72(25%). V96 with dual-iso."),
        
        # V96 + V417 at various ratios (inject low-CV isotonic into V96)
        ('v430_blend_v96_v417_9010', [(V96, 0.9), (V417, 0.1)],
         "V96(90%) + V417-a003-iso(10%). Inject low-CV isotonic."),
        ('v431_blend_v96_v417_8020', [(V96, 0.8), (V417, 0.2)],
         "V96(80%) + V417-a003-iso(20%)."),
        ('v432_blend_v96_v417_9505', [(V96, 0.95), (V417, 0.05)],
         "V96(95%) + V417-a003-iso(5%). Minimal injection."),
        
        # V189 + V417
        ('v433_blend_v189_v417_9010', [(V189, 0.9), (V417, 0.1)],
         "V189(90%) + V417-a003-iso(10%). Current best + low-CV iso."),
        ('v434_blend_v189_v417_8020', [(V189, 0.8), (V417, 0.2)],
         "V189(80%) + V417-a003-iso(20%)."),
        
        # === V416 (a=0.02 iso, CV=158) blends - even lower CV ===
        
        # V416 + V63 50/50
        ('v435_blend_v416_v63_5050', [(V416, 0.5), (V63, 0.5)],
         "V416-a002-iso(50%) + V63-a01-iso(50%). Ultra-low CV + reference iso."),
        
        # V435 + V72 75/25
        ('v436_blend_v435_v72_7525', [('submit_v435_blend_v416_v63_5050.zip', 0.75), (V72, 0.25)],
         "V435(75%) + V72(25%). V96 with a002-iso."),
        
        # V96 + V416
        ('v437_blend_v96_v416_9010', [(V96, 0.9), (V416, 0.1)],
         "V96(90%) + V416-a002-iso(10%). Ultra-low CV injection."),
        
        # === V418 (a=0.04 iso, CV=169) blends ===
        
        # V418 + V63 50/50
        ('v438_blend_v418_v63_5050', [(V418, 0.5), (V63, 0.5)],
         "V418-a004-iso(50%) + V63(50%)."),
        
        # V438 + V72 75/25
        ('v439_blend_v438_v72_7525', [('submit_v438_blend_v418_v63_5050.zip', 0.75), (V72, 0.25)],
         "V438(75%) + V72(25%). V96 with a004-iso."),
        
        # === Multi-alpha isotonic blends ===
        
        # V417 + V419 + V63 equal (3 alpha values with isotonic)
        ('v440_blend_3iso_equal', [(V417, 1/3), (V419, 1/3), (V63, 1/3)],
         "3-iso equal: V417-a003 + V419-a006 + V63-a01, each 33.3%."),
        
        # V440 + V72 75/25
        ('v441_blend_v440_v72_7525', [('submit_v440_blend_3iso_equal.zip', 0.75), (V72, 0.25)],
         "V440(75%) + V72(25%). V96 with 3-iso blend."),
        
        # V96 + V440 80/20
        ('v442_blend_v96_v440_8020', [(V96, 0.8), ('submit_v440_blend_3iso_equal.zip', 0.2)],
         "V96(80%) + V440-3iso(20%)."),
        
        # === Fine-tuned V417 ratios ===
        
        # V417 + V61 at 60/40 (more V417 weight)
        ('v443_blend_v417_v61_6040', [(V417, 0.6), (V61, 0.4)],
         "V417-a003-iso(60%) + V61(40%). More isotonic weight."),
        
        # V443 + V72 75/25
        ('v444_blend_v443_v72_7525', [('submit_v443_blend_v417_v61_6040.zip', 0.75), (V72, 0.25)],
         "V443(75%) + V72(25%). V96 with 60/40 iso/lin."),
        
        # V417 + V61 at 40/60 (more V61 weight)
        ('v445_blend_v417_v61_4060', [(V417, 0.4), (V61, 0.6)],
         "V417-a003-iso(40%) + V61(60%). More linear weight."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v426', 'v427', 'v428', 'v429', 'v430', 'v431', 'v432',
                  'v433', 'v434', 'v435', 'v436', 'v437', 'v438', 'v439',
                  'v440', 'v441', 'v442', 'v443', 'v444', 'v445']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
