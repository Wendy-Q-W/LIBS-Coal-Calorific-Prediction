"""
exp_v46_nonlinear.py
Phase 2: Non-linear Models with AV-weighted + GK-CV Dual Validation

TE-CV is dead (anti-correlated). New validation strategy:
  1. GK-CV (GroupKFold, in-distribution) — measures model fit quality
  2. AV-weighted RMSE — weights samples by test-likeness, measures test performance

Models to test:
  A. Kernel Ridge Regression (RBF) — non-parametric, captures nonlinearity
  B. Gaussian Process Regression (RBF + WhiteKernel) — Bayesian, uncertainty
  C. Bayesian Ridge Regression — automatic relevance determination
  D. SVR (RBF) — support vector regression
  E. Ridge (V39 baseline) — linear, for comparison

All on V39 feature pipeline: SNV for PCA + total norm for hand features.
"""
import os, sys, re, glob, warnings, json
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, BayesianRidge
from sklearn.kernel_ridge import KernelRidge
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
from sklearn.svm import SVR
from sklearn.model_selection import GroupKFold, LeaveOneGroupOut
from sklearn.metrics import mean_squared_error

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}

# ── Data loading (from all_snv.py) ─────────────────────────────────────────

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5: continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except:
        return None, None
    if not wl: return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights

def load_labels():
    label_map, aux_map = {}, {}
    for coal in COAL_TYPES:
        fp = os.path.join(LABEL_DIR, f"{coal}.xlsx")
        if not os.path.exists(fp): continue
        df = pd.read_excel(fp)
        for _, row in df.iterrows():
            name = str(row['名称']).strip()
            q = float(row['发热量(Q)'])
            label_map[(coal, name)] = q
            aux = {
                '全水分': float(row.get('全水分', np.nan)),
                '灰分':   float(row.get('灰分', np.nan)),
                '氢':     float(row.get('氢', np.nan)),
                '硫':     float(row.get('硫', np.nan)),
            }
            aux_map[(coal, name)] = aux
    return label_map, aux_map

def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None, is_train=True):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir): return None
    spectra, names, targets, auxs, groups, months = [], [], [], [], [], []
    batch_idx = 0
    for batch_dir in sorted(os.listdir(coal_dir)):
        full = os.path.join(coal_dir, batch_dir)
        if not os.path.isdir(full): continue
        date_part = batch_dir.replace(coal_type, '').strip()
        month = extract_month(date_part)
        csvs = sorted(glob.glob(os.path.join(full, "*.csv")))
        if not csvs: continue
        for csv_path in csvs:
            wl, inten = read_spectrum_csv(csv_path)
            if wl is None: continue
            spectra.append((wl, inten))
            names.append(date_part)
            groups.append(batch_idx)
            months.append(month)
            if is_train and label_map:
                key = (coal_type, date_part)
                targets.append(label_map.get(key, np.nan))
                if aux_map and key in aux_map:
                    auxs.append(aux_map[key])
                else:
                    auxs.append({'全水分': np.nan, '灰分': np.nan, '氢': np.nan, '硫': np.nan})
        batch_idx += 1
    return {
        'spectra': spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': auxs, 'groups': np.array(groups),
        'n_batches': batch_idx, 'months': np.array(months),
    }

# ── Feature extraction (V39 pipeline) ──────────────────────────────────────

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0

def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    snv = (inten - inten.mean()) / (inten.std() + 1e-8)

    d1 = np.diff(inten_norm)
    d2 = np.diff(d1)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        d1.std(), np.abs(d1).mean(),
        d2.std(), np.abs(d2).mean(),
    ], dtype=np.float32)

    labs = np.array([line_integral(wl, inten, c, w) for c, w in KEY_LINES.values()],
                    dtype=np.float32)
    lrel = labs / (total + 1e-8)

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum  = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    return snv, stats, labs, lrel, rats

def compute_features(data):
    spectra = data['spectra']
    min_len = min(len(s[1]) for s in spectra)

    snv_list, hand_list = [], []
    for wl, inten in spectra:
        inten_c = inten[:min_len].copy()
        wl_c = wl[:min_len].copy()
        snv, stats, labs, lrel, rats = spectrum_features(wl_c, inten_c)
        snv = np.nan_to_num(snv, nan=0.0, posinf=0.0, neginf=0.0)
        hand = np.concatenate([stats, labs, lrel, rats])
        hand = np.nan_to_num(hand, nan=0.0, posinf=0.0, neginf=0.0)
        snv_list.append(snv)
        hand_list.append(hand)

    return np.array(snv_list, dtype=np.float32), np.array(hand_list, dtype=np.float32)

def build_feature_matrix(snv_mat, hand_feats, scaler_spec=None, pca=None, scaler_final=None, fit=True):
    if fit:
        scaler_spec = StandardScaler()
        snv_scaled = scaler_spec.fit_transform(snv_mat)
        n_comp = min(N_PCA_MAX, snv_scaled.shape[0] - 1, snv_scaled.shape[1])
        pca = PCA(n_components=n_comp, random_state=42)
        snv_pca = pca.fit_transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        scaler_final = StandardScaler()
        X = scaler_final.fit_transform(X)
        return X, scaler_spec, pca, scaler_final
    else:
        snv_scaled = scaler_spec.transform(snv_mat)
        snv_pca = pca.transform(snv_scaled)
        X = np.hstack([snv_pca, hand_feats])
        X = scaler_final.transform(X)
        return X

# ── AV weights ─────────────────────────────────────────────────────────────

def load_av_weights(coal_type, n_train):
    """Load adversarial validation sample weights from Phase 1 results."""
    av_path = os.path.join(_HERE, "adversarial_validation_results.json")
    if not os.path.exists(av_path):
        return np.ones(n_train)
    with open(av_path, 'r', encoding='utf-8') as f:
        av = json.load(f)
    if coal_type not in av:
        return np.ones(n_train)
    weights = np.array(av[coal_type]['sample_weights'])
    if len(weights) != n_train:
        return np.ones(n_train)
    return weights

# ── Model factory ──────────────────────────────────────────────────────────

def make_model(model_name, alpha=0.1):
    if model_name == 'ridge':
        return Ridge(alpha=alpha)
    elif model_name == 'bayesian_ridge':
        return BayesianRidge()
    elif model_name == 'kernel_ridge_rbf':
        return KernelRidge(kernel='rbf', gamma=0.01, alpha=alpha)
    elif model_name == 'kernel_ridge_poly':
        return KernelRidge(kernel='poly', degree=2, gamma=0.01, alpha=alpha)
    elif model_name == 'gpr':
        kernel = ConstantKernel(1.0) * RBF(length_scale=1.0) + WhiteKernel(noise_level=1.0)
        return GaussianProcessRegressor(kernel=kernel, alpha=1.0, normalize_y=True,
                                        n_restarts_optimizer=0, random_state=42)
    elif model_name == 'svr_rbf':
        return SVR(kernel='rbf', C=1.0, gamma='scale')
    else:
        raise ValueError(f"Unknown model: {model_name}")

# ── Two-stage training with CV ─────────────────────────────────────────────

def train_two_stage_cv(X, y, aux, groups, n_batches, model_name, sample_weights=None, alpha=0.1):
    """Two-stage training with CV evaluation.
    Stage 1: X -> aux (OOF prediction)
    Stage 2: [X + pred_aux] -> y
    Returns (oof_preds, batch_oof_rmse, av_weighted_rmse)
    """
    n = len(y)
    aux = np.array(aux, dtype=np.float32)
    # Fill NaN aux with mean
    for j in range(aux.shape[1]):
        col = aux[:, j]
        mask = np.isnan(col)
        if mask.all():
            aux[:, j] = 0.0
        elif mask.any():
            aux[mask, j] = np.nanmean(col)

    # CV splits
    if n_batches <= 11:
        cv = LeaveOneGroupOut()
        splits = list(cv.split(X, y, groups))
    else:
        cv = GroupKFold(n_splits=5)
        splits = list(cv.split(X, y, groups))

    oof_preds = np.zeros(n)

    for tr_idx, val_idx in splits:
        # Stage 1: predict aux on training fold
        aux_oof_val = np.zeros((len(val_idx), aux.shape[1]))
        for j in range(aux.shape[1]):
            m = make_model(model_name, alpha)
            sw = sample_weights[tr_idx] if sample_weights is not None else None
            try:
                if sw is not None and model_name in ('ridge',):
                    m.fit(X[tr_idx], aux[tr_idx, j], sample_weight=sw)
                else:
                    m.fit(X[tr_idx], aux[tr_idx, j])
            except Exception:
                m = Ridge(alpha=0.1)
                m.fit(X[tr_idx], aux[tr_idx, j])
            aux_oof_val[:, j] = m.predict(X[val_idx])

        # Stage 2: [X + pred_aux] -> y
        X_s2_tr = np.hstack([X[tr_idx], aux[tr_idx]])
        X_s2_val = np.hstack([X[val_idx], aux_oof_val])

        sc = StandardScaler()
        X_s2_tr_s = sc.fit_transform(X_s2_tr)
        X_s2_val_s = sc.transform(X_s2_val)

        m2 = make_model(model_name, alpha)
        sw = sample_weights[tr_idx] if sample_weights is not None else None
        try:
            if sw is not None and model_name in ('ridge',):
                m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sw)
            else:
                m2.fit(X_s2_tr_s, y[tr_idx])
        except Exception:
            m2 = Ridge(alpha=0.1)
            m2.fit(X_s2_tr_s, y[tr_idx])

        oof_preds[val_idx] = m2.predict(X_s2_val_s)

    # Batch-level aggregation
    batch_groups = groups
    batch_preds, batch_trues, batch_av_weights = [], [], []
    for b in range(n_batches):
        mask = batch_groups == b
        if mask.sum() == 0: continue
        batch_preds.append(np.median(oof_preds[mask]))
        batch_trues.append(y[mask][0])

    batch_preds = np.array(batch_preds)
    batch_trues = np.array(batch_trues)

    # GK-CV RMSE (unweighted)
    gk_rmse = np.sqrt(np.mean((batch_preds - batch_trues) ** 2))

    return oof_preds, gk_rmse, batch_preds, batch_trues

# ── Main experiment ────────────────────────────────────────────────────────

def run_experiment():
    print("=" * 70)
    print("Phase 2: Non-linear Model Comparison")
    print("Validation: GK-CV + AV-weighted RMSE")
    print("=" * 70)

    label_map, aux_map = load_labels()

    models_to_test = [
        ('ridge',         0.1,  'Ridge a=0.1 (V39 baseline)'),
        ('ridge',         0.05, 'Ridge a=0.05'),
        ('ridge',         0.5,  'Ridge a=0.5'),
        ('bayesian_ridge', None,'BayesianRidge'),
        ('kernel_ridge_rbf', 0.1, 'KernelRidge RBF a=0.1 g=0.01'),
        ('kernel_ridge_rbf', 1.0, 'KernelRidge RBF a=1.0 g=0.01'),
        ('kernel_ridge_poly', 0.1, 'KernelRidge poly2 a=0.1'),
        ('svr_rbf',       None, 'SVR RBF C=1.0'),
    ]

    all_results = {}

    for coal in COAL_TYPES:
        print(f"\n{'=' * 60}")
        print(f"  [{coal}]")
        print(f"{'=' * 60}")

        train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map, is_train=True)
        if train_data is None:
            print("  SKIP: no data")
            continue

        X, sc_spec, pca, sc_final = build_feature_matrix(
            *compute_features(train_data), fit=True)
        y = train_data['targets']
        # Convert aux from list of dicts to array
        aux_list = []
        for a in train_data['aux']:
            aux_list.append([a.get(col, np.nan) for col in AUX_COLS])
        aux = np.array(aux_list, dtype=np.float32)
        groups = train_data['groups']
        n_batches = train_data['n_batches']

        # AV weights
        av_weights = load_av_weights(coal, len(y))
        # Also time weights (V28)
        if coal in TIME_WEIGHT_TAU:
            tw = compute_time_weights(train_data['months'], TEST_MONTH,
                                       TIME_WEIGHT_TAU[coal])
            # Combined: AV * TW
            combined_weights = av_weights * tw
            combined_weights = combined_weights / combined_weights.mean()
        else:
            combined_weights = av_weights

        print(f"  N={len(y)}, batches={n_batches}")
        print(f"  AV weight range: [{av_weights.min():.3f}, {av_weights.max():.3f}]")

        coal_results = {}
        for model_name, alpha, desc in models_to_test:
            try:
                # Without AV weights (pure GK-CV)
                _, gk_rmse, _, _ = train_two_stage_cv(
                    X, y, aux, groups, n_batches, model_name,
                    sample_weights=None, alpha=alpha or 0.1)

                # With AV+TW weights (only for models that support sample_weight)
                if model_name in ('ridge',):
                    _, gk_rmse_w, _, _ = train_two_stage_cv(
                        X, y, aux, groups, n_batches, model_name,
                        sample_weights=combined_weights, alpha=alpha)
                    print(f"  {desc:40s}  GK={gk_rmse:7.2f}  GK+AVTW={gk_rmse_w:7.2f}")
                    coal_results[f"{model_name}_{alpha}"] = {
                        'gk': gk_rmse, 'gk_avtw': gk_rmse_w
                    }
                else:
                    print(f"  {desc:40s}  GK={gk_rmse:7.2f}")
                    coal_results[f"{model_name}_{alpha}"] = {
                        'gk': gk_rmse
                    }
            except Exception as e:
                print(f"  {desc:40s}  ERROR: {e}")
                coal_results[f"{model_name}_{alpha}"] = {'error': str(e)}

        all_results[coal] = coal_results

    # Summary
    print(f"\n{'=' * 70}")
    print("Summary: GK-CV RMSE by coal and model")
    print(f"{'=' * 70}")

    # Collect all model keys
    all_model_keys = set()
    for coal_results in all_results.values():
        all_model_keys.update(coal_results.keys())
    all_model_keys = sorted(all_model_keys)

    # Header
    header = f"{'Model':45s}"
    for coal in COAL_TYPES:
        short = coal[:8]
        header += f" {short:>8s}"
    header += f" {'Global':>8s}"
    print(header)
    print("-" * len(header))

    for mk in all_model_keys:
        row = f"{mk:45s}"
        vals = []
        for coal in COAL_TYPES:
            if coal in all_results and mk in all_results[coal]:
                v = all_results[coal][mk].get('gk', None)
                if v is not None:
                    row += f" {v:8.1f}"
                    vals.append(v)
                else:
                    row += f" {'ERR':>8s}"
            else:
                row += f" {'--':>8s}"
        if vals:
            row += f" {np.mean(vals):8.1f}"
        else:
            row += f" {'--':>8s}"
        print(row)

    # Also show AVTW results for ridge models
    print(f"\n{'=' * 70}")
    print("Ridge models: GK vs GK+AVTW (lower = better)")
    print(f"{'=' * 70}")
    for mk in all_model_keys:
        if 'ridge' not in mk:
            continue
        row = f"{mk:45s}"
        gk_vals, gk_avtw_vals = [], []
        for coal in COAL_TYPES:
            if coal in all_results and mk in all_results[coal]:
                gk = all_results[coal][mk].get('gk', None)
                gk_avtw = all_results[coal][mk].get('gk_avtw', None)
                if gk is not None and gk_avtw is not None:
                    row += f"  {gk:6.1f}/{gk_avtw:6.1f}"
                    gk_vals.append(gk)
                    gk_avtw_vals.append(gk_avtw)
                elif gk is not None:
                    row += f"  {gk:6.1f}/  ----"
                    gk_vals.append(gk)
                else:
                    row += f"  ------/------"
            else:
                row += f"  ------/------"
        if gk_vals:
            row += f"  {np.mean(gk_vals):6.1f}/{np.mean(gk_avtw_vals):6.1f}" if gk_avtw_vals else f"  {np.mean(gk_vals):6.1f}/  ----"
        print(row)

    return all_results

if __name__ == '__main__':
    run_experiment()
