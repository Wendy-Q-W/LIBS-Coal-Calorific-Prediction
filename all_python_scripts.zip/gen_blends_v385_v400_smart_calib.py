"""
gen_blends_v385_v400_smart_calib.py
Generate blends of smart calibration methods with V61/V63/V72/V96.
Key insight: Huber calibration has slope≈1.0 (very gentle), different from V61's slope=1.4.
This provides calibration diversity WITHOUT lowering corr much.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    # New smart calibration models
    V371 = 'submit_v371_a005_clip_linear.zip'
    V372 = 'submit_v372_a005_ridge_hi.zip'
    V373 = 'submit_v373_a005_huber.zip'
    V374 = 'submit_v374_a005_clip_iso.zip'
    V375 = 'submit_v375_a01_clip_linear.zip'
    V376 = 'submit_v376_a01_ridge_hi.zip'
    V377 = 'submit_v377_a01_huber.zip'
    V378 = 'submit_v378_a01_clip_iso.zip'
    V379 = 'submit_v379_a007_clip_linear.zip'
    V380 = 'submit_v380_a007_clip_iso.zip'
    V381 = 'submit_v381_a007_huber.zip'
    
    # Also include poly2/poly3 from earlier
    V341 = 'submit_v341_a005_poly2.zip'
    V342 = 'submit_v342_a005_poly3.zip'
    V346 = 'submit_v346_a01_poly3.zip'
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V61_linear_ref', V61),
        ('V63_isotonic_ref', V63),
        ('V72_iso_a005_ref', V72),
        ('V371_clip_linear', V371),
        ('V372_ridge_hi', V372),
        ('V373_huber', V373),
        ('V374_clip_iso', V374),
        ('V375_a01_clip_lin', V375),
        ('V376_a01_ridge_hi', V376),
        ('V377_a01_huber', V377),
        ('V378_a01_clip_iso', V378),
        ('V379_a007_clip_lin', V379),
        ('V380_a007_clip_iso', V380),
        ('V381_a007_huber', V381),
        ('V341_poly2', V341),
        ('V342_poly3', V342),
        ('V346_a01_poly3', V346),
    ]
    
    corr_data = {}
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        corr_data[label] = (corr, mae, fname)
        print(f"  {label:25s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === Huber blends (most promising - slope≈1.0, very different from V61) ===
        
        # V373(huber) + V63(isotonic) 50/50 - V74 structure with Huber
        ('v385_blend_v373_v63_5050', [(V373, 0.5), (V63, 0.5)],
         "V373-huber(50%) + V63(50%). V74 with Huber instead of linear."),
        
        # V385 + V72 75/25 - V96 structure with Huber
        ('v386_blend_v385_v72_7525', [('submit_v385_blend_v373_v63_5050.zip', 0.75), (V72, 0.25)],
         "V385(75%) + V72(25%). V96 structure with Huber."),
        
        # V96 + V373 at various ratios
        ('v387_blend_v96_v373_9010', [(V96, 0.9), (V373, 0.1)],
         "V96(90%) + V373-huber(10%)."),
        ('v388_blend_v96_v373_8020', [(V96, 0.8), (V373, 0.2)],
         "V96(80%) + V373-huber(20%)."),
        
        # V377(a01-huber) + V61 50/50
        ('v389_blend_v377_v61_5050', [(V377, 0.5), (V61, 0.5)],
         "V377-a01-huber(50%) + V61(50%). Mix a=0.1 Huber with a=0.05 linear."),
        
        # V389 + V72 75/25
        ('v390_blend_v389_v72_7525', [('submit_v389_blend_v377_v61_5050.zip', 0.75), (V72, 0.25)],
         "V389(75%) + V72(25%). V96 with a01-Huber."),
        
        # === Clip linear blends ===
        
        # V371(clip_linear) + V63 50/50
        ('v391_blend_v371_v63_5050', [(V371, 0.5), (V63, 0.5)],
         "V371-clip-linear(50%) + V63(50%). V74 with clipped linear."),
        
        # V391 + V72 75/25
        ('v392_blend_v391_v72_7525', [('submit_v391_blend_v371_v63_5050.zip', 0.75), (V72, 0.25)],
         "V391(75%) + V72(25%). V96 with clipped linear."),
        
        # === Multi-calib super blends with Huber ===
        
        # V61 + V63 + V373(huber) + V342(poly3) equal
        ('v393_blend_4calib_huber', [(V61, 0.25), (V63, 0.25), (V373, 0.25), (V342, 0.25)],
         "4-calib: V61-linear(25%) + V63-iso(25%) + V373-huber(25%) + V342-poly3(25%)."),
        
        # V96 + V393 80/20
        ('v394_blend_v96_v393_8020', [(V96, 0.8), ('submit_v393_blend_4calib_huber.zip', 0.2)],
         "V96(80%) + V393-4calib-huber(20%)."),
        
        # V61 + V63 + V373(huber) equal (3-calib)
        ('v395_blend_3calib_huber', [(V61, 1/3), (V63, 1/3), (V373, 1/3)],
         "3-calib: V61-linear + V63-iso + V373-huber, each 33.3%."),
        
        # V395 + V72 75/25
        ('v396_blend_v395_v72_7525', [('submit_v395_blend_3calib_huber.zip', 0.75), (V72, 0.25)],
         "V395(75%) + V72(25%). V96 with 3-calib huber blend."),
        
        # V96 + V395 80/20
        ('v397_blend_v96_v395_8020', [(V96, 0.8), ('submit_v395_blend_3calib_huber.zip', 0.2)],
         "V96(80%) + V395-3calib(20%)."),
        
        # === a=0.07 Huber/Clip blends (intermediate alpha) ===
        
        # V381(a007-huber) + V63 50/50
        ('v398_blend_v381_v63_5050', [(V381, 0.5), (V63, 0.5)],
         "V381-a007-huber(50%) + V63(50%). Intermediate alpha Huber."),
        
        # V398 + V72 75/25
        ('v399_blend_v398_v72_7525', [('submit_v398_blend_v381_v63_5050.zip', 0.75), (V72, 0.25)],
         "V398(75%) + V72(25%). V96 with a007-Huber."),
        
        # V189 + V393 80/20 (current best + 4-calib huber diversity)
        ('v400_blend_v189_v393_8020', [(V189, 0.8), ('submit_v393_blend_4calib_huber.zip', 0.2)],
         "V189(80%) + V393-4calib-huber(20%). Current best + Huber diversity."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v385', 'v386', 'v387', 'v388', 'v389', 'v390', 'v391', 'v392',
                  'v393', 'v394', 'v395', 'v396', 'v397', 'v398', 'v399', 'v400']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
