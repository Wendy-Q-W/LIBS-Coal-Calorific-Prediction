"""V19: 低成本参数扫描 — PCA组件数 / 谱线窗口 / 基线校正 / 归一化策略
全部用无泄露双重CV (GroupKFold 10种子 + 时间外推3煤种)
基线: Ridge(0.1) + PCA(30) + 原始归一化(inten/total) + 原始窗口
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from all import compute_features as orig_compute_features

label_map, aux_map = load_labels()
TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']
RIDGE_ALPHA = 0.1


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features_custom(wl, inten, key_lines, norm_mode='total'):
    """自定义参数的 feature extraction"""
    total = inten.sum() + 1e-8

    if norm_mode == 'total':
        inten_norm = inten / total
    elif norm_mode == 'max':
        inten_norm = inten / (inten.max() + 1e-8)
    elif norm_mode == 'snv':
        # Standard Normal Variate: (x - mean) / std
        mu, sigma = inten.mean(), inten.std() + 1e-8
        inten_norm = (inten - mu) / sigma
    elif norm_mode == 'minmax':
        mn, mx = inten.min(), inten.max()
        inten_norm = (inten - mn) / (mx - mn + 1e-8)
    else:
        inten_norm = inten / total

    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)

    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)),
        float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)

    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in key_lines.items()],
        dtype=np.float32
    )
    lrel = labs / total

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum,
        labs[1] / ash_sum,
        labs[0] / ash_sum,
        labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    return inten_norm, stats, labs, lrel, rats


def compute_features_custom(data, key_lines=None, norm_mode='total'):
    if key_lines is None:
        key_lines = KEY_LINES
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features_custom(wl, inten, key_lines, norm_mode)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data2 = copy.copy(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    return inorm_mat, data2


def build_fm(inorm_mat, hand_feats, n_batches, n_pca_max=30):
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    X = np.hstack([sp, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X


def oof_ridge(X, y, aux, groups, splits, alpha):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = Ridge(alpha=alpha)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = Ridge(alpha=alpha)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


def gkfold_cv(coal, n_pca_max=30, key_lines=None, norm_mode='total', alpha=0.1, n_seeds=10):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_custom(td, key_lines, norm_mode)
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    X = build_fm(inorm_mat, hand_feats, nb, n_pca_max)
    coal_mean = float(y.mean())

    is_small = nb <= SMALL_BATCH_THRESHOLD
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits, alpha)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits, alpha)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': np.mean(all_sh), 'w': w, 'small': False}


def time_ext(coal, n_pca_max=30, key_lines=None, norm_mode='total', alpha=0.1):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    inorm_mat, td2 = compute_features_custom(td, key_lines, norm_mode)
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])

    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    n_pca = min(n_pca_max, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)

    coal_mean = float(y[tm].mean())
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = Ridge(alpha=alpha); m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=alpha); m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(vy[mk_][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def run_config(name, n_pca_max=30, key_lines=None, norm_mode='total'):
    t0 = time.time()
    print(f"\n{'='*55}")
    print(f"  {name}")
    print(f"{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv(coal, n_pca_max=n_pca_max, key_lines=key_lines, norm_mode=norm_mode)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = np.mean(gk_all) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext(coal, n_pca_max=n_pca_max, key_lines=key_lines, norm_mode=norm_mode)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = np.mean(te_all) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


def make_windowed_lines(scale=1.0):
    """按 scale 缩放所有谱线窗口宽度"""
    return {k: (c, h * scale) for k, (c, h) in KEY_LINES.items()}


if __name__ == "__main__":
    results = {}

    # ── 基线 ──
    results['baseline'] = run_config(
        "基线: PCA(30) + norm=total + win=1.0",
        n_pca_max=30, norm_mode='total')

    # ── P1: PCA 组件数 ──
    for npc in [10, 15, 20, 25, 40, 50]:
        results[f'PCA({npc})'] = run_config(
            f"PCA({npc})", n_pca_max=npc)

    # ── P2: 谱线窗口宽度 ──
    for scale in [0.5, 1.5, 2.0, 3.0]:
        kl = make_windowed_lines(scale)
        results[f'win={scale}'] = run_config(
            f"窗口×{scale}", key_lines=kl)

    # ── P3: 归一化策略 ──
    for nm in ['max', 'snv', 'minmax']:
        results[f'norm={nm}'] = run_config(
            f"归一化={nm}", norm_mode=nm)

    # ── 汇总 ──
    print(f"\n{'='*55}")
    print("  汇总: V19 参数扫描双重CV")
    print(f"{'='*55}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':20s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:20s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
