"""
exp_v40.py
V40: SNV deep variants + PCA dimension tuning

V39 online=230.06 (SNV for PCA + total norm for hand features)
TE-CV=267.39, actual online improvement=10.34 (prediction error <1)

Directions:
1. SNV + detrend (remove linear trend before SNV)
2. 1st derivative + SNV (Norris derivative)
3. 2nd derivative + SNV
4. PCA dimension sweep: 10, 15, 20, 25, 30, 35, 40
5. SNV + time weighting for ALL coal types
6. SNV + per-coal tau optimization
"""
import os, re, glob, warnings, time
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']
KEY_LINES = {
    'C': (247.86, 10.0), 'H': (656.30, 15.0),
    'O': (777.20, 15.0), 'N': (742.40, 10.0),
    'Ca': (422.70, 2.0), 'Ca2': (393.40, 2.0),
    'Mg': (285.20, 2.0), 'Al': (308.20, 2.0),
    'Si': (288.20, 2.0), 'Fe': (438.40, 3.0),
    'Na': (589.00, 1.5),
}
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TEST_MONTH = 12
# V28 time weighting (only for large-sample coals)
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
# V40: try time weighting for ALL coals with SNV
TIME_WEIGHT_TAU_ALL = {
    '赵固一矿豫焦末煤': 30, '赵固二矿中煤矿': 30, '中马矿中煤矿': 30,
    '九里山矿中煤矿': 20, '煤场混煤': 30,
}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    """Hand features with total-intensity normalization."""
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_spec_matrix(data, mode='snv'):
    """Compute spectrum matrix for PCA input.
    
    mode: 'snv' = Standard Normal Variate
          'snv_dt' = SNV + detrend (remove linear trend)
          'd1_snv' = 1st derivative then SNV
          'd2_snv' = 2nd derivative then SNV
          'total' = total intensity normalization (V28 baseline)
    """
    raw_spectra = data['spectra']
    specs = []
    for wl, inten in raw_spectra:
        if mode == 'total':
            s = inten / (inten.sum() + 1e-8)
        elif mode == 'snv':
            s = (inten - inten.mean()) / (inten.std() + 1e-8)
        elif mode == 'snv_dt':
            # SNV then detrend
            s = (inten - inten.mean()) / (inten.std() + 1e-8)
            # Remove linear trend
            x = np.arange(len(s), dtype=np.float64)
            if len(s) > 2:
                coeffs = np.polyfit(x, s, 1)
                s = s - np.polyval(coeffs, x)
        elif mode == 'd1_snv':
            # 1st derivative then SNV
            d = np.diff(inten)
            s = (d - d.mean()) / (d.std() + 1e-8)
        elif mode == 'd2_snv':
            # 2nd derivative then SNV
            d = np.diff(inten, 2)
            s = (d - d.mean()) / (d.std() + 1e-8)
        else:
            s = inten / (inten.sum() + 1e-8)
        specs.append(s)
    min_len = min(len(s) for s in specs)
    return np.array([s[:min_len] for s in specs], dtype=np.float32)


def compute_hand_features(data):
    raw_spectra = data['spectra']
    stats_list, labs_list, lrel_list, rats_list = [], [], [], []
    for wl, inten in raw_spectra:
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    data2 = dict(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    return data2


def build_fm(spec_mat, data2, n_batches, n_pca_max=30, scalers=None, fit=True):
    hand_feats = np.hstack([data2['stats'], data2['labs'], data2['lrel'], data2['rats']])
    if fit:
        sc = StandardScaler()
        spec_scaled = sc.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1) if n_batches else min(n_pca_max, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        sh = StandardScaler()
        X = sh.fit_transform(X)
        return X, (sc, pca, sh)
    else:
        sc, pca, sh = scalers
        spec_scaled = sc.transform(spec_mat)
        spec_pca = pca.transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        return sh.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights=None):
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    X_s2 = np.hstack([X_spec, aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2.fit(X_s2[tr], y[tr])
        vp = m2.predict(X_s2[va])
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(vp[mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(vp[vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w}


def eval_gk(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    def _run(splits):
        return train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        return _run(splits)['cv_rmse'], is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run(splits))
        return float(np.mean([r['cv_rmse'] for r in runs])), is_small


def eval_te(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    months = data['months']
    coal_mean = float(y.mean())

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]
    splits = [(tr_idx, val_idx)]

    te_weights = None
    if sample_weights is not None:
        te_weights = sample_weights[tr_mask]

    run = train_v28(X_spec, y, aux, groups, splits, coal_mean, te_weights)
    return run['cv_rmse']


def run_config(label_map, aux_map, name, spec_mode='snv', n_pca_max=30,
               time_weight_mode='v28'):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {name}")
    print(f"{'='*70}", flush=True)

    gk_results, te_results = {}, {}

    for coal_type in COAL_TYPES:
        data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if data is None or data['n_batches'] == 0:
            continue

        n_batches = data['n_batches']
        n_spec = len(data['spectra'])
        months = data['months']
        is_small = n_batches <= SMALL_BATCH_THRESHOLD

        spec_mat = compute_spec_matrix(data, mode=spec_mode)
        data2 = compute_hand_features(data)
        X_spec, scalers = build_fm(spec_mat, data2, n_batches,
                                    n_pca_max=n_pca_max, fit=True)

        sample_weights = None
        if time_weight_mode == 'v28':
            if coal_type in TIME_WEIGHT_TAU and not is_small:
                tau = TIME_WEIGHT_TAU[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)
        elif time_weight_mode == 'all':
            if coal_type in TIME_WEIGHT_TAU_ALL:
                tau = TIME_WEIGHT_TAU_ALL[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

        gk, is_small = eval_gk(coal_type, data, X_spec, sample_weights)
        te = eval_te(coal_type, data, X_spec, sample_weights)

        gk_results[coal_type] = gk
        te_results[coal_type] = te
        tag = "LOO" if is_small else f"{N_ENSEMBLE_SEEDS}s"
        te_s = f"TE={te:.2f}" if te else "TE=N/A"
        sw_s = "tw=on" if sample_weights is not None else "tw=off"
        print(f"  [{coal_type}] {n_batches}b/{n_spec}s  GK={gk:.2f}  {te_s}  ({tag}, {sw_s})", flush=True)

    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {name}")
    print(f"     GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V40: SNV Deep Variants + PCA Sweep")
    print("=" * 70)

    label_map, aux_map = load_labels()
    results = {}

    # A. V39 baseline (SNV + V28 time weighting, PCA=30)
    results['A_v39_snv'] = run_config(
        label_map, aux_map, "A: V39 SNV (PCA=30)", spec_mode='snv', n_pca_max=30)

    # B. SNV + detrend
    results['B_snv_dt'] = run_config(
        label_map, aux_map, "B: SNV + Detrend", spec_mode='snv_dt', n_pca_max=30)

    # C. 1st derivative + SNV
    results['C_d1_snv'] = run_config(
        label_map, aux_map, "C: 1st Deriv + SNV", spec_mode='d1_snv', n_pca_max=30)

    # D. 2nd derivative + SNV
    results['D_d2_snv'] = run_config(
        label_map, aux_map, "D: 2nd Deriv + SNV", spec_mode='d2_snv', n_pca_max=30)

    # E. PCA dimension sweep
    for npc in [10, 15, 20, 25, 35, 40]:
        results[f'E_snv_pca{npc}'] = run_config(
            label_map, aux_map, f"E: SNV PCA={npc}", spec_mode='snv', n_pca_max=npc)

    # F. SNV + time weighting for ALL coals
    results['F_snv_tw_all'] = run_config(
        label_map, aux_map, "F: SNV + TW ALL", spec_mode='snv', n_pca_max=30,
        time_weight_mode='all')

    # G. Best PCA from sweep + TW ALL
    # Will fill after seeing results, but try PCA=20 + TW ALL
    results['G_snv_pca20_tw_all'] = run_config(
        label_map, aux_map, "G: SNV PCA=20 + TW ALL", spec_mode='snv', n_pca_max=20,
        time_weight_mode='all')

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    base_gk, base_te = results['A_v39_snv']
    print(f"  {'config':35s}  {'GK':>8s}  {'TE':>8s}  {'dGK':>7s}  {'dTE':>7s}")
    for name, (gk, te) in results.items():
        print(f"  {name:35s}  {gk:8.2f}  {te:8.2f}  {gk-base_gk:+7.2f}  {te-base_te:+7.2f}")


if __name__ == "__main__":
    main()
