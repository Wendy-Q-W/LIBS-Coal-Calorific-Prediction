"""V15d: ElasticNet快速实验 (固定参数, 不用ElasticNetCV)
只跑3个有时间分割的煤种, 用5种子(非10), 只测时间外推CV
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV, ElasticNet
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def build_fm(data, n_batches, n_pca_max=30):
    inorm_mat = compute_features(data)
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    hf = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([sp, hf])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X

def oof_enet(X, y, aux, groups, splits, alpha, l1_ratio):
    """ElasticNet OOF (固定参数)"""
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = ElasticNet(alpha=alpha, l1_ratio=l1_ratio, max_iter=5000, random_state=RANDOM_STATE)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = ElasticNet(alpha=alpha, l1_ratio=l1_ratio, max_iter=5000, random_state=RANDOM_STATE)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot

def oof_ridge(X, y, aux, groups, splits, alphas):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = RidgeCV(alphas=alphas); m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = RidgeCV(alphas=alphas); m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot

def time_ext(coal, model_type='ridge', alpha=1.0, l1_ratio=0.5):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names, cm = td['aux'], td['names'], float(y.mean())
    X = build_fm(td, nb)
    is_small = nb <= SMALL_BATCH_THRESHOLD

    # 搜 w (用5种子而非10)
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        if model_type == 'ridge':
            op, ot = oof_ridge(X, y, aux, groups, splits, ALPHAS)
        else:
            op, ot = oof_enet(X, y, aux, groups, splits, alpha, l1_ratio)
        w, _ = find_best_shrinkage(op, ot, cm)
    else:
        ws = []
        for s in range(5):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            if model_type == 'ridge':
                op, ot = oof_ridge(X, y, aux, groups, splits, ALPHAS)
            else:
                op, ot = oof_enet(X, y, aux, groups, splits, alpha, l1_ratio)
            w_s, _ = find_best_shrinkage(op, ot, cm)
            ws.append(w_s)
        w = float(np.mean(ws))

    # 时间外推
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return {'w': w, 'cm': cm, 'small': is_small, 'no_split': True}

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya)); continue
        if model_type == 'ridge':
            m1 = RidgeCV(alphas=ALPHAS)
        else:
            m1 = ElasticNet(alpha=alpha, l1_ratio=l1_ratio, max_iter=5000, random_state=RANDOM_STATE)
        m1.fit(X[tm], ya[tm])
        pa[:, ci] = m1.predict(X)

    X2 = np.nan_to_num(np.hstack([X, pa]))
    sc = StandardScaler(); X2 = sc.fit_transform(X2)
    if model_type == 'ridge':
        m2 = RidgeCV(alphas=ALPHAS)
    else:
        m2 = ElasticNet(alpha=alpha, l1_ratio=l1_ratio, max_iter=5000, random_state=RANDOM_STATE)
    m2.fit(X2[tm], y[tm])
    vp = m2.predict(X2[vm])

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk]))); bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bp)])))
    bl = [w * p + (1-w) * cm for p in bp]
    cv_sh = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))
    return {'cv_raw': cv_raw, 'cv_sh': cv_sh, 'w': w, 'cm': cm, 'small': is_small}

TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']

def run(name, model_type='ridge', alpha=1.0, l1_ratio=0.5):
    t0 = time.time()
    print(f"\n{'='*55}")
    print(f"  {name}")
    print(f"{'='*55}", flush=True)
    all_sh = []
    for coal in TIME_COALS:
        r = time_ext(coal, model_type, alpha, l1_ratio)
        if r is None or r.get('no_split'): continue
        tag = 'small' if r['small'] else 'large'
        print(f"  [{coal}] ({tag}) raw={r['cv_raw']:.1f} shrunk={r['cv_sh']:.1f} w={r['w']:.2f}", flush=True)
        all_sh.append(r['cv_sh'])
    if all_sh:
        avg = np.mean(all_sh)
        print(f"  >> avg shrunk = {avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
        return avg
    return None

if __name__ == "__main__":
    # 精细搜索: alpha=0.05~0.3, l1=0.8~0.95
    configs = [
        (0.05, 0.9,  "EN a=0.05 l1=0.9"),
        (0.05, 0.95, "EN a=0.05 l1=0.95"),
        (0.1,  0.8,  "EN a=0.1 l1=0.8"),
        (0.1,  0.9,  "EN a=0.1 l1=0.9 (已知最优)"),
        (0.1,  0.95, "EN a=0.1 l1=0.95"),
        (0.15, 0.85, "EN a=0.15 l1=0.85"),
        (0.15, 0.9,  "EN a=0.15 l1=0.9"),
        (0.15, 0.95, "EN a=0.15 l1=0.95"),
        (0.2,  0.9,  "EN a=0.2 l1=0.9"),
        (0.2,  0.95, "EN a=0.2 l1=0.95"),
        (0.3,  0.9,  "EN a=0.3 l1=0.9"),
        (0.3,  0.95, "EN a=0.3 l1=0.95"),
    ]

    for alpha, l1, desc in configs:
        run(desc, model_type='elasticnet', alpha=alpha, l1_ratio=l1)
