"""
gen_blends_v234_v260_final.py
Final blend generation with correct file names.
Also check V64 (alpha=0.03 early) vs V221 correlation.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    # Check V64 vs V221 correlation
    v64 = load_existing_submission('submit_v64_a003_bias.zip')
    v221 = load_existing_submission('submit_v221_a003_linear.zip')
    if v64 is not None and v221 is not None:
        corr = np.corrcoef(np.array(v64.values), np.array(v221.values))[0, 1]
        mae = np.mean(np.abs(np.array(v64.values) - np.array(v221.values)))
        print(f"  corr(V64, V221) = {corr:.6f}  MAE = {mae:.2f}")
        if corr > 0.999:
            print("  -> V64 and V221 are essentially the same model")
    
    # Also check V65 (alpha=0.02) and V66 (alpha=0.01)
    v65 = load_existing_submission('submit_v65_a002_bias.zip')
    v66 = load_existing_submission('submit_v66_a001_bias.zip')
    v96 = load_existing_submission('submit_v96_blend_v74_v72_7525.zip')
    
    if v96 is not None:
        v96_arr = np.array(v96.values)
        for name, sub in [('V64_a003', v64), ('V65_a002', v65), ('V66_a001', v66)]:
            if sub is None:
                continue
            arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, arr)[0, 1]
            mae = np.mean(np.abs(arr - v96_arr))
            print(f"  corr(V96, {name}) = {corr:.6f}  MAE = {mae:.2f}")
    
    # File name mapping
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V221 = 'submit_v221_a003_linear.zip'
    V218 = 'submit_v218_a015_isotonic.zip'
    V220 = 'submit_v220_a030_isotonic.zip'
    V216 = 'submit_v216_a015_linear.zip'
    V206 = 'submit_v206_deriv1_a005_isotonic.zip'
    V64 = 'submit_v64_a003_bias.zip'
    V65 = 'submit_v65_a002_bias.zip'
    V66 = 'submit_v66_a001_bias.zip'
    
    # Also check V67 (multi_alpha) and V88 (pca40)
    V67 = 'submit_v67_multi_alpha.zip'
    V88 = 'submit_v88_ridge_pca40_a005_bias.zip'
    
    for name, fname in [('V67_multi_alpha', V67), ('V88_pca40', V88)]:
        sub = load_existing_submission(fname)
        if sub is not None and v96 is not None:
            arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, arr)[0, 1]
            mae = np.mean(np.abs(arr - v96_arr))
            print(f"  corr(V96, {name}) = {corr:.6f}  MAE = {mae:.2f}")
    
    # Generate strategic blends
    print(f"\n{'=' * 70}")
    print("  STRATEGIC BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # Key blend: V221+V63 50/50 (V74 equivalent with lower alpha)
        ('v242_blend_v221_v63_5050', [(V221, 0.5), (V63, 0.5)],
         "V221-a003(50%) + V63-a01-iso(50%). V74 equivalent with alpha=0.03 instead of 0.05."),
        
        # V242 + V72 75/25 (V96 equivalent with V221)
        ('v243_blend_v242_v72_7525', [('submit_v242_blend_v221_v63_5050.zip', 0.75), (V72, 0.25)],
         "V242(75%) + V72(25%). V96 structure with V221 instead of V61."),
        
        # V61 + V218 + V63 (3-way alpha diversity)
        ('v244_blend_v61_v218_v63', [(V61, 0.4), (V218, 0.2), (V63, 0.4)],
         "V61(40%) + V218-a015-iso(20%) + V63(40%). Alpha diversity."),
        
        # 4-way: V61 + V63 + V221 + V218
        ('v247_blend_4way_alpha', [(V61, 0.35), (V63, 0.35), (V221, 0.15), (V218, 0.15)],
         "4-way: V61(35%) + V63(35%) + V221-a003(15%) + V218-a015-iso(15%)."),
        
        # V96 + V244
        ('v248_blend_v96_v244_8020', [(V96, 0.8), ('submit_v244_blend_v61_v218_v63.zip', 0.2)],
         "V96(80%) + V244-3way(20%)."),
        
        # V65 (alpha=0.02) + V63 50/50 (even lower alpha)
        ('v249_blend_v65_v63_5050', [(V65, 0.5), (V63, 0.5)],
         "V65-a002(50%) + V63-a01-iso(50%). Even lower alpha than V221."),
        
        # V249 + V72 75/25
        ('v250_blend_v249_v72_7525', [('submit_v249_blend_v65_v63_5050.zip', 0.75), (V72, 0.25)],
         "V249(75%) + V72(25%). V96 structure with alpha=0.02."),
        
        # V66 (alpha=0.01) + V63 50/50 (lowest alpha)
        ('v251_blend_v66_v63_5050', [(V66, 0.5), (V63, 0.5)],
         "V66-a001(50%) + V63-a01-iso(50%). Lowest alpha."),
        
        # V251 + V72 75/25
        ('v252_blend_v251_v72_7525', [('submit_v251_blend_v66_v63_5050.zip', 0.75), (V72, 0.25)],
         "V251(75%) + V72(25%). V96 structure with alpha=0.01."),
        
        # V96 + V65 (alpha=0.02) at 10%
        ('v253_blend_v96_v65_9010', [(V96, 0.9), (V65, 0.1)],
         "V96(90%) + V65-a002(10%). Very low alpha model."),
        
        # V96 + V66 (alpha=0.01) at 5%
        ('v254_blend_v96_v66_9505', [(V96, 0.95), (V66, 0.05)],
         "V96(95%) + V66-a001(5%). Lowest alpha, tiny weight."),
        
        # Super-ensemble: V61 + V63 + V221 + V218 + V220 (5 alpha values)
        ('v255_blend_5way_alpha', [(V61, 0.25), (V63, 0.25), (V221, 0.20), (V218, 0.15), (V220, 0.15)],
         "5-way alpha ensemble: 0.03/0.05/0.1/0.15/0.30."),
        
        # V96 + V255 super-ensemble
        ('v256_blend_v96_v255_7030', [(V96, 0.70), ('submit_v255_blend_5way_alpha.zip', 0.30)],
         "V96(70%) + V255-5way(30%)."),
        
        # V88 (PCA40) + V96 blend - different PCA dimension
        ('v257_blend_v96_v88_9010', [(V96, 0.9), (V88, 0.1)],
         "V96(90%) + V88-PCA40(10%). Different PCA dimension."),
        
        # V88 (PCA40) + V63 50/50
        ('v258_blend_v88_v63_5050', [(V88, 0.5), (V63, 0.5)],
         "V88-PCA40(50%) + V63(50%). PCA diversity."),
        
        # V258 + V72 75/25
        ('v259_blend_v258_v72_7525', [('submit_v258_blend_v88_v63_5050.zip', 0.75), (V72, 0.25)],
         "V258(75%) + V72(25%). V96 with PCA40."),
        
        # V67 (multi_alpha) + V96 blend
        ('v260_blend_v96_v67_8020', [(V96, 0.8), (V67, 0.2)],
         "V96(80%) + V67-multi-alpha(20%). Early multi-alpha model."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation check for new blends
    print(f"\n{'=' * 70}")
    print("  CORRELATION OF NEW BLENDS WITH V96")
    print(f"{'=' * 70}")
    
    v96_arr = np.array(v96.values)
    new_blends = ['v242', 'v243', 'v244', 'v247', 'v248', 'v249', 'v250', 
                  'v251', 'v252', 'v253', 'v254', 'v255', 'v256', 'v257', 'v258', 'v259', 'v260']
    
    for vid in new_blends:
        fname = f'submit_{vid}'
        # Find the actual file
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(fname) and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
