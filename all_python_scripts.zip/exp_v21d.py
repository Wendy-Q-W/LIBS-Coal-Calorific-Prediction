"""V21d: Ca3+Ti+Sr 多种子稳定性验证
最优配置: Ca3=5.0, Ti=2.0, Sr=5.0 → GK-3.30, TE-9.28 (10种子)
验证: 50/100种子下是否仍改善
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from all import COAL_TYPES, KEY_LINES as KEY_LINES_V19
from exp_v20 import gkfold_cv_v20, time_ext_v20
from exp_v21 import make_extended_lines
from exp_v19 import label_map, aux_map, TIME_COALS

BEST_NEW = {'Ca3': (396.5, 5.0), 'Ti': (335.0, 2.0), 'Sr': (408.0, 5.0)}
best_kl = make_extended_lines(BEST_NEW)


def run_stability(name, key_lines, n_seeds_list):
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    for ns in n_seeds_list:
        t0 = time.time()
        gk_all, te_all = [], []
        for coal in COAL_TYPES:
            r = gkfold_cv_v20(coal, key_lines=key_lines, n_seeds=ns)
            if r: gk_all.append(r['sh'])
        for coal in TIME_COALS:
            r = time_ext_v20(coal, key_lines=key_lines)
            if r: te_all.append(r['sh'])
        gk, te = np.mean(gk_all), np.mean(te_all)
        print(f"  seeds={ns}: GK={gk:.2f}  TE={te:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk, te


if __name__ == "__main__":
    # 基线 (V19) 多种子
    print("="*55)
    print("  V19基线 (多种子)")
    print("="*55, flush=True)
    for ns in [10, 50, 100]:
        t0 = time.time()
        gk_all, te_all = [], []
        for coal in COAL_TYPES:
            r = gkfold_cv_v20(coal, key_lines=KEY_LINES_V19, n_seeds=ns)
            if r: gk_all.append(r['sh'])
        for coal in TIME_COALS:
            r = time_ext_v20(coal, key_lines=KEY_LINES_V19)
            if r: te_all.append(r['sh'])
        gk, te = np.mean(gk_all), np.mean(te_all)
        print(f"  seeds={ns}: GK={gk:.2f}  TE={te:.2f}  ({time.time()-t0:.0f}s)", flush=True)

    # 最优配置 多种子
    run_stability("Ca3=5,Ti=2,Sr=5 (多种子)", best_kl, [10, 50, 100])
