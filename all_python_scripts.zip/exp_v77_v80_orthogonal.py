"""
exp_v77_v80_orthogonal.py

4 experiments orthogonal to V72-V76, designed without needing their results.

Analysis of all 12 online scores reveals:
  - V61 (alpha=0.05, linear) = 203.21 (BEST)
  - V63 (alpha=0.1, isotonic) = 203.60 (2nd best)
  - Per-coal 'a' values (alpha=0.05, linear):
      赵固一矿: a=1.41 (captures 71% of variance)
      赵固二矿: a=1.81 (captures 55% -- most compressed)
      中马矿:   a=1.19 (captures 84%)
      九里山:   a=1.20 (captures 83%)
      煤场混煤:  a=1.29 (captures 78%)

V77: Per-coal calibration selection
  - Use isotonic for high-compression coals (a > 1.35): 赵固一矿, 赵固二矿
  - Use linear for low-compression coals (a <= 1.35): 中马矿, 九里山, 煤场混煤
  - Hypothesis: isotonic captures nonlinear bias for compressed coals,
    while linear avoids overfitting for well-calibrated coals
  - All at alpha=0.05 (V61's optimal alpha)

V78: Weighted OOF bias correction
  - For time-weighted coals (九里山, 煤场混煤), weight recent batches more
    when fitting the linear bias correction
  - Currently: LinearRegression.fit(OOF_preds, OOF_true) with equal weights
  - New: LinearRegression.fit(OOF_preds, OOF_true, sample_weight=time_weights)
  - Rationale: test set is December, so recent training batches should
    dominate the bias correction fitting
  - All at alpha=0.05, linear calibration

V79: Reverse stage alpha (S1=0.05, S2=0.1)
  - V70 tested S1=0.1, S2=0.05 = 206.01 (worse than V61)
  - V79 reverses: lower alpha for Stage1 (aux prediction, more stable),
    higher alpha for Stage2 (final prediction)
  - This is NOT the same as V61 (both stages 0.05) or V55 (both stages 0.1)
  - All with linear bias correction

V80: Per-coal blend of V61 and V63
  - High-compression coals (a > 1.35): use V63 (isotonic handles nonlinearity)
  - Low-compression coals (a <= 1.35): use V61 (linear is sufficient)
  - Zero training needed, just select predictions from existing submissions
"""
import os, sys, re, glob, warnings, io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11

TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}

# V77/V80: coals with a > 1.35 use isotonic, else linear
ISOTONIC_COALS = {'赵固一矿豫焦末煤', '赵固二矿中煤矿'}
LINEAR_COALS = {'中马矿中煤矿', '九里山矿中煤矿', '煤场混煤'}


# ===============================================================================
# Data loading (reused from V72)
# ===============================================================================

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


# ===============================================================================
# Feature extraction (reused from V72)
# ===============================================================================

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(snv)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=N_PCA_MAX):
    spec_mat = data.get('_spec_mat', compute_features(data))
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ===============================================================================
# Training (reused from V72, with V79 modification for split alpha)
# ===============================================================================

def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.1, ridge_alpha_s2=None):
    """
    Train one CV run. If ridge_alpha_s2 is specified, use different alpha for Stage2.
    V79: ridge_alpha=0.05 (Stage1), ridge_alpha_s2=0.1 (Stage2)
    """
    if ridge_alpha_s2 is None:
        ridge_alpha_s2 = ridge_alpha

    # Stage 1: predict aux variables
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X, y_aux)
        aux_models[col_name] = m

    # Stage 2: predict calorific value
    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha_s2)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_center)

    final_model = Ridge(alpha=ridge_alpha_s2)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)

    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = float(np.median(preds[mask]))
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


# ===============================================================================
# Core: train one coal with configurable calibration and alpha
# ===============================================================================

def train_and_predict_coal(coal, label_map, aux_map, ridge_alpha=0.05,
                           calibration='linear',
                           ridge_alpha_s2=None,
                           weighted_oof=False):
    """
    Train models for one coal type and return test predictions + CV.

    Parameters:
        ridge_alpha: alpha for Stage1 (and Stage2 if ridge_alpha_s2 is None)
        calibration: 'linear', 'isotonic', or 'auto' (V77: per-coal selection)
        ridge_alpha_s2: if not None, use different alpha for Stage2 (V79)
        weighted_oof: if True, weight OOF points by time proximity for bias correction (V78)
    """
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    spec_mat = compute_features(train_data)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    sample_weights = None
    oof_sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)
            if weighted_oof:
                oof_sample_weights = sample_weights.copy()

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(X, y, aux, groups, splits, coal_center,
                            n_batches, sample_weights,
                            ridge_alpha=ridge_alpha,
                            ridge_alpha_s2=ridge_alpha_s2)
        runs.append(run)

    if is_small:
        r = runs[0]
        print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
              f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
    else:
        cv_rmses = [r['cv_rmse'] for r in runs]
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
              f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])

    # Calibration
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    # For V77 auto calibration: decide based on coal type
    if calibration == 'auto':
        if coal in ISOTONIC_COALS:
            calibration = 'isotonic'
        else:
            calibration = 'linear'
        print(f"    Auto-selected calibration: {calibration}")

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        if weighted_oof and oof_sample_weights is not None:
            # V78: weight OOF points by time proximity
            # Need to expand per-sample weights to per-batch OOF points
            # OOF points are per-batch, so we need batch-level weights
            # Each OOF point corresponds to one batch; find its month
            batch_months = []
            for run in runs:
                # OOF preds are per-batch, in order of validation batches
                # We need to map them back to batch months
                # Actually, all_oof_p is concatenated across runs (seeds)
                # For small coals (1 run), it's straightforward
                # For large coals (100 seeds), each seed produces different OOF
                # The batch order varies by seed, so we can't directly map
                # Instead, use the global sample_weights expanded per spectrum
                pass
            
            # For V78: use per-spectrum sample weights expanded to OOF batch level
            # Each OOF point is a batch-level prediction
            # For small coals: 1 run, OOF has n_batches points
            # For large coals: 100 runs, each with n_batches OOF points
            # We need to construct OOF weights matching all_oof_p length
            
            # Approach: for each run, the OOF points correspond to validation batches
            # We don't know which batch each OOF point belongs to
            # But we can use a simpler approach: assign each OOF point the weight
            # based on its true value's batch (unique true values = unique batches)
            
            # Actually, the simplest approach: for each OOF point, find the batch
            # it belongs to by matching the true value
            unique_true = np.unique(all_oof_t)
            oof_weights = np.ones(len(all_oof_p))
            
            # Map each unique true value to its batch month
            # True values are batch-level targets
            # We need to find which batch each true value belongs to
            train_months = train_data['months']
            train_targets = y
            batch_info = {}  # true_value -> (month, weight)
            for i in range(len(train_targets)):
                tv = float(train_targets[i])
                month = int(train_months[i])
                # Time weight for this spectrum
                diff = abs(month - TEST_MONTH)
                diff = min(diff, 12 - diff)
                tw = np.exp(-diff * 30 / tau)
                if tv not in batch_info:
                    batch_info[tv] = {'month': month, 'weight': tw}
                else:
                    # Average if multiple spectra have same target (same batch)
                    batch_info[tv]['weight'] = (batch_info[tv]['weight'] + tw) / 2
            
            for idx in range(len(all_oof_t)):
                tv = float(all_oof_t[idx])
                # Find closest true value
                closest = min(batch_info.keys(), key=lambda x: abs(x - tv))
                oof_weights[idx] = batch_info[closest]['weight']
            
            # Normalize weights
            oof_weights = oof_weights / oof_weights.mean()
            
            lr.fit(all_oof_p.reshape(-1, 1), all_oof_t, sample_weight=oof_weights)
            a, b = float(lr.coef_[0]), float(lr.intercept_)
            calibrator = ('linear', a, b)
            print(f"    Weighted bias correction: a={a:.4f}, b={b:.2f} "
                  f"(using {len(oof_weights)} weighted OOF points)")
        else:
            lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
            a, b = float(lr.coef_[0]), float(lr.intercept_)
            calibrator = ('linear', a, b)
            print(f"    Bias correction: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a_lin, b_lin = float(lr.coef_[0]), float(lr.intercept_)
        p_min, p_max = float(np.min(all_oof_p)), float(np.max(all_oof_p))
        cal_min = float(ir.predict([p_min])[0])
        cal_max = float(ir.predict([p_max])[0])
        print(f"    Isotonic (lin_approx: a={a_lin:.4f}, b={b_lin:.2f})  "
              f"range: [{p_min:.1f},{p_max:.1f}] -> [{cal_min:.1f},{cal_max:.1f}]")

    # Predict test
    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))

        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])

        test_preds[name] = pred_val

    return {
        'cv_rmse': cv_rmse,
        'test_preds': test_preds,
    }


# ===============================================================================
# Submission helpers
# ===============================================================================

def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0

    readme = f"""# LIBS 煤炭发热量预测 — 方案介绍

**版本**: {variant_name}
**作者**: ATIpiu
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 方法概述

{feature_desc}

## CV-RMSE (for reference only)

| 煤种 | CV-RMSE |
|---|---|
"""
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"

    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")

    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def load_existing_submission(zip_name):
    """Load existing submission predictions as a Series."""
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        print(f"  WARNING: {fname} not found!")
        return None
    with zipfile.ZipFile(fname) as zf:
        csv_content = zf.read('submit/submit.csv')
        df = pd.read_csv(io.BytesIO(csv_content), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


# ===============================================================================
# V77: Per-coal calibration selection (isotonic for high-compression, linear for low)
# ===============================================================================

def run_v77_per_coal_calibration():
    print(f"\n{'=' * 70}")
    print(f"  V77: Per-coal calibration selection")
    print(f"  Isotonic for high-compression coals: {ISOTONIC_COALS}")
    print(f"  Linear for low-compression coals: {LINEAR_COALS}")
    print(f"  All at alpha=0.05")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        calib = 'isotonic' if coal in ISOTONIC_COALS else 'linear'
        print(f"    Using: {calib}")
        result = train_and_predict_coal(coal, label_map, aux_map,
                                        ridge_alpha=0.05, calibration=calib)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(
        'v77_per_coal_calibration', all_preds, cv_results,
        "Per-coal calibration: isotonic for high-compression coals (a>1.35: "
        "赵固一矿, 赵固二矿), linear for low-compression (中马矿, 九里山, 煤场混煤). "
        "All at alpha=0.05. Rationale: isotonic captures nonlinear bias for "
        "strongly compressed predictions, linear avoids overfitting for "
        "well-calibrated coals.")


# ===============================================================================
# V78: Weighted OOF bias correction
# ===============================================================================

def run_v78_weighted_oof_bias():
    print(f"\n{'=' * 70}")
    print(f"  V78: Weighted OOF bias correction")
    print(f"  Time-weighted coals use weighted OOF for bias fitting")
    print(f"  All at alpha=0.05, linear calibration")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map,
                                        ridge_alpha=0.05, calibration='linear',
                                        weighted_oof=True)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(
        'v78_weighted_oof_bias', all_preds, cv_results,
        "Weighted OOF bias correction: for time-weighted coals (九里山, 煤场混煤), "
        "OOF points are weighted by time proximity to test month (December). "
        "Recent batches have more influence on bias correction parameters. "
        "All at alpha=0.05, linear calibration.")


# ===============================================================================
# V79: Reverse stage alpha (S1=0.05, S2=0.1)
# ===============================================================================

def run_v79_reverse_stage_alpha():
    print(f"\n{'=' * 70}")
    print(f"  V79: Reverse stage alpha")
    print(f"  Stage1 (aux prediction): alpha=0.05")
    print(f"  Stage2 (final prediction): alpha=0.1")
    print(f"  V70 tested S1=0.1/S2=0.05=206.01. V79 reverses.")
    print(f"  With linear bias correction")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map,
                                        ridge_alpha=0.05, calibration='linear',
                                        ridge_alpha_s2=0.1)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(
        'v79_reverse_stage_alpha', all_preds, cv_results,
        "Reverse stage alpha: Stage1 (aux prediction) alpha=0.05, "
        "Stage2 (final prediction) alpha=0.1. "
        "V70 (S1=0.1/S2=0.05) was 206.01 online. V79 tests the reverse: "
        "lower alpha for stable aux prediction, higher alpha for final. "
        "With linear bias correction.")


# ===============================================================================
# V80: Per-coal blend of V61 and V63
# ===============================================================================

def run_v80_per_coal_blend():
    print(f"\n{'=' * 70}")
    print(f"  V80: Per-coal blend of V61 and V63")
    print(f"  High-compression coals -> V63 (isotonic)")
    print(f"  Low-compression coals -> V61 (linear)")
    print(f"{'=' * 70}")

    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')

    if v61 is None or v63 is None:
        print("  ERROR: Cannot load V61 or V63 submissions!")
        return None, 0

    all_preds = {}
    for name in v61.index:
        # Determine coal type
        coal_type = None
        for c in COAL_TYPES:
            if c in name:
                coal_type = c
                break
        if coal_type is None:
            # Fallback: use V61 (best overall)
            all_preds[name] = float(v61[name])
            continue

        if coal_type in ISOTONIC_COALS:
            # High compression -> use V63 (isotonic)
            all_preds[name] = float(v63[name])
        else:
            # Low compression -> use V61 (linear)
            all_preds[name] = float(v61[name])

    # Summary
    v61_count = sum(1 for n in v61.index
                    if any(c in n for c in LINEAR_COALS))
    v63_count = sum(1 for n in v61.index
                    if any(c in n for c in ISOTONIC_COALS))
    print(f"\n  V61 predictions used: {v61_count} (low-compression coals)")
    print(f"  V63 predictions used: {v63_count} (high-compression coals)")
    print(f"  Blend mean: {np.mean(list(all_preds.values())):.2f}")

    return pack_submission(
        'v80_per_coal_blend', all_preds, {},
        "Per-coal blend: V63 (isotonic, alpha=0.1) for high-compression coals "
        "(赵固一矿 a=1.41, 赵固二矿 a=1.81), "
        "V61 (linear, alpha=0.05) for low-compression coals "
        "(中马矿 a=1.19, 九里山 a=1.20, 煤场混煤 a=1.29). "
        "Rationale: isotonic captures nonlinear bias where compression is severe, "
        "linear is sufficient and less prone to overfitting where compression is mild.")


# ===============================================================================
# Main
# ===============================================================================

if __name__ == '__main__':
    results = {}

    # V77: Per-coal calibration selection
    _, cv = run_v77_per_coal_calibration()
    results['v77'] = cv

    # V78: Weighted OOF bias correction
    _, cv = run_v78_weighted_oof_bias()
    results['v78'] = cv

    # V79: Reverse stage alpha
    _, cv = run_v79_reverse_stage_alpha()
    results['v79'] = cv

    # V80: Per-coal blend
    _, cv = run_v80_per_coal_blend()
    results['v80'] = cv

    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Baselines:")
    print(f"    V61 (linear, alpha=0.05):    CV=172.15  Online=203.21")
    print(f"    V63 (isotonic, alpha=0.1):   CV=183.50  Online=203.60")
    print()
    for name, cv in results.items():
        print(f"    {name}: CV={cv:.2f}")
    print()
    print("  Priority for submission:")
    print("    1. V77 (per-coal calibration) -- combines V61+V63 strengths per coal")
    print("    2. V80 (per-coal blend) -- zero risk, selects best method per coal")
    print("    3. V78 (weighted OOF bias) -- time-aware calibration")
    print("    4. V79 (reverse stage alpha) -- explores stage-specific regularization")
