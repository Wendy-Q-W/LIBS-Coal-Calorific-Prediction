"""V17b: SelectKBest 无泄露验证
修正: SelectKBest 只在训练月(10/11月)上 fit, 再 transform 验证月(1/2/3月)
对比: PCA(无监督, 无泄露) vs SelectKBest(有监督, 正确无泄露)
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_regression
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()
TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def time_ext_noleak(coal, dim_type='pca', n_kbest=30, n_pca_max=30):
    """时间外推CV, SelectKBest 只在训练月上 fit (无泄露)。
    
    流程:
      1. compute_features (无监督, 不涉及y, 无泄露)
      2. StandardScaler 只在训练月上 fit
      3. PCA / SelectKBest 只在训练月上 fit
      4. StandardScaler (手工特征) 只在训练月上 fit
      5. RidgeCV 两阶段, 训练月→验证月
    """
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']

    # 计算归一化光谱和手工特征 (无监督)
    inorm_mat = compute_features(data=td)
    hand_feats = np.hstack([td['stats'], td['labs'], td['lrel'], td['rats']])

    # 时间分割
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    # StandardScaler (光谱) - 只在训练月上 fit
    sc_spec = StandardScaler()
    spec_tr = sc_spec.fit_transform(inorm_mat[tm])
    spec_va = sc_spec.transform(inorm_mat[vm])

    # 降维 - 只在训练月上 fit
    if dim_type == 'pca':
        n_pca = min(n_pca_max, nb - 1, spec_tr.shape[0] - 1)
        reducer = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        sp_tr = reducer.fit_transform(spec_tr)
        sp_va = reducer.transform(spec_va)
    elif dim_type == 'kbest':
        k = min(n_kbest, spec_tr.shape[1], spec_tr.shape[0] - 1)
        reducer = SelectKBest(f_regression, k=k)
        sp_tr = reducer.fit_transform(spec_tr, y[tm])
        sp_va = reducer.transform(spec_va)
    else:
        sp_tr = spec_tr
        sp_va = spec_va

    # 拼接手工特征
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)

    # StandardScaler (全部特征) - 只在训练月上 fit
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)

    coal_mean = float(y[tm].mean())  # 训练月均值

    # Stage1: 光谱 → 辅助指标 (只在训练月上训练)
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = RidgeCV(alphas=ALPHAS)
        m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)

    # Stage2: [光谱特征 + 预测辅助指标] → 发热量
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)

    m2 = RidgeCV(alphas=ALPHAS)
    m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)

    # 按批次聚合
    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk])))
        bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))

    # 收缩 (w=1.0 即不收缩, 这里直接用 raw 作为基线对比)
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    # 也测 local_mean 收缩
    local_mean = float(np.mean(bp))
    bl_local = [w * p + (1 - w) * local_mean for p in bp]
    cv_local = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bl_local)])))

    return {
        'cv_raw': cv_raw, 'cv_sh': cv_sh, 'cv_local': cv_local,
        'w': w, 'coal_mean': coal_mean,
    }


def run(name, dim_type='pca', n_kbest=30):
    t0 = time.time()
    print(f"\n{'=' * 55}")
    print(f"  {name}")
    print(f"{'=' * 55}", flush=True)
    all_raw, all_sh, all_local = [], [], []
    for coal in TIME_COALS:
        r = time_ext_noleak(coal, dim_type=dim_type, n_kbest=n_kbest)
        if r is None:
            continue
        print(f"  [{coal}] raw={r['cv_raw']:.1f} shrunk={r['cv_sh']:.1f} "
              f"local={r['cv_local']:.1f} w={r['w']:.2f}", flush=True)
        all_raw.append(r['cv_raw'])
        all_sh.append(r['cv_sh'])
        all_local.append(r['cv_local'])
    if all_sh:
        print(f"  >> avg raw={np.mean(all_raw):.2f}  "
              f"shrunk={np.mean(all_sh):.2f}  local={np.mean(all_local):.2f}  "
              f"({time.time() - t0:.0f}s)", flush=True)
        return {'raw': np.mean(all_raw), 'shrunk': np.mean(all_sh),
                'local': np.mean(all_local)}
    return None


if __name__ == "__main__":
    results = {}

    # 基线: PCA (无泄露)
    results['PCA(30)'] = run("基线: PCA(30) 无泄露", dim_type='pca')

    # SelectKBest 无泄露
    for k in [20, 30, 50, 80, 100, 150, 200]:
        results[f'KBest({k})'] = run(
            f"SelectKBest(k={k}) 无泄露", dim_type='kbest', n_kbest=k)

    # 汇总
    print(f"\n{'=' * 55}")
    print("  汇总 (无泄露时间外推CV)")
    print(f"{'=' * 55}")
    base = results.get('PCA(30)', {})
    base_sh = base.get('shrunk', 999) if base else 999
    base_raw = base.get('raw', 999) if base else 999
    for name, val in results.items():
        if val is None:
            continue
        mk = ""
        if name == 'PCA(30)':
            mk = "  <-- baseline"
        elif val['shrunk'] < base_sh:
            mk = "  BETTER"
        elif val['shrunk'] > base_sh:
            mk = "  WORSE"
        print(f"  {name:15s}: raw={val['raw']:.2f}  shrunk={val['shrunk']:.2f}  "
              f"local={val['local']:.2f}{mk}")
