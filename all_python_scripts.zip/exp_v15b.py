"""V15实验: 逐个跑，输出写入文件"""
import sys, os, re, warnings
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV, ElasticNetCV, LassoCV
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def build_fm(data, n_batches, n_pca_max=30):
    inorm_mat = compute_features(data)
    sc = StandardScaler()
    ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    hf = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([sp, hf])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler()
    X = sh.fit_transform(X)
    return X

def oof_ridge(X, y, aux, groups, splits, alphas):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = RidgeCV(alphas=alphas); m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = RidgeCV(alphas=alphas); m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot

def oof_enet(X, y, aux, groups, splits):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = ElasticNetCV(l1_ratio=[0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE, max_iter=10000)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = ElasticNetCV(l1_ratio=[0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE, max_iter=10000)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot

def time_ext(coal, model_type='ridge', n_pca_max=30, alphas=None):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names, cm = td['aux'], td['names'], float(y.mean())
    if alphas is None: alphas = ALPHAS
    X = build_fm(td, nb, n_pca_max)
    is_small = nb <= SMALL_BATCH_THRESHOLD

    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        if model_type == 'ridge':
            op, ot = oof_ridge(X, y, aux, groups, splits, alphas)
        else:
            op, ot = oof_enet(X, y, aux, groups, splits)
        w, _ = find_best_shrinkage(op, ot, cm)
    else:
        ws = []
        for s in range(10):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            if model_type == 'ridge':
                op, ot = oof_ridge(X, y, aux, groups, splits, alphas)
            else:
                op, ot = oof_enet(X, y, aux, groups, splits)
            w_s, _ = find_best_shrinkage(op, ot, cm)
            ws.append(w_s)
        w = float(np.mean(ws))

    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return {'w': w, 'cm': cm, 'small': is_small, 'no_split': True}

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya)); continue
        if model_type == 'ridge':
            m1 = RidgeCV(alphas=alphas)
        else:
            m1 = ElasticNetCV(l1_ratio=[0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE, max_iter=10000)
        m1.fit(X[tm], ya[tm])
        pa[:, ci] = m1.predict(X)

    X2 = np.nan_to_num(np.hstack([X, pa]))
    sc = StandardScaler(); X2 = sc.fit_transform(X2)
    if model_type == 'ridge':
        m2 = RidgeCV(alphas=alphas)
    else:
        m2 = ElasticNetCV(l1_ratio=[0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE, max_iter=10000)
    m2.fit(X2[tm], y[tm])
    vp = m2.predict(X2[vm])

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk]))); bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bp)])))
    bl = [w * p + (1-w) * cm for p in bp]
    cv_sh = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))
    return {'cv_raw': cv_raw, 'cv_sh': cv_sh, 'w': w, 'cm': cm, 'small': is_small}

def run(name, model_type='ridge', n_pca_max=30, alphas_map=None):
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    ar, as_ = [], []
    for coal in COAL_TYPES:
        al = alphas_map.get(coal) if alphas_map else None
        r = time_ext(coal, model_type, n_pca_max, al)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        if r.get('no_split'):
            print(f"  [{coal}] ({tag}) w={r['w']:.2f} mean={r['cm']:.0f} (no split)", flush=True)
        else:
            ar.append(r['cv_raw']); as_.append(r['cv_sh'])
            print(f"  [{coal}] ({tag}) raw={r['cv_raw']:.2f} shrunk={r['cv_sh']:.2f} w={r['w']:.2f}", flush=True)
    if ar:
        avg = np.mean(as_)
        print(f"  >> avg raw={np.mean(ar):.2f} shrunk={avg:.2f}", flush=True)
        return avg
    return None

if __name__ == "__main__":
    exp_name = sys.argv[1] if len(sys.argv) > 1 else 'baseline'

    if exp_name == 'baseline':
        run("基线: Ridge default alphas n_pca=30")
    elif exp_name == 'high_alpha_zgy':
        ha = [100.0, 500.0, 1000.0, 5000.0, 10000.0, 50000.0, 100000.0]
        run("赵固一/二高alpha", alphas_map={'赵固一矿豫焦末煤': ha, '赵固二矿中煤矿': ha})
    elif exp_name == 'high_alpha_all':
        ha = [100.0, 500.0, 1000.0, 5000.0, 10000.0, 50000.0, 100000.0]
        run("全煤种高alpha", alphas_map={ct: ha for ct in COAL_TYPES})
    elif exp_name == 'elasticnet':
        run("ElasticNet", model_type='elasticnet')
    elif exp_name == 'n_pca_50':
        run("N_PCA=50", n_pca_max=50)
    elif exp_name == 'n_pca_80':
        run("N_PCA=80", n_pca_max=80)
