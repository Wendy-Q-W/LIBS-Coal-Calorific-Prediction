"""V14b 精简实验: 快速对比(10种子)"""
import os, sys, copy, warnings
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS, ALPHAS,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    get_cv_splits, find_best_shrinkage,
)
from experiment_v14 import build_feature_matrix_v14

SEEDS = list(range(10))

def _train_lgb(X_spec, y, aux, groups, splits, coal_mean, seed=42):
    params = dict(n_estimators=300, learning_rate=0.1, max_depth=5, num_leaves=15,
                  subsample=0.8, colsample_bytree=0.8, reg_alpha=1.0, reg_lambda=10.0,
                  random_state=seed, verbose=-1, n_jobs=1)
    aux_models = {}
    pred_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci, cn in enumerate(AUX_COLS):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pred_aux_oof[:, ci] = float(np.nanmean(ya)); aux_models[cn] = None; continue
        m = lgb.LGBMRegressor(**params); oof = np.zeros(len(ya))
        for tr, va in splits:
            m.fit(X_spec[tr], ya[tr]); oof[va] = m.predict(X_spec[va])
        pred_aux_oof[:, ci] = oof; m.fit(X_spec, ya); aux_models[cn] = m
    X_s2 = np.nan_to_num(np.hstack([X_spec, pred_aux_oof]))
    oof_bp, oof_bt, brms = [], [], []
    for tr, va in splits:
        m2 = lgb.LGBMRegressor(**params); m2.fit(X_s2[tr], y[tr])
        vp = m2.predict(X_s2[va]); vg = groups[va]
        se = []
        for bg in np.unique(vg):
            mk = vg == bg; tq = float(y[va][mk][0]); pq = float(np.median(vp[mk]))
            oof_bp.append(pq); oof_bt.append(tq); se.append((tq-pq)**2)
        brms.append(float(np.sqrt(np.mean(se))))
    cv_raw = float(np.mean(brms))
    bw, cv_sh = find_best_shrinkage(oof_bp, oof_bt, coal_mean)
    return cv_sh

def train_lgb(ct, td, use_sg, use_snv):
    y, aux, groups = td['targets'], td['aux'], td['groups']
    nb, cm = td['n_batches'], float(y.mean())
    X, _, _, _ = build_feature_matrix_v14(td, nb, fit=True, use_sg=use_sg, use_snv=use_snv)
    if nb <= SMALL_BATCH_THRESHOLD:
        sp = get_cv_splits(groups, nb)
        r = _train_lgb(X, y, aux, groups, sp, cm)
        print(f"  [{ct}] {nb}batch LGB LOOCV CV={r:.2f}")
        return r
    cvs = [_train_lgb(X, y, aux, groups, get_cv_splits(groups, nb, s), cm, s) for s in SEEDS]
    r = float(np.mean(cvs))
    print(f"  [{ct}] {nb}batch LGB 10seed CV={r:.2f}±{np.std(cvs):.2f}")
    return r

def train_ridge(ct, td, use_sg, use_snv):
    from all import _train_one_run
    y, aux, groups = td['targets'], td['aux'], td['groups']
    nb, cm = td['n_batches'], float(y.mean())
    X, _, _, _ = build_feature_matrix_v14(td, nb, fit=True, use_sg=use_sg, use_snv=use_snv)
    if nb <= SMALL_BATCH_THRESHOLD:
        sp = get_cv_splits(groups, nb)
        r = _train_one_run(X, y, aux, groups, sp, cm, nb)
        print(f"  [{ct}] {nb}batch Ridge LOOCV CV={r['cv_rmse']:.2f}")
        return r['cv_rmse']
    cvs = [_train_one_run(X, y, aux, groups, get_cv_splits(groups, nb, s), cm, nb)['cv_rmse'] for s in SEEDS]
    r = float(np.mean(cvs))
    print(f"  [{ct}] {nb}batch Ridge 10seed CV={r:.2f}±{np.std(cvs):.2f}")
    return r

if __name__ == "__main__":
    lm, am = load_labels()
    results = {}
    configs = [
        ("Ridge+更多比值only",   lambda ct,td: train_ridge(ct,td,False,False)),
        ("Ridge+更多比值+SG+SNV", lambda ct,td: train_ridge(ct,td,True,True)),
        ("LGB+更多比值only",     lambda ct,td: train_lgb(ct,td,False,False)),
        ("LGB+更多比值+SG+SNV",  lambda ct,td: train_lgb(ct,td,True,True)),
    ]
    for name, fn in configs:
        print(f"\n{'='*50}\n{name}\n{'='*50}")
        cvs = {}
        for ct in COAL_TYPES:
            td = load_coal_spectra(TRAIN_DIR, ct, lm, am)
            if td is None or td['n_batches']==0: continue
            cvs[ct] = fn(ct, td)
        g = float(np.mean(list(cvs.values())))
        print(f"  => 全局 CV-RMSE: {g:.2f}")
        results[name] = g
    
    print(f"\n{'='*50}\n汇总 (10种子快速版)\n{'='*50}")
    print(f"  V13 基线(100seed):     170.62")
    for n, g in results.items():
        print(f"  {n}: {g:.2f}")
