"""
v511_v530_uncertainty_adjust.py

NEW APPROACH: Uncertainty-based V96 adjustment.

KEY INSIGHT: V96 = blend of V61, V63, V72. When these 3 models disagree on a
prediction, that prediction is more likely to be wrong. By shrinking
high-disagreement predictions toward the coal mean, we can potentially reduce
RMSE without increasing gap (only adjusting 2-5 out of 26 predictions).

This is fundamentally different from all previous approaches:
- Does NOT change the model (corr stays very high → gap stays ~25)
- Targets the WORST predictions (largest potential RMSE reduction)
- Fixing ONE bad prediction by 100 points can drop RMSE by ~20 points

Also computes training coal means for accurate shrinkage targets.
"""
import os, sys, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_pred(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


# === Load training coal means ===
print("Loading training coal means...")
sys.path.insert(0, _HERE)
try:
    import exp_v260_v270_tree_models as base
    label_map, aux_map = base.load_labels()
    COAL_TYPES = base.COAL_TYPES
    coal_means_train = {}
    for coal in COAL_TYPES:
        train_data = base.load_coal_spectra(base.TRAIN_DIR, coal, label_map, aux_map)
        if train_data is not None:
            coal_means_train[coal] = float(np.mean(train_data['targets']))
            print(f"  {coal}: train mean = {coal_means_train[coal]:.2f} (n={len(train_data['targets'])})")
except Exception as e:
    print(f"  WARNING: Could not load training coal means: {e}")
    coal_means_train = {}


# === Load predictions ===
print("\nLoading predictions...")
v61 = load_pred('submit_v61_a005_bias.zip')
v63 = load_pred('submit_v63_isotonic.zip')
v72 = load_pred('submit_v72_isotonic_a005.zip')
v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')

batch_names = list(v96.index)
n = len(batch_names)
print(f"  {n} test batches loaded")

# Align all predictions to V96 order
v61_arr = np.array([v61[b] for b in batch_names])
v63_arr = np.array([v63[b] for b in batch_names])
v72_arr = np.array([v72[b] for b in batch_names])
v96_arr = np.array([v96[b] for b in batch_names])

# === Extract coal types ===
COAL_PREFIXES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]

def extract_coal_type(name):
    for ct in COAL_PREFIXES:
        if name.startswith(ct):
            return ct
    return 'unknown'

coal_types = [extract_coal_type(b) for b in batch_names]

# === Compute coal means ===
# Use training coal means if available, otherwise V96 per-coal mean
coal_mean_arr = np.zeros(n)
for i, ct in enumerate(coal_types):
    if ct in coal_means_train:
        coal_mean_arr[i] = coal_means_train[ct]
    else:
        # Fallback: V96 per-coal mean
        mask = [c == ct for c in coal_types]
        coal_mean_arr[i] = np.mean(v96_arr[mask])

print("\nCoal means:")
for ct in set(coal_types):
    mask = [c == ct for c in coal_types]
    train_mean = coal_means_train.get(ct, None)
    v96_mean = np.mean(v96_arr[mask])
    print(f"  {ct}: train={train_mean}, V96_mean={v96_mean:.1f}, n_batches={sum(mask)}")

# === Compute disagreement and z-scores ===
disagreement = np.max([v61_arr, v63_arr, v72_arr], axis=0) - np.min([v61_arr, v63_arr, v72_arr], axis=0)

# Z-score within coal type
z_scores = np.zeros(n)
for ct in set(coal_types):
    mask = np.array([c == ct for c in coal_types])
    ct_preds = v96_arr[mask]
    ct_std = np.std(ct_preds) if len(ct_preds) > 1 else 100
    for i in np.where(mask)[0]:
        z_scores[i] = (v96_arr[i] - np.mean(ct_preds)) / ct_std if ct_std > 0 else 0

# === Print per-batch analysis ===
print(f"\n{'='*90}")
print("  PER-BATCH ANALYSIS (sorted by disagreement)")
print(f"{'='*90}")
print(f"{'#':>3s} {'Batch':40s} {'V96':>7s} {'CoalMn':>7s} {'V61':>7s} {'V63':>7s} {'V72':>7s} {'Disag':>7s} {'|Z|':>6s}")
print("-" * 90)

sorted_idx = np.argsort(disagreement)[::-1]
for rank, i in enumerate(sorted_idx):
    print(f"{rank+1:3d} {batch_names[i]:40s} {v96_arr[i]:7.1f} {coal_mean_arr[i]:7.1f} "
          f"{v61_arr[i]:7.1f} {v63_arr[i]:7.1f} {v72_arr[i]:7.1f} {disagreement[i]:7.1f} {abs(z_scores[i]):6.2f}")

# === Generate uncertainty-adjusted variants ===
print(f"\n{'='*90}")
print("  GENERATING UNCERTAINTY-ADJUSTED V96 VARIANTS")
print(f"{'='*90}")

variants = []

# --- Shrink toward coal mean ---
for K in [2, 3, 5]:
    for alpha in [0.3, 0.5, 0.7]:
        top_k = set(sorted_idx[:K])
        adjusted = v96_arr.copy()
        for idx in top_k:
            adjusted[idx] = alpha * v96_arr[idx] + (1 - alpha) * coal_mean_arr[idx]

        corr = np.corrcoef(v96_arr, adjusted)[0, 1]
        mae = np.mean(np.abs(adjusted - v96_arr))
        max_change = np.max(np.abs(adjusted - v96_arr))

        vid = f"v5{K+8}_adjK{K}_s{int(alpha*100)}"
        desc = (f"V96 + top-{K} disagreement batches shrunk {int(alpha*100)}% toward coal mean. "
                f"corr={corr:.6f}, MAE={mae:.2f}, max_chg={max_change:.1f}. "
                f"Adjusted: {[batch_names[i][:10] for i in sorted_idx[:K]]}")

        all_preds = {batch_names[i]: float(adjusted[i]) for i in range(n)}
        pack_submission(vid, all_preds, desc)
        variants.append((vid, corr, mae))

# --- Replace with V72 ---
for K in [3, 5]:
    top_k = set(sorted_idx[:K])
    adjusted = v96_arr.copy()
    for idx in top_k:
        adjusted[idx] = v72_arr[idx]

    corr = np.corrcoef(v96_arr, adjusted)[0, 1]
    mae = np.mean(np.abs(adjusted - v96_arr))

    vid = f"v5{20+K}_rplV72_K{K}"
    desc = (f"V96 + top-{K} disagreement replaced by V72. "
            f"corr={corr:.6f}, MAE={mae:.2f}")

    all_preds = {batch_names[i]: float(adjusted[i]) for i in range(n)}
    pack_submission(vid, all_preds, desc)
    variants.append((vid, corr, mae))

# --- Replace with median ---
for K in [3, 5]:
    top_k = set(sorted_idx[:K])
    adjusted = v96_arr.copy()
    for idx in top_k:
        adjusted[idx] = np.median([v61_arr[idx], v63_arr[idx], v72_arr[idx]])

    corr = np.corrcoef(v96_arr, adjusted)[0, 1]
    mae = np.mean(np.abs(adjusted - v96_arr))

    vid = f"v5{30+K}_rplMed_K{K}"
    desc = (f"V96 + top-{K} disagreement replaced by median(V61,V63,V72). "
            f"corr={corr:.6f}, MAE={mae:.2f}")

    all_preds = {batch_names[i]: float(adjusted[i]) for i in range(n)}
    pack_submission(vid, all_preds, desc)
    variants.append((vid, corr, mae))

# --- Z-score based shrinkage ---
sorted_z_idx = np.argsort(np.abs(z_scores))[::-1]
for K in [3, 5]:
    for alpha in [0.5]:
        top_k = set(sorted_z_idx[:K])
        adjusted = v96_arr.copy()
        for idx in top_k:
            adjusted[idx] = alpha * v96_arr[idx] + (1 - alpha) * coal_mean_arr[idx]

        corr = np.corrcoef(v96_arr, adjusted)[0, 1]
        mae = np.mean(np.abs(adjusted - v96_arr))

        vid = f"v5{40+K}_zK{K}_s{int(alpha*100)}"
        desc = (f"V96 + top-{K} |z-score| batches shrunk {int(alpha*100)}% toward coal mean. "
                f"corr={corr:.6f}, MAE={mae:.2f}")

        all_preds = {batch_names[i]: float(adjusted[i]) for i in range(n)}
        pack_submission(vid, all_preds, desc)
        variants.append((vid, corr, mae))

# --- Blends of V96 with adjusted variants ---
# Load the most promising adjusted variants and blend with V96
blend_pairs = [
    # (adjusted zip name, V96 weight, adjusted weight, vid, desc)
    ('submit_v511_adjK2_s30.zip', 0.9, 0.1, 'v526_v96_v511_9010',
     'V96(90%) + V511(10%). Minimal uncertainty adjustment.'),
    ('submit_v511_adjK2_s30.zip', 0.8, 0.2, 'v527_v96_v511_8020',
     'V96(80%) + V511(20%).'),
    ('submit_v514_adjK3_s30.zip', 0.9, 0.1, 'v528_v96_v514_9010',
     'V96(90%) + V514(10%). K=3 light adjustment.'),
    ('submit_v515_adjK3_s50.zip', 0.9, 0.1, 'v529_v96_v515_9010',
     'V96(90%) + V515(10%). K=3 medium adjustment.'),
    ('submit_v520_rplV72_K3.zip', 0.9, 0.1, 'v530_v96_v520_9010',
     'V96(90%) + V520(10%). K=3 V72 replacement.'),
]

for adj_zip, w96, w_adj, vid, desc in blend_pairs:
    adj_sub = load_pred(adj_zip)
    if adj_sub is None:
        print(f"  SKIP {vid}: {adj_zip} not found")
        continue
    adj_arr = np.array([adj_sub[b] for b in batch_names])
    adjusted = w96 * v96_arr + w_adj * adj_arr

    corr = np.corrcoef(v96_arr, adjusted)[0, 1]
    mae = np.mean(np.abs(adjusted - v96_arr))

    all_preds = {batch_names[i]: float(adjusted[i]) for i in range(n)}
    full_desc = f"{desc} corr={corr:.6f}, MAE={mae:.2f}"
    pack_submission(vid, all_preds, full_desc)
    variants.append((vid, corr, mae))

# === Summary ===
print(f"\n{'='*90}")
print("  SUMMARY - All uncertainty-adjusted variants")
print(f"{'='*90}")
print(f"{'Variant':35s} {'corr(V96)':>10s} {'MAE':>8s} {'MaxChg':>8s}")
print("-" * 65)

# Also show V470 and V506 for comparison
v470 = load_pred('submit_v470_blend_v469_v72_7525.zip')
v506 = load_pred('submit_v506_v96bm_v96_5050.zip')
if v470 is not None:
    v470_arr = np.array([v470[b] for b in batch_names])
    corr470 = np.corrcoef(v96_arr, v470_arr)[0, 1]
    mae470 = np.mean(np.abs(v470_arr - v96_arr))
    print(f"{'V470 (batch_mean blend)':35s} {corr470:10.6f} {mae470:8.2f} {np.max(np.abs(v470_arr-v96_arr)):8.2f}")
if v506 is not None:
    v506_arr = np.array([v506[b] for b in batch_names])
    corr506 = np.corrcoef(v96_arr, v506_arr)[0, 1]
    mae506 = np.mean(np.abs(v506_arr - v96_arr))
    print(f"{'V506 (V96bm+V96 5050)':35s} {corr506:10.6f} {mae506:8.2f} {np.max(np.abs(v506_arr-v96_arr)):8.2f}")

print("-" * 65)
for vid, corr, mae in variants:
    # Load the variant to compute max change
    for f in os.listdir(OUTPUT_DIR):
        if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
            sub = load_pred(f)
            if sub is not None:
                sub_arr = np.array([sub[b] for b in batch_names])
                max_chg = np.max(np.abs(sub_arr - v96_arr))
                print(f"{vid:35s} {corr:10.6f} {mae:8.2f} {max_chg:8.2f}")
            break

print("\n  Done.")
