"""V19d: 精调main窗口×5~7 + 逐主元素 + 多种子稳定性验证
关键发现: main=5.0,metal=1.0 → GK-3.25, TE-39.76 (V19c)
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    KEY_LINES, RANDOM_STATE,
)
from exp_v19 import run_config, gkfold_cv, time_ext


MAIN_KEYS = ['C', 'H', 'O', 'N']
METAL_KEYS = ['Ca', 'Ca2', 'Mg', 'Al', 'Si', 'Fe', 'Na']


def make_diff(main_s, metal_s):
    kl = {}
    for k, (c, h) in KEY_LINES.items():
        kl[k] = (c, h * main_s if k in MAIN_KEYS else h * metal_s)
    return kl


def run_config_seeds(name, key_lines, n_seeds_list=None):
    """用不同种子数验证稳定性"""
    if n_seeds_list is None:
        n_seeds_list = [10, 30]
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    for ns in n_seeds_list:
        gk_all, te_all = [], []
        for coal in COAL_TYPES:
            r = gkfold_cv(coal, key_lines=key_lines, n_seeds=ns)
            if r: gk_all.append(r['sh'])
        for coal in ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']:
            r = time_ext(coal, key_lines=key_lines)
            if r: te_all.append(r['sh'])
        gk, te = np.mean(gk_all), np.mean(te_all)
        print(f"  seeds={ns}: GK={gk:.2f}  TE={te:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk, te


if __name__ == "__main__":
    results = {}

    # 基线
    results['baseline'] = run_config("基线 win=1.0", n_pca_max=30)
    base_gk, base_te = results['baseline']['gk'], results['baseline']['te']

    # P1: main窗口精调 (metal=1.0)
    for ms in [5.0, 6.0, 7.0, 8.0]:
        kl = make_diff(ms, 1.0)
        results[f'main={ms},metal=1.0'] = run_config(
            f"主元素×{ms},金属×1.0", key_lines=kl)

    # P2: main=5.0, metal微调
    for mts in [0.5, 1.5, 2.0]:
        kl = make_diff(5.0, mts)
        results[f'main=5.0,metal={mts}'] = run_config(
            f"主元素×5.0,金属×{mts}", key_lines=kl)

    # P3: 逐主元素 — 哪个最重要?
    for k in MAIN_KEYS:
        # 只有该主元素×5, 其余主元素×1, 金属×1
        kl = {}
        for kk, (c, h) in KEY_LINES.items():
            s = 5.0 if kk == k else 1.0
            kl[kk] = (c, h * s)
        results[f'only_{k}=5.0'] = run_config(
            f"仅{k}×5.0", key_lines=kl)

    # P4: O+N组合 (O贡献最大)
    for combo, scales in [
        ('O+N=5.0', {'O': 5.0, 'N': 5.0}),
        ('O+C=5.0', {'O': 5.0, 'C': 5.0}),
        ('O+H=5.0', {'O': 5.0, 'H': 5.0}),
        ('O=5,H=3', {'O': 5.0, 'H': 3.0}),
        ('O=5,C=3', {'O': 5.0, 'C': 3.0}),
    ]:
        kl = {}
        for kk, (c, h) in KEY_LINES.items():
            s = scales.get(kk, 1.0)
            kl[kk] = (c, h * s)
        results[combo] = run_config(combo, key_lines=kl)

    # 汇总
    print(f"\n{'='*60}")
    print("  V19d: 精调+逐主元素扫描")
    print(f"{'='*60}")
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
