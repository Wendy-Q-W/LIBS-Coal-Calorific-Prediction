"""
exp_v32_framework.py
方向B+: PLS直接端到端 (不拼接手工特征, PLS原始光谱->直接预测Q)
方向C+: SG导数替换原始光谱做PCA (非拼接)
方向A+: LightGBM在PCA(30)特征上 (非原始手工特征)
基于V28配置(含时间加权),双重CV验证。
"""
import os, re, glob, warnings, time
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.signal import savgol_filter
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from lightgbm import LGBMRegressor, early_stopping, log_evaluation

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']
KEY_LINES = {
    'C':   (247.86, 5.0), 'H':   (656.30, 7.5),
    'O':   (777.20, 7.5), 'N':   (742.40, 5.0),
    'Ca':  (422.70, 1.0), 'Ca2': (393.40, 1.0),
    'Mg':  (285.20, 1.0), 'Al':  (308.20, 1.0),
    'Si':  (288.20, 1.0), 'Fe':  (438.40, 1.5),
    'Na':  (589.00, 0.75),
}

N_PCA_MAX = 30
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features(wl, inten)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return inorm_mat


# ═══════════════════════════════════════════════════════════════════════════════
# Feature matrix builders for different modes
# ═══════════════════════════════════════════════════════════════════════════════

def build_fm_standard(data, n_batches, fit=True, scaler_spec=None, pca=None, scaler_hand=None):
    """V28 standard: inorm -> StandardScaler -> PCA(30) -> hstack hand feats -> StandardScaler"""
    inorm_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def build_fm_sg_replace(data, n_batches, sg_deriv=1, sg_win=11, sg_poly=2,
                        fit=True, scaler_spec=None, pca=None, scaler_hand=None):
    """SG derivative REPLACES original spectrum as PCA input."""
    inorm_mat = compute_features(data)
    # Apply SG derivative to the normalized intensity matrix
    spec_deriv = savgol_filter(inorm_mat, window_length=sg_win, polyorder=sg_poly,
                               deriv=sg_deriv, axis=1)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_deriv)
        n_pca = min(N_PCA_MAX, n_batches - 1, spec_scaled.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_deriv))
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def build_fm_pls_direct(data, n_batches, n_pls=30,
                        fit=True, scaler_spec=None, pls=None, scaler_hand=None):
    """PLS replaces PCA: supervised dimensionality reduction."""
    inorm_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_comp = min(n_pls, n_batches - 1, spec_scaled.shape[0] - 1)
        pls = PLSRegression(n_components=n_comp, scale=False)
        # PLS needs y; will be set outside
        return spec_scaled, scaler_spec, pls, None
    else:
        spec_scaled = scaler_spec.transform(inorm_mat)
        return spec_scaled


# ═══════════════════════════════════════════════════════════════════════════════
# CV infrastructure
# ═══════════════════════════════════════════════════════════════════════════════

def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def _train_one_run_ridge(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                         sample_weights=None):
    """Two-stage Ridge with OOF aux prediction."""
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)

    final_model = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def _train_one_run_lgbm(X_spec, y, aux, groups, splits, coal_mean, n_batches,
                        sample_weights=None, lgbm_params=None):
    """Two-stage with LightGBM as Stage 2 model."""
    if lgbm_params is None:
        lgbm_params = {
            'n_estimators': 200,
            'max_depth': 3,
            'learning_rate': 0.05,
            'num_leaves': 7,
            'min_child_samples': 5,
            'subsample': 0.7,
            'colsample_bytree': 0.7,
            'reg_alpha': 1.0,
            'reg_lambda': 1.0,
            'random_state': 42,
            'verbose': -1,
        }

    # Stage 1: Ridge OOF for aux (keep Ridge for aux - it's more stable)
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X_spec, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = LGBMRegressor(**lgbm_params)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)

    # Final model trained on all data
    final_model = LGBMRegressor(**lgbm_params)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def _train_one_run_pls(inorm_mat, y, aux, groups, splits, coal_mean, n_batches,
                       n_pls=30, sample_weights=None):
    """PLS per-fold: fit on train fold, transform both. Then Ridge Stage 2."""
    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    aux_oof = np.zeros_like(aux, dtype=np.float32)

    for tr_idx, val_idx in splits:
        sc = StandardScaler()
        spec_tr = sc.fit_transform(inorm_mat[tr_idx])
        spec_va = sc.transform(inorm_mat[val_idx])

        n_comp = min(n_pls, spec_tr.shape[0] - 1, spec_tr.shape[1])
        pls = PLSRegression(n_components=n_comp, scale=False)
        # PLS doesn't support sample_weight; fit without it
        pls.fit(spec_tr, y[tr_idx])
        pls_tr = pls.transform(spec_tr)
        pls_va = pls.transform(spec_va)

        # Stage 1: aux via Ridge on PLS scores
        pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
        pa_va = np.zeros((len(val_idx), aux.shape[1]), dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                continue
            m1 = Ridge(alpha=RIDGE_ALPHA)
            if sample_weights is not None:
                m1.fit(pls_tr, ya[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m1.fit(pls_tr, ya[tr_idx])
            pa_tr[:, ci] = m1.predict(pls_tr)
            pa_va[:, ci] = m1.predict(pls_va)
        aux_oof[val_idx] = pa_va

        X2_tr = np.nan_to_num(np.hstack([pls_tr, pa_tr]))
        X2_va = np.nan_to_num(np.hstack([pls_va, pa_va]))
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X2_tr, y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X2_tr, y[tr_idx])
        vp = m2.predict(X2_va)
        vg = groups[val_idx]
        for bg in np.unique(vg):
            mk = vg == bg
            true_q = float(y[val_idx][mk][0])
            pred_q = float(np.median(vp[mk]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)

    cv_rmse_raw = float(np.sqrt(np.mean(
        (np.array(oof_batch_preds) - np.array(oof_batch_true)) ** 2)))
    best_w, cv_rmse_shrunk = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_mean)

    # Train final on all data
    sc = StandardScaler()
    spec_all = sc.fit_transform(inorm_mat)
    n_comp = min(n_pls, spec_all.shape[0] - 1, spec_all.shape[1])
    pls = PLSRegression(n_components=n_comp, scale=False)
    # PLS doesn't support sample_weight
    pls.fit(spec_all, y)
    pls_all = pls.transform(spec_all)

    pa_all = np.zeros((len(y), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_all[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m1.fit(pls_all, ya, sample_weight=sample_weights)
        else:
            m1.fit(pls_all, ya)
        pa_all[:, ci] = m1.predict(pls_all)

    X2_all = np.nan_to_num(np.hstack([pls_all, pa_all]))
    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        m2.fit(X2_all, y, sample_weight=sample_weights)
    else:
        m2.fit(X2_all, y)

    return {
        'cv_rmse': cv_rmse_shrunk, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def train_coal_gk(coal_type, train_data, mode='standard', **kwargs):
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        months = train_data.get('months')
        if months is not None and len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    if mode == 'standard':
        X_spec, _, _, _ = build_fm_standard(train_data, n_batches, fit=True)
        if is_small:
            splits = get_cv_splits(groups, n_batches)
            run = _train_one_run_ridge(X_spec, y, aux, groups, splits, coal_mean,
                                       n_batches, sample_weights=sample_weights)
            return run, is_small
        else:
            runs = []
            for seed in ENSEMBLE_SEEDS:
                splits = get_cv_splits(groups, n_batches, seed=seed)
                run = _train_one_run_ridge(X_spec, y, aux, groups, splits, coal_mean,
                                           n_batches, sample_weights=sample_weights)
                runs.append(run)
            avg_w = float(np.mean([r['shrink_w'] for r in runs]))
            for r in runs:
                r['shrink_w'] = avg_w
            return runs, is_small

    elif mode == 'sg_replace':
        sg_deriv = kwargs.get('sg_deriv', 1)
        sg_win = kwargs.get('sg_win', 11)
        sg_poly = kwargs.get('sg_poly', 2)
        X_spec, _, _, _ = build_fm_sg_replace(
            train_data, n_batches, sg_deriv=sg_deriv, sg_win=sg_win, sg_poly=sg_poly,
            fit=True)
        if is_small:
            splits = get_cv_splits(groups, n_batches)
            run = _train_one_run_ridge(X_spec, y, aux, groups, splits, coal_mean,
                                       n_batches, sample_weights=sample_weights)
            return run, is_small
        else:
            runs = []
            for seed in ENSEMBLE_SEEDS:
                splits = get_cv_splits(groups, n_batches, seed=seed)
                run = _train_one_run_ridge(X_spec, y, aux, groups, splits, coal_mean,
                                           n_batches, sample_weights=sample_weights)
                runs.append(run)
            avg_w = float(np.mean([r['shrink_w'] for r in runs]))
            for r in runs:
                r['shrink_w'] = avg_w
            return runs, is_small

    elif mode == 'lgbm':
        X_spec, _, _, _ = build_fm_standard(train_data, n_batches, fit=True)
        lgbm_params = kwargs.get('lgbm_params')
        if is_small:
            splits = get_cv_splits(groups, n_batches)
            run = _train_one_run_lgbm(X_spec, y, aux, groups, splits, coal_mean,
                                      n_batches, sample_weights=sample_weights,
                                      lgbm_params=lgbm_params)
            return run, is_small
        else:
            runs = []
            for seed in ENSEMBLE_SEEDS:
                splits = get_cv_splits(groups, n_batches, seed=seed)
                run = _train_one_run_lgbm(X_spec, y, aux, groups, splits, coal_mean,
                                          n_batches, sample_weights=sample_weights,
                                          lgbm_params=lgbm_params)
                runs.append(run)
            avg_w = float(np.mean([r['shrink_w'] for r in runs]))
            for r in runs:
                r['shrink_w'] = avg_w
            return runs, is_small

    elif mode == 'pls_direct':
        inorm_mat = compute_features(train_data)
        n_pls = kwargs.get('n_pls', 30)
        if is_small:
            splits = get_cv_splits(groups, n_batches)
            run = _train_one_run_pls(inorm_mat, y, aux, groups, splits, coal_mean,
                                     n_batches, n_pls=n_pls,
                                     sample_weights=sample_weights)
            return run, is_small
        else:
            runs = []
            for seed in ENSEMBLE_SEEDS:
                splits = get_cv_splits(groups, n_batches, seed=seed)
                run = _train_one_run_pls(inorm_mat, y, aux, groups, splits, coal_mean,
                                         n_batches, n_pls=n_pls,
                                         sample_weights=sample_weights)
                runs.append(run)
            avg_w = float(np.mean([r['shrink_w'] for r in runs]))
            for r in runs:
                r['shrink_w'] = avg_w
            return runs, is_small

    return None, is_small


def train_coal_te(coal_type, train_data, mode='standard', **kwargs):
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    months = train_data['months']
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sw = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)
        sample_weights = sw

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    inorm_mat = compute_features(train_data)

    if mode == 'standard':
        X_spec, _, _, _ = build_fm_standard(train_data, n_batches, fit=True)
    elif mode == 'sg_replace':
        sg_deriv = kwargs.get('sg_deriv', 1)
        sg_win = kwargs.get('sg_win', 11)
        sg_poly = kwargs.get('sg_poly', 2)
        X_spec, _, _, _ = build_fm_sg_replace(
            train_data, n_batches, sg_deriv=sg_deriv, sg_win=sg_win, sg_poly=sg_poly,
            fit=True)
    elif mode == 'lgbm':
        X_spec, _, _, _ = build_fm_standard(train_data, n_batches, fit=True)
    elif mode == 'pls_direct':
        # PLS direct: fit on train, transform val
        n_pls = kwargs.get('n_pls', 30)
        sc = StandardScaler()
        spec_tr = sc.fit_transform(inorm_mat[tr_idx])
        spec_va = sc.transform(inorm_mat[val_idx])
        n_comp = min(n_pls, spec_tr.shape[0] - 1, spec_tr.shape[1])
        pls = PLSRegression(n_components=n_comp, scale=False)
        # PLS doesn't support sample_weight
        pls.fit(spec_tr, y[tr_idx])
        pls_tr = pls.transform(spec_tr)
        pls_va = pls.transform(spec_va)

        pa_va = np.zeros((len(val_idx), aux.shape[1]), dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa_va[:, ci] = float(np.nanmean(ya[tr_idx]))
                continue
            m1 = Ridge(alpha=RIDGE_ALPHA)
            if sample_weights is not None:
                m1.fit(pls_tr, ya[tr_idx], sample_weight=sample_weights)
            else:
                m1.fit(pls_tr, ya[tr_idx])
            pa_va[:, ci] = m1.predict(pls_va)

        pa_tr = np.zeros((len(tr_idx), aux.shape[1]), dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa_tr[:, ci] = float(np.nanmean(ya[tr_idx]))
                continue
            m1 = Ridge(alpha=RIDGE_ALPHA)
            if sample_weights is not None:
                m1.fit(pls_tr, ya[tr_idx], sample_weight=sample_weights)
            else:
                m1.fit(pls_tr, ya[tr_idx])
            pa_tr[:, ci] = m1.predict(pls_tr)

        X2_tr = np.nan_to_num(np.hstack([pls_tr, pa_tr]))
        X2_va = np.nan_to_num(np.hstack([pls_va, pa_va]))
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X2_tr, y[tr_idx], sample_weight=sample_weights)
        else:
            m2.fit(X2_tr, y[tr_idx])
        vp = m2.predict(X2_va)
        vg = groups[val_idx]
        oof_preds, oof_true = [], []
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(vp[mk])))
            oof_true.append(float(y[val_idx][mk][0]))
        oof_preds = np.array(oof_preds)
        oof_true = np.array(oof_true)
        rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
        best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
        return {
            'oof_preds': oof_preds, 'oof_true': oof_true,
            'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
            'shrink_w': best_w, 'coal_mean': coal_mean,
        }

    # For standard/sg_replace/lgbm: use the X_spec built above
    # Stage 1: aux
    predicted_aux_val = np.zeros((len(val_idx), len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_val[:, col_idx] = float(np.nanmean(y_aux[tr_idx]))
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights)
        else:
            m.fit(X_spec[tr_idx], y_aux[tr_idx])
        predicted_aux_val[:, col_idx] = m.predict(X_spec[val_idx])

    X_s2_tr = np.nan_to_num(np.hstack([X_spec[tr_idx], aux[tr_idx, :]]))
    X_s2_val = np.nan_to_num(np.hstack([X_spec[val_idx], predicted_aux_val]))
    scaler_s2 = StandardScaler()
    X_s2_tr_s = scaler_s2.fit_transform(X_s2_tr)
    X_s2_val_s = scaler_s2.transform(X_s2_val)

    if mode == 'lgbm':
        lgbm_params = kwargs.get('lgbm_params')
        m2 = LGBMRegressor(**lgbm_params)
    else:
        m2 = Ridge(alpha=RIDGE_ALPHA)

    if sample_weights is not None:
        m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sample_weights)
    else:
        m2.fit(X_s2_tr_s, y[tr_idx])

    val_pred = m2.predict(X_s2_val_s)
    val_groups = groups[val_idx]
    oof_preds, oof_true = [], []
    for bg in np.unique(val_groups):
        mask = val_groups == bg
        oof_preds.append(float(np.median(val_pred[mask])))
        oof_true.append(float(y[val_idx][mask][0]))
    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w, 'coal_mean': coal_mean,
    }


def gk_cv_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    else:
        return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


def run_experiment(label_map, aux_map, config_name, mode='standard', **kwargs):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {config_name}")
    print(f"{'='*70}")
    gk_results = {}
    te_results = {}
    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None or train_data['n_batches'] == 0:
            continue
        n_batches = train_data['n_batches']
        runs, is_small = train_coal_gk(coal_type, train_data, mode=mode, **kwargs)
        gk_rmse = gk_cv_rmse(runs, is_small)
        gk_results[coal_type] = gk_rmse
        te_result = train_coal_te(coal_type, train_data, mode=mode, **kwargs)
        te_rmse = te_result['rmse_shrunk'] if te_result else None
        te_results[coal_type] = te_rmse
        te_str = f"TE={te_rmse:.2f}" if te_rmse else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b  GK={gk_rmse:.2f}  {te_str}")
    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {config_name}")
    print(f"     GK-Avg={gk_avg:.2f}  TE-Avg={te_avg:.2f}  ({time.time()-t0:.0f}s)")
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V32: Framework Change Experiments")
    print("  B+: PLS direct (per-fold, no hand feats)")
    print("  C+: SG derivative REPLACE original spectrum in PCA")
    print("  A+: LightGBM on PCA(30) features")
    print("=" * 70)

    label_map, aux_map = load_labels()

    results = {}

    # Baseline
    results['V28'] = run_experiment(label_map, aux_map, "V28 Baseline", mode='standard')

    # C+: SG derivative replace (1st order, various windows)
    for win in [7, 11, 15]:
        results[f'SG1_replace_w{win}'] = run_experiment(
            label_map, aux_map, f"SG1 replace win={win}",
            mode='sg_replace', sg_deriv=1, sg_win=win, sg_poly=2)

    # C+: SG derivative replace (2nd order)
    for win in [7, 11, 15]:
        results[f'SG2_replace_w{win}'] = run_experiment(
            label_map, aux_map, f"SG2 replace win={win}",
            mode='sg_replace', sg_deriv=2, sg_win=win, sg_poly=2)

    # B+: PLS direct (various n_components)
    for n_pls in [15, 20, 30]:
        results[f'PLS_direct_n{n_pls}'] = run_experiment(
            label_map, aux_map, f"PLS direct n={n_pls}",
            mode='pls_direct', n_pls=n_pls)

    # A+: LightGBM on PCA features (conservative params)
    lgbm_params_conservative = {
        'n_estimators': 100, 'max_depth': 3, 'learning_rate': 0.05,
        'num_leaves': 7, 'min_child_samples': 5,
        'subsample': 0.7, 'colsample_bytree': 0.7,
        'reg_alpha': 1.0, 'reg_lambda': 5.0,
        'random_state': 42, 'verbose': -1,
    }
    results['LGBM_conservative'] = run_experiment(
        label_map, aux_map, "LightGBM conservative (d3, n100)",
        mode='lgbm', lgbm_params=lgbm_params_conservative)

    # A+: LightGBM slightly deeper
    lgbm_params_medium = {
        'n_estimators': 150, 'max_depth': 4, 'learning_rate': 0.05,
        'num_leaves': 11, 'min_child_samples': 5,
        'subsample': 0.7, 'colsample_bytree': 0.7,
        'reg_alpha': 1.0, 'reg_lambda': 5.0,
        'random_state': 42, 'verbose': -1,
    }
    results['LGBM_medium'] = run_experiment(
        label_map, aux_map, "LightGBM medium (d4, n150)",
        mode='lgbm', lgbm_params=lgbm_params_medium)

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY (GK / TE)")
    print(f"{'='*70}")
    base_gk, base_te = results['V28']
    print(f"  {'config':28s}  {'GK':>8s}  {'TE':>8s}  {'dGK':>7s}  {'dTE':>7s}")
    for name, (gk, te) in results.items():
        print(f"  {name:28s}  {gk:8.2f}  {te:8.2f}  {gk-base_gk:+7.2f}  {te-base_te:+7.2f}")


if __name__ == "__main__":
    main()
