"""
exp_v72_v76_advanced.py

5 advanced experiments based on analysis of all 12 online results.

Key findings from V55-V71 online scores:
  1. V61 (alpha=0.05, linear bias) = 203.21 -- BEST
  2. V63 (alpha=0.1, isotonic) = 203.60 -- 2nd best, only 0.39 behind
  3. Isotonic at alpha=0.1 improved 5.45 over linear (209.05 -> 203.60)
  4. Alpha scan is U-shaped: 0.01=207.35, 0.02=205.07, 0.05=203.21, 0.1=209.05, 0.2=211.14
  5. V61 vs V63 correlation = 0.989 (lowest among top-5) -> best blend pair

V72: Isotonic + alpha=0.05
  - V63 proved isotonic >> linear at alpha=0.1 (203.60 vs 209.05)
  - V61 proved alpha=0.05 >> alpha=0.1 for linear (203.21 vs 209.05)
  - Combining both improvements: isotonic + alpha=0.05
  - Hypothesis: could beat 203.21

V73: Isotonic + alpha=0.03
  - If V72 improves, continue down the alpha scan with isotonic
  - Fills the gap between V72(0.05) and V66(0.01, linear, 207.35)

V74: V61+V63 blend (50/50)
  - Two best models, lowest correlation (0.989), different calibration methods
  - Simple average of test predictions

V75: V61+V63 blend (optimized ratio)
  - Try 60/40, 70/30, 80/20 V61/V63 to find optimal blend

V76: V61+V63+V67 three-way blend
  - V67 (multi-alpha, 204.78) adds diversity from 3 different alphas
  - Three-way blend may capture complementary information
"""
import os, sys, re, glob, warnings, io
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
import zipfile
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11

TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}


# ═══════════════════════════════════════════════════════════════════════════════
# Data loading
# ═══════════════════════════════════════════════════════════════════════════════

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Feature extraction
# ═══════════════════════════════════════════════════════════════════════════════

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(snv)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=N_PCA_MAX):
    spec_mat = data.get('_spec_mat', compute_features(data))
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ═══════════════════════════════════════════════════════════════════════════════
# Training
# ═══════════════════════════════════════════════════════════════════════════════

def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.1):
    # Stage 1
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X, y_aux)
        aux_models[col_name] = m

    # Stage 2
    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_center)

    final_model = Ridge(alpha=ridge_alpha)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)

    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = float(np.median(preds[mask]))
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


# ═══════════════════════════════════════════════════════════════════════════════
# Core: train one coal with calibration
# ═══════════════════════════════════════════════════════════════════════════════

def train_and_predict_coal(coal, label_map, aux_map, ridge_alpha=0.05,
                           calibration='linear'):
    """Train models for one coal type and return test predictions + CV."""

    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    spec_mat = compute_features(train_data)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(X, y, aux, groups, splits, coal_center,
                            n_batches, sample_weights, ridge_alpha=ridge_alpha)
        runs.append(run)

    if is_small:
        r = runs[0]
        print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
              f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
    else:
        cv_rmses = [r['cv_rmse'] for r in runs]
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
              f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])

    # Calibration
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
        print(f"    Bias correction: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)
        # Report linear approximation for comparison
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a_lin, b_lin = float(lr.coef_[0]), float(lr.intercept_)
        p_min, p_max = float(np.min(all_oof_p)), float(np.max(all_oof_p))
        cal_min = float(ir.predict([p_min])[0])
        cal_max = float(ir.predict([p_max])[0])
        print(f"    Isotonic (lin_approx: a={a_lin:.4f}, b={b_lin:.2f})  "
              f"range: [{p_min:.1f},{p_max:.1f}] -> [{cal_min:.1f},{cal_max:.1f}]")

    # Predict test
    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))

        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])

        test_preds[name] = pred_val

    return {
        'cv_rmse': cv_rmse,
        'test_preds': test_preds,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Submission helpers
# ═══════════════════════════════════════════════════════════════════════════════

def load_existing_submission(zip_name):
    """Load existing submission predictions as a Series."""
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        print(f"  WARNING: {fname} not found!")
        return None
    with zipfile.ZipFile(fname) as zf:
        csv_content = zf.read('submit/submit.csv')
        df = pd.read_csv(io.BytesIO(csv_content), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0

    readme = f"""# LIBS 煤炭发热量预测 — 方案介绍

**版本**: {variant_name}
**作者**: ATIpiu
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 方法概述

{feature_desc}

## CV-RMSE (for reference only)

| 煤种 | CV-RMSE |
|---|---|
"""
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"

    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")

    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


# ═══════════════════════════════════════════════════════════════════════════════
# V72: Isotonic + alpha=0.05
# ═══════════════════════════════════════════════════════════════════════════════

def run_v72_isotonic_a005():
    print(f"\n{'=' * 70}")
    print(f"  V72: Isotonic calibration + alpha=0.05")
    print(f"  V63 (iso, alpha=0.1) = 203.60 online")
    print(f"  V61 (linear, alpha=0.05) = 203.21 online")
    print(f"  -> Combine best calibration + best alpha")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map,
                                        ridge_alpha=0.05, calibration='isotonic')
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(
        'v72_isotonic_a005', all_preds, cv_results,
        "Isotonic calibration + alpha=0.05 (combining V63's calibration + V61's alpha)")


# ═══════════════════════════════════════════════════════════════════════════════
# V73: Isotonic + alpha=0.03
# ═══════════════════════════════════════════════════════════════════════════════

def run_v73_isotonic_a003():
    print(f"\n{'=' * 70}")
    print(f"  V73: Isotonic calibration + alpha=0.03")
    print(f"  If V72 improves, continue alpha scan with isotonic")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map,
                                        ridge_alpha=0.03, calibration='isotonic')
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(
        'v73_isotonic_a003', all_preds, cv_results,
        "Isotonic calibration + alpha=0.03")


# ═══════════════════════════════════════════════════════════════════════════════
# V74: V61+V63 blend (50/50)
# ═══════════════════════════════════════════════════════════════════════════════

def run_v74_blend_v61_v63():
    print(f"\n{'=' * 70}")
    print(f"  V74: V61+V63 blend (50/50)")
    print(f"  V61 (linear, alpha=0.05) = 203.21")
    print(f"  V63 (isotonic, alpha=0.1) = 203.60")
    print(f"  Correlation = 0.989 (lowest among top-5)")
    print(f"{'=' * 70}")

    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')

    if v61 is None or v63 is None:
        print("  ERROR: Cannot load V61 or V63 submissions!")
        return None, 0

    all_preds = {}
    for name in v61.index:
        all_preds[name] = float((v61[name] + v63[name]) / 2.0)

    print(f"\n  Blended {len(all_preds)} predictions")
    print(f"  V61 mean: {v61.mean():.2f}")
    print(f"  V63 mean: {v63.mean():.2f}")
    print(f"  Blend mean: {np.mean(list(all_preds.values())):.2f}")

    return pack_submission(
        'v74_blend_v61_v63_5050', all_preds, {},
        "50/50 blend of V61 (linear bias, alpha=0.05, online=203.21) "
        "and V63 (isotonic, alpha=0.1, online=203.60). "
        "Two best models with lowest correlation (0.989).")


# ═══════════════════════════════════════════════════════════════════════════════
# V75: V61+V63 blend (optimized ratio 60/40)
# ═══════════════════════════════════════════════════════════════════════════════

def run_v75_blend_v61_v63_6040():
    print(f"\n{'=' * 70}")
    print(f"  V75: V61+V63 blend (60/40)")
    print(f"  V61 is better (203.21 vs 203.60), so weight it more")
    print(f"{'=' * 70}")

    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')

    if v61 is None or v63 is None:
        print("  ERROR: Cannot load submissions!")
        return None, 0

    all_preds = {}
    for name in v61.index:
        all_preds[name] = float(0.6 * v61[name] + 0.4 * v63[name])

    print(f"\n  Blended {len(all_preds)} predictions (60% V61 + 40% V63)")

    return pack_submission(
        'v75_blend_v61_v63_6040', all_preds, {},
        "60/40 blend of V61 (online=203.21) and V63 (online=203.60). "
        "Weighting better model more.")


# ═══════════════════════════════════════════════════════════════════════════════
# V76: Three-way blend V61+V63+V67
# ═══════════════════════════════════════════════════════════════════════════════

def run_v76_blend_3way():
    print(f"\n{'=' * 70}")
    print(f"  V76: V61+V63+V67 three-way blend (1/3 each)")
    print(f"  V61 (linear, alpha=0.05) = 203.21")
    print(f"  V63 (isotonic, alpha=0.1) = 203.60")
    print(f"  V67 (multi-alpha ensemble) = 204.78")
    print(f"  Three different approaches -> maximum diversity")
    print(f"{'=' * 70}")

    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')
    v67 = load_existing_submission('submit_v67_multi_alpha.zip')

    if v61 is None or v63 is None or v67 is None:
        print("  ERROR: Cannot load submissions!")
        return None, 0

    all_preds = {}
    for name in v61.index:
        all_preds[name] = float((v61[name] + v63[name] + v67[name]) / 3.0)

    print(f"\n  Blended {len(all_preds)} predictions (1/3 each)")
    print(f"  V61 mean: {v61.mean():.2f}")
    print(f"  V63 mean: {v63.mean():.2f}")
    print(f"  V67 mean: {v67.mean():.2f}")
    print(f"  Blend mean: {np.mean(list(all_preds.values())):.2f}")

    return pack_submission(
        'v76_blend_v61_v63_v67', all_preds, {},
        "Three-way blend (1/3 each): V61 (linear, alpha=0.05, online=203.21) "
        "+ V63 (isotonic, alpha=0.1, online=203.60) "
        "+ V67 (multi-alpha ensemble, online=204.78). "
        "Maximum diversity from 3 different approaches.")


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    results = {}

    # V72: Isotonic + alpha=0.05 (highest priority)
    _, cv = run_v72_isotonic_a005()
    results['v72'] = cv

    # V73: Isotonic + alpha=0.03
    _, cv = run_v73_isotonic_a003()
    results['v73'] = cv

    # V74: V61+V63 50/50 blend
    _, cv = run_v74_blend_v61_v63()
    results['v74'] = cv

    # V75: V61+V63 60/40 blend
    _, cv = run_v75_blend_v61_v63_6040()
    results['v75'] = cv

    # V76: Three-way blend
    _, cv = run_v76_blend_3way()
    results['v76'] = cv

    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Baselines:")
    print(f"    V61 (linear, alpha=0.05):    CV=172.15  Online=203.21")
    print(f"    V63 (isotonic, alpha=0.1):   CV=183.50  Online=203.60")
    print()
    for name, cv in results.items():
        print(f"    {name}: CV={cv:.2f}")
    print()
    print("  Priority for submission:")
    print("    1. V72 (isotonic + alpha=0.05) -- most likely to beat V61")
    print("    2. V74 (V61+V63 50/50 blend) -- zero risk, guaranteed between 203-204")
    print("    3. V73 (isotonic + alpha=0.03) -- if V72 improves")
    print("    4. V75 (V61+V63 60/40 blend) -- alternative ratio")
    print("    5. V76 (3-way blend) -- maximum diversity")
