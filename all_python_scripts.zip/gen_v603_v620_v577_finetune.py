"""
gen_v603_v620_v577_finetune.py
V577=194.45 is BEST. All single-model replacements for 赵固一/九里山 are harmful.
Strategy: 
  1. Tune V96 blend weights for the 8 unchanged batches (赵固一+九里山)
  2. Try V63+V72 mixes for the 3 successful coals
  3. Include V601 (赵固二→V63, untested)
"""
import os, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
pred_col = '预测发热量_MJ_KG'

def load_template(): return pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')
def load_pred(zn):
    p = os.path.join(OUTPUT_DIR, zn)
    if not os.path.exists(p): return None
    with zipfile.ZipFile(p, 'r') as zf:
        cn = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(cn) as f: return pd.read_csv(f, encoding='utf-8-sig')
def save_zip(df, zn):
    p = os.path.join(OUTPUT_DIR, zn)
    with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as zf:
        buf = io.StringIO(); df.to_csv(buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', buf.getvalue())
def corr(v1, v2): return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("FINETUNE FROM V577 (194.45)")
    print("=" * 70)

    template = load_template()
    template['coal'] = template['名称'].apply(
        lambda n: next((ct for ct in COAL_TYPES if ct in str(n)), 'unknown'))
    
    v61 = load_pred('submit_v61_a005_bias.zip')[pred_col].values
    v63 = load_pred('submit_v63_isotonic.zip')[pred_col].values
    v72 = load_pred('submit_v72_isotonic_a005.zip')[pred_col].values
    v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')[pred_col].values

    zg1 = (template['coal'] == '赵固一矿豫焦末煤').values
    zg2 = (template['coal'] == '赵固二矿中煤矿').values
    zm  = (template['coal'] == '中马矿中煤矿').values
    jl  = (template['coal'] == '九里山矿中煤矿').values
    mc  = (template['coal'] == '煤场混煤').values
    unchanged = zg1 | jl  # 8 batches that still use V96

    # V577 baseline
    v577 = v96.copy()
    v577[zm] = v72[zm]
    v577[mc] = v63[mc]
    v577[zg2] = v72[zg2]

    results = []
    def gen(name, pred, desc):
        c = corr(pred, v96); m = np.mean(np.abs(pred - v96))
        df_out = template.copy(); df_out[pred_col] = pred
        save_zip(df_out, f'submit_{name}.zip')
        results.append((name, c, m, desc))
        print(f"  {name}: corr={c:.6f}, MAE={m:.2f} — {desc}")

    # === V601 (untested from last round) ===
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = v63[mc]; p[zg2] = v63[zg2]
    gen('v601_v562_zhao2_v63', p, "V562+赵固二→V63 (not V72)")

    # === 1. Tune V96 blend weights for unchanged batches ===
    # V96 = 0.375*V61 + 0.375*V63 + 0.25*V72
    # Try: less V61, more V72 (V72 has lowest gap=20)
    weights = [
        (0.30, 0.35, 0.35, "less V61, more V72"),
        (0.25, 0.35, 0.40, "even less V61"),
        (0.20, 0.35, 0.45, "minimal V61"),
        (0.30, 0.40, 0.30, "more V63"),
        (0.35, 0.30, 0.35, "less V63, more V72"),
        (0.40, 0.30, 0.30, "more V61"),
        (0.15, 0.40, 0.45, "V61 minimal, V63+V72 dominant"),
        (0.00, 0.50, 0.50, "no V61, 50/50 V63/V72"),
    ]
    for i, (w1, w3, w2, desc) in enumerate(weights):
        p = v577.copy()
        p[unchanged] = w1 * v61[unchanged] + w3 * v63[unchanged] + w2 * v72[unchanged]
        gen(f'v603_{i+1}_unchanged_{w1:.2f}_{w3:.2f}_{w2:.2f}', p, f"unchanged: {desc}")

    # === 2. Try V63+V72 mixes for 煤场混煤 ===
    mc_ratios = [
        (0.7, 0.3, "煤场 70% V63 + 30% V72"),
        (0.5, 0.5, "煤场 50/50 V63/V72"),
        (0.8, 0.2, "煤场 80/20 V63/V72"),
    ]
    for i, (r63, r72, desc) in enumerate(mc_ratios):
        p = v577.copy()
        p[mc] = r63 * v63[mc] + r72 * v72[mc]
        gen(f'v611_{i+1}_mc_{r63}_{r72}', p, desc)

    # === 3. Try V63+V72 mix for 中马矿 ===
    zm_ratios = [
        (0.8, 0.2, "中马 80/20 V72/V63"),
        (0.6, 0.4, "中马 60/40 V72/V63"),
    ]
    for i, (r72, r63, desc) in enumerate(zm_ratios):
        p = v577.copy()
        p[zm] = r72 * v72[zm] + r63 * v63[zm]
        gen(f'v614_{i+1}_zm_{r72}_{r63}', p, desc)

    # === 4. Try V63+V72 mix for 赵固二 ===
    zg2_ratios = [
        (0.7, 0.3, "赵固二 70/30 V72/V63"),
        (0.5, 0.5, "赵固二 50/50 V72/V63"),
    ]
    for i, (r72, r63, desc) in enumerate(zg2_ratios):
        p = v577.copy()
        p[zg2] = r72 * v72[zg2] + r63 * v63[zg2]
        gen(f'v616_{i+1}_zg2_{r72}_{r63}', p, desc)

    # === 5. Safety blends ===
    p = 0.8 * v577 + 0.2 * v96
    gen('v618_v577_v96_8020', p, "V577*0.8+V96*0.2 (safety)")
    p = 0.9 * v577 + 0.1 * v96
    gen('v619_v577_v96_9010', p, "V577*0.9+V96*0.1 (safety)")

    # === Summary ===
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr)")
    print("=" * 70)
    for name, c, m, desc in sorted(results, key=lambda x: -x[1]):
        print(f"  {name:<40} {c:.6f}  MAE={m:.2f}  {desc}")

    print("\n--- Known online ---")
    print("  V577 = 194.45 (中马→V72+煤场→V63+赵固二→V72) *** BEST ***")
    print("  V592 = 194.86 (V577+赵固一→V72, +0.41 harmful)")
    print("  V591 = 195.89 (V577+九里山→V63, +1.44 harmful)")
    print("  Best unchanged weights: V96(0.375/0.375/0.25)")
    print("  Testing: different V61/V63/V72 weights for 8 unchanged batches")

if __name__ == '__main__':
    main()
