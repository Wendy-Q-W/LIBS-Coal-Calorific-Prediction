"""
V14 实验脚本: 测试各改进方向对 CV-RMSE 的影响
方向1: 批次内异常光谱剔除（余弦相似度）
方向2: SG平滑 + SNV变换
方向3: 增加化学计量比特征
"""

import os, sys, glob, warnings, copy
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.signal import savgol_filter
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from all import (
    read_spectrum_csv, load_labels, load_coal_spectra,
    COAL_TYPES, TRAIN_DIR, TEST_DIR, AUX_COLS, KEY_LINES,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    N_ENSEMBLE_SEEDS, ENSEMBLE_SEEDS,
    line_integral, spectrum_features, compute_features,
    build_feature_matrix, get_cv_splits, aggregate_to_batch,
    find_best_shrinkage, _train_one_run, train_coal_model,
)

# ── 方向1: 批次内异常光谱剔除 ──────────────────────────────────────────────────

def cosine_similarity_matrix(mat):
    """计算矩阵各行间的余弦相似度。"""
    norms = np.linalg.norm(mat, axis=1, keepdims=True) + 1e-8
    normalized = mat / norms
    return normalized @ normalized.T


def remove_outlier_spectra(data, threshold=0.85):
    """
    对每个批次内，用余弦相似度剔除离群光谱。
    计算每条光谱与批次内其他光谱的平均相似度，低于 threshold 的剔除。
    """
    raw_spectra = data['spectra']
    names = data['names']
    targets = data['targets']
    aux = data['aux']
    groups = data['groups']

    # 把光谱转为等长向量（用归一化强度）
    inorms = []
    for wl, inten in raw_spectra:
        total = inten.sum() + 1e-8
        inorms.append(inten / total)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)

    keep_indices = []
    unique_batches = list(dict.fromkeys(names))  # 保持顺序

    for batch_name in unique_batches:
        batch_mask = np.array([n == batch_name for n in names])
        batch_idx = np.where(batch_mask)[0]

        if len(batch_idx) <= 2:
            # 批次内光谱太少，不剔除
            keep_indices.extend(batch_idx)
            continue

        batch_mat = inorm_mat[batch_idx]
        sim_matrix = cosine_similarity_matrix(batch_mat)
        # 每条光谱与批次内其他光谱的平均相似度
        np.fill_diagonal(sim_matrix, 0)
        avg_sim = sim_matrix.sum(axis=1) / (len(batch_idx) - 1)

        kept = batch_idx[avg_sim >= threshold]
        if len(kept) == 0:
            # 全部低于阈值，保留最相似的
            kept = batch_idx[avg_sim >= avg_sim.mean()]

        keep_indices.extend(kept.tolist())

    keep_indices = sorted(keep_indices)
    print(f"  异常剔除: {len(raw_spectra)} → {len(keep_indices)} 条 "
          f"(剔除 {len(raw_spectra) - len(keep_indices)} 条, threshold={threshold})")

    # 重新映射 groups，使其连续从0开始
    kept_names = [names[i] for i in keep_indices]
    name_to_group = {}
    g = 0
    for n in kept_names:
        if n not in name_to_group:
            name_to_group[n] = g
            g += 1
    new_groups = np.array([name_to_group[n] for n in kept_names])

    new_data = {
        'spectra':   [raw_spectra[i] for i in keep_indices],
        'names':     kept_names,
        'targets':   targets[keep_indices] if targets is not None else None,
        'aux':       aux[keep_indices] if aux is not None else None,
        'groups':    new_groups,
        'n_batches': len(name_to_group),
    }
    return new_data


def _remap_groups(names, keep_indices, pos_in_keep):
    """重新映射 groups，使其连续从0开始。"""
    original_name = names[keep_indices[pos_in_keep]]
    # 简单方案：用名称的首次出现顺序映射
    seen = {}
    g = 0
    for i in keep_indices:
        n = names[i]
        if n not in seen:
            seen[n] = g
            g += 1
    return seen[original_name]


# ── 方向2: SG平滑 + SNV ─────────────────────────────────────────────────────────

def spectrum_features_v14(wl, inten, use_sg=True, use_snv=True):
    """增强版特征提取: SG平滑 + SNV + 更多化学计量比。"""
    total = inten.sum() + 1e-8
    inten_norm = inten / total

    # SNV (Standard Normal Variate): 去均值/标准差
    if use_snv:
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
    else:
        snv = inten_norm.copy()

    # SG平滑
    if use_sg:
        n = len(inten_norm)
        # window_length 必须为奇数且 < 数据长度
        wl_size = min(11, n if n % 2 == 1 else n - 1)
        if wl_size >= 5:
            inten_smooth = savgol_filter(inten_norm, window_length=wl_size, polyorder=2)
            inten_deriv1 = savgol_filter(inten_norm, window_length=wl_size, polyorder=2, deriv=1)
        else:
            inten_smooth = inten_norm
            inten_deriv1 = np.diff(inten_norm, prepend=0)
    else:
        inten_smooth = inten_norm
        inten_deriv1 = np.diff(inten_norm, prepend=0)

    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)

    # 原始17维统计 + SG导数3维
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)),
        float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
        # SG导数特征
        float(inten_deriv1.mean()),
        float(inten_deriv1.std()),
        float(np.max(inten_deriv1) - np.min(inten_deriv1)),
        # SNV统计
        float(snv.mean()),
        float(snv.std()),
    ], dtype=np.float32)

    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32
    )
    lrel = labs / total

    # 化学计量比（更多组合）
    C, H, O, N = labs[0], labs[1], labs[2], labs[3]
    Ca, Ca2, Mg, Al, Si, Fe, Na = labs[4], labs[5], labs[6], labs[7], labs[8], labs[9], labs[10]
    ash_sum = Ca + Ca2 + Mg + Al + Si + Fe + 1e-8
    comb_sum = C + H + O + N

    rats = np.array([
        comb_sum / ash_sum,
        H / ash_sum,
        C / ash_sum,
        H / (C + 1e-8),
        C / (O + 1e-8),       # C/O 比
        H / (O + 1e-8),       # H/O 比
        C / (N + 1e-8),       # C/N 比
        (C + H) / (O + N + 1e-8),  # 可燃/含氧氮
        Na / ash_sum,         # Na/灰分
        Fe / (Ca + 1e-8),     # Fe/Ca
        Si / (Al + 1e-8),     # Si/Al
    ], dtype=np.float32)

    return inten_norm, stats, labs, lrel, rats


def compute_features_v14(data, use_sg=True, use_snv=True):
    """V14批量特征计算。"""
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []

    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features_v14(wl, inten, use_sg, use_snv)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)

    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)

    data['stats'] = np.array(stats_list)
    data['labs']  = np.array(labs_list)
    data['lrel']  = np.array(lrel_list)
    data['rats']  = np.array(rats_list)

    return inorm_mat


def build_feature_matrix_v14(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None, fit=True,
                              use_sg=True, use_snv=True):
    """V14特征矩阵构建。"""
    inorm_mat = compute_features_v14(data, use_sg, use_snv)

    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ── V14 训练函数 ────────────────────────────────────────────────────────────────

def train_coal_model_v14(coal_type, train_data, use_outlier_removal=True,
                          use_sg=True, use_snv=True, outlier_threshold=0.85):
    """V14训练: 异常剔除 + SG/SNV + 更多特征 + Ridge两阶段。"""
    data = copy.deepcopy(train_data)

    if use_outlier_removal:
        data = remove_outlier_spectra(data, threshold=outlier_threshold)

    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())

    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix_v14(
        data, n_batches, fit=True, use_sg=use_sg, use_snv=use_snv)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches)
        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条光谱  (LOOCV)")
        print(f"    CV-RMSE: raw={run['cv_rmse_raw']:.2f}  shrunk={run['cv_rmse']:.2f}  w={run['shrink_w']:.2f}")
        return {'cv_rmse': run['cv_rmse'], 'cv_rmse_raw': run['cv_rmse_raw'], 'shrink_w': run['shrink_w']}
    else:
        runs, cv_rmses = [], []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run(X_spec, y, aux, groups, splits, coal_mean, n_batches)
            runs.append(run)
            cv_rmses.append(run['cv_rmse'])

        cv_mean = float(np.mean(cv_rmses))
        cv_std = float(np.std(cv_rmses))
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条光谱  ({N_ENSEMBLE_SEEDS}种子)")
        print(f"    CV-RMSE: {cv_mean:.2f} ± {cv_std:.2f}  w={avg_w:.2f}")
        return {'cv_rmse': cv_mean, 'shrink_w': avg_w}


# ── 主实验 ──────────────────────────────────────────────────────────────────────

def run_experiment(name, **kwargs):
    print(f"\n{'='*60}")
    print(f"实验: {name}")
    print(f"{'='*60}")

    label_map, aux_map = load_labels()
    cv_results = {}

    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None or train_data['n_batches'] == 0:
            continue
        result = train_coal_model_v14(coal_type, train_data, **kwargs)
        cv_results[coal_type] = result['cv_rmse']

    global_cv = float(np.mean(list(cv_results.values())))
    print(f"\n{'='*60}")
    print(f"{name} 全局 CV-RMSE: {global_cv:.2f}")
    print(f"  各煤种: {cv_results}")
    return global_cv


if __name__ == "__main__":
    # V13 基线
    print("="*60)
    print("V13 基线 (已知 CV=170.62)")
    print("="*60)

    # 实验1: 仅异常剔除
    cv1 = run_experiment("仅异常剔除(threshold=0.85)", use_outlier_removal=True, use_sg=False, use_snv=False)

    # 实验2: 仅SG+SNV
    cv2 = run_experiment("仅SG+SNV特征", use_outlier_removal=False, use_sg=True, use_snv=True)

    # 实验3: 仅更多化学计量比（不用SG/SNV）
    cv3 = run_experiment("仅更多比值特征", use_outlier_removal=False, use_sg=False, use_snv=False)

    # 实验4: 全部组合
    cv4 = run_experiment("异常剔除+SG+SNV+更多比值", use_outlier_removal=True, use_sg=True, use_snv=True)

    # 实验5: 不同异常阈值
    cv5 = run_experiment("异常剔除(threshold=0.75)+SG+SNV", use_outlier_removal=True, use_sg=True, use_snv=True, outlier_threshold=0.75)

    print(f"\n{'='*60}")
    print("实验结果汇总")
    print(f"{'='*60}")
    print(f"  V13 基线:                   170.62")
    print(f"  仅异常剔除(0.85):            {cv1:.2f}")
    print(f"  仅SG+SNV:                    {cv2:.2f}")
    print(f"  仅更多比值:                  {cv3:.2f}")
    print(f"  异常剔除+SG+SNV+更多比值:    {cv4:.2f}")
    print(f"  异常剔除(0.75)+SG+SNV:       {cv5:.2f}")
