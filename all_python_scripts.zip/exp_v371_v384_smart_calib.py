"""
exp_v371_v384_smart_calib.py
Test smart calibration methods designed to minimize gap while keeping low CV.
Key insight: linear has low CV+high gap(31), isotonic has high CV+low gap(20).
Goal: find calibration with low CV+low gap.
- clip_linear: linear but clamped to OOF range (no extrapolation)
- ridge_hi: ridge alpha=100 (very gentle calibration, slope≈1)
- huber_calib: robust to OOF outliers
- clip_linear_iso: isotonic inside OOF range, linear outside
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp_v260_v270_tree_models import (
    run_experiment, pack_submission, OUTPUT_DIR
)

if __name__ == '__main__':
    experiments = [
        # a=0.05 (same as V61) with smart calibrations
        ('v371_a005_clip_linear', 0.05, 'clip_linear',
         'Ridge a=0.05 + clipped linear calibration. Linear but clamped to OOF range to prevent extrapolation.'),
        ('v372_a005_ridge_hi', 0.05, 'ridge_hi',
         'Ridge a=0.05 + ridge calibration alpha=100. Very gentle, slope near 1.'),
        ('v373_a005_huber', 0.05, 'huber_calib',
         'Ridge a=0.05 + Huber calibration. Robust to OOF outliers.'),
        ('v374_a005_clip_iso', 0.05, 'clip_linear_iso',
         'Ridge a=0.05 + isotonic inside OOF range, linear outside. Best of both worlds.'),

        # a=0.1 (same as V63) with smart calibrations
        ('v375_a01_clip_linear', 0.1, 'clip_linear',
         'Ridge a=0.1 + clipped linear calibration.'),
        ('v376_a01_ridge_hi', 0.1, 'ridge_hi',
         'Ridge a=0.1 + ridge calibration alpha=100.'),
        ('v377_a01_huber', 0.1, 'huber_calib',
         'Ridge a=0.1 + Huber calibration.'),
        ('v378_a01_clip_iso', 0.1, 'clip_linear_iso',
         'Ridge a=0.1 + isotonic inside OOF range, linear outside.'),

        # a=0.07 (between V61 and V63) with best smart calibrations
        ('v379_a007_clip_linear', 0.07, 'clip_linear',
         'Ridge a=0.07 + clipped linear. Intermediate alpha.'),
        ('v380_a007_clip_iso', 0.07, 'clip_linear_iso',
         'Ridge a=0.07 + isotonic in-range, linear out. Intermediate alpha.'),
        ('v381_a007_huber', 0.07, 'huber_calib',
         'Ridge a=0.07 + Huber calibration. Intermediate alpha.'),

        # a=0.05 with isotonic variants (for comparison)
        ('v382_a005_iso_clip', 0.05, 'isotonic',
         'Ridge a=0.05 + isotonic (reference, same as V72).'),
    ]

    results = {}
    for vid, alpha, calib, desc in experiments:
        _, cv = run_experiment(
            vid, desc,
            ridge_alpha=alpha,
            calibration=calib,
            preprocessing='snv',
            use_pca=True,
        )
        results[vid] = cv
        print(f"  CV={cv:.2f}")

    print(f"\n{'='*70}")
    print("  SUMMARY")
    print(f"{'='*70}")
    for vid, cv in results.items():
        print(f"  {vid:30s}  CV={cv:.2f}")
