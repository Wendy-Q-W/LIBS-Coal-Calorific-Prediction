"""
gen_v526_v535_blends.py
Blend V96 with the most promising uncertainty-adjusted variants.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")

def load_pred(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]

def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip

def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_pred(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)

if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'

    # Uncertainty-adjusted variants
    V510_s70 = 'submit_v510_adjK2_s70.zip'     # K=2 shrink 70%, corr=0.9997
    V510_s50 = 'submit_v510_adjK2_s50.zip'     # K=2 shrink 50%, corr=0.9993
    V511_s70 = 'submit_v511_adjK3_s70.zip'     # K=3 shrink 70%, corr=0.9995
    V511_s50 = 'submit_v511_adjK3_s50.zip'     # K=3 shrink 50%, corr=0.9987
    V523_rplV72 = 'submit_v523_rplV72_K3.zip'  # K=3 replace V72, corr=0.9994

    # Batch_mean candidates
    V470 = 'submit_v470_blend_v469_v72_7525.zip'
    V506 = 'submit_v506_v96bm_v96_5050.zip'

    v96 = load_pred(V96)
    v96_arr = np.array(v96.values)

    blends = [
        # V96 + uncertainty adjustment blends (very high corr)
        ('v526_v96_v510s70_9010', [(V96, 0.9), (V510_s70, 0.1)],
         "V96(90%) + V510_adjK2_s70(10%). Minimal uncertainty adjustment."),
        ('v527_v96_v510s70_8020', [(V96, 0.8), (V510_s70, 0.2)],
         "V96(80%) + V510_adjK2_s70(20%)."),
        ('v528_v96_v523rpl_9010', [(V96, 0.9), (V523_rplV72, 0.1)],
         "V96(90%) + V523_rplV72_K3(10%). V72 replacement blend."),
        ('v529_v96_v523rpl_8020', [(V96, 0.8), (V523_rplV72, 0.2)],
         "V96(80%) + V523_rplV72_K3(20%)."),
        ('v530_v96_v511s70_9010', [(V96, 0.9), (V511_s70, 0.1)],
         "V96(90%) + V511_adjK3_s70(10%). K=3 adjustment blend."),
        ('v531_v96_v511s70_8020', [(V96, 0.8), (V511_s70, 0.2)],
         "V96(80%) + V511_adjK3_s70(20%)."),

        # V189 + uncertainty adjustment
        ('v532_v189_v523rpl_9010', [(V189, 0.9), (V523_rplV72, 0.1)],
         "V189(90%) + V523_rplV72(10%). Current best + V72 replacement."),

        # V96 + V470 (batch_mean + uncertainty)
        ('v533_v96_v470_9010', [(V96, 0.9), (V470, 0.1)],
         "V96(90%) + V470_bmean(10%). Inject batch_mean."),
        ('v534_v96_v470_8020', [(V96, 0.8), (V470, 0.2)],
         "V96(80%) + V470_bmean(20%)."),

        # V523 + V470 (uncertainty + batch_mean)
        ('v535_v523_v470_5050', [(V523_rplV72, 0.5), (V470, 0.5)],
         "V523_rplV72(50%) + V470_bmean(50%). Uncertainty + batch_mean."),
    ]

    print(f"{'='*70}")
    print("  BLEND GENERATION")
    print(f"{'='*70}")

    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)

    # Correlation summary
    print(f"\n{'='*70}")
    print("  CORRELATION SUMMARY")
    print(f"{'='*70}")

    all_ids = ['v526', 'v527', 'v528', 'v529', 'v530', 'v531',
               'v532', 'v533', 'v534', 'v535']

    # Also show standalone candidates
    standalone = [
        ('V96 (baseline)', V96),
        ('V510_adjK2_s70', V510_s70),
        ('V511_adjK3_s70', V511_s70),
        ('V523_rplV72_K3', V523_rplV72),
        ('V470_bmean', V470),
        ('V506_v96bm_v96', V506),
    ]

    print(f"  {'Standalone':35s} {'corr(V96)':>10s} {'MAE':>8s}")
    print("  " + "-" * 55)
    for label, fname in standalone:
        sub = load_pred(fname)
        if sub is None:
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:35s} {corr:10.6f} {mae:8.2f}")

    print(f"\n  {'Blends':35s} {'corr(V96)':>10s} {'MAE':>8s}")
    print("  " + "-" * 55)
    for vid in all_ids:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_pred(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f[7:-4]:35s} {corr:10.6f} {mae:8.2f}")
                break

    print("\n  Done.")
