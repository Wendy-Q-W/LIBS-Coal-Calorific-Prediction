"""
exp_v53_robust_median.py

V53: RobustScaler replacing StandardScaler everywhere
     - StandardScaler uses mean/std, sensitive to outlier spikes in LIBS spectra
     - RobustScaler uses median/IQR, more stable under distribution shift
     - Theory: if test spectra have different noise characteristics (laser energy drift),
       RobustScaler preserves feature relationships better than StandardScaler

V54: Median shrinkage target instead of mean
     - V39 shrinks predictions toward coal_mean = y.mean()
     - V54 uses coal_median = np.median(y) instead
     - Theory: median is robust to outlier batches; if test set has shifted Q distribution,
       median center is a safer shrinkage target

V55: Linear bias correction
     - Collect OOF (pred, true) pairs from V39's CV
     - Fit y_true ~ a * y_pred + b via simple linear regression
     - Apply correction to final test predictions
     - Theory: if model has systematic over/underestimation under distribution shift,
       2-parameter correction fixes it with near-zero overfitting risk

V56: RobustScaler + median shrinkage combined (if both V53 and V54 look promising)

All variants use V39's exact architecture: SNV + PCA(30) + hand features(43) +
two-stage Ridge(alpha=0.1) + TW(九里山tau=20, 煤场混煤tau=30) + 100-seed ensemble.

CV is anti-correlated with online score, so CV is logged but NOT used for selection.
All variants generate submission zips for leaderboard blind testing.
"""
import os, sys, re, glob, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
import zipfile
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
RIDGE_ALPHA = 0.1
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11

TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}


# ═══════════════════════════════════════════════════════════════════════════════
# Data loading (identical to all_snv.py)
# ═══════════════════════════════════════════════════════════════════════════════

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Feature extraction (V39: SNV for PCA, total norm for hand)
# ═══════════════════════════════════════════════════════════════════════════════

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
        spec_mats.append(snv)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, use_robust=False):
    """Build feature matrix. If use_robust=True, use RobustScaler instead of StandardScaler."""
    inorm_mat = compute_features(data)

    ScalerClass = RobustScaler if use_robust else StandardScaler
    scaler_kwargs = {'quantile_range': (25.0, 75.0)} if use_robust else {}

    if fit:
        scaler_spec = ScalerClass(**scaler_kwargs)
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = ScalerClass(**scaler_kwargs)
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ═══════════════════════════════════════════════════════════════════════════════
# Training (V39 two-stage, configurable scaler, shrinkage, bias correction)
# ═══════════════════════════════════════════════════════════════════════════════

def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, use_robust=False):
    """Two-stage training with configurable scaler."""
    ScalerClass = RobustScaler if use_robust else StandardScaler
    scaler_kwargs = {'quantile_range': (25.0, 75.0)} if use_robust else {}

    # Stage 1: aux OOF
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None:
            m.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m.fit(X, y_aux)
        aux_models[col_name] = m

    # Stage 2
    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = ScalerClass(**scaler_kwargs)
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_center)

    final_model = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    """Predict test batches for one run."""
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)

    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = float(np.median(preds[mask]))
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


# ═══════════════════════════════════════════════════════════════════════════════
# Variant runner
# ═══════════════════════════════════════════════════════════════════════════════

def run_variant(variant_name, use_robust=False, use_median=False,
                use_bias_correction=False):
    """
    Run a single variant and generate submission.

    Parameters:
        use_robust: If True, use RobustScaler instead of StandardScaler (V53)
        use_median: If True, shrink toward median instead of mean (V54)
        use_bias_correction: If True, apply linear bias correction to predictions (V55)
    """
    print(f"\n{'=' * 70}")
    print(f"  Variant: {variant_name}")
    print(f"  use_robust={use_robust}, use_median={use_median}, "
          f"use_bias_correction={use_bias_correction}")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
        if train_data is None:
            continue

        y = train_data['targets']
        aux = train_data['aux']
        groups = train_data['groups']
        n_batches = train_data['n_batches']

        # V54: median shrinkage target
        if use_median:
            coal_center = float(np.median(y))
        else:
            coal_center = float(y.mean())

        X, scaler_spec, pca, scaler_hand = build_feature_matrix(
            train_data, n_batches, fit=True, use_robust=use_robust)

        is_small = n_batches <= SMALL_BATCH_THRESHOLD

        # Time weights (V39 config)
        sample_weights = None
        if coal in TIME_WEIGHT_TAU:
            tau = TIME_WEIGHT_TAU[coal]
            months = train_data['months']
            if len(months) == len(y):
                sample_weights = compute_time_weights(months, TEST_MONTH, tau)

        seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
        runs = []
        for seed in seeds:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = train_one_run(X, y, aux, groups, splits, coal_center,
                                n_batches, sample_weights, use_robust=use_robust)
            runs.append(run)

        if is_small:
            r = runs[0]
            print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
                  f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
        else:
            cv_rmses = [r['cv_rmse'] for r in runs]
            avg_w = float(np.mean([r['shrink_w'] for r in runs]))
            for r in runs:
                r['shrink_w'] = avg_w
            print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
                  f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

        cv_results[coal] = np.mean([r['cv_rmse'] for r in runs])

        # V55: Bias correction — collect OOF predictions and fit linear correction
        if use_bias_correction:
            # Aggregate OOF across all runs (seeds)
            all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
            all_oof_t = np.concatenate([r['oof_true'] for r in runs])

            # Fit y_true = a * y_pred + b
            lr = LinearRegression()
            lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
            a, b = float(lr.coef_[0]), float(lr.intercept_)

            # Report correction parameters
            pred_mean = float(np.mean(all_oof_p))
            true_mean = float(np.mean(all_oof_t))
            print(f"    Bias correction: a={a:.4f}, b={b:.2f} "
                  f"(pred_mean={pred_mean:.1f}, true_mean={true_mean:.1f})")

        # Predict test
        test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
        if test_data is None:
            continue

        X_test = build_feature_matrix(
            test_data, n_batches=None,
            scaler_spec=scaler_spec, pca=pca,
            scaler_hand=scaler_hand, fit=False, use_robust=use_robust)

        all_batch_preds = []
        for run in runs:
            bp = predict_test(X_test, test_data, run, coal_center)
            all_batch_preds.append(bp)

        # Average across seeds
        batch_names = list(all_batch_preds[0].keys())
        for name in batch_names:
            vals = [bp[name] for bp in all_batch_preds]
            pred_val = float(np.mean(vals))

            # V55: Apply bias correction
            if use_bias_correction:
                pred_val = a * pred_val + b

            all_preds[name] = pred_val
            print(f"    {name}: {all_preds[name]:.2f}")

    global_cv = float(np.mean(list(cv_results.values())))
    print(f"\n  Global CV-RMSE: {global_cv:.2f}")

    # Pack submission
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    # Generate README
    features = []
    if use_robust:
        features.append("RobustScaler (median/IQR) replacing StandardScaler")
    if use_median:
        features.append("Median shrinkage target replacing mean")
    if use_bias_correction:
        features.append("Linear bias correction (a*y_pred + b)")
    feat_str = "; ".join(features) if features else "V39 baseline (no change)"

    readme = f"""# LIBS 煤炭发热量预测 — 方案介绍

**版本**: {variant_name}
**作者**: ATIpiu
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 方法概述

基于 V39 SNV hybrid 基线 (线上 230.06)，调整:
- {feat_str}

## CV-RMSE (CV is anti-correlated with online score, logged for reference only)

| 煤种 | CV-RMSE |
|---|---|
"""
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"

    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")

    print(f"\n  [OK] {out_zip}")
    return out_zip


if __name__ == '__main__':
    # V53: RobustScaler replacing StandardScaler
    run_variant('v53_robust', use_robust=True, use_median=False,
                use_bias_correction=False)

    # V54: Median shrinkage target
    run_variant('v54_median', use_robust=False, use_median=True,
                use_bias_correction=False)

    # V55: Linear bias correction
    run_variant('v55_bias_corr', use_robust=False, use_median=False,
                use_bias_correction=True)

    # V56: RobustScaler + median shrinkage combined
    run_variant('v56_robust_median', use_robust=True, use_median=True,
                use_bias_correction=False)
