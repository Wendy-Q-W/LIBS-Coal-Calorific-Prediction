"""V19b: 窗口宽度深入探索
- win=3.0是V19最强信号，测试更大窗口(4~6)找拐点
- 差异化窗口: 主元素(C/H/O/N)用大窗口, 金属线(Ca/Mg/Al/Si/Fe/Na)用原始
- win=3.0 + PCA(25)组合优化
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    compute_features_custom, build_fm, oof_ridge, gkfold_cv, time_ext, run_config,
    label_map, aux_map, TIME_COALS, make_windowed_lines,
)


def make_diff_windows(main_scale, metal_scale):
    """主元素(C/H/O/N)用main_scale, 金属线用metal_scale"""
    main_keys = ['C_247.96', 'H_656.29', 'O_777.19', 'N_746.83']
    kl = {}
    for k, (c, h) in KEY_LINES.items():
        if k in main_keys:
            kl[k] = (c, h * main_scale)
        else:
            kl[k] = (c, h * metal_scale)
    return kl


if __name__ == "__main__":
    results = {}

    # ── 基线 ──
    results['baseline'] = run_config(
        "基线: PCA(30) + win=1.0",
        n_pca_max=30)

    # ── P1: 更大窗口扫描 ──
    for scale in [3.5, 4.0, 5.0, 6.0]:
        kl = make_windowed_lines(scale)
        results[f'win={scale}'] = run_config(
            f"窗口×{scale}", key_lines=kl)

    # ── P2: 差异化窗口 ──
    # 主元素大窗口, 金属线原始
    for ms in [2.0, 3.0, 4.0]:
        kl = make_diff_windows(ms, 1.0)
        results[f'main={ms},metal=1.0'] = run_config(
            f"主元素×{ms},金属×1.0", key_lines=kl)

    # 主元素大窗口, 金属线也放大
    for ms, mts in [(3.0, 2.0), (4.0, 2.0), (3.0, 1.5)]:
        kl = make_diff_windows(ms, mts)
        results[f'main={ms},metal={mts}'] = run_config(
            f"主元素×{ms},金属×{mts}", key_lines=kl)

    # ── P3: win=3.0 + PCA微调 ──
    kl3 = make_windowed_lines(3.0)
    for npc in [25, 35, 40]:
        results[f'win=3.0+PCA({npc})'] = run_config(
            f"win=3.0+PCA({npc})", n_pca_max=npc, key_lines=kl3)

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V19b: 窗口宽度深入探索")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':25s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:25s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
