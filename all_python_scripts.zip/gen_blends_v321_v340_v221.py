"""
gen_blends_v321_v340_v221.py
V221 (a=0.03, CV=164.28, corr=0.997) is the best untested model.
Generate all V221-based blends and check correlations.
Also generate V64-based blends (V64 = V221 equivalent).
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    V107 = 'submit_v107_blend_v74_v72_8020.zip'
    
    V221 = 'submit_v221_a003_linear.zip'
    V64 = 'submit_v64_a003_bias.zip'
    V166 = 'submit_v166_a003_isotonic.zip'
    V73 = 'submit_v73_isotonic_a003.zip'
    
    # Existing V221 blends
    V234 = 'submit_v234_blend_v96_v221_9010.zip'
    V235 = 'submit_v235_blend_v96_v221_9505.zip'
    V242 = 'submit_v242_blend_v221_v63_5050.zip'
    V240 = 'submit_v240_blend_v96_v221_v218.zip'
    V245 = 'submit_v245_blend_v96_v221_975025.zip'
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS - V221 FAMILY")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V221_a003_linear', V221),
        ('V64_a003_bias', V64),
        ('V166_a003_iso', V166),
        ('V73_iso_a003', V73),
        ('V234_v96_v221_9010', V234),
        ('V235_v96_v221_9505', V235),
        ('V242_v221_v63_5050', V242),
        ('V240_v96_v221_v218', V240),
        ('V245_v96_v221_975025', V245),
        ('V61_a005', V61),
        ('V63_iso', V63),
        ('V72_iso_a005', V72),
        ('V74_blend', V74),
    ]
    
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:30s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:30s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Also check V221 vs V61 (same pipeline, different alpha)
    v221 = load_existing_submission(V221)
    v61 = load_existing_submission(V61)
    if v221 is not None and v61 is not None:
        corr = np.corrcoef(np.array(v221.values), np.array(v61.values))[0, 1]
        mae = np.mean(np.abs(np.array(v221.values) - np.array(v61.values)))
        print(f"\n  corr(V221_a003, V61_a005) = {corr:.6f}  MAE = {mae:.2f}")
    
    # V221 vs V64 (should be identical)
    v64 = load_existing_submission(V64)
    if v221 is not None and v64 is not None:
        corr = np.corrcoef(np.array(v221.values), np.array(v64.values))[0, 1]
        mae = np.mean(np.abs(np.array(v221.values) - np.array(v64.values)))
        print(f"  corr(V221, V64) = {corr:.6f}  MAE = {mae:.2f}")
    
    # V166 vs V63 (same alpha=0.03, isotonic vs V63 alpha=0.1 isotonic)
    v166 = load_existing_submission(V166)
    v63 = load_existing_submission(V63)
    if v166 is not None and v63 is not None:
        corr = np.corrcoef(np.array(v166.values), np.array(v63.values))[0, 1]
        mae = np.mean(np.abs(np.array(v166.values) - np.array(v63.values)))
        print(f"  corr(V166_a003_iso, V63_a01_iso) = {corr:.6f}  MAE = {mae:.2f}")
    
    # Generate NEW blends
    print(f"\n{'=' * 70}")
    print("  NEW BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # V221 + V166 50/50 (V74 equivalent with a=0.03)
        ('v321_blend_v221_v166_5050', [(V221, 0.5), (V166, 0.5)],
         "V221-a003-linear(50%) + V166-a003-iso(50%). V74 structure with a=0.03."),
        
        # V321 + V72 75/25 (V96 structure with a=0.03)
        ('v322_blend_v321_v72_7525', [('submit_v321_blend_v221_v166_5050.zip', 0.75), (V72, 0.25)],
         "V321(75%) + V72(25%). V96 structure with a=0.03."),
        
        # V321 + V73 75/25 (V96 structure with a=0.03, all a=0.03)
        ('v323_blend_v321_v73_7525', [('submit_v321_blend_v221_v166_5050.zip', 0.75), (V73, 0.25)],
         "V321(75%) + V73-a003-iso(25%). V96 structure, all a=0.03."),
        
        # V322 + V72 77/23 (V189 structure)
        ('v324_blend_v321_v72_7723', [('submit_v321_blend_v221_v166_5050.zip', 0.77), (V72, 0.23)],
         "V321(77%) + V72(23%). V189 structure with a=0.03."),
        
        # V96 + V322 (V96 + V96-a003-equivalent) at various ratios
        ('v325_blend_v96_v322_8020', [(V96, 0.8), ('submit_v322_blend_v321_v72_7525.zip', 0.2)],
         "V96(80%) + V322-a003-v96(20%)."),
        ('v326_blend_v96_v322_9010', [(V96, 0.9), ('submit_v322_blend_v321_v72_7525.zip', 0.1)],
         "V96(90%) + V322-a003-v96(10%)."),
        
        # V242 (V221+V63 50/50) already exists - check it
        # V242 + V72 75/25 (V96 with V221 replacing V61)
        ('v327_blend_v242_v72_7525', [(V242, 0.75), (V72, 0.25)],
         "V242(75%) + V72(25%). V96 with V221 replacing V61."),
        
        # V221 + V63 60/40 (more V221 weight)
        ('v328_blend_v221_v63_6040', [(V221, 0.6), (V63, 0.4)],
         "V221(60%) + V63(40%). More a=0.03 weight."),
        
        # V328 + V72 75/25
        ('v329_blend_v328_v72_7525', [('submit_v328_blend_v221_v63_6040.zip', 0.75), (V72, 0.25)],
         "V328(75%) + V72(25%). V96 with more V221 weight."),
        
        # V96 + V221 at fine ratios
        ('v330_blend_v96_v221_8020', [(V96, 0.8), (V221, 0.2)],
         "V96(80%) + V221(20%). Direct blend."),
        ('v331_blend_v96_v221_975025', [(V96, 0.975), (V221, 0.025)],
         "V96(97.5%) + V221(2.5%). Tiny addition."),
        
        # 3-way: V221 + V61 + V63 (mix a=0.03 and a=0.05)
        ('v332_blend_v221_v61_v63', [(V221, 0.4), (V61, 0.3), (V63, 0.3)],
         "V221(40%) + V61(30%) + V63(30%). Mix a=0.03 and a=0.05."),
        
        # V332 + V72 75/25
        ('v333_blend_v332_v72_7525', [('submit_v332_blend_v221_v61_v63.zip', 0.75), (V72, 0.25)],
         "V332(75%) + V72(25%). V96 with mixed alpha."),
        
        # V189 + V322 (current best + a=0.03 V96)
        ('v334_blend_v189_v322_8020', [(V189, 0.8), ('submit_v322_blend_v321_v72_7525.zip', 0.2)],
         "V189(80%) + V322-a003(20%). Current best + a=0.03 V96."),
        
        # V221 + V166 60/40 (more linear)
        ('v335_blend_v221_v166_6040', [(V221, 0.6), (V166, 0.4)],
         "V221(60%) + V166(40%). More linear a=0.03."),
        
        # V335 + V73 75/25
        ('v336_blend_v335_v73_7525', [('submit_v335_blend_v221_v166_6040.zip', 0.75), (V73, 0.25)],
         "V335(75%) + V73(25%). V96 with more linear a=0.03."),
        
        # V96 + V327 (V96 + V96-with-V221)
        ('v337_blend_v96_v327_8020', [(V96, 0.8), ('submit_v327_blend_v242_v72_7525.zip', 0.2)],
         "V96(80%) + V327(20%). V96 + V96-with-V221."),
        
        # V221 + V72 50/50 (direct, no V63 intermediate)
        ('v338_blend_v221_v72_5050', [(V221, 0.5), (V72, 0.5)],
         "V221(50%) + V72(50%). Direct blend."),
        
        # V338 + V96 50/50
        ('v339_blend_v96_v338_5050', [(V96, 0.5), ('submit_v338_blend_v221_v72_5050.zip', 0.5)],
         "V96(50%) + V338(50%). Half V96, half V221+V72."),
        
        # V96 + V221 + V166 3-way
        ('v340_blend_v96_v221_v166', [(V96, 0.80), (V221, 0.10), (V166, 0.10)],
         "V96(80%) + V221(10%) + V166(10%). V96 + a=0.03 linear+iso."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v321', 'v322', 'v323', 'v324', 'v325', 'v326', 'v327', 'v328',
                  'v329', 'v330', 'v331', 'v332', 'v333', 'v334', 'v335', 'v336',
                  'v337', 'v338', 'v339', 'v340']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
