"""
V14 实验补充: 测试更多比值+SG+SNV组合 + LightGBM
"""
import os, sys, copy, warnings
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.linear_model import RidgeCV
import lightgbm as lgb

warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from all import (
    load_labels, load_coal_spectra,
    COAL_TYPES, TRAIN_DIR, AUX_COLS, ALPHAS,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    N_ENSEMBLE_SEEDS, ENSEMBLE_SEEDS,
    get_cv_splits, aggregate_to_batch, find_best_shrinkage,
    _train_one_run,
)
from experiment_v14 import (
    build_feature_matrix_v14,
    train_coal_model_v14,
)


# ── LightGBM 两阶段 ────────────────────────────────────────────────────────────

def _train_one_run_lgb(X_spec, y, aux, groups, splits, coal_mean, n_batches, seed=42):
    """LightGBM 两阶段: Stage1 OOF + Stage2。"""
    # Stage1: 光谱 → 辅助指标
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    
    lgb_params = {
        'n_estimators': 500,
        'learning_rate': 0.05,
        'max_depth': 5,
        'num_leaves': 15,
        'subsample': 0.8,
        'colsample_bytree': 0.8,
        'reg_alpha': 1.0,
        'reg_lambda': 10.0,
        'random_state': seed,
        'verbose': -1,
        'n_jobs': 1,
    }

    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = lgb.LGBMRegressor(**lgb_params)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            m.fit(X_spec[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X_spec[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m.fit(X_spec, y_aux)
        aux_models[col_name] = m

    # Stage2: [光谱 + 预测辅助] → 发热量
    X_s2 = np.hstack([X_spec, predicted_aux_oof])
    X_s2 = np.nan_to_num(X_s2, nan=0.0, posinf=0.0, neginf=0.0)

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []

    for tr_idx, val_idx in splits:
        m2 = lgb.LGBMRegressor(**lgb_params)
        m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]

        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse_shrunk = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_mean)

    final_model = lgb.LGBMRegressor(**lgb_params)
    final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models,
        'final_model': final_model,
        'cv_rmse': cv_rmse_shrunk,
        'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'scaler_s2': None,  # LGB不需要scaler
    }


def train_coal_lgb(coal_type, train_data, use_sg=True, use_snv=True):
    """LightGBM 训练。"""
    data = copy.deepcopy(train_data)
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())

    X_spec, scaler_spec, pca, scaler_hand = build_feature_matrix_v14(
        data, n_batches, fit=True, use_sg=use_sg, use_snv=use_snv)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _train_one_run_lgb(X_spec, y, aux, groups, splits, coal_mean, n_batches)
        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条  (LOOCV, LightGBM)")
        print(f"    CV-RMSE: raw={run['cv_rmse_raw']:.2f}  shrunk={run['cv_rmse']:.2f}  w={run['shrink_w']:.2f}")
        return {'cv_rmse': run['cv_rmse']}
    else:
        cv_rmses = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            run = _train_one_run_lgb(X_spec, y, aux, groups, splits, coal_mean, n_batches, seed=seed)
            cv_rmses.append(run['cv_rmse'])
        cv_mean = float(np.mean(cv_rmses))
        cv_std = float(np.std(cv_rmses))
        print(f"\n  [{coal_type}]  {n_batches}批次  {len(y)}条  ({N_ENSEMBLE_SEEDS}种子, LightGBM)")
        print(f"    CV-RMSE: {cv_mean:.2f} ± {cv_std:.2f}")
        return {'cv_rmse': cv_mean}


# ── 实验 ────────────────────────────────────────────────────────────────────────

def run_exp(name, fn):
    print(f"\n{'='*60}")
    print(f"实验: {name}")
    print(f"{'='*60}")
    label_map, aux_map = load_labels()
    cv_results = {}
    for ct in COAL_TYPES:
        td = load_coal_spectra(TRAIN_DIR, ct, label_map, aux_map)
        if td is None or td['n_batches'] == 0:
            continue
        r = fn(ct, td)
        cv_results[ct] = r['cv_rmse']
    g = float(np.mean(list(cv_results.values())))
    print(f"\n{name} 全局 CV-RMSE: {g:.2f}")
    return g


if __name__ == "__main__":
    # 实验6: 更多比值 + SG+SNV（无异常剔除）
    cv6 = run_exp("更多比值+SG+SNV(无异常剔除)",
                  lambda ct, td: train_coal_model_v14(ct, td, use_outlier_removal=False, use_sg=True, use_snv=True))

    # 实验7: 更多比值 only（无SG/SNV，无异常剔除）— 复跑确认
    cv7 = run_exp("更多比值only(无SG/SNV)",
                  lambda ct, td: train_coal_model_v14(ct, td, use_outlier_removal=False, use_sg=False, use_snv=False))

    # 实验8: LightGBM + 更多比值 + SG+SNV
    cv8 = run_exp("LightGBM+更多比值+SG+SNV",
                  lambda ct, td: train_coal_lgb(ct, td, use_sg=True, use_snv=True))

    # 实验9: LightGBM + 更多比值 only
    cv9 = run_exp("LightGBM+更多比值only",
                  lambda ct, td: train_coal_lgb(ct, td, use_sg=False, use_snv=False))

    print(f"\n{'='*60}")
    print("全部实验结果汇总")
    print(f"{'='*60}")
    print(f"  V13 基线(Ridge):              170.62")
    print(f"  仅更多比值(Ridge):             161.51")
    print(f"  仅SG+SNV(Ridge):              164.63")
    print(f"  更多比值+SG+SNV(Ridge):       {cv6:.2f}")
    print(f"  更多比值only复跑(Ridge):       {cv7:.2f}")
    print(f"  LightGBM+更多比值+SG+SNV:     {cv8:.2f}")
    print(f"  LightGBM+更多比值only:        {cv9:.2f}")
