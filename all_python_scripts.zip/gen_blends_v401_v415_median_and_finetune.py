"""
gen_blends_v401_v415_median_and_finetune.py
Two strategies:
1. Median blend (more robust than mean, ignores outlier calibration errors)
2. Fine-tuned V96 ratios with Huber component
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


def pack_median_blend(variant_name, component_files, desc):
    subs = {}
    for fname in component_files:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  ERROR: {fname} not found")
            return None
        subs[fname] = sub
    all_preds = {}
    for idx in subs[component_files[0]].index:
        vals = [subs[fname][idx] for fname in component_files]
        all_preds[idx] = float(np.median(vals))
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    V373 = 'submit_v373_a005_huber.zip'
    V342 = 'submit_v342_a005_poly3.zip'
    V371 = 'submit_v371_a005_clip_linear.zip'
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    print(f"{'=' * 70}")
    print("  MEDIAN BLENDS")
    print(f"{'=' * 70}")
    
    # Median blends - more robust to outlier calibration errors
    median_blends = [
        # 4-way median: V61 + V63 + V72 + V373
        ('v401_median_4way', [V61, V63, V72, V373],
         "Median of V61-linear + V63-iso + V72-iso + V373-huber. Robust to outliers."),
        
        # 5-way median: V61 + V63 + V72 + V373 + V342
        ('v402_median_5way', [V61, V63, V72, V373, V342],
         "Median of 5 calib methods. Maximum robustness."),
        
        # 3-way median: V61 + V63 + V373
        ('v403_median_3calib', [V61, V63, V373],
         "Median of V61-linear + V63-iso + V373-huber."),
        
        # 3-way median: V74 + V72 + V373 (V96 components + Huber)
        ('v404_median_v96_huber', [V74, V72, V373],
         "Median of V74 + V72 + V373-huber. V96 components + Huber."),
    ]
    
    for vid, components, desc in median_blends:
        print(f"\n  {vid}: {desc}")
        pack_median_blend(vid, components, desc)
    
    print(f"\n{'=' * 70}")
    print("  FINE-TUNED HUBER BLENDS")
    print(f"{'=' * 70}")
    
    # Fine-tuned blends with Huber at various ratios
    finetune_blends = [
        # V96 structure with Huber replacing V61 at different ratios
        # V385 = 50/50 Huber+V63, V386 = 75/25 V385+V72
        # Try different V385:V72 ratios
        ('v405_blend_v385_v72_8020', [('submit_v385_blend_v373_v63_5050.zip', 0.80), (V72, 0.20)],
         "V385-huber+V63(80%) + V72(20%). More Huber weight."),
        ('v406_blend_v385_v72_7030', [('submit_v385_blend_v373_v63_5050.zip', 0.70), (V72, 0.30)],
         "V385-huber+V63(70%) + V72(30%). More V72 weight."),
        
        # Huber + V63 at different ratios (not just 50/50)
        ('v407_blend_v373_v63_6040', [(V373, 0.6), (V63, 0.4)],
         "V373-huber(60%) + V63(40%). More Huber."),
        ('v408_blend_v373_v63_4060', [(V373, 0.4), (V63, 0.6)],
         "V373-huber(40%) + V63(60%). More isotonic."),
        
        # V407 + V72 75/25
        ('v409_blend_v407_v72_7525', [('submit_v407_blend_v373_v63_6040.zip', 0.75), (V72, 0.25)],
         "V407(75%) + V72(25%). V96 with 60/40 Huber/V63."),
        # V408 + V72 75/25
        ('v410_blend_v408_v72_7525', [('submit_v408_blend_v373_v63_4060.zip', 0.75), (V72, 0.25)],
         "V408(75%) + V72(25%). V96 with 40/60 Huber/V63."),
        
        # V96 + V386 at various ratios (V96 + full Huber blend)
        ('v411_blend_v96_v386_9010', [(V96, 0.9), ('submit_v386_blend_v385_v72_7525.zip', 0.1)],
         "V96(90%) + V386-huber-blend(10%). Small Huber addition."),
        ('v412_blend_v96_v386_8020', [(V96, 0.8), ('submit_v386_blend_v385_v72_7525.zip', 0.2)],
         "V96(80%) + V386-huber-blend(20%)."),
        
        # Trimmed mean: remove highest and lowest, average the rest
        # 4-way trimmed: V61 + V63 + V72 + V373, remove min and max, average middle 2
        # This is equivalent to median of 4 values
        # Already done as v401
        
        # V189 + V386 90/10 (current best + Huber blend)
        ('v413_blend_v189_v386_9010', [(V189, 0.9), ('submit_v386_blend_v385_v72_7525.zip', 0.1)],
         "V189(90%) + V386-huber-blend(10%). Current best + small Huber."),
        
        # V189 + V386 80/20
        ('v414_blend_v189_v386_8020', [(V189, 0.8), ('submit_v386_blend_v385_v72_7525.zip', 0.2)],
         "V189(80%) + V386-huber-blend(20%). Current best + Huber."),
        
        # V96 + V373 95/5 (tiny Huber addition)
        ('v415_blend_v96_v373_9505', [(V96, 0.95), (V373, 0.05)],
         "V96(95%) + V373-huber(5%). Minimal Huber addition."),
    ]
    
    for vid, components, desc in finetune_blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v401', 'v402', 'v403', 'v404', 'v405', 'v406', 'v407', 'v408',
                  'v409', 'v410', 'v411', 'v412', 'v413', 'v414', 'v415']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
