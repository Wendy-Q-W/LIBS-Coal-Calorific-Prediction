"""
gen_v574_v590_v562_expand.py
V562=195.14 is BEST (V538+煤场混煤→V63). 
Decomposition:
  煤场混煤→V63 = -1.23 (HUGE win)
  赵固一→V63 + 赵固二→V72 = +1.09 (HARMFUL together)

Strategy: V562 base + individual coal additions to find what helps.
Also test 九里山 with V63 (not V72 which failed).
"""
import os, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
pred_col = '预测发热量_MJ_KG'

def load_template():
    return pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')

def load_pred(zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(zip_path): return None
    with zipfile.ZipFile(zip_path, 'r') as zf:
        csv_name = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(csv_name) as f:
            return pd.read_csv(f, encoding='utf-8-sig')

def save_zip(df, zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', csv_buf.getvalue())
    return zip_path

def corr(v1, v2): return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("EXPAND FROM V562 (195.14) — BEST SO FAR")
    print("=" * 70)

    template = load_template()
    template['coal'] = template['名称'].apply(
        lambda n: next((ct for ct in COAL_TYPES if ct in str(n)), 'unknown'))
    masks = {ct: (template['coal'] == ct).values for ct in COAL_TYPES}

    v61 = load_pred('submit_v61_a005_bias.zip')[pred_col].values
    v63 = load_pred('submit_v63_isotonic.zip')[pred_col].values
    v72 = load_pred('submit_v72_isotonic_a005.zip')[pred_col].values
    v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')[pred_col].values

    zm = masks['中马矿中煤矿']
    zg1 = masks['赵固一矿豫焦末煤']
    zg2 = masks['赵固二矿中煤矿']
    jl = masks['九里山矿中煤矿']
    mc = masks['煤场混煤']

    # V562 baseline = V96 + 中马→V72 + 煤场混煤→V63
    v562 = v96.copy()
    v562[zm] = v72[zm]
    v562[mc] = v63[mc]

    results = []

    def gen(name, pred, desc):
        c = corr(pred, v96)
        m = np.mean(np.abs(pred - v96))
        df_out = template.copy()
        df_out[pred_col] = pred
        save_zip(df_out, f'submit_{name}.zip')
        results.append((name, c, m, desc))
        print(f"  {name}: corr={c:.6f}, MAE={m:.2f} — {desc}")

    # === Individual coal additions on V562 ===

    # V574: V562 + 九里山→V63
    p = v562.copy(); p[jl] = v63[jl]
    gen('v574_v562_jiuli_v63', p, "V562+九里山→V63")

    # V575: V562 + 九里山→V61
    p = v562.copy(); p[jl] = v61[jl]
    gen('v575_v562_jiuli_v61', p, "V562+九里山→V61")

    # V576: V562 + 赵固一→V63 (only)
    p = v562.copy(); p[zg1] = v63[zg1]
    gen('v576_v562_zhao1_v63', p, "V562+赵固一→V63")

    # V577: V562 + 赵固二→V72 (only)
    p = v562.copy(); p[zg2] = v72[zg2]
    gen('v577_v562_zhao2_v72', p, "V562+赵固二→V72")

    # V578: V562 + 赵固二→V63 (try V63 instead of V72)
    p = v562.copy(); p[zg2] = v63[zg2]
    gen('v578_v562_zhao2_v63', p, "V562+赵固二→V63 (not V72)")

    # V579: V562 + 赵固一→V72 (try V72 instead of V63)
    p = v562.copy(); p[zg1] = v72[zg1]
    gen('v579_v562_zhao1_v72', p, "V562+赵固一→V72 (not V63)")

    # === Partial 九里山 (V72 failed full, try gentle) ===

    # V580: V562 + 九里山 80/20 V96/V72
    p = v562.copy(); p[jl] = 0.8 * v96[jl] + 0.2 * v72[jl]
    gen('v580_v562_jiuli_8020_v72', p, "V562+九里山 80/20 V96/V72")

    # V581: V562 + 九里山 50/50 V96/V63
    p = v562.copy(); p[jl] = 0.5 * v96[jl] + 0.5 * v63[jl]
    gen('v581_v562_jiuli_5050_v63', p, "V562+九里山 50/50 V96/V63")

    # === 煤场混煤 ratio tuning ===

    # V582: V538 + 煤场混煤 80/20 V96/V63 (gentler than V562's full V63)
    p = v538_like(v96, v72, zm)  # V538
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = 0.8 * v96[mc] + 0.2 * v63[mc]
    gen('v582_v538_mc_8020_v63', p, "V538+煤场混煤 80/20 V96/V63")

    # V583: V538 + 煤场混煤 90/10 V96/V63
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = 0.9 * v96[mc] + 0.1 * v63[mc]
    gen('v583_v538_mc_9010_v63', p, "V538+煤场混煤 90/10 V96/V63")

    # V584: V538 + 煤场混煤 60/40 V96/V63 (more aggressive than V562)
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = 0.6 * v96[mc] + 0.4 * v63[mc]
    gen('v584_v538_mc_6040_v63', p, "V538+煤场混煤 60/40 V96/V63")

    # V585: V538 + 煤场混煤→V72 (try V72 instead of V63)
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = v72[mc]
    gen('v585_v538_mc_v72', p, "V538+煤场混煤→V72 (not V63)")

    # === Isolate: V96 + 煤场混煤→V63 ONLY (no 中马 change) ===
    p = v96.copy(); p[mc] = v63[mc]
    gen('v586_v96_mc_v63_only', p, "V96+煤场混煤→V63 only (no 中马)")

    # === Combo: V562 + 九里山→V63 + 赵固一→V63 (all V63 coals) ===
    p = v562.copy(); p[jl] = v63[jl]; p[zg1] = v63[zg1]
    gen('v587_v562_jiuli_zhao1_v63', p, "V562+九里山→V63+赵固一→V63")

    # === Combo: V562 + 九里山→V63 + 赵固二→V63 ===
    p = v562.copy(); p[jl] = v63[jl]; p[zg2] = v63[zg2]
    gen('v588_v562_jiuli_zhao2_v63', p, "V562+九里山→V63+赵固二→V63")

    # === Safety: V96 + V562 80/20 ===
    p = 0.8 * v96 + 0.2 * v562
    gen('v589_v96_v562_8020', p, "V96+V562 80/20 (safety)")

    # === Safety: V96 + V562 50/50 ===
    p = 0.5 * v96 + 0.5 * v562
    gen('v590_v96_v562_5050', p, "V96+V562 50/50")

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr)")
    print("=" * 70)
    print(f"{'Variant':<35} {'corr':<12} {'MAE':<8} {'Description'}")
    print("-" * 90)
    for name, c, m, desc in sorted(results, key=lambda x: -x[1]):
        print(f"{name:<35} {c:.6f}     {m:.2f}   {desc}")

    print("\n--- Known online scores ---")
    print("  V96  = 196.98 (baseline)")
    print("  V538 = 196.37 (中马→V72)")
    print("  V562 = 195.14 (中马→V72+煤场混煤→V63) *** BEST ***")
    print("  V566 = 196.23 (V562+赵固一→V63+赵固二→V72, 赵固 HURTS +1.09)")
    print("  V546 = 197.09 (V538+九里→V72, 九里→V72 HURTS +0.72)")
    print("  V567 = 196.17 (V538+V566 80/20)")
    print("")
    print("  KEY QUESTIONS:")
    print("  1. V574: Does 九里山→V63 help on V562? (V72 hurt, V63 might differ)")
    print("  2. V576/V577: Which of 赵固一/赵固二 individually hurts?")
    print("  3. V582-V584: Can we tune 煤场混煤 ratio for even better?")
    print("  4. V586: Isolate 煤场混煤 effect without 中马")

def v538_like(v96, v72, zm):
    p = v96.copy(); p[zm] = v72[zm]; return p

if __name__ == '__main__':
    main()
