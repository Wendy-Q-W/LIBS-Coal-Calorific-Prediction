"""V15c: 精准per-coal alpha实验 (只跑3个有时间分割的煤种)"""
import sys, os, re, warnings
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def build_fm(data, n_batches, n_pca_max=30):
    inorm_mat = compute_features(data)
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    hf = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([sp, hf])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X

def oof_ridge(X, y, aux, groups, splits, alphas):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = RidgeCV(alphas=alphas); m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = RidgeCV(alphas=alphas); m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot

def time_ext(coal, alphas=None):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names, cm = td['aux'], td['names'], float(y.mean())
    if alphas is None: alphas = ALPHAS
    X = build_fm(td, nb)
    is_small = nb <= SMALL_BATCH_THRESHOLD

    # 搜 w (用GroupKFold/LOOCV)
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits, alphas)
        w, _ = find_best_shrinkage(op, ot, cm)
    else:
        ws = []
        for s in range(10):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits, alphas)
            w_s, _ = find_best_shrinkage(op, ot, cm)
            ws.append(w_s)
        w = float(np.mean(ws))

    # 时间外推
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return {'w': w, 'cm': cm, 'small': is_small, 'no_split': True}

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya)); continue
        m1 = RidgeCV(alphas=alphas); m1.fit(X[tm], ya[tm])
        pa[:, ci] = m1.predict(X)

    X2 = np.nan_to_num(np.hstack([X, pa]))
    sc = StandardScaler(); X2 = sc.fit_transform(X2)
    m2 = RidgeCV(alphas=alphas); m2.fit(X2[tm], y[tm])
    vp = m2.predict(X2[vm])

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk]))); bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bp)])))

    # 测试多个固定w值
    results = {'raw': cv_raw}
    for w_test in [0.0, 0.25, 0.5, 0.75, 1.0]:
        bl = [w_test * p + (1-w_test) * cm for p in bp]
        results[f'w={w_test:.2f}'] = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))
    # 也测CV搜的w
    bl = [w * p + (1-w) * cm for p in bp]
    results[f'cv_w={w:.2f}'] = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))
    results['cv_w'] = w
    results['cm'] = cm
    results['small'] = is_small
    return results


if __name__ == "__main__":
    # 只跑3个有时间分割的煤种
    time_coals = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']

    # 多组alpha配置
    configs = [
        ("baseline", {
            '赵固一矿豫焦末煤': None, '赵固二矿中煤矿': None, '煤场混煤': None
        }),
        ("zge_high", {
            '赵固一矿豫焦末煤': [100,500,1000,5000,10000,50000,100000],
            '赵固二矿中煤矿': None, '煤场混煤': None
        }),
        ("zge2_high", {
            '赵固一矿豫焦末煤': None,
            '赵固二矿中煤矿': [100,500,1000,5000,10000,50000,100000],
            '煤场混煤': None
        }),
        ("hmh_high", {
            '赵固一矿豫焦末煤': None, '赵固二矿中煤矿': None,
            '煤场混煤': [100,500,1000,5000,10000,50000,100000]
        }),
        ("zge2_hmh_high", {
            '赵固一矿豫焦末煤': None,
            '赵固二矿中煤矿': [100,500,1000,5000,10000,50000,100000],
            '煤场混煤': [100,500,1000,5000,10000,50000,100000]
        }),
        ("all_high", {
            '赵固一矿豫焦末煤': [100,500,1000,5000,10000,50000,100000],
            '赵固二矿中煤矿': [100,500,1000,5000,10000,50000,100000],
            '煤场混煤': [100,500,1000,5000,10000,50000,100000]
        }),
    ]

    for config_name, alphas_map in configs:
        print(f"\n{'='*55}")
        print(f"  {config_name}")
        print(f"{'='*55}", flush=True)
        all_shrunk = []
        for coal in time_coals:
            al = alphas_map.get(coal)
            r = time_ext(coal, al)
            if r is None or r.get('no_split'): continue
            tag = 'small' if r['small'] else 'large'
            cvw = r['cv_w']
            cvw_key = f'cv_w={cvw:.2f}'
            cvw_val = r[cvw_key]
            print(f"  [{coal}] ({tag}) raw={r['raw']:.1f} "
                  f"cv_w={cvw:.2f}->{cvw_val:.1f} "
                  f"w0={r['w=0.00']:.1f} w1={r['w=1.00']:.1f}", flush=True)
            all_shrunk.append(cvw_val)

        if all_shrunk:
            print(f"  >> avg shrunk(cv_w) = {np.mean(all_shrunk):.2f}", flush=True)
