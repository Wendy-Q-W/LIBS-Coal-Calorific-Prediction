"""
exp_v35_residual_multitask.py
辅助残差修正 + 混煤多任务分支

基于V28光谱级框架, 改变辅助约束的融合方式:
  V28: [光谱特征 + 预测辅助指标] → Ridge → Q (特征拼接, 剂量太重)
  V35: Q_spec = 光谱模型; Q_aux = 辅助→Q映射; Q = Q_spec + alpha*(Q_aux - Q_spec)

混煤多任务分支:
  对煤场混煤, 用PLS同时预测[Q, aux] (共享潜变量=真多任务)
  低权重融合: Q = Q_main + beta * (Q_multi - Q_main)

双重CV: GK-CV(10seed) + TE-CV(10/11月->1/2/3月)
"""
import os, re, glob, warnings, time
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']
KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.30, 15.0),
    'O':   (777.20, 15.0), 'N':   (742.40, 10.0),
    'Ca':  (422.70, 2.0),  'Ca2': (393.40, 2.0),
    'Mg':  (285.20, 2.0),  'Al':  (308.20, 2.0),
    'Si':  (288.20, 2.0),  'Fe':  (438.40, 3.0),
    'Na':  (589.00, 1.5),
}
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    weights = np.exp(-time_diff / tau) if (time_diff := diff * 30) is not None else None
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features(wl, inten)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data2 = dict(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    return inorm_mat, data2


def build_fm(inorm_mat, data, n_batches):
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    sc = StandardScaler()
    ss = sc.fit_transform(inorm_mat)
    n_pca = min(30, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    X = np.hstack([sp, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler()
    X = sh.fit_transform(X)
    return X


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


# ═══════════════════════════════════════════════════════════════════════════════
# Training functions
# ═══════════════════════════════════════════════════════════════════════════════

def _train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights=None):
    """V28 baseline: 两阶段Ridge, Stage2拼接aux_pred."""
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    X_s2 = np.hstack([X_spec, aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2.fit(X_s2[tr], y[tr])
        vp = m2.predict(X_s2[va])
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(vp[mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(vp[vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w}


def _train_residual(X_spec, y, aux, groups, splits, coal_mean,
                    sample_weights=None, alpha_res=0.1):
    """辅助残差修正: Q = Q_spec + alpha*(Q_aux - Q_spec)."""
    # Stage 1: aux OOF (same as V28)
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    # Stage 2a: Q_spec (光谱only, 不含aux)
    q_spec_oof = np.zeros(len(y))
    for tr, va in splits:
        m2a = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2a.fit(X_spec[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2a.fit(X_spec[tr], y[tr])
        q_spec_oof[va] = m2a.predict(X_spec[va])

    # Stage 2b: Q_aux (辅助指标→Q映射)
    q_aux_oof = np.zeros(len(y))
    for tr, va in splits:
        aux_tr = np.nan_to_num(aux_oof[tr], nan=0.0)
        aux_va = np.nan_to_num(aux_oof[va], nan=0.0)
        if aux_tr.shape[0] < 2:
            q_aux_oof[va] = float(np.mean(y[tr]))
            continue
        m2b = Ridge(alpha=1.0)
        m2b.fit(aux_tr, y[tr])
        q_aux_oof[va] = m2b.predict(aux_va)

    # Final: 残差修正
    q_final = q_spec_oof + alpha_res * (q_aux_oof - q_spec_oof)

    # 按批次聚合
    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(q_final[va][mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(q_final[va][vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w}


def _train_multitask(X_spec, y, aux, groups, splits, coal_mean,
                     sample_weights=None, alpha_res=0.1,
                     alpha_fusion=0.1, n_pls=10):
    """残差修正 + 混煤PLS多任务分支.

    主模型 = 残差修正版
    多任务 = PLS同时预测[Q, aux], 取Q预测
    Final = Q_main + alpha_fusion * (Q_multi - Q_main)
    """
    # === 主模型: 残差修正 ===
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    q_spec_oof = np.zeros(len(y))
    for tr, va in splits:
        m2a = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2a.fit(X_spec[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2a.fit(X_spec[tr], y[tr])
        q_spec_oof[va] = m2a.predict(X_spec[va])

    q_aux_oof = np.zeros(len(y))
    for tr, va in splits:
        aux_tr = np.nan_to_num(aux_oof[tr], nan=0.0)
        aux_va = np.nan_to_num(aux_oof[va], nan=0.0)
        if aux_tr.shape[0] < 2:
            q_aux_oof[va] = float(np.mean(y[tr]))
            continue
        m2b = Ridge(alpha=1.0)
        m2b.fit(aux_tr, y[tr])
        q_aux_oof[va] = m2b.predict(aux_va)

    q_main = q_spec_oof + alpha_res * (q_aux_oof - q_spec_oof)

    # === 多任务分支: PLS on [Q, aux] ===
    # 构建多目标矩阵
    Y_multi = np.column_stack([y] + [aux[:, ci] for ci in range(aux.shape[1])])
    # 填充NaN
    for ci in range(1, Y_multi.shape[1]):
        col = Y_multi[:, ci]
        if np.isnan(col).any():
            Y_multi[np.isnan(col), ci] = float(np.nanmean(col))

    X_clean = np.nan_to_num(X_spec, nan=0.0, posinf=0.0, neginf=0.0)
    q_multi_oof = np.zeros(len(y))
    for tr, va in splits:
        n_comp = min(n_pls, len(tr) - 1, X_clean.shape[1])
        n_comp = max(1, n_comp)
        try:
            pls = PLSRegression(n_components=n_comp, scale=False)
            pls.fit(X_clean[tr], Y_multi[tr])
            pred_multi = pls.predict(X_clean[va])
            q_multi_oof[va] = pred_multi[:, 0]
        except Exception:
            q_multi_oof[va] = float(np.mean(y[tr]))

    # === 融合 ===
    q_final = q_main + alpha_fusion * (q_multi_oof - q_main)

    # 按批次聚合
    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(q_final[va][mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(q_final[va][vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w}


# ═══════════════════════════════════════════════════════════════════════════════
# GK-CV and TE-CV wrappers
# ═══════════════════════════════════════════════════════════════════════════════

def train_gk(coal_type, data, mode='v28', **kwargs):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    months = data['months']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    inorm_mat, data2 = compute_features(data)
    X_spec = build_fm(inorm_mat, data2, n_batches)

    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    def _run(splits):
        if mode == 'v28':
            return _train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights)
        elif mode == 'residual':
            return _train_residual(X_spec, y, aux, groups, splits, coal_mean,
                                   sample_weights, alpha_res=kwargs.get('alpha_res', 0.1))
        elif mode == 'multitask':
            return _train_multitask(X_spec, y, aux, groups, splits, coal_mean,
                                    sample_weights,
                                    alpha_res=kwargs.get('alpha_res', 0.1),
                                    alpha_fusion=kwargs.get('alpha_fusion', 0.1),
                                    n_pls=kwargs.get('n_pls', 10))

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        return _run(splits), is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run(splits))
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_te(coal_type, data, mode='v28', **kwargs):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    months = data['months']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)

    inorm_mat, data2 = compute_features(data)
    X_spec = build_fm(inorm_mat, data2, n_batches)

    # Build splits: single fold tr→val
    splits = [(tr_idx, val_idx)]

    if mode == 'v28':
        run = _train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights)
    elif mode == 'residual':
        run = _train_residual(X_spec, y, aux, groups, splits, coal_mean,
                              sample_weights, alpha_res=kwargs.get('alpha_res', 0.1))
    elif mode == 'multitask':
        run = _train_multitask(X_spec, y, aux, groups, splits, coal_mean,
                               sample_weights,
                               alpha_res=kwargs.get('alpha_res', 0.1),
                               alpha_fusion=kwargs.get('alpha_fusion', 0.1),
                               n_pls=kwargs.get('n_pls', 10))

    return {'rmse_shrunk': run['cv_rmse'], 'rmse_raw': run['cv_rmse_raw'],
            'shrink_w': run['shrink_w']}


def gk_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


def run_experiment(label_map, aux_map, config_name, mode='v28', **kwargs):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {config_name}")
    print(f"{'='*70}", flush=True)
    gk_results, te_results = {}, {}
    for coal_type in COAL_TYPES:
        data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if data is None or data['n_batches'] == 0:
            continue
        n_batches = data['n_batches']
        n_spec = len(data['spectra'])
        runs, is_small = train_gk(coal_type, data, mode=mode, **kwargs)
        gk = gk_rmse(runs, is_small)
        te_r = train_te(coal_type, data, mode=mode, **kwargs)
        te = te_r['rmse_shrunk'] if te_r else None
        gk_results[coal_type] = gk
        te_results[coal_type] = te
        tag = "LOO" if is_small else f"{N_ENSEMBLE_SEEDS}s"
        te_s = f"TE={te:.2f}" if te else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b/{n_spec}s  GK={gk:.2f}  {te_s}  ({tag})", flush=True)
    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {config_name}")
    print(f"     GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V35: Residual Correction + Mixed-Coal Multitask")
    print("=" * 70)
    label_map, aux_map = load_labels()
    results = {}

    # 1. V28 baseline
    results['V28_baseline'] = run_experiment(
        label_map, aux_map, "V28 Baseline", mode='v28')

    # 2. 残差修正 (不同alpha)
    for alpha in [0.05, 0.1, 0.15, 0.2]:
        results[f'residual_a{alpha}'] = run_experiment(
            label_map, aux_map, f"Residual alpha={alpha}",
            mode='residual', alpha_res=alpha)

    # 3. 残差修正(0.1) + 混煤多任务 (不同fusion alpha)
    for alpha_f in [0.05, 0.1, 0.15, 0.2]:
        results[f'multitask_a0.1_f{alpha_f}'] = run_experiment(
            label_map, aux_map, f"Multitask res=0.1 fusion={alpha_f}",
            mode='multitask', alpha_res=0.1, alpha_fusion=alpha_f, n_pls=10)

    # 4. 残差修正(0.05) + 混煤多任务 (更保守)
    for alpha_f in [0.05, 0.1]:
        results[f'multitask_a0.05_f{alpha_f}'] = run_experiment(
            label_map, aux_map, f"Multitask res=0.05 fusion={alpha_f}",
            mode='multitask', alpha_res=0.05, alpha_fusion=alpha_f, n_pls=10)

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    base_gk, base_te = results['V28_baseline']
    print(f"  {'config':35s}  {'GK':>8s}  {'TE':>8s}  {'dGK':>7s}  {'dTE':>7s}")
    for name, (gk, te) in results.items():
        print(f"  {name:35s}  {gk:8.2f}  {te:8.2f}  {gk-base_gk:+7.2f}  {te-base_te:+7.2f}")


if __name__ == "__main__":
    main()
