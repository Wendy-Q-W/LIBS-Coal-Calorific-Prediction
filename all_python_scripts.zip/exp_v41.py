"""
exp_v41.py
V41: Per-coal normalization + Dual-PCA + 中马矿 investigation

V40 findings:
- Pure SNV is best preprocessing (derivatives/detrend all worse)
- PCA=15 marginally better than PCA=30 (TE -0.46)
- TW ALL improves both GK and TE (first time both improve)
- 中马矿 TE=359.00 unchanged across ALL configs (suspicious)

Directions:
1. Per-coal norm: SNV for coals where it helps TE (赵固一/赵固二/煤场混煤), 
   total for others (中马矿/九里山)
2. Dual-PCA: concatenate SNV-PCA + total-PCA (both information sources)
3. SNV + TW ALL + PCA=15 (combine marginal winners)
4. Per-coal tau optimization for TW ALL
5. Investigate 中马矿 TE=359 (check month distribution, batch count)
"""
import os, re, glob, warnings, time
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']
KEY_LINES = {
    'C': (247.86, 10.0), 'H': (656.30, 15.0),
    'O': (777.20, 15.0), 'N': (742.40, 10.0),
    'Ca': (422.70, 2.0), 'Ca2': (393.40, 2.0),
    'Mg': (285.20, 2.0), 'Al': (308.20, 2.0),
    'Si': (288.20, 2.0), 'Fe': (438.40, 3.0),
    'Na': (589.00, 1.5),
}
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TIME_WEIGHT_TAU_ALL = {
    '赵固一矿豫焦末煤': 30, '赵固二矿中煤矿': 30, '中马矿中煤矿': 30,
    '九里山矿中煤矿': 20, '煤场混煤': 30,
}
# Per-coal normalization selection
SNV_COALS = {'赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤'}
TOTAL_COALS = {'中马矿中煤矿', '九里山矿中煤矿'}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_spec_matrix(data, mode='snv'):
    raw_spectra = data['spectra']
    specs = []
    for wl, inten in raw_spectra:
        if mode == 'snv':
            s = (inten - inten.mean()) / (inten.std() + 1e-8)
        else:
            s = inten / (inten.sum() + 1e-8)
        specs.append(s)
    min_len = min(len(s) for s in specs)
    return np.array([s[:min_len] for s in specs], dtype=np.float32)


def compute_hand_features(data):
    raw_spectra = data['spectra']
    stats_list, labs_list, lrel_list, rats_list = [], [], [], []
    for wl, inten in raw_spectra:
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    data2 = dict(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    return data2


def build_fm(spec_mat, data2, n_batches, n_pca_max=30, scalers=None, fit=True):
    hand_feats = np.hstack([data2['stats'], data2['labs'], data2['lrel'], data2['rats']])
    if fit:
        sc = StandardScaler()
        spec_scaled = sc.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1) if n_batches else min(n_pca_max, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        sh = StandardScaler()
        X = sh.fit_transform(X)
        return X, (sc, pca, sh)
    else:
        sc, pca, sh = scalers
        spec_scaled = sc.transform(spec_mat)
        spec_pca = pca.transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        return sh.transform(X)


def build_fm_dual(spec_snv, spec_total, data2, n_batches, n_pca_max=30,
                  scalers=None, fit=True):
    """Dual-PCA: concatenate SNV-PCA + total-PCA + hand features."""
    hand_feats = np.hstack([data2['stats'], data2['labs'], data2['lrel'], data2['rats']])
    if fit:
        # SNV PCA
        sc_s = StandardScaler()
        snv_scaled = sc_s.fit_transform(spec_snv)
        n_pca_s = min(n_pca_max, n_batches - 1, snv_scaled.shape[0] - 1) if n_batches else min(n_pca_max, snv_scaled.shape[0] - 1)
        n_pca_s = max(1, n_pca_s)
        pca_s = PCA(n_components=n_pca_s, random_state=RANDOM_STATE)
        snv_pca = pca_s.fit_transform(snv_scaled)

        # Total PCA
        sc_t = StandardScaler()
        total_scaled = sc_t.fit_transform(spec_total)
        n_pca_t = min(n_pca_max, n_batches - 1, total_scaled.shape[0] - 1) if n_batches else min(n_pca_max, total_scaled.shape[0] - 1)
        n_pca_t = max(1, n_pca_t)
        pca_t = PCA(n_components=n_pca_t, random_state=RANDOM_STATE)
        total_pca = pca_t.fit_transform(total_scaled)

        X = np.hstack([snv_pca, total_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        sh = StandardScaler()
        X = sh.fit_transform(X)
        return X, (sc_s, pca_s, sc_t, pca_t, sh)
    else:
        sc_s, pca_s, sc_t, pca_t, sh = scalers
        snv_pca = pca_s.transform(sc_s.transform(spec_snv))
        total_pca = pca_t.transform(sc_t.transform(spec_total))
        X = np.hstack([snv_pca, total_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        return sh.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights=None):
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    X_s2 = np.hstack([X_spec, aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2.fit(X_s2[tr], y[tr])
        vp = m2.predict(X_s2[va])
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(vp[mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(vp[vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w}


def eval_gk(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    def _run(splits):
        return train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        return _run(splits)['cv_rmse'], is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run(splits))
        return float(np.mean([r['cv_rmse'] for r in runs])), is_small


def eval_te(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    months = data['months']
    coal_mean = float(y.mean())

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]
    splits = [(tr_idx, val_idx)]

    te_weights = None
    if sample_weights is not None:
        te_weights = sample_weights[tr_mask]

    run = train_v28(X_spec, y, aux, groups, splits, coal_mean, te_weights)
    return run['cv_rmse']


def investigate_coal(coal_type, data):
    """Print detailed info about a coal type."""
    months = data['months']
    groups = data['groups']
    names = data['names']
    y = data['targets']
    n_batches = data['n_batches']

    print(f"\n  --- {coal_type} investigation ---")
    print(f"  Batches: {n_batches}, Spectra: {len(y)}")
    print(f"  Q range: {y.min():.0f} ~ {y.max():.0f}, mean={y.mean():.1f}")

    # Month distribution
    unique_months = sorted(set(months))
    for m in unique_months:
        mask = months == m
        batches = set(groups[mask])
        print(f"  Month {m}: {mask.sum()} spectra, {len(batches)} batches, Q={y[mask].mean():.1f}±{y[mask].std():.1f}")

    # TE-CV split
    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    print(f"  TE-CV: train={tr_mask.sum()} (months 10,11), val={val_mask.sum()} (months 1,2,3)")
    if tr_mask.sum() > 0:
        tr_batches = set(groups[tr_mask])
        print(f"  TE-CV train batches: {len(tr_batches)}")
    if val_mask.sum() > 0:
        val_batches = set(groups[val_mask])
        print(f"  TE-CV val batches: {len(val_batches)}")
        val_q = y[val_mask]
        print(f"  TE-CV val Q: {val_q.mean():.1f}±{val_q.std():.1f}, range={val_q.min():.0f}~{val_q.max():.0f}")
        coal_mean = y.mean()
        val_batch_means = [y[val_mask][groups[val_mask]==b].mean() for b in val_batches]
        rmse_mean = np.sqrt(np.mean((np.array(val_batch_means) - coal_mean)**2))
        print(f"  TE if predict coal mean: RMSE={rmse_mean:.2f}")


def run_config(label_map, aux_map, name, spec_mode='snv', n_pca_max=30,
               time_weight_mode='v28', dual_pca=False, per_coal_norm=False):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {name}")
    print(f"{'='*70}", flush=True)

    gk_results, te_results = {}, {}

    for coal_type in COAL_TYPES:
        data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if data is None or data['n_batches'] == 0:
            continue

        n_batches = data['n_batches']
        n_spec = len(data['spectra'])
        months = data['months']
        is_small = n_batches <= SMALL_BATCH_THRESHOLD

        data2 = compute_hand_features(data)

        if dual_pca:
            spec_snv = compute_spec_matrix(data, 'snv')
            spec_total = compute_spec_matrix(data, 'total')
            X_spec, scalers = build_fm_dual(spec_snv, spec_total, data2, n_batches,
                                             n_pca_max=n_pca_max, fit=True)
        elif per_coal_norm:
            mode = 'snv' if coal_type in SNV_COALS else 'total'
            spec_mat = compute_spec_matrix(data, mode)
            X_spec, scalers = build_fm(spec_mat, data2, n_batches,
                                        n_pca_max=n_pca_max, fit=True)
        else:
            spec_mat = compute_spec_matrix(data, spec_mode)
            X_spec, scalers = build_fm(spec_mat, data2, n_batches,
                                        n_pca_max=n_pca_max, fit=True)

        sample_weights = None
        if time_weight_mode == 'v28':
            if coal_type in TIME_WEIGHT_TAU and not is_small:
                tau = TIME_WEIGHT_TAU[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)
        elif time_weight_mode == 'all':
            if coal_type in TIME_WEIGHT_TAU_ALL:
                tau = TIME_WEIGHT_TAU_ALL[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

        gk, is_small = eval_gk(coal_type, data, X_spec, sample_weights)
        te = eval_te(coal_type, data, X_spec, sample_weights)

        gk_results[coal_type] = gk
        te_results[coal_type] = te
        tag = "LOO" if is_small else f"{N_ENSEMBLE_SEEDS}s"
        te_s = f"TE={te:.2f}" if te else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b/{n_spec}s  GK={gk:.2f}  {te_s}  ({tag})", flush=True)

    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {name}")
    print(f"     GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V41: Per-coal Norm + Dual-PCA + Investigation")
    print("=" * 70)

    label_map, aux_map = load_labels()

    # === Investigate 中马矿 ===
    print("\n" + "=" * 70)
    print("INVESTIGATION: 中马矿中煤矿 (TE=359 unchanged)")
    print("=" * 70)
    data = load_coal_spectra(TRAIN_DIR, '中马矿中煤矿', label_map, aux_map)
    if data:
        investigate_coal('中马矿中煤矿', data)

    # Also investigate 赵固一矿 (worst TE)
    print("\n" + "=" * 70)
    print("INVESTIGATION: 赵固一矿豫焦末煤 (TE=375)")
    print("=" * 70)
    data = load_coal_spectra(TRAIN_DIR, '赵固一矿豫焦末煤', label_map, aux_map)
    if data:
        investigate_coal('赵固一矿豫焦末煤', data)

    results = {}

    # A. V39 baseline
    results['A_v39'] = run_config(
        label_map, aux_map, "A: V39 SNV PCA=30", spec_mode='snv', n_pca_max=30)

    # B. SNV + TW ALL + PCA=15 (combine marginal winners)
    results['B_snv_pca15_tw_all'] = run_config(
        label_map, aux_map, "B: SNV PCA=15 + TW ALL",
        spec_mode='snv', n_pca_max=15, time_weight_mode='all')

    # C. Per-coal norm (SNV for 3 coals, total for 2)
    results['C_per_coal_norm'] = run_config(
        label_map, aux_map, "C: Per-coal Norm",
        per_coal_norm=True, n_pca_max=30)

    # D. Per-coal norm + TW ALL
    results['D_per_coal_tw_all'] = run_config(
        label_map, aux_map, "D: Per-coal Norm + TW ALL",
        per_coal_norm=True, n_pca_max=30, time_weight_mode='all')

    # E. Dual-PCA (SNV-PCA + total-PCA concatenated)
    results['E_dual_pca'] = run_config(
        label_map, aux_map, "E: Dual-PCA",
        dual_pca=True, n_pca_max=30)

    # F. Dual-PCA + TW ALL
    results['F_dual_tw_all'] = run_config(
        label_map, aux_map, "F: Dual-PCA + TW ALL",
        dual_pca=True, n_pca_max=30, time_weight_mode='all')

    # G. Dual-PCA + PCA=15
    results['G_dual_pca15'] = run_config(
        label_map, aux_map, "G: Dual-PCA PCA=15",
        dual_pca=True, n_pca_max=15)

    # H. Per-coal norm + PCA=15 + TW ALL
    results['H_per_coal_pca15_tw_all'] = run_config(
        label_map, aux_map, "H: Per-coal PCA=15 + TW ALL",
        per_coal_norm=True, n_pca_max=15, time_weight_mode='all')

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    base_gk, base_te = results['A_v39']
    print(f"  {'config':35s}  {'GK':>8s}  {'TE':>8s}  {'dGK':>7s}  {'dTE':>7s}")
    for name, (gk, te) in results.items():
        print(f"  {name:35s}  {gk:8.2f}  {te:8.2f}  {gk-base_gk:+7.2f}  {te-base_te:+7.2f}")


if __name__ == "__main__":
    main()
