"""V26: 1D-CNN End-to-End -- 方向二: 替代手工特征+PCA+Ridge

基线: V19 Ridge(0.1)+PCA(30)+主元素窗口x5 -> GK=273.08, TE=240.20, 线上=250.64

思路: CNN自动学习哪些波长区域重要、如何提取特征、如何做非线性映射 -- 全部端到端优化。
      卷积核天然具有平移不变性, 对波长漂移有一定鲁棒性。

数据量:
  赵固一矿: 11 batches, 140 spectra (small)
  赵固二矿: 7 batches, 86 spectra (small)
  中马矿:   7 batches, 96 spectra (small)
  九里山矿: 18 batches, 262 spectra (large)
  煤场混煤: 27 batches, 360 spectra (large)

策略:
  1. 全煤种合并训练 (最大化数据量) -- 但煤种间Q范围差异大, 用煤种均值中心化
  2. 数据增强: 强度缩放+/-10%, 波长平移+/-2, 高斯噪声1%
  3. CNN架构: Conv1d(1,32,k=51) -> Conv1d(32,64,k=21) -> Conv1d(64,64,k=7) -> AvgPool -> FC
  4. 两阶段: Stage1 CNN预测aux -> Stage2 CNN预测Q
  5. Early stopping on TE-CV

  验证标准: 双重CV (GK + TE) 同时改善

运行: PYTHONPATH=/tmp/torch_install python exp_v26.py
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES, AUX_COLS,
)
from exp_v19 import label_map, aux_map, TIME_COALS, extract_month

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

torch.manual_seed(42)
np.random.seed(42)

DEVICE = torch.device('cpu')
SEQ_LEN = 7305


# ═══════════════════════════════════════════════════════════════════════════════
# Data preparation
# ═══════════════════════════════════════════════════════════════════════════════

def load_raw_spectra_matrix(coal):
    """Load raw spectra as (n, seq_len) float32 matrix + targets + groups + aux."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    spectra = np.array([s[1] for s in td['spectra']], dtype=np.float32)
    # Normalize per spectrum: divide by total intensity
    totals = spectra.sum(axis=1, keepdims=True) + 1e-8
    spectra = spectra / totals
    return {
        'X': spectra,
        'y': td['targets'].astype(np.float32),
        'aux': td['aux'].astype(np.float32),
        'groups': td['groups'],
        'names': np.array(td['names']),
        'n_batches': td['n_batches'],
    }


def augment_spectrum(spectrum, rng):
    """Apply random augmentation to a single spectrum."""
    # Random intensity scaling
    scale = rng.uniform(0.9, 1.1)
    spectrum = spectrum * scale
    # Random wavelength shift (±2 points)
    shift = rng.randint(-2, 3)
    spectrum = np.roll(spectrum, shift)
    # Random gaussian noise
    noise = rng.normal(0, 0.01 * spectrum.std(), spectrum.shape)
    spectrum = spectrum + noise
    return spectrum.astype(np.float32)


def prepare_cnn_data(data, augment=False, aug_factor=2, rng_seed=42):
    """Prepare data for CNN, optionally with augmentation."""
    X, y, aux, groups = data['X'], data['y'], data['aux'], data['groups']
    
    if not augment:
        return X, y, aux, groups
    
    rng = np.random.RandomState(rng_seed)
    X_aug = [X]
    y_aug = [y]
    aux_aug = [aux]
    groups_aug = [groups]
    
    for _ in range(aug_factor):
        X_new = np.array([augment_spectrum(x, rng) for x in X])
        X_aug.append(X_new)
        y_aug.append(y.copy())
        aux_aug.append(aux.copy())
        groups_aug.append(groups.copy())
    
    return (np.vstack(X_aug), np.concatenate(y_aug),
            np.vstack(aux_aug), np.concatenate(groups_aug))


# ═══════════════════════════════════════════════════════════════════════════════
# CNN Model
# ═══════════════════════════════════════════════════════════════════════════════

class LIBS_CNN(nn.Module):
    def __init__(self, seq_len=SEQ_LEN, n_aux=4, out_dim=1):
        super().__init__()
        self.conv = nn.Sequential(
            # Layer 1: large kernel for wide peaks
            nn.Conv1d(1, 32, kernel_size=51, padding=25),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.AvgPool1d(5),
            # Layer 2: medium kernel
            nn.Conv1d(32, 64, kernel_size=21, padding=10),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.AvgPool1d(5),
            # Layer 3: small kernel for fine structure
            nn.Conv1d(64, 64, kernel_size=7, padding=3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(16),
        )
        self.head = nn.Sequential(
            nn.Linear(64 * 16, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, out_dim)
        )

    def forward(self, x):
        # x: (batch, 1, seq_len)
        x = self.conv(x)
        x = x.flatten(1)
        return self.head(x).squeeze(-1)


def train_cnn(X_tr, y_tr, X_va=None, y_va=None,
              n_epochs=100, lr=1e-3, weight_decay=1e-3, patience=15,
              batch_size=32, verbose=False):
    """Train CNN, return model and best val prediction."""
    X_tr_t = torch.from_numpy(X_tr).float().unsqueeze(1).to(DEVICE)  # (N, 1, L)
    y_tr_t = torch.from_numpy(y_tr).float().to(DEVICE)
    
    train_ds = TensorDataset(X_tr_t, y_tr_t)
    train_dl = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    
    model = LIBS_CNN(seq_len=X_tr.shape[1]).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = nn.MSELoss()
    
    best_loss = float('inf')
    best_state = None
    no_improve = 0
    
    for epoch in range(n_epochs):
        model.train()
        for xb, yb in train_dl:
            optimizer.zero_grad()
            pred = model(xb)
            loss = criterion(pred, yb)
            loss.backward()
            optimizer.step()
        
        # Validation
        if X_va is not None and y_va is not None:
            model.eval()
            with torch.no_grad():
                X_va_t = torch.from_numpy(X_va).float().unsqueeze(1).to(DEVICE)
                y_va_t = torch.from_numpy(y_va).float().to(DEVICE)
                val_pred = model(X_va_t).cpu().numpy()
                val_loss = np.sqrt(np.mean((val_pred - y_va) ** 2))
            
            if val_loss < best_loss:
                best_loss = val_loss
                best_state = copy.deepcopy(model.state_dict())
                no_improve = 0
            else:
                no_improve += 1
            
            if verbose and epoch % 10 == 0:
                print(f"    Epoch {epoch}: train_loss={loss.item():.2f}, val_rmse={val_loss:.2f}")
            
            if no_improve >= patience:
                break
        else:
            # No validation set: save last
            best_state = copy.deepcopy(model.state_dict())
            best_loss = loss.item()
    
    if best_state is not None:
        model.load_state_dict(best_state)
    
    return model, best_loss


def predict_cnn(model, X):
    """Predict with trained CNN."""
    model.eval()
    with torch.no_grad():
        X_t = torch.from_numpy(X).float().unsqueeze(1).to(DEVICE)
        pred = model(X_t).cpu().numpy()
    return pred


# ═══════════════════════════════════════════════════════════════════════════════
# CV with CNN
# ═══════════════════════════════════════════════════════════════════════════════

def gkfold_cv_cnn(coal, augment=False, n_seeds=3, n_epochs=80):
    """GroupKFold CV with CNN. Only for large coals (too slow for small)."""
    data = load_raw_spectra_matrix(coal)
    if data is None:
        return None
    
    X, y, aux, groups, nb = data['X'], data['y'], data['aux'], data['groups'], data['n_batches']
    coal_mean = float(y.mean())
    
    if nb <= SMALL_BATCH_THRESHOLD:
        # For small samples: use LOOCV with CNN (fewer epochs, heavier augmentation)
        names_arr = data['names']
        splits = list(LeaveOneGroupOut().split(np.zeros(len(groups)), np.zeros(len(groups)), groups))
        all_op, all_ot = [], []
        for fold_i, (tr_idx, va_idx) in enumerate(splits):
            X_tr_raw, y_tr, aux_tr, groups_tr = prepare_cnn_data(
                {'X': X[tr_idx], 'y': y[tr_idx], 'aux': aux[tr_idx], 'groups': groups[tr_idx]},
                augment=augment, aug_factor=3, rng_seed=fold_i)
            
            # Standardize
            sc = StandardScaler()
            X_tr_sc = sc.fit_transform(X_tr_raw)
            X_va_sc = sc.transform(X[va_idx])
            
            model, _ = train_cnn(X_tr_sc, y_tr, X_va_sc, y[va_idx],
                                n_epochs=n_epochs, patience=10, batch_size=16)
            val_pred = predict_cnn(model, X_va_sc)
            # Batch aggregation
            vg = groups[va_idx]
            for bg in np.unique(vg):
                mk = vg == bg
                all_op.append(float(np.median(val_pred[mk])))
                all_ot.append(float(y[va_idx][mk][0]))
            print(f"    fold {fold_i+1}/{len(splits)} done", flush=True)
        
        w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            all_op, all_ot = [], []
            for fold_i, (tr_idx, va_idx) in enumerate(splits):
                X_tr_raw, y_tr, aux_tr, groups_tr = prepare_cnn_data(
                    {'X': X[tr_idx], 'y': y[tr_idx], 'aux': aux[tr_idx], 'groups': groups[tr_idx]},
                    augment=augment, aug_factor=2, rng_seed=s*100+fold_i)
                
                sc = StandardScaler()
                X_tr_sc = sc.fit_transform(X_tr_raw)
                X_va_sc = sc.transform(X[va_idx])
                
                model, _ = train_cnn(X_tr_sc, y_tr, X_va_sc, y[va_idx],
                                    n_epochs=n_epochs, patience=15, batch_size=32)
                val_pred = predict_cnn(model, X_va_sc)
                vg = groups[va_idx]
                for bg in np.unique(vg):
                    mk = vg == bg
                    all_op.append(float(np.median(val_pred[mk])))
                    all_ot.append(float(y[va_idx][mk][0]))
                print(f"    seed {s} fold {fold_i+1}/5 done", flush=True)
            
            w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_cnn(coal, augment=False, n_epochs=80):
    """Time extrapolation CV with CNN."""
    data = load_raw_spectra_matrix(coal)
    if data is None:
        return None
    
    X, y, aux, groups, nb = data['X'], data['y'], data['aux'], data['groups'], data['n_batches']
    names_arr = data['names']
    
    # Time split
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g
        idx = np.where(mk)[0][0]
        bm[g] = extract_month(names_arr[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    
    X_tr_raw, y_tr, aux_tr, groups_tr = prepare_cnn_data(
        {'X': X[tm], 'y': y[tm], 'aux': aux[tm], 'groups': groups[tm]},
        augment=augment, aug_factor=3, rng_seed=42)
    
    sc = StandardScaler()
    X_tr_sc = sc.fit_transform(X_tr_raw)
    X_va_sc = sc.transform(X[vm])
    
    model, _ = train_cnn(X_tr_sc, y_tr, X_va_sc, y[vm],
                        n_epochs=n_epochs, patience=15, batch_size=32)
    val_pred = predict_cnn(model, X_va_sc)
    
    coal_mean = float(y[tm].mean())
    vg2 = groups[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(val_pred[mk_])))
        bt.append(float(y[vm][mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def run_config(name, augment=False, n_seeds=3, n_epochs=80):
    t0 = time.time()
    print(f"\n{'=' * 55}\n  {name}\n{'=' * 55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        print(f"  Training GK [{coal}]...", flush=True)
        r = gkfold_cv_cnn(coal, augment=augment, n_seeds=n_seeds, n_epochs=n_epochs)
        if r is None:
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        print(f"  Training TE [{coal}]...", flush=True)
        r = time_ext_cnn(coal, augment=augment, n_epochs=n_epochs)
        if r is None:
            continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time() - t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # CNN without augmentation (quick test)
    results['cnn_no_aug'] = run_config(
        "CNN (no aug, 3 seeds, 80 epochs)", augment=False, n_seeds=3, n_epochs=80)

    # CNN with augmentation
    results['cnn_aug'] = run_config(
        "CNN (aug, 3 seeds, 80 epochs)", augment=True, n_seeds=3, n_epochs=80)

    # Summary
    print(f"\n{'=' * 60}")
    print("  V26: 1D-CNN -- Dual CV Summary")
    print(f"{'=' * 60}")
    print(f"  V19 baseline: GK=273.08, TE=240.20, online=250.64")
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  verdict")
    for name, val in results.items():
        if val is None:
            continue
        gk_ok = "B" if val['gk'] < 273.0 else "W"
        te_ok = "B" if val['te'] < 240.0 else "W"
        both = " **DOUBLE**" if val['gk'] < 273.0 and val['te'] < 240.0 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_ok}/{te_ok}{both}")
