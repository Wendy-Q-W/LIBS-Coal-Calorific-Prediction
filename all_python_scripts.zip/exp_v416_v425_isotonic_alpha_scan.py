"""
exp_v416_v425_isotonic_alpha_scan.py
Key insight: isotonic calibration reduces gap by 6-10 vs linear.
V221(a=0.03, linear): CV=164, gap=38, online=202.62
If a=0.03 isotonic has gap≈28-32, online≈192-196 -> breaks 197!

Scan alpha values with isotonic calibration to find the sweet spot.
Also verify V166 = V73 (both a=0.03 isotonic).
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exp_v260_v270_tree_models import run_experiment

if __name__ == '__main__':
    experiments = [
        # Isotonic with various alpha values
        ('v416_iso_a002', 0.02, 'isotonic',
         'Ridge a=0.02 + isotonic. Lower alpha = lower CV but potentially higher gap.'),
        ('v417_iso_a003', 0.03, 'isotonic',
         'Ridge a=0.03 + isotonic. Same as V166/V73. Key candidate!'),
        ('v418_iso_a004', 0.04, 'isotonic',
         'Ridge a=0.04 + isotonic.'),
        ('v419_iso_a006', 0.06, 'isotonic',
         'Ridge a=0.06 + isotonic.'),
        ('v420_iso_a008', 0.08, 'isotonic',
         'Ridge a=0.08 + isotonic.'),
        ('v421_iso_a012', 0.12, 'isotonic',
         'Ridge a=0.12 + isotonic. Higher than V63(a=0.1).'),
        ('v422_iso_a015', 0.15, 'isotonic',
         'Ridge a=0.15 + isotonic. Much higher alpha.'),
        ('v423_iso_a020', 0.20, 'isotonic',
         'Ridge a=0.20 + isotonic.'),
        ('v424_iso_a030', 0.30, 'isotonic',
         'Ridge a=0.30 + isotonic.'),
        ('v425_iso_a050', 0.50, 'isotonic',
         'Ridge a=0.50 + isotonic. Very high alpha.'),
    ]

    results = {}
    for vid, alpha, calib, desc in experiments:
        _, cv = run_experiment(
            vid, desc,
            ridge_alpha=alpha,
            calibration=calib,
            preprocessing='snv',
            use_pca=True,
        )
        results[vid] = cv
        print(f"  CV={cv:.2f}")

    print(f"\n{'='*70}")
    print("  SUMMARY")
    print(f"{'='*70}")
    for vid, cv in results.items():
        print(f"  {vid:25s}  CV={cv:.2f}")
