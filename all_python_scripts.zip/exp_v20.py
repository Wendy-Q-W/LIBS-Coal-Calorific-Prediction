"""V20: 在V19窗口基础上探索新特征方向
基线: V19 main=5.0,metal=1.0 → GK=273.08, TE=240.19
方向:
  P1: 峰值特征 (peak height, prominence, FWHM) 补充积分特征
  P2: 多尺度窗口 (同时用窄窗口+宽窗口积分)
  P3: 基线校正 (多项式/滚动最小值)
  P4: PCA重新调优 (新窗口下的最优PCA)
  P5: 连续谱斜率特征
  P6: alpha微调 (新特征下alpha=0.1是否仍最优)
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.signal import peak_widths, peak_prominences
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    KEY_LINES as KEY_LINES_V19, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, N_PCA_MAX,
)
from exp_v19 import (
    compute_features_custom, build_fm, oof_ridge, run_config,
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
)

# V19 最优窗口配置 (已在all.py中)
KEY_LINES = KEY_LINES_V19  # main=5.0, metal=1.0


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def extract_peak_features(wl, inten, center_nm, halfwin_nm):
    """提取窗口内的峰值特征: 峰高、峰面积(积分)、FWHM、prominence"""
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    if mask.sum() < 3:
        return 0.0, 0.0, 0.0, 0.0
    w_wl = wl[mask]
    w_int = inten[mask]
    peak_idx = np.argmax(w_int)
    peak_height = float(w_int[peak_idx])
    # prominence approximation: peak - min(window)
    baseline_est = float(np.percentile(w_int, 10))
    prominence = peak_height - baseline_est
    # FWHM approximation
    half_max = baseline_est + prominence / 2
    above = w_int >= half_max
    if above.sum() >= 2:
        idx_above = np.where(above)[0]
        fwhm_nm = float(w_wl[idx_above[-1]] - w_wl[idx_above[0]])
    else:
        fwhm_nm = 0.0
    integral = float(w_int.sum())
    return peak_height, prominence, fwhm_nm, integral


def spectrum_features_v20(wl, inten, key_lines, feature_mode='v19'):
    """V20特征: 在V19基础上增加峰值/多尺度/基线校正特征"""
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)

    # 基础统计 (与V19相同)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)),
        float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)

    # 谱线积分 (V19窗口)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in key_lines.items()],
        dtype=np.float32
    )
    lrel = labs / total

    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum,
        labs[1] / ash_sum,
        labs[0] / ash_sum,
        labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)

    extra_feats = []

    if feature_mode == 'peak':
        # P1: 峰值特征 (每条线: peak_height, prominence, fwhm)
        for _, (c, h) in key_lines.items():
            ph, pr, fw, _ = extract_peak_features(wl, inten, c, h)
            extra_feats.extend([ph, pr, fw])
    elif feature_mode == 'multiscale':
        # P2: 多尺度窗口 (同时用原始窄窗口+V19宽窗口)
        narrow_lines = {
            'C':   (247.86, 2.0),
            'H':   (656.3,  3.0),
            'O':   (777.2,  3.0),
            'N':   (742.4,  2.0),
            'Ca':  (422.7,  2.0),
            'Ca2': (393.4,  2.0),
            'Mg':  (285.2,  2.0),
            'Al':  (308.2,  2.0),
            'Si':  (288.2,  2.0),
            'Fe':  (438.4,  3.0),
            'Na':  (589.0,  1.5),
        }
        for _, (c, h) in narrow_lines.items():
            extra_feats.append(line_integral(wl, inten, c, h))
    elif feature_mode == 'baseline':
        # P3: 基线校正后的谱线积分
        # 简单基线: 每个波长点取前后窗口的最小值
        win_size = max(5, len(inten) // 200)
        baseline = np.minimum.accumulate(inten)
        baseline2 = np.minimum.accumulate(inten[::-1])[::-1]
        baseline = np.minimum(baseline, baseline2)
        inten_bs = inten - baseline
        inten_bs = np.maximum(inten_bs, 0)
        for _, (c, h) in key_lines.items():
            extra_feats.append(line_integral(wl, inten_bs, c, h))
    elif feature_mode == 'slope':
        # P5: 连续谱斜率特征
        # 将光谱分成10段, 计算每段均值, 再算斜率
        n_seg = 10
        seg_size = len(inten) // n_seg
        seg_means = [inten[i*seg_size:(i+1)*seg_size].mean() for i in range(n_seg)]
        seg_means = np.array(seg_means)
        # 相邻段比值
        for i in range(n_seg - 1):
            extra_feats.append(seg_means[i+1] / (seg_means[i] + 1e-8))
        # 整体斜率
        x = np.arange(n_seg)
        slope = np.polyfit(x, seg_means, 1)[0]
        extra_feats.append(float(slope))

    extra = np.array(extra_feats, dtype=np.float32) if extra_feats else np.array([], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats, extra


def compute_features_v20(data, key_lines=None, feature_mode='v19'):
    if key_lines is None:
        key_lines = KEY_LINES
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list, extra_list = [], [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats, extra = spectrum_features_v20(wl, inten, key_lines, feature_mode)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
        extra_list.append(extra)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data2 = copy.copy(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    if extra_list and len(extra_list[0]) > 0:
        data2['extra'] = np.array(extra_list)
    else:
        data2['extra'] = None
    return inorm_mat, data2


def build_fm_v20(inorm_mat, hand_feats, extra_feats, n_batches, n_pca_max=30):
    sc = StandardScaler(); ss = sc.fit_transform(inorm_mat)
    n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp = pca.fit_transform(ss)
    parts = [sp, hand_feats]
    if extra_feats is not None and extra_feats.shape[1] > 0:
        parts.append(extra_feats)
    X = np.hstack(parts)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    sh = StandardScaler(); X = sh.fit_transform(X)
    return X


def oof_ridge_v20(X, y, aux, groups, splits, alpha):
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = Ridge(alpha=alpha)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = Ridge(alpha=alpha)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


def gkfold_cv_v20(coal, n_pca_max=30, key_lines=None, feature_mode='v19', alpha=0.1, n_seeds=10):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_v20(td, key_lines, feature_mode)
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    extra = td2.get('extra', None)
    X = build_fm_v20(inorm_mat, hand_feats, extra, nb, n_pca_max)
    coal_mean = float(y.mean())
    is_small = nb <= SMALL_BATCH_THRESHOLD
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge_v20(X, y, aux, groups, splits, alpha)
        w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge_v20(X, y, aux, groups, splits, alpha)
            w, cv_sh = find_best_shrinkage(op, ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': np.mean(all_sh), 'w': w, 'small': False}


def time_ext_v20(coal, n_pca_max=30, key_lines=None, feature_mode='v19', alpha=0.1):
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None: return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    inorm_mat, td2 = compute_features_v20(td, key_lines, feature_mode)
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    extra = td2.get('extra', None)
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1: return None
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    n_pca = min(n_pca_max, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    parts_tr = [sp_tr, hand_feats[tm]]
    parts_va = [sp_va, hand_feats[vm]]
    if extra is not None and extra.shape[1] > 0:
        parts_tr.append(extra[tm])
        parts_va.append(extra[vm])
    X_tr = np.hstack(parts_tr); X_va = np.hstack(parts_va)
    X_tr = np.nan_to_num(X_tr); X_va = np.nan_to_num(X_va)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr); X_va = sc_all.transform(X_va)
    coal_mean = float(y[tm].mean())
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm])); continue
        m1 = Ridge(alpha=alpha); m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr); pa_va[:, ci] = m1.predict(X_va)
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr); X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=alpha); m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)
    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(vy[mk_][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def run_config_v20(name, n_pca_max=30, key_lines=None, feature_mode='v19', alpha=0.1):
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_v20(coal, n_pca_max=n_pca_max, key_lines=key_lines,
                          feature_mode=feature_mode, alpha=alpha)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = np.mean(gk_all) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_v20(coal, n_pca_max=n_pca_max, key_lines=key_lines,
                         feature_mode=feature_mode, alpha=alpha)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = np.mean(te_all) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # ── 基线 (V19配置) ──
    results['baseline'] = run_config_v20("V19基线", feature_mode='v19')

    # ── P1: 峰值特征 ──
    results['peak'] = run_config_v20("峰值特征(峰高/prominence/FWHM)", feature_mode='peak')

    # ── P2: 多尺度窗口 ──
    results['multiscale'] = run_config_v20("多尺度窗口(窄+宽)", feature_mode='multiscale')

    # ── P3: 基线校正 ──
    results['baseline_corr'] = run_config_v20("基线校正后积分", feature_mode='baseline')

    # ── P4: 连续谱斜率 ──
    results['slope'] = run_config_v20("连续谱斜率", feature_mode='slope')

    # ── P5: PCA重新调优 (V19窗口下) ──
    for npc in [20, 25, 35, 40, 50]:
        results[f'PCA({npc})'] = run_config_v20(
            f"PCA({npc})", n_pca_max=npc, feature_mode='v19')

    # ── P6: alpha微调 (V19特征下) ──
    for alpha in [0.03, 0.05, 0.2, 0.5]:
        results[f'alpha={alpha}'] = run_config_v20(
            f"alpha={alpha}", feature_mode='v19', alpha=alpha)

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V20: 新特征方向探索")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':25s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:25s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
