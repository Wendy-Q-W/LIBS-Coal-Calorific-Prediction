"""V21c: 精调Ca3+Ti+Sr新线窗口宽度 + 种子稳定性验证
最优候选: +Ca3(396.5)+Ti(335.0)+Sr(408.0) → GK-1.84, TE-8.52
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from all import KEY_LINES as KEY_LINES_V19
from exp_v20 import run_config_v20, gkfold_cv_v20, time_ext_v20
from exp_v21 import make_extended_lines


def make_new_lines(ca3_w, ti_w, sr_w):
    return {
        'Ca3': (396.5, ca3_w),
        'Ti':  (335.0, ti_w),
        'Sr':  (408.0, sr_w),
    }


if __name__ == "__main__":
    results = {}

    # 基线
    results['baseline'] = run_config_v20("V19基线", feature_mode='v19')

    # ── P1: 新线窗口宽度扫描 (全部相同) ──
    for w in [1.0, 2.0, 3.0, 5.0, 8.0, 10.0]:
        kl = make_extended_lines(make_new_lines(w, w, w))
        results[f'new_win={w}'] = run_config_v20(
            f"Ca3+Ti+Sr win={w}", key_lines=kl, feature_mode='v19')

    # ── P2: 逐线窗口差异 ──
    # Ti最重要, 试不同窗口
    for tw in [1.0, 3.0, 5.0, 8.0]:
        kl = make_extended_lines(make_new_lines(2.0, tw, 2.0))
        results[f'Ti_w={tw}'] = run_config_v20(
            f"Ca3=2,Ti={tw},Sr=2", key_lines=kl, feature_mode='v19')

    # Ca3窗口
    for cw in [1.0, 3.0, 5.0]:
        kl = make_extended_lines(make_new_lines(cw, 2.0, 2.0))
        results[f'Ca3_w={cw}'] = run_config_v20(
            f"Ca3={cw},Ti=2,Sr=2", key_lines=kl, feature_mode='v19')

    # Sr窗口
    for sw in [1.0, 3.0, 5.0]:
        kl = make_extended_lines(make_new_lines(2.0, 2.0, sw))
        results[f'Sr_w={sw}'] = run_config_v20(
            f"Ca3=2,Ti=2,Sr={sw}", key_lines=kl, feature_mode='v19')

    # ── P3: 最优组合 + PCA微调 ──
    # 先用默认win=2.0测几个PCA
    best_kl = make_extended_lines(make_new_lines(2.0, 2.0, 2.0))
    for npc in [25, 35, 40]:
        results[f'best+PCA({npc})'] = run_config_v20(
            f"Ca3+Ti+Sr+PCA({npc})", n_pca_max=npc,
            key_lines=best_kl, feature_mode='v19')

    # ── P4: 最优组合 + alpha微调 ──
    for alpha in [0.05, 0.2]:
        results[f'best+alpha={alpha}'] = run_config_v20(
            f"Ca3+Ti+Sr+alpha={alpha}", alpha=alpha,
            key_lines=best_kl, feature_mode='v19')

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V21c: Ca3+Ti+Sr窗口精调")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
