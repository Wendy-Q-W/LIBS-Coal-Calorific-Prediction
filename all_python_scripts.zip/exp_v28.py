"""V28: Time-Weighted Samples + Time-Series CV -- 方向一/三

基线: V19 Ridge(0.1)+PCA(30)+主元素窗口x5 -> GK=273.08, TE=240.20, 线上=250.64

方向三 (Time-Weighted): 给训练样本按时间距离赋予权重
  - 指数衰减: weights = exp(-time_diff / tau)
  - tau越大越接近等权(退化为V19), tau越小越偏向近期
  - 扫描 tau ∈ {14, 30, 60, 90, 180}

方向一 (Time-Series CV): 用时间外推CV选超参数
  - Leave-One-Time-Block-Out: 按时间排序, 每次留一个时间块做验证
  - 用这个CV的得分选Ridge alpha和PCA n_components
  - 验证: 选出的参数在双重CV上是否改善

验证标准: 双重CV (GK不恶化 + TE改善)
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    N_PCA_MAX, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage, KEY_LINES,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
    extract_month, compute_features_custom, build_fm, oof_ridge,
)


def get_time_info(td):
    """Extract time info from training data.
    
    Returns dict with:
      - months: array of month for each sample
      - batch_months: dict batch_id -> month
    """
    names_arr = np.array(td['names'])
    groups = td['groups']
    months = np.zeros(len(groups), dtype=int)
    batch_months = {}
    for g in np.unique(groups):
        mk = groups == g
        idx = np.where(mk)[0][0]
        m = extract_month(names_arr[idx])
        months[mk] = m
        batch_months[g] = m
    return {'months': months, 'batch_months': batch_months}


def compute_time_weights(train_months, val_month, tau=30, circular=True):
    """Compute exponential decay weights for training samples.
    
    Closer in time to val -> higher weight.
    circular=True: use circular month distance (fixes Oct->Feb direction bug)
    """
    diff = np.abs(train_months - val_month)
    if circular:
        diff = np.minimum(diff, 12 - diff)  # circular month distance
    time_diff = diff * 30  # approximate days (month*30)
    weights = np.exp(-time_diff / tau)
    # Normalize: average weight = 1
    weights = weights / weights.mean()
    return weights


def oof_ridge_weighted(X, y, aux, groups, splits, alpha, sample_weights_fn=None):
    """OOF Ridge with optional sample weights.
    
    sample_weights_fn: function(tr_idx) -> weights array, or None.
    If provided, weights are used in Ridge.fit for both stage1 and stage2.
    """
    op, ot = [], []
    for tr, va in splits:
        sw = None
        if sample_weights_fn is not None:
            sw = sample_weights_fn(tr)
        
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = Ridge(alpha=alpha)
            if sw is not None:
                m1.fit(X[tr], ya[tr], sample_weight=sw)
            else:
                m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = Ridge(alpha=alpha)
        if sw is not None:
            m2.fit(X2t, y[tr], sample_weight=sw)
        else:
            m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


# ═══════════════════════════════════════════════════════════════════════════════
# Direction 3: Time-Weighted
# ═══════════════════════════════════════════════════════════════════════════════

def gkfold_cv_timeweight(coal, tau=30, n_seeds=10, circular=True):
    """GroupKFold CV with time-weighted sample weights."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    X = build_fm(inorm_mat, hand_feats, nb)
    coal_mean = float(y.mean())
    
    ti = get_time_info(td)
    months = ti['months']
    
    is_small = nb <= SMALL_BATCH_THRESHOLD
    
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        all_op, all_ot = [], []
        for tr, va in splits:
            val_batch = groups[va][0]
            val_month = ti['batch_months'][val_batch]
            def _wfn(tr_idx, _vm=val_month, _tau=tau, _circ=circular):
                return compute_time_weights(months[tr_idx], _vm, tau=_tau, circular=_circ)
            op, ot = oof_ridge_weighted(X, y, aux, groups, [(tr, va)], RIDGE_ALPHA, sample_weights_fn=_wfn)
            all_op.extend(op)
            all_ot.extend(ot)
        w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
        return {'sh': cv_sh, 'w': w, 'small': True}
    else:
        all_sh = []
        for s in range(n_seeds):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            all_op, all_ot = [], []
            for tr, va in splits:
                val_months = months[va]
                val_month = float(np.median(val_months))
                def _wfn(tr_idx, _vm=val_month, _tau=tau, _circ=circular):
                    return compute_time_weights(months[tr_idx], _vm, tau=_tau, circular=_circ)
                op, ot = oof_ridge_weighted(X, y, aux, groups, [(tr, va)], RIDGE_ALPHA, sample_weights_fn=_wfn)
                all_op.extend(op)
                all_ot.extend(ot)
            w, cv_sh = find_best_shrinkage(all_op, all_ot, coal_mean)
            all_sh.append(cv_sh)
        return {'sh': float(np.mean(all_sh)), 'w': w, 'small': False}


def time_ext_timeweight(coal, tau=30, circular=True):
    """Time extrapolation CV with time-weighted sample weights."""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']
    names_arr = np.array(names)
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    ti = get_time_info(td)
    months = ti['months']
    
    ub = np.unique(groups)
    bm = ti['batch_months']
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None
    
    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])
    
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_mat[tm])
    spec_va = sc.transform(inorm_mat[vm])
    n_pca = min(N_PCA_MAX, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)
    
    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)
    
    # Time weights: val month = median of val months
    val_month = float(np.median(months[vm]))
    # For val months (1,2,3), training months (10,11) -> diff in days
    # 10->1 = ~90 days, 11->1 = ~60 days, 10->3 = ~150 days, 11->3 = ~120 days
    sw = compute_time_weights(months[tm], val_month, tau=tau, circular=circular)
    
    coal_mean = float(y[tm].mean())
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(X_tr, ya[tm], sample_weight=sw)
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)
    
    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)
    m2 = Ridge(alpha=RIDGE_ALPHA)
    m2.fit(X2_tr, y[tm], sample_weight=sw)
    vp = m2.predict(X2_va)
    
    vg2 = groups[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk_ = vg2 == bg
        bp.append(float(np.median(vp[mk_])))
        bt.append(float(y[vm][mk_][0]))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)
    return {'sh': cv_sh, 'w': w}


# ═══════════════════════════════════════════════════════════════════════════════
# Direction 1: Time-Series CV for hyperparameter selection
# ═══════════════════════════════════════════════════════════════════════════════

def time_series_cv_select(coal, alpha_candidates=None, pca_candidates=None):
    """Use Time-Series CV (Leave-One-Time-Block-Out) to select hyperparameters.
    
    Splits data into time blocks, trains on earlier blocks, validates on later.
    Selects alpha and n_pca that minimize time-series CV RMSE.
    """
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux = td['aux']
    inorm_mat, td2 = compute_features_custom(td, KEY_LINES, 'total')
    hand_feats = np.hstack([td2['stats'], td2['labs'], td2['lrel'], td2['rats']])
    ti = get_time_info(td)
    batch_months = ti['batch_months']
    
    # Create time-ordered blocks: sort unique batches by month
    ub = np.unique(groups)
    batch_month_list = [(g, batch_months[g]) for g in ub]
    batch_month_list.sort(key=lambda x: x[1])
    
    # Assign time block IDs: group batches into blocks by time order
    # For small coals (7-11 batches): use 3 blocks (train on 1st, val on 2nd+3rd)
    # For large coals: use 5 blocks
    n_blocks = min(5, max(3, len(ub) // 3))
    block_size = len(batch_month_list) // n_blocks
    time_blocks = np.zeros(len(groups), dtype=int)
    for i, (g, m) in enumerate(batch_month_list):
        block_id = min(i // block_size, n_blocks - 1)
        time_blocks[groups == g] = block_id
    
    # Forward-chaining CV: train on blocks 0..t-1, val on block t
    alpha_candidates = alpha_candidates or [0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0]
    pca_candidates = pca_candidates or [10, 15, 20, 25, 30]
    
    best_score = float('inf')
    best_alpha = RIDGE_ALPHA
    best_pca = N_PCA_MAX
    
    for alpha in alpha_candidates:
        for n_pca_max in pca_candidates:
            all_preds, all_targets = [], []
            for t in range(1, n_blocks):
                tr = time_blocks < t
                va = time_blocks == t
                if tr.sum() == 0 or va.sum() == 0:
                    continue
                
                sc = StandardScaler()
                spec_tr = sc.fit_transform(inorm_mat[tr])
                spec_va = sc.transform(inorm_mat[va])
                n_pca = min(n_pca_max, spec_tr.shape[0] - 1, spec_tr.shape[1])
                pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
                sp_tr = pca.fit_transform(spec_tr)
                sp_va = pca.transform(spec_va)
                
                X_tr = np.hstack([sp_tr, hand_feats[tr]])
                X_va = np.hstack([sp_va, hand_feats[va]])
                X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
                X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)
                sc_all = StandardScaler()
                X_tr = sc_all.fit_transform(X_tr)
                X_va = sc_all.transform(X_va)
                
                pa_tr = np.zeros((tr.sum(), aux.shape[1]), dtype=np.float32)
                pa_va = np.zeros((va.sum(), aux.shape[1]), dtype=np.float32)
                for ci in range(aux.shape[1]):
                    ya = aux[:, ci]
                    if np.isnan(ya).any():
                        pa_tr[:, ci] = float(np.nanmean(ya[tr]))
                        pa_va[:, ci] = float(np.nanmean(ya[tr]))
                        continue
                    m1 = Ridge(alpha=alpha)
                    m1.fit(X_tr, ya[tr])
                    pa_tr[:, ci] = m1.predict(X_tr)
                    pa_va[:, ci] = m1.predict(X_va)
                
                X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
                X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
                m2 = Ridge(alpha=alpha)
                m2.fit(X2_tr, y[tr])
                vp = m2.predict(X2_va)
                vg = groups[va]
                for bg in np.unique(vg):
                    mk = vg == bg
                    all_preds.append(float(np.median(vp[mk])))
                    all_targets.append(float(y[va][mk][0]))
            
            if len(all_preds) == 0:
                continue
            rmse = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(all_targets, all_preds)])))
            if rmse < best_score:
                best_score = rmse
                best_alpha = alpha
                best_pca = n_pca_max
    
    return {'alpha': best_alpha, 'n_pca': best_pca, 'score': best_score}


# ═══════════════════════════════════════════════════════════════════════════════
# Run helpers
# ═══════════════════════════════════════════════════════════════════════════════

def run_timeweight(name, tau=30):
    t0 = time.time()
    print(f"\n{'='*55}\n  {name}\n{'='*55}", flush=True)
    gk_all = []
    for coal in COAL_TYPES:
        r = gkfold_cv_timeweight(coal, tau=tau)
        if r is None: continue
        tag = 'small' if r['small'] else 'large'
        print(f"  GK [{coal}] sh={r['sh']:.2f} w={r['w']:.2f} ({tag})", flush=True)
        gk_all.append(r['sh'])
    gk_avg = float(np.mean(gk_all)) if gk_all else 0
    te_all = []
    for coal in TIME_COALS:
        r = time_ext_timeweight(coal, tau=tau)
        if r is None: continue
        print(f"  TE [{coal}] sh={r['sh']:.1f} w={r['w']:.2f}", flush=True)
        te_all.append(r['sh'])
    te_avg = float(np.mean(te_all)) if te_all else 0
    print(f"  >> GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return {'gk': gk_avg, 'te': te_avg}


if __name__ == "__main__":
    results = {}

    # Baseline
    results['baseline'] = {'gk': 273.08, 'te': 240.20}
    print("  baseline: GK=273.08, TE=240.20 (V19, known)")

    # ── Direction 3: Time-Weighted ──
    for tau in [14, 30, 60, 90, 180]:
        results[f'tw_tau{tau}'] = run_timeweight(f"Time-Weighted tau={tau}", tau=tau)

    # ── Direction 1: Time-Series CV hyperparameter selection ──
    print(f"\n{'='*55}\n  Time-Series CV Hyperparameter Selection\n{'='*55}", flush=True)
    for coal in COAL_TYPES:
        r = time_series_cv_select(coal)
        if r is None: continue
        print(f"  [{coal}] -> alpha={r['alpha']}, n_pca={r['n_pca']}, score={r['score']:.1f}", flush=True)

    # ── Summary ──
    print(f"\n{'='*60}")
    print("  V28: Time-Weighted + Time-Series CV -- Dual CV Summary")
    print(f"{'='*60}")
    base_gk = results['baseline']['gk']
    base_te = results['baseline']['te']
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None or 'gk' not in val: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
