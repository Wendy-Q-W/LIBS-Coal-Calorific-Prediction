"""V17: 三个优化方向在时间外推CV上的对比实验 (Ridge基线)
方向1: RobustScaler 替代 StandardScaler
方向2: 中位数收缩 / 动态局部收缩
方向3: SelectKBest 替代 PCA
基线: RidgeCV + StandardScaler + PCA + 均值收缩 (= V11b)
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_regression
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()
TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def build_fm(data, n_batches, scaler_type='standard', dim_type='pca',
             y_for_select=None, n_pca_max=30, n_kbest=50):
    """构建特征矩阵，支持 scaler_type 和 dim_type 切换。"""
    inorm_mat = compute_features(data)

    if scaler_type == 'robust':
        sc = RobustScaler(quantile_range=(25.0, 75.0))
    else:
        sc = StandardScaler()
    ss = sc.fit_transform(inorm_mat)

    if dim_type == 'pca':
        n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        sp = pca.fit_transform(ss)
    elif dim_type == 'kbest':
        if y_for_select is None:
            n_pca = min(n_pca_max, n_batches - 1, ss.shape[0] - 1)
            pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
            sp = pca.fit_transform(ss)
        else:
            k = min(n_kbest, ss.shape[1], ss.shape[0] - 1)
            selector = SelectKBest(f_regression, k=k)
            sp = selector.fit_transform(ss, y_for_select)
    else:
        sp = ss

    hf = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([sp, hf])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if scaler_type == 'robust':
        sh = RobustScaler(quantile_range=(25.0, 75.0))
    else:
        sh = StandardScaler()
    X = sh.fit_transform(X)
    return X


def oof_ridge(X, y, aux, groups, splits):
    """RidgeCV OOF"""
    op, ot = [], []
    for tr, va in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya)); continue
            m1 = RidgeCV(alphas=ALPHAS)
            m1.fit(X[tr], ya[tr])
            pa[va, ci] = m1.predict(X[va])
        X2t = np.nan_to_num(np.hstack([X[tr], pa[tr]]))
        X2v = np.nan_to_num(np.hstack([X[va], pa[va]]))
        m2 = RidgeCV(alphas=ALPHAS)
        m2.fit(X2t, y[tr])
        vp = m2.predict(X2v); vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            op.append(float(np.median(vp[mk]))); ot.append(float(y[va][mk][0]))
    return op, ot


def time_ext(coal, scaler_type='standard', dim_type='pca',
             shrink_mode='mean', n_kbest=50):
    """时间外推CV评估。

    shrink_mode:
      'mean'   - 训练集均值收缩 (基线)
      'median' - 训练集中位数收缩
      'local'  - 测试预测局部均值收缩
      'none'   - 不收缩 (raw)
    """
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']

    if shrink_mode == 'median':
        coal_target = float(np.median(y))
    else:
        coal_target = float(y.mean())

    X = build_fm(td, nb, scaler_type=scaler_type, dim_type=dim_type,
                 y_for_select=y if dim_type == 'kbest' else None,
                 n_kbest=n_kbest)

    is_small = nb <= SMALL_BATCH_THRESHOLD

    # 搜 w (用5种子)
    if is_small:
        d = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(d, d, groups))
        op, ot = oof_ridge(X, y, aux, groups, splits)
        w, _ = find_best_shrinkage(op, ot, coal_target)
    else:
        ws = []
        for s in range(5):
            d = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=s)
            splits = list(gkf.split(d, d, groups))
            op, ot = oof_ridge(X, y, aux, groups, splits)
            w_s, _ = find_best_shrinkage(op, ot, coal_target)
            ws.append(w_s)
        w = float(np.mean(ws))

    # 时间外推: 10/11月训 → 1/2/3月验
    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return {'w': w, 'cm': coal_target, 'small': is_small, 'no_split': True}

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya)); continue
        m1 = RidgeCV(alphas=ALPHAS)
        m1.fit(X[tm], ya[tm])
        pa[:, ci] = m1.predict(X)

    X2 = np.nan_to_num(np.hstack([X, pa]))
    sc = StandardScaler(); X2 = sc.fit_transform(X2)
    m2 = RidgeCV(alphas=ALPHAS)
    m2.fit(X2[tm], y[tm])
    vp = m2.predict(X2[vm])

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk]))); bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))

    if shrink_mode == 'local':
        local_mean = float(np.mean(bp))
        bl = [w * p + (1 - w) * local_mean for p in bp]
    elif shrink_mode == 'none':
        bl = bp
    else:
        bl = [w * p + (1 - w) * coal_target for p in bp]
    cv_sh = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bl)])))
    return {
        'cv_raw': cv_raw, 'cv_sh': cv_sh, 'w': w,
        'cm': coal_target, 'small': is_small,
    }


def run(name, scaler_type='standard', dim_type='pca', shrink_mode='mean', n_kbest=50):
    t0 = time.time()
    print(f"\n{'=' * 55}")
    print(f"  {name}")
    print(f"{'=' * 55}", flush=True)
    all_raw, all_sh = [], []
    for coal in TIME_COALS:
        r = time_ext(coal, scaler_type=scaler_type, dim_type=dim_type,
                     shrink_mode=shrink_mode, n_kbest=n_kbest)
        if r is None or r.get('no_split'):
            continue
        tag = 'small' if r['small'] else 'large'
        print(f"  [{coal}] ({tag}) raw={r['cv_raw']:.1f} shrunk={r['cv_sh']:.1f} "
              f"w={r['w']:.2f}", flush=True)
        all_raw.append(r['cv_raw'])
        all_sh.append(r['cv_sh'])
    if all_sh:
        avg_raw = np.mean(all_raw)
        avg_sh = np.mean(all_sh)
        print(f"  >> avg raw={avg_raw:.2f}  shrunk={avg_sh:.2f}  ({time.time() - t0:.0f}s)", flush=True)
        return {'raw': avg_raw, 'shrunk': avg_sh}
    return None


if __name__ == "__main__":
    results = {}

    # ── 基线 (V11b Ridge) ──
    results['baseline'] = run(
        "基线: Ridge + StdScaler + PCA + 均值收缩 (V11b)",
        scaler_type='standard', dim_type='pca', shrink_mode='mean')

    # ── 方向1: RobustScaler ──
    results['robust'] = run(
        "方向1: RobustScaler 替代 StandardScaler",
        scaler_type='robust', dim_type='pca', shrink_mode='mean')

    # ── 方向2a: 中位数收缩 ──
    results['median_shrink'] = run(
        "方向2a: 中位数收缩 (coal_mean=median)",
        scaler_type='standard', dim_type='pca', shrink_mode='median')

    # ── 方向2b: 局部均值收缩 ──
    results['local_shrink'] = run(
        "方向2b: 动态局部均值收缩",
        scaler_type='standard', dim_type='pca', shrink_mode='local')

    # ── 方向3a: SelectKBest (k=50) ──
    results['kbest50'] = run(
        "方向3a: SelectKBest(k=50) 替代 PCA",
        scaler_type='standard', dim_type='kbest', shrink_mode='mean', n_kbest=50)

    # ── 方向3b: SelectKBest (k=30) ──
    results['kbest30'] = run(
        "方向3b: SelectKBest(k=30) 与PCA维数对齐",
        scaler_type='standard', dim_type='kbest', shrink_mode='mean', n_kbest=30)

    # ── 方向3c: SelectKBest (k=100) ──
    results['kbest100'] = run(
        "方向3c: SelectKBest(k=100) 更多特征",
        scaler_type='standard', dim_type='kbest', shrink_mode='mean', n_kbest=100)

    # ── 组合: RobustScaler + 中位数收缩 ──
    results['robust+median'] = run(
        "组合: RobustScaler + 中位数收缩",
        scaler_type='robust', dim_type='pca', shrink_mode='median')

    # ── 组合: RobustScaler + SelectKBest(50) ──
    results['robust+kbest50'] = run(
        "组合: RobustScaler + SelectKBest(k=50)",
        scaler_type='robust', dim_type='kbest', shrink_mode='mean', n_kbest=50)

    # ── 组合: RobustScaler + SelectKBest(50) + 中位数收缩 ──
    results['all3'] = run(
        "组合: RobustScaler + SelectKBest(50) + 中位数收缩",
        scaler_type='robust', dim_type='kbest', shrink_mode='median', n_kbest=50)

    # ── 汇总 ──
    print(f"\n{'=' * 55}")
    print("  汇总 (时间外推CV, 越低越好)")
    print(f"{'=' * 55}")
    base_sh = results.get('baseline', {}).get('shrunk', 999) if results.get('baseline') else 999
    base_raw = results.get('baseline', {}).get('raw', 999) if results.get('baseline') else 999
    for name, val in results.items():
        if val is not None:
            marker = ""
            if name == 'baseline':
                marker = "  <-- 基线"
            elif val['shrunk'] < base_sh:
                marker = "  ✓ shrunk优于基线"
            elif val['shrunk'] > base_sh:
                marker = "  ✗ shrunk恶化"
            print(f"  {name:25s}: raw={val['raw']:.2f}  shrunk={val['shrunk']:.2f}{marker}")
