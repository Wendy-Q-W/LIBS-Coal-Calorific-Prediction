"""
exp_v481_v490_batch_mean_alphas.py
Test batch_mean with different alpha values.
V448 (a=0.05 iso + batch_mean) reduced CV from 172→167.
Test if batch_mean also helps at other alphas.
"""
import os, sys, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import exp_v260_v270_tree_models as base
from exp_v260_v270_tree_models import run_experiment, PIPELINE_CONFIG

if __name__ == '__main__':
    # Reset to defaults first
    base.PIPELINE_CONFIG.update({
        'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
    })

    experiments = [
        ('v481_bm_a003_iso', 0.03, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.03 iso + batch_mean'),
        
        ('v482_bm_a004_iso', 0.04, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.04 iso + batch_mean'),
        
        ('v483_bm_a006_iso', 0.06, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.06 iso + batch_mean'),
        
        ('v484_bm_a008_iso', 0.08, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.08 iso + batch_mean'),
        
        ('v485_bm_a010_iso', 0.10, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.10 iso + batch_mean (= V63 with batch_mean)'),
        
        ('v486_bm_a015_iso', 0.15, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.15 iso + batch_mean'),
        
        ('v487_bm_a003_lin', 0.03, 'linear',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.03 linear + batch_mean'),
        
        ('v488_bm_a010_lin', 0.10, 'linear',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.10 linear + batch_mean'),
        
        # PCA40 with batch_mean
        ('v489_bm_a005_pca40', 0.05, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.05 iso + batch_mean + PCA40'),
        
        # PCA20 with batch_mean
        ('v490_bm_a005_pca20', 0.05, 'isotonic',
         {'batch_agg': 'mean', 'ensemble_agg': 'mean', 'fixed_shrink_w': None},
         'a=0.05 iso + batch_mean + PCA20'),
    ]

    results = {}
    for vid, alpha, calib, config, desc in experiments:
        base.PIPELINE_CONFIG.update(config)
        
        # Override PCA components for v489/v490
        old_n_pca = base.N_PCA_MAX
        if 'pca40' in vid:
            base.N_PCA_MAX = 40
        elif 'pca20' in vid:
            base.N_PCA_MAX = 20
        
        print(f"\n{'='*70}")
        print(f"  {vid}: {desc}")
        print(f"  alpha={alpha}, calib={calib}, PCA={base.N_PCA_MAX}")
        print(f"{'='*70}")
        
        _, cv = run_experiment(
            vid, desc,
            ridge_alpha=alpha,
            calibration=calib,
            preprocessing='snv',
            use_pca=True,
        )
        results[vid] = cv
        print(f"  CV={cv:.2f}")
        
        # Restore PCA
        base.N_PCA_MAX = old_n_pca

    # Reset
    base.PIPELINE_CONFIG.update({
        'batch_agg': 'median', 'ensemble_agg': 'mean', 'fixed_shrink_w': None
    })

    print(f"\n{'='*70}")
    print("  SUMMARY - batch_mean alpha scan")
    print(f"{'='*70}")
    
    print(f"  Reference: V72 (a=0.05 iso + median)     CV=172.15")
    print(f"  Reference: V448 (a=0.05 iso + mean)      CV=166.63  (delta=-5.52)")
    print(f"  Reference: V416 (a=0.02 iso + median)    CV=158.30")
    print(f"  Reference: V417 (a=0.03 iso + median)    CV=164.28")
    print(f"  Reference: V63  (a=0.10 iso + median)    CV=184.00")
    print()
    
    for vid, cv in results.items():
        print(f"  {vid:30s}  CV={cv:.2f}")
