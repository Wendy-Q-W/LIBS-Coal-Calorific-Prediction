"""
exp_v102_v113_sg_bayesian.py

Break the blend ceiling (V96=196.98) by introducing GENUINELY DIFFERENT preprocessing.

All current models (V61, V63, V72, V74, V85, V96) share the same SNV preprocessing
-> PCA(30) -> Ridge pipeline. Their correlations are 0.989-0.996, so blending has
hit a ceiling around 197.

Lasso (V86) and ElasticNet (V87) had lower correlations (0.972-0.990) but were
"diversity traps" - low quality predictions that hurt blends.

KEY INSIGHT: We need diverse preprocessing that produces DIFFERENT but still GOOD
predictions. Savitzky-Golay (SG) filtering is the standard chemometric approach:

  V102: SG smoothing (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias
    - SG smoothing reduces spectral noise before SNV
    - Different PCA components -> different predictions
    - Should maintain quality (smoothing removes noise, not signal)

  V103: SG 1st derivative (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias
    - First derivative removes baseline drift
    - Enhances peak resolution
    - Very different spectral representation from raw SNV

  V104: SG 2nd derivative (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias
    - Second derivative removes linear baseline + curvature
    - Even more aggressive baseline correction
    - Maximally different from SNV

  V105: SNV + BayesianRidge + linear bias
    - Bayesian Ridge uses evidence maximization for automatic regularization
    - Different optimization landscape from fixed-alpha Ridge
    - Same preprocessing but different model -> tests model diversity

  V106: SG smoothing (w=7, p=2) + SNV + Ridge(a=0.05) + linear bias
    - Larger SG window -> more smoothing
    - Tests if w=5 or w=7 is better

  V107: V74+V72 blend (80/20) - fine-tune blend ratio
  V108: V74+V72 blend (77.5/22.5) - fine-tune blend ratio

  V109-V113: Blends of V96 (75/25) + each new model at 90/10 and 80/20
    - If any new model adds value, these blends could break 197

All models use the same:
  - Two-stage (aux prediction -> Q prediction)
  - 100-seed ensemble (or LOOCV for small coals)
  - Shrinkage to coal center
  - Linear/isotonic bias correction
  - Hand features (43): stats(17) + line integrals(11) + line ratios(11) + compound ratios(4)
"""
import os, sys, re, glob, warnings, io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.signal import savgol_filter
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression, Lasso, ElasticNet, BayesianRidge
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}

# Preprocessing options
PREPROCESS_SNV      = 'snv'
PREPROCESS_SG_SNV   = 'sg_snv'      # SG smoothing then SNV
PREPROCESS_SG1_SNV  = 'sg1_snv'     # SG 1st derivative then SNV
PREPROCESS_SG2_SNV  = 'sg2_snv'     # SG 2nd derivative then SNV

# Model factory
MODEL_CONFIGS = {
    'ridge': {
        'factory': lambda alpha: Ridge(alpha=alpha),
        'supports_weight': True,
    },
    'lasso': {
        'factory': lambda alpha: Lasso(alpha=alpha, max_iter=10000, selection='cyclic'),
        'supports_weight': True,
    },
    'elasticnet': {
        'factory': lambda alpha: ElasticNet(alpha=alpha, l1_ratio=0.5, max_iter=10000, selection='cyclic'),
        'supports_weight': True,
    },
    'bayesian_ridge': {
        'factory': lambda alpha: BayesianRidge(),
        'supports_weight': True,
    },
}


# ===============================================================================
# Data loading (reused from v86_v89)
# ===============================================================================

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


# ===============================================================================
# Feature extraction with configurable preprocessing
# ===============================================================================

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def apply_preprocessing(inten, preprocess=PREPROCESS_SNV, sg_window=5, sg_poly=2):
    """Apply spectral preprocessing to produce the spectral matrix input."""
    if preprocess == PREPROCESS_SNV:
        processed = (inten - inten.mean()) / (inten.std() + 1e-8)
    elif preprocess == PREPROCESS_SG_SNV:
        smoothed = savgol_filter(inten, sg_window, sg_poly)
        processed = (smoothed - smoothed.mean()) / (smoothed.std() + 1e-8)
    elif preprocess == PREPROCESS_SG1_SNV:
        deriv = savgol_filter(inten, sg_window, sg_poly, deriv=1)
        processed = (deriv - deriv.mean()) / (deriv.std() + 1e-8)
    elif preprocess == PREPROCESS_SG2_SNV:
        deriv2 = savgol_filter(inten, sg_window, sg_poly, deriv=2)
        processed = (deriv2 - deriv2.mean()) / (deriv2.std() + 1e-8)
    else:
        processed = (inten - inten.mean()) / (inten.std() + 1e-8)
    return processed.astype(np.float32)


def compute_features(data, preprocess=PREPROCESS_SNV, sg_window=5, sg_poly=2):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        processed = apply_preprocessing(inten, preprocess, sg_window, sg_poly)
        spec_mats.append(processed)
        # Hand features always from raw spectra (stable base)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=30):
    spec_mat = data.get('_spec_mat')
    if spec_mat is None:
        spec_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ===============================================================================
# Training with configurable model type and preprocessing
# ===============================================================================

def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def make_model(model_type, alpha):
    cfg = MODEL_CONFIGS.get(model_type, MODEL_CONFIGS['ridge'])
    return cfg['factory'](alpha)


def model_supports_weight(model_type):
    return MODEL_CONFIGS.get(model_type, MODEL_CONFIGS['ridge'])['supports_weight']


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.1, model_type='ridge'):
    sw_ok = model_supports_weight(model_type)

    # Stage 1: predict aux variables
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = make_model(model_type, ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            if sample_weights is not None and sw_ok:
                m.fit(X[tr_idx], y_aux[tr_idx], sample_weight=sample_weights[tr_idx])
            else:
                m.fit(X[tr_idx], y_aux[tr_idx])
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        if sample_weights is not None and sw_ok:
            m = make_model(model_type, ridge_alpha)
            m.fit(X, y_aux, sample_weight=sample_weights)
        else:
            m = make_model(model_type, ridge_alpha)
            m.fit(X, y_aux)
        aux_models[col_name] = m

    # Stage 2: predict calorific value
    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = make_model(model_type, ridge_alpha)
        if sample_weights is not None and sw_ok:
            m2.fit(X_s2[tr_idx], y[tr_idx], sample_weight=sample_weights[tr_idx])
        else:
            m2.fit(X_s2[tr_idx], y[tr_idx])
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = float(np.median(val_pred[mask]))
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(
        oof_batch_preds, oof_batch_true, coal_center)

    if sample_weights is not None and sw_ok:
        final_model = make_model(model_type, ridge_alpha)
        final_model.fit(X_s2, y, sample_weight=sample_weights)
    else:
        final_model = make_model(model_type, ridge_alpha)
        final_model.fit(X_s2, y)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)

    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)

    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = float(np.median(preds[mask]))
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


def train_and_predict_coal(coal, label_map, aux_map,
                           ridge_alpha=0.05, calibration='linear',
                           model_type='ridge', n_pca_max=30,
                           preprocess=PREPROCESS_SNV, sg_window=5, sg_poly=2):
    """Train models for one coal type with configurable preprocessing and model."""
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    spec_mat = compute_features(train_data, preprocess=preprocess,
                                sg_window=sg_window, sg_poly=sg_poly)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(
        train_data, n_batches, fit=True, n_pca_max=n_pca_max)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(X, y, aux, groups, splits, coal_center,
                            n_batches, sample_weights,
                            ridge_alpha=ridge_alpha, model_type=model_type)
        runs.append(run)

    if is_small:
        r = runs[0]
        print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
              f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
    else:
        cv_rmses = [r['cv_rmse'] for r in runs]
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
              f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])

    # Calibration
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
        print(f"    Bias correction: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a_lin = float(lr.coef_[0])
        print(f"    Isotonic (lin_approx: a={a_lin:.4f})")

    # Predict test
    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data, preprocess=preprocess,
                                     sg_window=sg_window, sg_poly=sg_poly)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(
        test_data, n_batches=None,
        scaler_spec=scaler_spec, pca=pca,
        scaler_hand=scaler_hand, fit=False)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))

        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])

        test_preds[name] = pred_val

    return {
        'cv_rmse': cv_rmse,
        'test_preds': test_preds,
    }


# ===============================================================================
# Submission helpers (reused)
# ===============================================================================

def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0

    readme = f"""# LIBS 煤炭发热量预测 — 方案介绍

**版本**: {variant_name}
**作者**: ATIpiu
**提交时间**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## 方法概述

{feature_desc}

## CV-RMSE (for reference only)

| 煤种 | CV-RMSE |
|---|---|
"""
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"

    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")

    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        print(f"  WARNING: {fname} not found!")
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


def run_model_experiment(variant_name, model_type, ridge_alpha, calibration,
                         preprocess, sg_window=5, sg_poly=2, n_pca_max=30,
                         desc=""):
    """Run a single model experiment with given configuration."""
    print(f"\n{'=' * 70}")
    print(f"  {variant_name}")
    print(f"  Model: {model_type}, alpha={ridge_alpha}, cal={calibration}")
    print(f"  Preprocess: {preprocess}, sg_window={sg_window}, sg_poly={sg_poly}")
    print(f"  PCA: {n_pca_max}")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(
            coal, label_map, aux_map,
            ridge_alpha=ridge_alpha, calibration=calibration,
            model_type=model_type, n_pca_max=n_pca_max,
            preprocess=preprocess, sg_window=sg_window, sg_poly=sg_poly)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")

    return pack_submission(variant_name, all_preds, cv_results, desc)


def run_blend_experiment(variant_name, components, desc=""):
    """Blend existing submissions with given weights.

    components: list of (zip_name, weight) tuples
    """
    print(f"\n{'=' * 70}")
    print(f"  {variant_name}: Blend")
    print(f"  Components:")
    for zip_name, w in components:
        print(f"    {zip_name}: {w*100:.1f}%")
    print(f"{'=' * 70}")

    subs = {}
    for zip_name, _ in components:
        sub = load_existing_submission(zip_name)
        if sub is None:
            print(f"  ERROR: Cannot load {zip_name}!")
            return None, 0
        subs[zip_name] = sub

    # Check correlations
    keys = list(subs.keys())
    if len(keys) >= 2:
        print(f"\n  Correlations:")
        for i, k1 in enumerate(keys):
            for j, k2 in enumerate(keys):
                if j > i:
                    c = np.corrcoef(subs[k1], subs[k2])[0, 1]
                    print(f"    {k1} vs {k2}: {c:.6f}")

    all_preds = {}
    for name in subs[keys[0]].index:
        val = 0.0
        for zip_name, w in components:
            val += w * subs[zip_name][name]
        all_preds[name] = float(val)

    print(f"\n  Blend mean: {np.mean(list(all_preds.values())):.2f}")

    return pack_submission(variant_name, all_preds, {}, desc)


# ===============================================================================
# Experiments
# ===============================================================================

def run_v102_sg_smooth():
    """SG smoothing (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias"""
    return run_model_experiment(
        'v102_sg_smooth_w5_snv_ridge_a005_bias',
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocess=PREPROCESS_SG_SNV, sg_window=5, sg_poly=2,
        desc="SG smoothing (window=5, poly=2) + SNV + Ridge(alpha=0.05) + linear bias. "
             "Savitzky-Golay smoothing reduces spectral noise before SNV normalization, "
             "producing different PCA components from standard SNV. "
             "Designed to add high-quality diversity to V96 blend (online=196.98).")


def run_v103_sg_deriv1():
    """SG 1st derivative (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias"""
    return run_model_experiment(
        'v103_sg_deriv1_w5_snv_ridge_a005_bias',
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocess=PREPROCESS_SG1_SNV, sg_window=5, sg_poly=2,
        desc="SG 1st derivative (window=5, poly=2) + SNV + Ridge(alpha=0.05) + linear bias. "
             "First derivative removes baseline drift, enhances peak resolution. "
             "Fundamentally different spectral representation from raw SNV.")


def run_v104_sg_deriv2():
    """SG 2nd derivative (w=5, p=2) + SNV + Ridge(a=0.05) + linear bias"""
    return run_model_experiment(
        'v104_sg_deriv2_w5_snv_ridge_a005_bias',
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocess=PREPROCESS_SG2_SNV, sg_window=5, sg_poly=2,
        desc="SG 2nd derivative (window=5, poly=2) + SNV + Ridge(alpha=0.05) + linear bias. "
             "Second derivative removes linear baseline and curvature. "
             "Maximally different from standard SNV preprocessing.")


def run_v105_bayesian_ridge():
    """SNV + BayesianRidge + linear bias"""
    return run_model_experiment(
        'v105_snv_bayesian_ridge_bias',
        model_type='bayesian_ridge', ridge_alpha=0.0, calibration='linear',
        preprocess=PREPROCESS_SNV,
        desc="SNV + BayesianRidge + linear bias. "
             "Bayesian Ridge uses evidence maximization for automatic regularization, "
             "different optimization from fixed-alpha Ridge. "
             "Same preprocessing but different model -> tests model diversity.")


def run_v106_sg_smooth_w7():
    """SG smoothing (w=7, p=2) + SNV + Ridge(a=0.05) + linear bias"""
    return run_model_experiment(
        'v106_sg_smooth_w7_snv_ridge_a005_bias',
        model_type='ridge', ridge_alpha=0.05, calibration='linear',
        preprocess=PREPROCESS_SG_SNV, sg_window=7, sg_poly=2,
        desc="SG smoothing (window=7, poly=2) + SNV + Ridge(alpha=0.05) + linear bias. "
             "Larger SG window -> more smoothing than V102.")


def run_v107_blend_8020():
    """V74+V72 blend (80/20)"""
    return run_blend_experiment(
        'v107_blend_v74_v72_8020',
        components=[
            ('submit_v74_blend_v61_v63_5050.zip', 0.80),
            ('submit_v72_isotonic_a005.zip', 0.20),
        ],
        desc="80/20 blend of V74 (V61+V63 50/50) and V72 (isotonic, alpha=0.05). "
             "V96 (75/25)=196.98 is current best. Testing if lower V72 weight improves.")


def run_v108_blend_7750():
    """V74+V72 blend (77.5/22.5)"""
    return run_blend_experiment(
        'v108_blend_v74_v72_7750',
        components=[
            ('submit_v74_blend_v61_v63_5050.zip', 0.775),
            ('submit_v72_isotonic_a005.zip', 0.225),
        ],
        desc="77.5/22.5 blend of V74 and V72. "
             "Fine-tuning between V96 (75/25=196.98) and V107 (80/20).")


def run_v109_v113_blends():
    """Blend V96 (best) + each new model at 90/10"""
    v96 = load_existing_submission('submit_v96_blend_v74_v72_7525.zip')
    if v96 is None:
        print("  ERROR: V96 not found!")
        return

    new_models = [
        ('v102_sg_smooth_w5_snv_ridge_a005_bias', 'v102'),
        ('v103_sg_deriv1_w5_snv_ridge_a005_bias', 'v103'),
        ('v104_sg_deriv2_w5_snv_ridge_a005_bias', 'v104'),
        ('v105_snv_bayesian_ridge_bias', 'v105'),
        ('v106_sg_smooth_w7_snv_ridge_a005_bias', 'v106'),
    ]

    for zip_base, short_name in new_models:
        new_sub = load_existing_submission(f'submit_{zip_base}.zip')
        if new_sub is None:
            print(f"  Skipping {short_name}: not found")
            continue

        c = np.corrcoef(v96, new_sub)[0, 1]
        print(f"\n  {short_name} corr with V96: {c:.6f}")

        # 90/10 blend
        run_blend_experiment(
            f'v109_blend_v96_{short_name}_9010',
            components=[
                ('submit_v96_blend_v74_v72_7525.zip', 0.90),
                (f'submit_{zip_base}.zip', 0.10),
            ],
            desc=f"90/10 blend of V96 (online=196.98) and {short_name}. "
                 f"Correlation: {c:.6f}. Testing if new preprocessing adds value.")

        # 80/20 blend (more aggressive)
        run_blend_experiment(
            f'v110_blend_v96_{short_name}_8020',
            components=[
                ('submit_v96_blend_v74_v72_7525.zip', 0.80),
                (f'submit_{zip_base}.zip', 0.20),
            ],
            desc=f"80/20 blend of V96 (online=196.98) and {short_name}. "
                 f"Correlation: {c:.6f}. More aggressive diversity injection.")


def run_v111_v113_best_blends():
    """Additional blends: V74 + best new model, V85 + best new model"""
    # These will be generated after we see which new model has lowest correlation
    # For now, generate all combinations at 90/10
    v74 = load_existing_submission('submit_v74_blend_v61_v63_5050.zip')
    if v74 is None:
        print("  ERROR: V74 not found!")
        return

    new_models = [
        ('v102_sg_smooth_w5_snv_ridge_a005_bias', 'v102'),
        ('v103_sg_deriv1_w5_snv_ridge_a005_bias', 'v103'),
        ('v104_sg_deriv2_w5_snv_ridge_a005_bias', 'v104'),
        ('v105_snv_bayesian_ridge_bias', 'v105'),
        ('v106_sg_smooth_w7_snv_ridge_a005_bias', 'v106'),
    ]

    for zip_base, short_name in new_models:
        new_sub = load_existing_submission(f'submit_{zip_base}.zip')
        if new_sub is None:
            continue

        c = np.corrcoef(v74, new_sub)[0, 1]
        print(f"\n  {short_name} corr with V74: {c:.6f}")

        # V74 + new model at 90/10 (bypassing V72)
        run_blend_experiment(
            f'v111_blend_v74_{short_name}_9010',
            components=[
                ('submit_v74_blend_v61_v63_5050.zip', 0.90),
                (f'submit_{zip_base}.zip', 0.10),
            ],
            desc=f"90/10 blend of V74 (V61+V63) and {short_name}. "
                 f"Correlation: {c:.6f}. Tests if new model can replace V72 in blend.")


# ===============================================================================
# Main
# ===============================================================================

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Run V102-V113 experiments')
    parser.add_argument('--only', type=str, default=None,
                        help='Run only specified experiment (e.g. v102, v107, blends)')
    args = parser.parse_args()

    results = {}

    if args.only is None or args.only == 'v102':
        _, cv = run_v102_sg_smooth()
        results['v102'] = cv
    if args.only is None or args.only == 'v103':
        _, cv = run_v103_sg_deriv1()
        results['v103'] = cv
    if args.only is None or args.only == 'v104':
        _, cv = run_v104_sg_deriv2()
        results['v104'] = cv
    if args.only is None or args.only == 'v105':
        _, cv = run_v105_bayesian_ridge()
        results['v105'] = cv
    if args.only is None or args.only == 'v106':
        _, cv = run_v106_sg_smooth_w7()
        results['v106'] = cv
    if args.only is None or args.only == 'v107':
        _, cv = run_v107_blend_8020()
        results['v107'] = cv
    if args.only is None or args.only == 'v108':
        _, cv = run_v108_blend_7750()
        results['v108'] = cv
    if args.only is None or args.only == 'blends':
        run_v109_v113_blends()
        run_v111_v113_best_blends()

    if results:
        print(f"\n{'=' * 70}")
        print("  SUMMARY")
        print(f"{'=' * 70}")
        print(f"  Baselines:")
        print(f"    V61 (Ridge, a=0.05, linear):  Online=203.21")
        print(f"    V63 (Ridge, a=0.1, isotonic): Online=203.60")
        print(f"    V72 (Ridge, a=0.05, isotonic): Online=~200 (est)")
        print(f"    V85 (V74+V72 70/30):          Online=196.99")
        print(f"    V96 (V74+V72 75/25):          Online=196.98 (BEST)")
        print()
        for name, cv in results.items():
            print(f"    {name}: CV={cv:.2f}")
