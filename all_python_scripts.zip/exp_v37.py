"""
exp_v37.py
V37: Hybrid normalization + tuned importance weighting + ensemble blend

Key insight from V36:
- SNV improves TE -6.0 but hurts GK +13.3 (likely because hand features 
  designed for total-intensity normalization get corrupted by SNV)
- Importance weighting improves TE -6.9 but hurts GK +25.1 (too aggressive)

Directions:
1. Hybrid norm: SNV for PCA part, total-intensity for hand features
2. Importance weighting with tight clips [0.3,3], [0.5,2]
3. Ensemble blend: Q = (1-beta)*Q_v28 + beta*Q_adapted

V28: GK=164.16, TE=278.27, online=240.40
"""
import os, re, glob, warnings, time
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']
KEY_LINES = {
    'C': (247.86, 10.0), 'H': (656.30, 15.0),
    'O': (777.20, 15.0), 'N': (742.40, 10.0),
    'Ca': (422.70, 2.0), 'Ca2': (393.40, 2.0),
    'Mg': (285.20, 2.0), 'Al': (308.20, 2.0),
    'Si': (288.20, 2.0), 'Fe': (438.40, 3.0),
    'Na': (589.00, 1.5),
}
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    """Extract features with total-intensity normalization (for hand features)."""
    total = inten.sum() + 1e-8
    inten_norm_total = inten / total
    deriv = np.diff(inten_norm_total)
    deriv2 = np.diff(inten_norm_total, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm_total.mean(), inten_norm_total.std(),
        float(skew(inten_norm_total)), float(kurtosis(inten_norm_total)),
        float(scipy_entropy(inten_norm_total + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm_total, stats, labs, lrel, rats


def compute_snv_spectra(data):
    """Compute SNV-normalized spectra for PCA input only."""
    raw_spectra = data['spectra']
    snvs = []
    for wl, inten in raw_spectra:
        snv = (inten - inten.mean()) / (inten.std() + 1e-8)
        snvs.append(snv)
    min_len = min(len(s) for s in snvs)
    return np.array([s[:min_len] for s in snvs], dtype=np.float32)


def compute_total_spectra(data):
    """Compute total-intensity normalized spectra (original V28 approach)."""
    raw_spectra = data['spectra']
    inorms = []
    for wl, inten in raw_spectra:
        total = inten.sum() + 1e-8
        inorms.append(inten / total)
    min_len = min(len(s) for s in inorms)
    return np.array([s[:min_len] for s in inorms], dtype=np.float32)


def compute_hand_features(data):
    """Compute hand-crafted features with total-intensity normalization."""
    raw_spectra = data['spectra']
    stats_list, labs_list, lrel_list, rats_list = [], [], [], []
    for wl, inten in raw_spectra:
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    data2 = dict(data)
    data2['stats'] = np.array(stats_list)
    data2['labs'] = np.array(labs_list)
    data2['lrel'] = np.array(lrel_list)
    data2['rats'] = np.array(rats_list)
    return data2


def build_fm_hybrid(snv_mat, data2, n_batches, spec_mode='snv',
                    scalers=None, fit=True):
    """Build feature matrix with configurable spectrum normalization.
    
    spec_mode: 'snv' = SNV normalized spectra for PCA
               'total' = total-intensity normalized spectra for PCA
               'both' = concatenate SNV-PCA + total-PCA
    """
    hand_feats = np.hstack([data2['stats'], data2['labs'], data2['lrel'], data2['rats']])

    if fit:
        sc = StandardScaler()
        spec_scaled = sc.fit_transform(snv_mat)
        n_pca = min(30, n_batches - 1, spec_scaled.shape[0] - 1) if n_batches else min(30, spec_scaled.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        sh = StandardScaler()
        X = sh.fit_transform(X)
        return X, (sc, pca, sh)
    else:
        sc, pca, sh = scalers
        spec_scaled = sc.transform(snv_mat)
        spec_pca = pca.transform(spec_scaled)
        X = np.hstack([spec_pca, hand_feats])
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
        return sh.transform(X)


def compute_importance_weights(X_train, X_test, C=1.0, clip_low=0.1, clip_high=10.0):
    X_combined = np.vstack([X_train, X_test])
    y_combined = np.concatenate([np.zeros(len(X_train)), np.ones(len(X_test))])
    clf = LogisticRegression(C=C, max_iter=1000, random_state=RANDOM_STATE,
                             class_weight='balanced')
    clf.fit(X_combined, y_combined)
    p_test = clf.predict_proba(X_train)[:, 1]
    p_test = np.clip(p_test, 1e-4, 1 - 1e-4)
    weights = p_test / (1 - p_test)
    weights = np.clip(weights, clip_low, clip_high)
    return weights / weights.mean()


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights=None):
    aux_oof = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            aux_oof[:, ci] = float(np.nanmean(ya))
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        oof = np.zeros(len(ya))
        for tr, va in splits:
            if sample_weights is not None:
                m1.fit(X_spec[tr], ya[tr], sample_weight=sample_weights[tr])
            else:
                m1.fit(X_spec[tr], ya[tr])
            oof[va] = m1.predict(X_spec[va])
        aux_oof[:, ci] = oof

    X_s2 = np.hstack([X_spec, aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    oof_preds, oof_true, fold_rmses = [], [], []
    for tr, va in splits:
        m2 = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m2.fit(X_s2[tr], y[tr], sample_weight=sample_weights[tr])
        else:
            m2.fit(X_s2[tr], y[tr])
        vp = m2.predict(X_s2[va])
        vg = groups[va]
        for bg in np.unique(vg):
            mk = vg == bg
            oof_preds.append(float(np.median(vp[mk])))
            oof_true.append(float(y[va][mk][0]))
        fold_se = [(float(y[va][mk][0]) - float(np.median(vp[vg==bg])))**2
                    for bg in np.unique(vg)]
        fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_raw = float(np.mean(fold_rmses))
    best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw, 'shrink_w': best_w,
            'oof_preds': oof_preds, 'oof_true': oof_true}


def eval_gk(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    n_batches = data['n_batches']
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    def _run(splits):
        return train_v28(X_spec, y, aux, groups, splits, coal_mean, sample_weights)

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        r = _run(splits)
        return r['cv_rmse'], is_small, r
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run(splits))
        avg_rmse = float(np.mean([r['cv_rmse'] for r in runs]))
        return avg_rmse, is_small, runs[0]


def eval_te(coal_type, data, X_spec, sample_weights=None):
    y = data['targets']
    aux = data['aux']
    groups = data['groups']
    months = data['months']
    coal_mean = float(y.mean())

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]
    splits = [(tr_idx, val_idx)]

    te_weights = None
    if sample_weights is not None:
        te_weights = sample_weights[tr_mask]

    run = train_v28(X_spec, y, aux, groups, splits, coal_mean, te_weights)
    return run['cv_rmse']


def run_config(label_map, aux_map, name, spec_mode='total',
               use_importance=False, imp_C=1.0, imp_clip=(0.1, 10.0),
               time_weight_mode='v28'):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {name}")
    print(f"{'='*70}", flush=True)

    gk_results, te_results = {}, {}

    for coal_type in COAL_TYPES:
        data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if data is None or data['n_batches'] == 0:
            continue

        n_batches = data['n_batches']
        n_spec = len(data['spectra'])
        months = data['months']

        # Compute spectra matrix based on spec_mode
        if spec_mode == 'snv':
            spec_mat = compute_snv_spectra(data)
        else:
            spec_mat = compute_total_spectra(data)

        data2 = compute_hand_features(data)
        X_spec, scalers = build_fm_hybrid(spec_mat, data2, n_batches, fit=True)

        # Sample weights
        sample_weights = None
        if time_weight_mode == 'v28':
            if coal_type in TIME_WEIGHT_TAU and n_batches > SMALL_BATCH_THRESHOLD:
                tau = TIME_WEIGHT_TAU[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)
        elif time_weight_mode == 'all':
            if coal_type in TIME_WEIGHT_TAU:
                tau = TIME_WEIGHT_TAU[coal_type]
                sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

        # Importance weighting
        if use_importance:
            test_data = load_coal_spectra(TEST_DIR, coal_type, label_map=None, aux_map=None)
            if test_data is not None and len(test_data['spectra']) > 0:
                if spec_mode == 'snv':
                    test_spec = compute_snv_spectra(test_data)
                else:
                    test_spec = compute_total_spectra(test_data)
                test_data2 = compute_hand_features(test_data)
                X_test = build_fm_hybrid(test_spec, test_data2, n_batches=None,
                                         scalers=scalers, fit=False)
                imp_w = compute_importance_weights(X_spec, X_test, C=imp_C,
                                                    clip_low=imp_clip[0],
                                                    clip_high=imp_clip[1])
                if sample_weights is not None:
                    sample_weights = sample_weights * imp_w
                else:
                    sample_weights = imp_w
                sample_weights = sample_weights / sample_weights.mean()

        gk, is_small, _ = eval_gk(coal_type, data, X_spec, sample_weights)
        te = eval_te(coal_type, data, X_spec, sample_weights)

        gk_results[coal_type] = gk
        te_results[coal_type] = te
        tag = "LOO" if is_small else f"{N_ENSEMBLE_SEEDS}s"
        te_s = f"TE={te:.2f}" if te else "TE=N/A"
        sw_s = "sw=on" if sample_weights is not None else "sw=off"
        print(f"  [{coal_type}] {n_batches}b/{n_spec}s  GK={gk:.2f}  {te_s}  ({tag}, {sw_s})", flush=True)

    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {name}")
    print(f"     GK={gk_avg:.2f}  TE={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V37: Hybrid Norm + Tuned Importance + Ensemble")
    print("=" * 70)

    label_map, aux_map = load_labels()
    results = {}

    # A. V28 baseline (total norm)
    results['A_v28'] = run_config(
        label_map, aux_map, "A: V28 Baseline", spec_mode='total')

    # B. Hybrid: SNV for PCA + total for hand features + V28 time
    results['B_hybrid_snv'] = run_config(
        label_map, aux_map, "B: Hybrid SNV (PCA) + Total (hand)",
        spec_mode='snv', time_weight_mode='v28')

    # C. Hybrid SNV + importance weighting (clip 0.3-3)
    results['C_hybrid_imp03_3'] = run_config(
        label_map, aux_map, "C: Hybrid SNV + Imp(0.3,3)",
        spec_mode='snv', use_importance=True, imp_clip=(0.3, 3.0))

    # D. Hybrid SNV + importance weighting (clip 0.5-2)
    results['D_hybrid_imp05_2'] = run_config(
        label_map, aux_map, "D: Hybrid SNV + Imp(0.5,2)",
        spec_mode='snv', use_importance=True, imp_clip=(0.5, 2.0))

    # E. Total norm + importance weighting (clip 0.3-3)
    results['E_total_imp03_3'] = run_config(
        label_map, aux_map, "E: Total + Imp(0.3,3)",
        spec_mode='total', use_importance=True, imp_clip=(0.3, 3.0))

    # F. Total norm + importance weighting (clip 0.5-2)
    results['F_total_imp05_2'] = run_config(
        label_map, aux_map, "F: Total + Imp(0.5,2)",
        spec_mode='total', use_importance=True, imp_clip=(0.5, 2.0))

    # G. Hybrid SNV + importance (0.3-3) + V28 time weighting
    results['G_hybrid_imp_v28tw'] = run_config(
        label_map, aux_map, "G: Hybrid SNV + Imp(0.3,3) + V28 TW",
        spec_mode='snv', use_importance=True, imp_clip=(0.3, 3.0),
        time_weight_mode='v28')

    # Summary
    print(f"\n{'='*70}")
    print("SUMMARY")
    print(f"{'='*70}")
    base_gk, base_te = results['A_v28']
    print(f"  {'config':35s}  {'GK':>8s}  {'TE':>8s}  {'dGK':>7s}  {'dTE':>7s}")
    for name, (gk, te) in results.items():
        print(f"  {name:35s}  {gk:8.2f}  {te:8.2f}  {gk-base_gk:+7.2f}  {te-base_te:+7.2f}")


if __name__ == "__main__":
    main()
