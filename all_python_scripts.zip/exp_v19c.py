"""V19c: 修复差异化窗口bug + win=3.0/3.5精调 + 逐线窗口扫描
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    KEY_LINES, RANDOM_STATE,
)
from exp_v19 import run_config, make_windowed_lines


# 修复: KEY_LINES的键名是 'C','H','O','N','Ca','Ca2','Mg','Al','Si','Fe','Na'
MAIN_KEYS = ['C', 'H', 'O', 'N']
METAL_KEYS = ['Ca', 'Ca2', 'Mg', 'Al', 'Si', 'Fe', 'Na']


def make_diff_windows(main_scale, metal_scale):
    """主元素(C/H/O/N)用main_scale, 金属线用metal_scale"""
    kl = {}
    for k, (c, h) in KEY_LINES.items():
        if k in MAIN_KEYS:
            kl[k] = (c, h * main_scale)
        else:
            kl[k] = (c, h * metal_scale)
    return kl


def make_per_line_windows(scales_dict):
    """逐线设置窗口: scales_dict = {'C': 3.0, 'H': 5.0, ...}"""
    kl = {}
    for k, (c, h) in KEY_LINES.items():
        s = scales_dict.get(k, 1.0)
        kl[k] = (c, h * s)
    return kl


if __name__ == "__main__":
    results = {}

    # ── 基线 ──
    results['baseline'] = run_config("基线: win=1.0", n_pca_max=30)

    # ── P1: 修复后的差异化窗口 ──
    # 主元素放大, 金属线保持
    for ms in [2.0, 3.0, 4.0, 5.0]:
        kl = make_diff_windows(ms, 1.0)
        results[f'main={ms},metal=1.0'] = run_config(
            f"主元素×{ms},金属×1.0", key_lines=kl)

    # 主元素+金属线都放大, 但主元素更大
    for ms, mts in [(3.0, 2.0), (4.0, 2.0), (3.0, 1.5), (5.0, 2.0)]:
        kl = make_diff_windows(ms, mts)
        results[f'main={ms},metal={mts}'] = run_config(
            f"主元素×{ms},金属×{mts}", key_lines=kl)

    # 金属线放大, 主元素保持
    for mts in [2.0, 3.0]:
        kl = make_diff_windows(1.0, mts)
        results[f'main=1.0,metal={mts}'] = run_config(
            f"主元素×1.0,金属×{mts}", key_lines=kl)

    # ── P2: 逐线扫描 — 每次只放大一条线 ──
    for k in KEY_LINES:
        scales = {k: 3.0}
        kl = make_per_line_windows(scales)
        results[f'only_{k}=3.0'] = run_config(
            f"仅{k}×3.0", key_lines=kl)

    # ── P3: win=3.0/3.5 对比 (确认V19b结果) ──
    for s in [3.0, 3.5]:
        kl = make_windowed_lines(s)
        results[f'all={s}'] = run_config(
            f"全部×{s}", key_lines=kl)

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V19c: 差异化窗口(修复) + 逐线扫描")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':25s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:25s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
