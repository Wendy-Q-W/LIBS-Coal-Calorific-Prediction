"""
gen_v591_v610_v577_expand.py
V577=194.45 is BEST (V562+赵固二→V72).
Decomposition:
  中马→V72: -0.61
  煤场混煤→V63: -1.22 (independent, V586=195.76 confirms)
  赵固二→V72: -0.69
  赵固一→V63: +1.77 (HARMFUL)
  九里山→V72: +0.72 (HARMFUL)

Remaining untested on V577:
  赵固一→V72 or V61 (V63 failed)
  九里山→V63 or V61 (V72 failed)
"""
import os, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
pred_col = '预测发热量_MJ_KG'

def load_template():
    return pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')

def load_pred(zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(zip_path): return None
    with zipfile.ZipFile(zip_path, 'r') as zf:
        csv_name = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(csv_name) as f:
            return pd.read_csv(f, encoding='utf-8-sig')

def save_zip(df, zip_name):
    zip_path = os.path.join(OUTPUT_DIR, zip_name)
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        csv_buf = io.StringIO()
        df.to_csv(csv_buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', csv_buf.getvalue())
    return zip_path

def corr(v1, v2): return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("EXPAND FROM V577 (194.45) — BEST SO FAR")
    print("=" * 70)

    template = load_template()
    template['coal'] = template['名称'].apply(
        lambda n: next((ct for ct in COAL_TYPES if ct in str(n)), 'unknown'))
    masks = {ct: (template['coal'] == ct).values for ct in COAL_TYPES}

    v61 = load_pred('submit_v61_a005_bias.zip')[pred_col].values
    v63 = load_pred('submit_v63_isotonic.zip')[pred_col].values
    v72 = load_pred('submit_v72_isotonic_a005.zip')[pred_col].values
    v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')[pred_col].values

    zm = masks['中马矿中煤矿']
    zg1 = masks['赵固一矿豫焦末煤']
    zg2 = masks['赵固二矿中煤矿']
    jl = masks['九里山矿中煤矿']
    mc = masks['煤场混煤']

    # V577 baseline = V96 + 中马→V72 + 煤场混煤→V63 + 赵固二→V72
    v577 = v96.copy()
    v577[zm] = v72[zm]
    v577[mc] = v63[mc]
    v577[zg2] = v72[zg2]

    # Also build V574 (V562+九里山→V63) which was generated but not submitted
    v574 = v96.copy()
    v574[zm] = v72[zm]
    v574[mc] = v63[mc]
    v574[jl] = v63[jl]

    results = []

    def gen(name, pred, desc):
        c = corr(pred, v96)
        m = np.mean(np.abs(pred - v96))
        df_out = template.copy()
        df_out[pred_col] = pred
        save_zip(df_out, f'submit_{name}.zip')
        results.append((name, c, m, desc))
        print(f"  {name}: corr={c:.6f}, MAE={m:.2f} — {desc}")

    # === V574 was generated but not submitted, include it ===
    gen('v574_v562_jiuli_v63', v574, "V562+九里山→V63 (resubmit)")

    # === Individual coal additions on V577 ===

    # V591: V577 + 九里山→V63
    p = v577.copy(); p[jl] = v63[jl]
    gen('v591_v577_jiuli_v63', p, "V577+九里山→V63")

    # V592: V577 + 赵固一→V72 (V63 failed, try V72)
    p = v577.copy(); p[zg1] = v72[zg1]
    gen('v592_v577_zhao1_v72', p, "V577+赵固一→V72")

    # V593: V577 + 赵固一→V61
    p = v577.copy(); p[zg1] = v61[zg1]
    gen('v593_v577_zhao1_v61', p, "V577+赵固一→V61")

    # V594: V577 + 九里山→V61
    p = v577.copy(); p[jl] = v61[jl]
    gen('v594_v577_jiuli_v61', p, "V577+九里山→V61")

    # === Combo: both remaining coals ===

    # V595: V577 + 九里山→V63 + 赵固一→V72 (both alternative models)
    p = v577.copy(); p[jl] = v63[jl]; p[zg1] = v72[zg1]
    gen('v595_v577_jiuli_v63_zhao1_v72', p, "V577+九里山→V63+赵固一→V72")

    # V596: V577 + 九里山→V63 + 赵固一→V61
    p = v577.copy(); p[jl] = v63[jl]; p[zg1] = v61[zg1]
    gen('v596_v577_jiuli_v63_zhao1_v61', p, "V577+九里山→V63+赵固一→V61")

    # === Blended versions (safer) ===

    # V597: V577 + 九里山 50/50 V96/V63 (gentle)
    p = v577.copy(); p[jl] = 0.5 * v96[jl] + 0.5 * v63[jl]
    gen('v597_v577_jiuli_5050_v63', p, "V577+九里山 50/50 V96/V63")

    # V598: V577 + 赵固一 50/50 V96/V72 (gentle)
    p = v577.copy(); p[zg1] = 0.5 * v96[zg1] + 0.5 * v72[zg1]
    gen('v598_v577_zhao1_5050_v72', p, "V577+赵固一 50/50 V96/V72")

    # === Safety: V96 + V577 blends ===

    # V599: V96 + V577 80/20
    p = 0.8 * v96 + 0.2 * v577
    gen('v599_v96_v577_8020', p, "V96+V577 80/20 (safety)")

    # V600: V96 + V577 50/50
    p = 0.5 * v96 + 0.5 * v577
    gen('v600_v96_v577_5050', p, "V96+V577 50/50")

    # === Try V63 for 赵固二 instead of V72 ===
    # V577 uses 赵固二→V72. Maybe V63 is even better?
    # V578 was V562+赵固二→V63 (corr=0.999276), not submitted
    p = v96.copy(); p[zm] = v72[zm]; p[mc] = v63[mc]; p[zg2] = v63[zg2]
    gen('v601_v562_zhao2_v63', p, "V562+赵固二→V63 (not V72)")

    # === Try different model for 中马 ===
    # V538 uses 中马→V72. What if V63 works too on V577?
    p = v96.copy(); p[zm] = v63[zm]; p[mc] = v63[mc]; p[zg2] = v72[zg2]
    gen('v602_v577_zhongma_v63', p, "V577 but 中马→V63 (not V72)")

    # === Summary ===
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr)")
    print("=" * 70)
    print(f"{'Variant':<40} {'corr':<12} {'MAE':<8} {'Description'}")
    print("-" * 95)
    for name, c, m, desc in sorted(results, key=lambda x: -x[1]):
        print(f"{name:<40} {c:.6f}     {m:.2f}   {desc}")

    print("\n--- Known online scores ---")
    print("  V96  = 196.98 (baseline)")
    print("  V538 = 196.37 (中马→V72, -0.61)")
    print("  V562 = 195.14 (+煤场→V63, -1.23)")
    print("  V577 = 194.45 (+赵固二→V72, -0.69) *** BEST ***")
    print("  V576 = 196.91 (V562+赵固一→V63, +1.77 HARMFUL)")
    print("  V546 = 197.09 (V538+九里→V72, +0.72 HARMFUL)")
    print("  V586 = 195.76 (煤场→V63 only, -1.22 independent)")
    print("")
    print("  REMAINING QUESTIONS:")
    print("  V591: 九里山→V63 helps? (V72 hurt, V63 might differ)")
    print("  V592: 赵固一→V72 helps? (V63 hurt badly)")
    print("  V595: Both together if individually helpful")

if __name__ == '__main__':
    main()
