"""
V15 实验脚本: 测试3个方向(时间外推CV评估)
方向1: 煤种级alpha调优(赵固二矿/赵固一矿用更高alpha)
方向2: ElasticNet替代Ridge
方向3: N_PCA_MAX增大(30→50/80)
"""
import sys, os, re, warnings, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV, ElasticNetCV, LassoCV
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from sklearn.pipeline import make_pipeline
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR, AUX_COLS,
    KEY_LINES, N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    line_integral, spectrum_features, compute_features, build_feature_matrix,
    find_best_shrinkage,
)

label_map, aux_map = load_labels()

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


# ── 可配置的特征矩阵构建 ────────────────────────────────────────────────────────

def build_feature_matrix_custom(data, n_batches, n_pca_max=30, fit=True,
                                 scaler_spec=None, pca=None, scaler_hand=None):
    """支持自定义N_PCA_MAX的特征矩阵构建。"""
    inorm_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(n_pca_max, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))

    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


# ── 可配置的两阶段OOF ──────────────────────────────────────────────────────────

def stage1_stage2_oof(X_spec, y, aux, groups, splits, model_type='ridge', alphas=None):
    """两阶段OOF，支持Ridge/ElasticNet。"""
    if alphas is None:
        alphas = ALPHAS
    oof_p, oof_t = [], []
    for tr_idx, val_idx in splits:
        pa = np.zeros_like(aux, dtype=np.float32)
        for ci in range(aux.shape[1]):
            ya = aux[:, ci]
            if np.isnan(ya).any():
                pa[:, ci] = float(np.nanmean(ya))
                continue
            if model_type == 'ridge':
                m1 = RidgeCV(alphas=alphas)
            elif model_type == 'elasticnet':
                m1 = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE)
            elif model_type == 'lasso':
                m1 = LassoCV(cv=3, random_state=RANDOM_STATE)
            m1.fit(X_spec[tr_idx], ya[tr_idx])
            pa[val_idx, ci] = m1.predict(X_spec[val_idx])

        X2_tr = np.hstack([X_spec[tr_idx], pa[tr_idx]])
        X2_val = np.hstack([X_spec[val_idx], pa[val_idx]])
        X2_tr = np.nan_to_num(X2_tr)
        X2_val = np.nan_to_num(X2_val)

        if model_type == 'ridge':
            m2 = RidgeCV(alphas=alphas)
        elif model_type == 'elasticnet':
            m2 = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE)
        elif model_type == 'lasso':
            m2 = LassoCV(cv=3, random_state=RANDOM_STATE)
        m2.fit(X2_tr, y[tr_idx])
        vp = m2.predict(X2_val)
        vg = groups[val_idx]
        for bg in np.unique(vg):
            mask = vg == bg
            oof_p.append(float(np.median(vp[mask])))
            oof_t.append(float(y[val_idx][mask][0]))
    return oof_p, oof_t


# ── 时间外推CV ──────────────────────────────────────────────────────────────────

def time_extrapolation(coal, model_type='ridge', n_pca_max=30, coal_alphas=None):
    """时间外推CV，支持自定义模型和参数。"""
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None
    y = train_data['targets']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    aux = train_data['aux']
    coal_mean = float(y.mean())
    names = train_data['names']

    alphas = coal_alphas if coal_alphas else ALPHAS
    X_spec, _, _, _ = build_feature_matrix_custom(train_data, n_batches, n_pca_max=n_pca_max, fit=True)
    is_small = n_batches <= SMALL_BATCH_THRESHOLD

    # 搜 w
    if is_small:
        dummy = np.zeros(len(groups))
        splits = list(LeaveOneGroupOut().split(dummy, dummy, groups))
        oof_p, oof_t = stage1_stage2_oof(X_spec, y, aux, groups, splits, model_type, alphas)
        w, _ = find_best_shrinkage(oof_p, oof_t, coal_mean)
    else:
        ws = []
        for seed in range(30):
            dummy = np.zeros(len(groups))
            gkf = GroupKFold(n_splits=5, shuffle=True, random_state=seed)
            splits = list(gkf.split(dummy, dummy, groups))
            oof_p, oof_t = stage1_stage2_oof(X_spec, y, aux, groups, splits, model_type, alphas)
            w_s, _ = find_best_shrinkage(oof_p, oof_t, coal_mean)
            ws.append(w_s)
        w = float(np.mean(ws))

    # 时间外推
    unique_batches = np.unique(groups)
    batch_to_month = {}
    for g in unique_batches:
        mask = groups == g
        idx = np.where(mask)[0][0]
        batch_to_month[g] = extract_month(names[idx])

    train_g = set(g for g in unique_batches if batch_to_month[g] in {10, 11})
    val_g   = set(g for g in unique_batches if batch_to_month[g] in {1, 2, 3})

    if len(train_g) < 3 or len(val_g) < 1:
        return {'w': w, 'coal_mean': coal_mean, 'is_small': is_small, 'no_split': True}

    train_mask = np.array([g in train_g for g in groups])
    val_mask   = np.array([g in val_g for g in groups])

    # 两阶段时间外推
    pa = np.zeros_like(aux, dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa[:, ci] = float(np.nanmean(ya))
            continue
        if model_type == 'ridge':
            m1 = RidgeCV(alphas=alphas)
        elif model_type == 'elasticnet':
            m1 = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE)
        elif model_type == 'lasso':
            m1 = LassoCV(cv=3, random_state=RANDOM_STATE)
        m1.fit(X_spec[train_mask], ya[train_mask])
        pa[:, ci] = m1.predict(X_spec)

    X2 = np.hstack([X_spec, pa])
    sc = StandardScaler()
    X2 = sc.fit_transform(np.nan_to_num(X2))
    if model_type == 'ridge':
        m2 = RidgeCV(alphas=alphas)
    elif model_type == 'elasticnet':
        m2 = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9, 0.95], cv=3, random_state=RANDOM_STATE)
    elif model_type == 'lasso':
        m2 = LassoCV(cv=3, random_state=RANDOM_STATE)
    m2.fit(X2[train_mask], y[train_mask])
    vp = m2.predict(X2[val_mask])

    vg = groups[val_mask]
    vy = y[val_mask]
    bp, bt = [], []
    for bg in np.unique(vg):
        mask = vg == bg
        bp.append(float(np.median(vp[mask])))
        bt.append(float(vy[mask][0]))

    cv_raw = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bp)])))
    bl = [w * p + (1-w) * coal_mean for p in bp]
    cv_shrunk = float(np.sqrt(np.mean([(t-p)**2 for t, p in zip(bt, bl)])))

    return {'cv_raw': cv_raw, 'cv_shrunk': cv_shrunk, 'w': w,
            'coal_mean': coal_mean, 'is_small': is_small}


def run_time_cv(name, model_type='ridge', n_pca_max=30, coal_alphas_map=None):
    """运行时间外推CV。"""
    print(f"\n{'='*55}")
    print(f"  {name}")
    print(f"{'='*55}")
    all_raw, all_shrunk = [], []
    for coal in COAL_TYPES:
        ca = coal_alphas_map.get(coal) if coal_alphas_map else None
        r = time_extrapolation(coal, model_type=model_type, n_pca_max=n_pca_max, coal_alphas=ca)
        if r is None:
            continue
        tag = 'small' if r['is_small'] else 'large'
        if r.get('no_split'):
            print(f"  [{coal}] ({tag}) w={r['w']:.2f}  mean={r['coal_mean']:.0f}  (no time split)")
        else:
            all_raw.append(r['cv_raw'])
            all_shrunk.append(r['cv_shrunk'])
            print(f"  [{coal}] ({tag}) raw={r['cv_raw']:.2f}  shrunk={r['cv_shrunk']:.2f}  w={r['w']:.2f}  mean={r['coal_mean']:.0f}")

    if all_raw:
        avg_raw = np.mean(all_raw)
        avg_shrunk = np.mean(all_shrunk)
        print(f"  >> avg raw={avg_raw:.2f}  avg shrunk={avg_shrunk:.2f}")
        return avg_shrunk
    return None


if __name__ == "__main__":
    results = {}

    # 基线
    results['V11b基线(ridge,alpha=default,n_pca=30)'] = run_time_cv(
        "基线: Ridge + default alphas + n_pca=30")

    # 方向1: 煤种级alpha调优
    # 赵固二矿: 高alpha(时间外推CV 206→114的历史记录)
    # 赵固一矿: 高alpha(时间外推CV 444, 需更强正则化)
    high_alpha = [100.0, 500.0, 1000.0, 5000.0, 10000.0, 50000.0, 100000.0]
    coal_alphas_high = {
        '赵固一矿豫焦末煤': high_alpha,
        '赵固二矿中煤矿': high_alpha,
    }
    results['方向1: 赵固一/二高alpha'] = run_time_cv(
        "方向1: 赵固一矿+赵固二矿用高alpha",
        coal_alphas_map=coal_alphas_high)

    # 全煤种高alpha
    results['方向1b: 全煤种高alpha'] = run_time_cv(
        "方向1b: 全煤种用高alpha",
        coal_alphas_map={ct: high_alpha for ct in COAL_TYPES})

    # 方向2: ElasticNet
    results['方向2: ElasticNet'] = run_time_cv(
        "方向2: ElasticNet替代Ridge",
        model_type='elasticnet')

    # 方向2b: Lasso
    results['方向2b: Lasso'] = run_time_cv(
        "方向2b: Lasso替代Ridge",
        model_type='lasso')

    # 方向3: N_PCA_MAX增大
    results['方向3: n_pca=50'] = run_time_cv(
        "方向3: N_PCA_MAX=50",
        n_pca_max=50)
    results['方向3b: n_pca=80'] = run_time_cv(
        "方向3b: N_PCA_MAX=80",
        n_pca_max=80)

    # 汇总
    print(f"\n{'='*55}")
    print("时间外推CV汇总 (avg shrunk, 越低越好)")
    print(f"{'='*55}")
    baseline = results.get('V11b基线(ridge,alpha=default,n_pca=30)')
    for name, cv in results.items():
        if cv is not None:
            delta = f"({'↑' if cv > baseline else '↓'}{abs(cv-baseline):.1f})" if baseline else ""
            print(f"  {name}: {cv:.2f} {delta}")
