"""
gen_v621_v640_v601_expand.py
V601=192.54 is NEW BEST! 赵固二→V63 is -1.91 better than V72.
Key insight: V63 can be MUCH better than V72 for some coals despite similar OOF.

V601 = V96 + 中马→V72 + 煤场→V63 + 赵固二→V63 (赵固一+九里山 unchanged)

Strategy: Test if V63 is also better for 中马 (untested pure, only 50/50 mix was bad).
         Also test 煤场→V72 (untested pure).
"""
import os, zipfile, io, numpy as np, pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
COAL_TYPES = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿', '九里山矿中煤矿', '煤场混煤']
pred_col = '预测发热量_MJ_KG'

def load_template(): return pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8-sig')
def load_pred(zn):
    p = os.path.join(OUTPUT_DIR, zn)
    if not os.path.exists(p): return None
    with zipfile.ZipFile(p, 'r') as zf:
        cn = [n for n in zf.namelist() if n.endswith('.csv')][0]
        with zf.open(cn) as f: return pd.read_csv(f, encoding='utf-8-sig')
def save_zip(df, zn):
    p = os.path.join(OUTPUT_DIR, zn)
    with zipfile.ZipFile(p, 'w', zipfile.ZIP_DEFLATED) as zf:
        buf = io.StringIO(); df.to_csv(buf, index=False, encoding='utf-8-sig')
        zf.writestr('submit.csv', buf.getvalue())
def corr(v1, v2): return float(np.corrcoef(v1, v2)[0, 1])

def main():
    print("=" * 70)
    print("EXPAND FROM V601 (192.54) — NEW BEST")
    print("=" * 70)

    template = load_template()
    template['coal'] = template['名称'].apply(
        lambda n: next((ct for ct in COAL_TYPES if ct in str(n)), 'unknown'))
    
    v61 = load_pred('submit_v61_a005_bias.zip')[pred_col].values
    v63 = load_pred('submit_v63_isotonic.zip')[pred_col].values
    v72 = load_pred('submit_v72_isotonic_a005.zip')[pred_col].values
    v96 = load_pred('submit_v96_blend_v74_v72_7525.zip')[pred_col].values

    zg1 = (template['coal'] == '赵固一矿豫焦末煤').values
    zg2 = (template['coal'] == '赵固二矿中煤矿').values
    zm  = (template['coal'] == '中马矿中煤矿').values
    jl  = (template['coal'] == '九里山矿中煤矿').values
    mc  = (template['coal'] == '煤场混煤').values

    # V601 = NEW BEST (192.54)
    v601 = v96.copy()
    v601[zm] = v72[zm]      # 中马→V72
    v601[mc] = v63[mc]      # 煤场→V63
    v601[zg2] = v63[zg2]    # 赵固二→V63 (NEW: was V72 in V577)

    results = []
    def gen(name, pred, desc):
        c = corr(pred, v96); m = np.mean(np.abs(pred - v96))
        df_out = template.copy(); df_out[pred_col] = pred
        save_zip(df_out, f'submit_{name}.zip')
        results.append((name, c, m, desc))
        print(f"  {name}: corr={c:.6f}, MAE={m:.2f} — {desc}")

    # === 1. 中马→V63 pure (UNTESTED, biggest potential) ===
    # V614_1 (中马 80/20 V72/V63) was +0.42 harmful, but that's a MIX
    # Pure V63 is a completely different prediction, not a dilution of V72
    # OOF: 中马 V63=197, V72=197 (identical!), but V63 was 1.91 better for 赵固二
    p = v601.copy()
    p[zm] = v63[zm]
    gen('v621_v601_zm_v63', p, "V601+中马→V63 (replace V72, UNTESTED pure)")

    # === 2. 煤场→V72 pure (UNTESTED) ===
    # V611_3 (煤场 80/20 V63/V72) was +0.70 harmful, suggesting V63> V72 for 煤场
    # But pure V72 is untested — the 80/20 mix doesn't tell us about pure V72
    p = v601.copy()
    p[mc] = v72[mc]
    gen('v622_v601_mc_v72', p, "V601+煤场→V72 (replace V63, UNTESTED pure)")

    # === 3. Both: 中马→V63 + 煤场→V72 ===
    p = v601.copy()
    p[zm] = v63[zm]
    p[mc] = v72[mc]
    gen('v623_v601_zm_v63_mc_v72', p, "V601+中马→V63+煤场→V72 (both changes)")

    # === 4. Safety: V601 blends ===
    p = 0.8 * v601 + 0.2 * v96
    gen('v624_v601_v96_8020', p, "V601*0.8+V96*0.2 (safety)")
    p = 0.9 * v601 + 0.1 * v96
    gen('v625_v601_v96_9010', p, "V601*0.9+V96*0.1 (safety)")

    # === 5. V601 + 赵固二 different ratios (fine-tune the big win) ===
    # V63 pure = -2.60 for 赵固二. Try slight V72/V96 mixes.
    for r63, r72, desc in [
        (0.9, 0.1, "赵固二 90/10 V63/V72"),
        (0.8, 0.2, "赵固二 80/20 V63/V72"),
        (0.7, 0.3, "赵固二 70/30 V63/V72"),
    ]:
        p = v601.copy()
        p[zg2] = r63 * v63[zg2] + r72 * v72[zg2]
        gen(f'v626_zg2_{r63}_{r72}', p, desc)

    # === 6. Try V63 for unchanged coals at partial weight ===
    # 赵固一→V63(100%)=+1.77, 九里山→V63(100%)=+1.44 (harmful at 100%)
    # But partial V63 (blended into V96) might be different
    for w1, w3, w2, desc in [
        (0.25, 0.50, 0.25, "unchanged 25/50/25 (more V63)"),
        (0.20, 0.50, 0.30, "unchanged 20/50/30 (more V63+V72)"),
        (0.30, 0.45, 0.25, "unchanged 30/45/25 (slight more V63)"),
    ]:
        p = v601.copy()
        unchanged = zg1 | jl
        p[unchanged] = w1 * v61[unchanged] + w3 * v63[unchanged] + w2 * v72[unchanged]
        gen(f'v630_unchanged_{w1:.2f}_{w3:.2f}_{w2:.2f}', p, desc)

    # === 7. ALL V63 for changed coals (中马 also V63) + safety ===
    p = v96.copy()
    p[zm] = v63[zm]      # 中马→V63
    p[mc] = v63[mc]      # 煤场→V63
    p[zg2] = v63[zg2]    # 赵固二→V63
    gen('v635_all_changed_v63', p, "all 3 changed coals→V63 (中马+煤场+赵固二)")

    # === Summary ===
    print("\n" + "=" * 70)
    print("SUMMARY (sorted by corr, highest = safest)")
    print("=" * 70)
    for name, c, m, desc in sorted(results, key=lambda x: -x[1]):
        print(f"  {name:<42} {c:.6f}  MAE={m:.2f}  {desc}")

    print("\n--- Known online scores ---")
    print("  V601 = 192.54 *** NEW BEST ***")
    print("  V577 = 194.45 (old best)")
    print("  V614_1 = 194.87 (中马 80/20 mix, +0.42 harmful)")
    print("  V611_3 = 195.15 (煤场 80/20 mix, +0.70 harmful)")
    print()
    print("--- Per-coal online decomposition (from V96=196.98) ---")
    print("  中马→V72  = -0.61 (5 batches)")
    print("  煤场→V63  = -1.22 (9 batches)")
    print("  赵固二→V63 = -2.60 (4 batches) ← V601 breakthrough")
    print("  赵固一→V63 = +1.77 (harmful)")
    print("  赵固一→V72 = +0.41 (harmful)")
    print("  九里山→V63 = +1.44 (harmful)")
    print("  九里山→V72 = +0.72 (harmful)")
    print()
    print("--- TOP PRIORITY: V621 (中马→V63 pure) ---")
    print("  If V63 is also better for 中马 (like 赵固二), could improve 1-2 points")

if __name__ == '__main__':
    main()
