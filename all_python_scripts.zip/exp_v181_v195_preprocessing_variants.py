"""
exp_v181_v195_preprocessing_variants.py

V178(per-coal)=201.03, gap=35 (normal) but still worse than V96=196.98.
V105(BR)=261.90, V146(PCA-only)=282.70 -> non-Ridge or no-hand-features = disaster.
V164(hand-only)=untested but V178 used it for 中马矿 and V178 is 4pts worse.

Strategy: Stay in V61's exact pipeline but change ONLY the spectral preprocessing.
SNV is just one of many standard NIR preprocessings. Different preprocessing
might produce different predictions with similar reliability.

V181: MSC (Multiplicative Scatter Correction) - classic NIR, fundamentally different from SNV
V182: Area normalization (normalize by sum instead of mean/std)
V183: Vector normalization (L2 norm)
V184: First derivative (np.diff, no smoothing)
V185: MSC + hand features + two-stage Ridge (full pipeline)
V186: Mean centering only (no scaling)
V187: SNV + mean-centering of hand features only (no scaling of hand features)

Also: Fine-grained V74+V72 ratio scan and three-way weight optimization.
"""
import os, sys, re, glob, warnings, io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from datetime import datetime

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

N_PCA_MAX = 30
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    return weights / weights.mean()


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx, 'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


# =====================================================================
# Preprocessing methods
# =====================================================================

def preprocess_snv(inten):
    """Standard Normal Variate"""
    return (inten - inten.mean()) / (inten.std() + 1e-8)


def preprocess_msc(inten, ref=None):
    """Multiplicative Scatter Correction.
    Needs a reference spectrum (mean of training set).
    If ref is None, uses mean of the current batch (approximate MSC)."""
    if ref is None:
        ref = inten.mean(axis=0) if inten.ndim > 1 else inten
    # Fit linear regression: inten = a*ref + b
    a, b = np.polyfit(ref, inten, 1)
    return (inten - b) / (a + 1e-8)


def preprocess_area_norm(inten):
    """Area normalization: divide by sum"""
    return inten / (inten.sum() + 1e-8)


def preprocess_vector_norm(inten):
    """Vector normalization: divide by L2 norm"""
    return inten / (np.sqrt((inten ** 2).sum()) + 1e-8)


def preprocess_first_deriv(inten):
    """First derivative (simple diff, no smoothing)"""
    return np.diff(inten)


def preprocess_mean_center(inten):
    """Mean centering only (no scaling)"""
    return inten - inten.mean()


def compute_features(data, preprocessing='snv', msc_ref=None):
    raw_spectra = data['spectra']
    spec_mats, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    
    for i, (wl, inten) in enumerate(raw_spectra):
        if preprocessing == 'snv':
            processed = preprocess_snv(inten)
        elif preprocessing == 'area':
            processed = preprocess_area_norm(inten)
        elif preprocessing == 'vector':
            processed = preprocess_vector_norm(inten)
        elif preprocessing == 'deriv1':
            processed = preprocess_first_deriv(inten)
        elif preprocessing == 'mean_center':
            processed = preprocess_mean_center(inten)
        elif preprocessing == 'msc':
            if msc_ref is not None:
                processed = preprocess_msc(inten, msc_ref)
            else:
                # Fallback: use SNV if no ref available
                processed = preprocess_snv(inten)
        else:
            processed = preprocess_snv(inten)
        
        spec_mats.append(processed)
        # Hand features always from raw inten (domain knowledge doesn't change)
        _, stats, labs, lrel, rats = spectrum_features(wl, inten)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    
    # Ensure all spectra have same length
    min_len = min(len(s) for s in spec_mats)
    spec_mat = np.array([s[:min_len] for s in spec_mats], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return spec_mat


def build_feature_matrix(data, n_batches, scaler_spec=None, pca=None, scaler_hand=None,
                         fit=True, n_pca_max=N_PCA_MAX):
    spec_mat = data.get('_spec_mat')
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(spec_mat)
        n_pca = min(n_pca_max, n_batches - 1, spec_scaled.shape[0] - 1)
        n_pca = max(1, n_pca)
        pca = PCA(n_components=n_pca, random_state=42)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(spec_mat))
    
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    k = min(5, n_batches)
    if seed is not None:
        gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
    else:
        gkf = GroupKFold(n_splits=k)
    return list(gkf.split(dummy, dummy, groups))


def batch_aggregate(preds_mask):
    return float(np.median(preds_mask))


def find_best_shrinkage(oof_preds, oof_true, coal_center):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_center
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                  sample_weights=None, ridge_alpha=0.05):
    def fit_ridge(m, X_tr, y_tr, sw=None):
        if sw is not None:
            m.fit(X_tr, y_tr, sample_weight=sw)
        else:
            m.fit(X_tr, y_tr)

    # Stage 1: aux
    aux_models = {}
    predicted_aux_oof = np.zeros_like(aux, dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_oof[:, col_idx] = float(np.nanmean(y_aux))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=ridge_alpha)
        oof = np.zeros(len(y_aux))
        for tr_idx, val_idx in splits:
            fit_ridge(m, X[tr_idx], y_aux[tr_idx], sample_weights[tr_idx] if sample_weights is not None else None)
            oof[val_idx] = m.predict(X[val_idx])
        predicted_aux_oof[:, col_idx] = oof
        m_full = Ridge(alpha=ridge_alpha)
        fit_ridge(m_full, X, y_aux, sample_weights)
        aux_models[col_name] = m_full

    X_s2 = np.hstack([X, predicted_aux_oof])
    scaler_s2 = StandardScaler()
    X_s2 = scaler_s2.fit_transform(np.nan_to_num(X_s2))

    # Stage 2: calorific
    oof_batch_preds, oof_batch_true, batch_rmses = [], [], []
    for tr_idx, val_idx in splits:
        m2 = Ridge(alpha=ridge_alpha)
        fit_ridge(m2, X_s2[tr_idx], y[tr_idx], sample_weights[tr_idx] if sample_weights is not None else None)
        val_pred = m2.predict(X_s2[val_idx])
        val_groups = groups[val_idx]
        fold_se = []
        for bg in np.unique(val_groups):
            mask = val_groups == bg
            true_q = float(y[val_idx][mask][0])
            pred_q = batch_aggregate(val_pred[mask])
            oof_batch_preds.append(pred_q)
            oof_batch_true.append(true_q)
            fold_se.append((true_q - pred_q) ** 2)
        batch_rmses.append(float(np.sqrt(np.mean(fold_se))))

    cv_rmse_raw = float(np.mean(batch_rmses))
    best_w, cv_rmse = find_best_shrinkage(oof_batch_preds, oof_batch_true, coal_center)
    final_model = Ridge(alpha=ridge_alpha)
    fit_ridge(final_model, X_s2, y, sample_weights)

    return {
        'aux_models': aux_models, 'scaler_s2': scaler_s2,
        'final_model': final_model,
        'cv_rmse': cv_rmse, 'cv_rmse_raw': cv_rmse_raw,
        'shrink_w': best_w,
        'oof_preds': np.array(oof_batch_preds),
        'oof_true': np.array(oof_batch_true),
    }


def predict_test(X_test, test_data, run, coal_center):
    n_test = len(X_test)
    pred_aux = np.zeros((n_test, len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        m = run['aux_models'].get(col_name)
        if m is not None:
            pred_aux[:, col_idx] = m.predict(X_test)
    X_test_s = run['scaler_s2'].transform(
        np.nan_to_num(np.hstack([X_test, pred_aux])))
    preds = run['final_model'].predict(X_test_s)
    batch_pred = {}
    shrink_w = run['shrink_w']
    test_names_arr = np.array(test_data['names'])
    for name in np.unique(test_names_arr):
        mask = test_names_arr == name
        bp = batch_aggregate(preds[mask])
        bp = shrink_w * bp + (1 - shrink_w) * coal_center
        batch_pred[str(name)] = bp
    return batch_pred


def train_and_predict_coal(coal, label_map, aux_map,
                           ridge_alpha=0.05, calibration='linear',
                           preprocessing='snv'):
    train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if train_data is None:
        return None

    # For MSC: compute reference spectrum from training data
    msc_ref = None
    if preprocessing == 'msc':
        all_intens = [inten for _, inten in train_data['spectra']]
        min_len = min(len(i) for i in all_intens)
        all_intens_arr = np.array([i[:min_len] for i in all_intens])
        msc_ref = all_intens_arr.mean(axis=0)

    spec_mat = compute_features(train_data, preprocessing=preprocessing, msc_ref=msc_ref)
    train_data['_spec_mat'] = spec_mat

    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_center = float(y.mean())

    X, scaler_spec, pca, scaler_hand = build_feature_matrix(train_data, n_batches, fit=True)

    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if coal in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal]
        months = train_data['months']
        if len(months) == len(y):
            sample_weights = compute_time_weights(months, TEST_MONTH, tau)

    seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
    runs = []
    for seed in seeds:
        splits = get_cv_splits(groups, n_batches, seed=seed)
        run = train_one_run(X, y, aux, groups, splits, coal_center, n_batches,
                            sample_weights, ridge_alpha)
        runs.append(run)

    if is_small:
        r = runs[0]
        print(f"    N={len(y)}  CV-RMSE: raw={r['cv_rmse_raw']:.2f}  "
              f"shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
    else:
        cv_rmses = [r['cv_rmse'] for r in runs]
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        print(f"    N={len(y)}  CV-RMSE: {np.mean(cv_rmses):.2f} "
              f"+/- {np.std(cv_rmses):.2f}  w={avg_w:.2f}")

    cv_rmse = np.mean([r['cv_rmse'] for r in runs])
    all_oof_p = np.concatenate([r['oof_preds'] for r in runs])
    all_oof_t = np.concatenate([r['oof_true'] for r in runs])

    calibrator = None
    if calibration == 'linear':
        lr = LinearRegression()
        lr.fit(all_oof_p.reshape(-1, 1), all_oof_t)
        a, b = float(lr.coef_[0]), float(lr.intercept_)
        calibrator = ('linear', a, b)
        print(f"    Bias: a={a:.4f}, b={b:.2f}")
    elif calibration == 'isotonic':
        ir = IsotonicRegression(out_of_bounds='clip', increasing=True)
        ir.fit(all_oof_p, all_oof_t)
        calibrator = ('isotonic', ir)

    test_data = load_coal_spectra(TEST_DIR, coal, label_map=None, aux_map=None)
    if test_data is None:
        return None

    test_spec_mat = compute_features(test_data, preprocessing=preprocessing, msc_ref=msc_ref)
    test_data['_spec_mat'] = test_spec_mat

    X_test = build_feature_matrix(test_data, n_batches=None,
                                  scaler_spec=scaler_spec, pca=pca,
                                  scaler_hand=scaler_hand, fit=False)

    all_batch_preds = []
    for run in runs:
        bp = predict_test(X_test, test_data, run, coal_center)
        all_batch_preds.append(bp)

    batch_names = list(all_batch_preds[0].keys())
    test_preds = {}
    for name in batch_names:
        vals = [bp[name] for bp in all_batch_preds]
        pred_val = float(np.mean(vals))
        if calibrator is not None:
            if calibrator[0] == 'linear':
                _, a, b = calibrator
                pred_val = a * pred_val + b
            elif calibrator[0] == 'isotonic':
                _, ir = calibrator
                pred_val = float(ir.predict([pred_val])[0])
        test_preds[name] = pred_val

    return {'cv_rmse': cv_rmse, 'test_preds': test_preds}


def pack_submission(variant_name, all_preds, cv_results, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    global_cv = float(np.mean(list(cv_results.values()))) if cv_results else 0.0
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n\n"
    readme += "## CV-RMSE\n\n| 煤种 | CV-RMSE |\n|---|---|\n"
    for ct, rmse in cv_results.items():
        readme += f"| {ct} | {rmse:.2f} |\n"
    readme += f"| **全局** | **{global_cv:.2f}** |\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"\n  [OK] {out_zip}")
    print(f"  Global CV-RMSE: {global_cv:.2f}")
    return out_zip, global_cv


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    return df.set_index('名称')['预测发热量_MJ_KG']


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, {}, desc)


def run_experiment(vid, desc, **kwargs):
    print(f"\n{'=' * 70}")
    print(f"  {vid}: {desc}")
    print(f"{'=' * 70}")
    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}
    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        result = train_and_predict_coal(coal, label_map, aux_map, **kwargs)
        if result is None:
            continue
        cv_results[coal] = result['cv_rmse']
        for name, pred in result['test_preds'].items():
            all_preds[name] = pred
            print(f"    {name}: {pred:.2f}")
    return pack_submission(vid, all_preds, cv_results, desc)


if __name__ == '__main__':
    results = {}

    # V181: MSC preprocessing + linear cal
    _, cv = run_experiment(
        'v181_msc_a005_linear',
        "MSC (Multiplicative Scatter Correction) + PCA(30) + hand features + two-stage Ridge. Classic NIR preprocessing, fundamentally different from SNV.",
        ridge_alpha=0.05, calibration='linear', preprocessing='msc')
    results['v181'] = cv

    # V182: Area normalization + linear cal
    _, cv = run_experiment(
        'v182_area_norm_a005_linear',
        "Area normalization + PCA(30) + hand features + two-stage Ridge.",
        ridge_alpha=0.05, calibration='linear', preprocessing='area')
    results['v182'] = cv

    # V183: Vector normalization + linear cal
    _, cv = run_experiment(
        'v183_vector_norm_a005_linear',
        "Vector normalization (L2) + PCA(30) + hand features + two-stage Ridge.",
        ridge_alpha=0.05, calibration='linear', preprocessing='vector')
    results['v183'] = cv

    # V184: First derivative + linear cal
    _, cv = run_experiment(
        'v184_deriv1_a005_linear',
        "First derivative (np.diff) + PCA(30) + hand features + two-stage Ridge.",
        ridge_alpha=0.05, calibration='linear', preprocessing='deriv1')
    results['v184'] = cv

    # V185: MSC + isotonic cal
    _, cv = run_experiment(
        'v185_msc_a005_isotonic',
        "MSC + PCA(30) + hand features + two-stage Ridge + isotonic calibration.",
        ridge_alpha=0.05, calibration='isotonic', preprocessing='msc')
    results['v185'] = cv

    # V186: Mean centering only + linear cal
    _, cv = run_experiment(
        'v186_mean_center_a005_linear',
        "Mean centering (no scaling) + PCA(30) + hand features + two-stage Ridge.",
        ridge_alpha=0.05, calibration='linear', preprocessing='mean_center')
    results['v186'] = cv

    # Summary
    print(f"\n{'=' * 70}")
    print("  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Baselines:")
    print(f"    V61 (SNV, linear):     CV=172.15  Online=203.21  gap=31")
    print(f"    V63 (SNV, isotonic):   CV=183.50  Online=203.60  gap=20")
    print(f"    V96 (V74+V72 75/25):   Online=196.98 (BEST)")
    print(f"    V178 (per-coal):        CV=166.20  Online=201.03  gap=35")
    print()
    for name, cv in results.items():
        status = "SAFE" if 170 <= cv <= 195 else ("OVERFIT?" if cv < 170 else "UNDERFIT?")
        print(f"    {name}: CV={cv:.2f}  [{status}]")
    print()

    # Correlation with V96
    print("  Correlation analysis:")
    v96 = load_existing_submission('submit_v96_blend_v74_v72_7525.zip')
    v61 = load_existing_submission('submit_v61_a005_bias.zip')
    v63 = load_existing_submission('submit_v63_isotonic.zip')
    v72 = load_existing_submission('submit_v72_isotonic_a005.zip')
    refs = {'V96': v96, 'V61': v61, 'V63': v63, 'V72': v72}
    
    for vid, cv in results.items():
        sub = load_existing_submission(f'submit_{vid}.zip')
        if sub is None:
            continue
        sub_arr = np.array(sub.values)
        corrs = {}
        for ref_name, ref in refs.items():
            if ref is not None:
                c = np.corrcoef(np.array(ref.values), sub_arr)[0, 1]
                corrs[ref_name] = c
        corr_v96 = corrs.get('V96', 1.0)
        min_corr = min(corrs.values())
        min_ref = min(corrs, key=corrs.get)
        blend_ok = "BLEND OK" if (170 <= cv <= 195 and corr_v96 < 0.995) else "SKIP"
        print(f"    {vid}: CV={cv:.2f}  corr(V96)={corr_v96:.4f}  "
              f"min_corr={min_corr:.4f}({min_ref})  [{blend_ok}]")

    # Auto-generate blends for promising models
    print()
    print("  Auto-generating blends for promising models...")
    if v96 is not None:
        v96_arr = np.array(v96.values)
        for vid, cv in results.items():
            if not (170 <= cv <= 195):
                print(f"    {vid}: CV={cv:.2f} outside safe range, skip")
                continue
            sub = load_existing_submission(f'submit_{vid}.zip')
            if sub is None:
                continue
            sub_arr = np.array(sub.values)
            corr = np.corrcoef(v96_arr, sub_arr)[0, 1]
            if corr >= 0.995:
                print(f"    {vid}: corr={corr:.4f} too high, skip")
                continue
            
            print(f"    {vid}: CV={cv:.2f}, corr={corr:.4f} -> GENERATING BLENDS")
            for w96, w_new in [(0.90, 0.10), (0.80, 0.20)]:
                blend_name = f'{vid}_blend_v96_{vid}_{int(w96*100)}{int(w_new*100)}'
                desc = f"V96 {w96*100:.0f}% + {vid} {w_new*100:.0f}%. CV={cv:.2f}, corr={corr:.4f}."
                pack_blend(blend_name,
                           [('v96_blend_v74_v72_7525', w96), (vid, w_new)],
                           desc)

    # Also generate fine-grained V74+V72 ratios
    print()
    print("  Fine-grained V74+V72 ratio scan:")
    v74_name = 'v74_blend_v61_v63_5050'
    v72_name = 'v72_isotonic_a005'
    for w74, w72, vid in [(0.72, 0.28, 'v187'), (0.73, 0.27, 'v188'),
                           (0.77, 0.23, 'v189'), (0.78, 0.22, 'v190')]:
        desc = f'V74 {w74*100:.0f}% + V72 {w72*100:.0f}%. Fine-grained ratio scan around V96(75/25)=196.98.'
        print(f'    {vid}: V74 {w74*100:.0f}% + V72 {w72*100:.0f}%')
        pack_blend(f'{vid}_blend_v74_v72_{int(w74*100)}{int(w72*100)}',
                   [(v74_name, w74), (v72_name, w72)],
                   desc)

    # Three-way optimized: V61 + V63 + V72 with various weights
    print()
    print("  Three-way weight optimization:")
    three_way_configs = [
        (0.35, 0.35, 0.30, 'v191'),  # less V72
        (0.40, 0.40, 0.20, 'v192'),  # even less V72
        (0.30, 0.30, 0.40, 'v193'),  # more V72
        (0.45, 0.35, 0.20, 'v194'),  # V61 dominant
        (0.35, 0.45, 0.20, 'v195'),  # V63 dominant
    ]
    for w61, w63, w72, vid in three_way_configs:
        desc = f'3-way: V61({w61*100:.0f}%) + V63({w63*100:.0f}%) + V72({w72*100:.0f}%). Direct weight optimization.'
        print(f'    {vid}: V61 {w61*100:.0f}% + V63 {w63*100:.0f}% + V72 {w72*100:.0f}%')
        pack_blend(f'{vid}_blend_3way_v61_v63_v72_{int(w61*100)}{int(w63*100)}{int(w72*100)}',
                   [('v61_a005_bias', w61), ('v63_isotonic', w63), ('v72_isotonic_a005', w72)],
                   desc)

    print("\n  Done.")
