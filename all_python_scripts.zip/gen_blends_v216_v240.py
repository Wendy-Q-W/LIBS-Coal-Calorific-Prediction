"""
gen_blends_v216_v240.py
Generate blends from alpha sweep models + correlation analysis.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, feature_desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    missing = template[template['预测发热量_MJ_KG'].isna()]['名称'].tolist()
    if missing:
        print(f"  WARNING: {len(missing)} missing: {missing}")
        template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{feature_desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    # Load all submissions
    models = {}
    model_names = [
        'submit_v96_blend_v74_v72_7525.zip',
        'submit_v74_blend_v61_v63_5050.zip',
        'submit_v61_snv_a005_linear.zip',
        'submit_v63_snv_a01_isotonic.zip',
        'submit_v72_snv_a005_isotonic.zip',
        'submit_v216_a015_linear.zip',
        'submit_v217_a020_linear.zip',
        'submit_v218_a015_isotonic.zip',
        'submit_v219_a020_isotonic.zip',
        'submit_v220_a030_isotonic.zip',
        'submit_v221_a003_linear.zip',
        'submit_v206_deriv1_a005_isotonic.zip',
        'submit_v184_deriv1_a005_linear.zip',
    ]
    
    for name in model_names:
        sub = load_existing_submission(name)
        if sub is not None:
            models[name] = sub
            print(f"  Loaded: {name}")
        else:
            print(f"  MISSING: {name}")
    
    # Correlation matrix with V96
    print(f"\n{'=' * 70}")
    print("  CORRELATION WITH V96")
    print(f"{'=' * 70}")
    
    v96_name = 'submit_v96_blend_v74_v72_7525.zip'
    if v96_name not in models:
        print("  V96 not found!")
        sys.exit(1)
    
    v96_arr = np.array(models[v96_name].values)
    
    for name, sub in models.items():
        if name == v96_name:
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        # Also compute MAE
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {name:50s}  corr={corr:.6f}  MAE={mae:.2f}")
    
    # Also compute pairwise correlations between key models
    print(f"\n{'=' * 70}")
    print("  PAIRWISE CORRELATIONS (key models)")
    print(f"{'=' * 70}")
    
    key_models = [
        'submit_v61_snv_a005_linear.zip',
        'submit_v63_snv_a01_isotonic.zip',
        'submit_v72_snv_a005_isotonic.zip',
        'submit_v216_a015_linear.zip',
        'submit_v218_a015_isotonic.zip',
        'submit_v220_a030_isotonic.zip',
        'submit_v221_a003_linear.zip',
    ]
    
    for i, n1 in enumerate(key_models):
        if n1 not in models:
            continue
        for n2 in key_models[i+1:]:
            if n2 not in models:
                continue
            a1 = np.array(models[n1].values)
            a2 = np.array(models[n2].values)
            corr = np.corrcoef(a1, a2)[0, 1]
            if abs(corr) < 0.999:  # Only show non-trivial pairs
                print(f"  corr({n1.split('_')[1]}, {n2.split('_')[1]}) = {corr:.6f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_snv_a005_linear.zip'
    V63 = 'submit_v63_snv_a01_isotonic.zip'
    V72 = 'submit_v72_snv_a005_isotonic.zip'
    
    blends = [
        # V221 (alpha=0.03, CV=164) blends - low CV might mean high gap
        ('v234_blend_v96_v221_9010', [(V96, 0.9), ('submit_v221_a003_linear.zip', 0.1)],
         "V96(90%) + V221-a003-lin(10%). V221 has lowest CV=164."),
        ('v235_blend_v96_v221_9505', [(V96, 0.95), ('submit_v221_a003_linear.zip', 0.05)],
         "V96(95%) + V221-a003-lin(5%). Tiny addition of low-alpha model."),
        
        # V218 (alpha=0.15, isotonic) blends
        ('v236_blend_v96_v218_9010', [(V96, 0.9), ('submit_v218_a015_isotonic.zip', 0.1)],
         "V96(90%) + V218-a015-iso(10%)."),
        ('v237_blend_v96_v218_8020', [(V96, 0.8), ('submit_v218_a015_isotonic.zip', 0.2)],
         "V96(80%) + V218-a015-iso(20%)."),
        
        # V220 (alpha=0.30, isotonic) blends - very regularized
        ('v238_blend_v96_v220_9010', [(V96, 0.9), ('submit_v220_a030_isotonic.zip', 0.1)],
         "V96(90%) + V220-a030-iso(10%). Very regularized."),
        ('v239_blend_v96_v220_8020', [(V96, 0.8), ('submit_v220_a030_isotonic.zip', 0.2)],
         "V96(80%) + V220-a030-iso(20%)."),
        
        # Multi-way: V96 + V221 + V218 (low alpha + high alpha diversity)
        ('v240_blend_v96_v221_v218', [(V96, 0.85), ('submit_v221_a003_linear.zip', 0.075), ('submit_v218_a015_isotonic.zip', 0.075)],
         "V96(85%) + V221-a003(7.5%) + V218-a015-iso(7.5%). Low+high alpha diversity."),
        
        # Multi-way: V96 + V220 + V206 (very regularized + deriv1 isotonic)
        ('v241_blend_v96_v220_v206', [(V96, 0.85), ('submit_v220_a030_isotonic.zip', 0.075), ('submit_v206_deriv1_a005_isotonic.zip', 0.075)],
         "V96(85%) + V220-a030-iso(7.5%) + V206-deriv1-iso(7.5%)."),
        
        # New V74 equivalent with V221: V221+V63 50/50 (replace V61 with V221)
        ('v242_blend_v221_v63_5050', [('submit_v221_a003_linear.zip', 0.5), (V63, 0.5)],
         "V221-a003(50%) + V63-a01-iso(50%). Replace V61 with less regularized V221."),
        
        # V242 + V72 75/25 (V96 equivalent with V221)
        ('v243_blend_v242_v72_7525', [('submit_v242_blend_v221_v63_5050.zip', 0.75), (V72, 0.25)],
         "V242(75%) + V72(25%). V96 structure but with V221 instead of V61."),
        
        # V61 + V218 + V63 (3-way with alpha diversity, no V72)
        ('v244_blend_v61_v218_v63', [(V61, 0.4), ('submit_v218_a015_isotonic.zip', 0.2), (V63, 0.4)],
         "V61(40%) + V218-a015-iso(20%) + V63(40%). Alpha diversity within Ridge."),
        
        # V96 + V221 at very small weight (2.5%)
        ('v245_blend_v96_v221_975025', [(V96, 0.975), ('submit_v221_a003_linear.zip', 0.025)],
         "V96(97.5%) + V221-a003(2.5%). Minimal addition."),
        
        # V96 + V216 (alpha=0.15, linear) - linear cal diversity
        ('v246_blend_v96_v216_9010', [(V96, 0.9), ('submit_v216_a015_linear.zip', 0.1)],
         "V96(90%) + V216-a015-lin(10%). Higher alpha + linear cal."),
        
        # 4-way: V61 + V63 + V221 + V218
        ('v247_blend_4way_alpha', [(V61, 0.35), (V63, 0.35), ('submit_v221_a003_linear.zip', 0.15), ('submit_v218_a015_isotonic.zip', 0.15)],
         "4-way: V61(35%) + V63(35%) + V221-a003(15%) + V218-a015-iso(15%)."),
        
        # V96 + V244 (multi-alpha blend) 
        ('v248_blend_v96_v244_8020', [(V96, 0.8), ('submit_v244_blend_v61_v218_v63.zip', 0.2)],
         "V96(80%) + V244-3way-alpha(20%)."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    print(f"\n  Done. Generated {len(blends)} blends.")
