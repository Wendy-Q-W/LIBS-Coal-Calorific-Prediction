"""
exp_v49_raw_spectra.py
Phase 4: Alternative Feature Extraction — Raw Spectra Ridge

V39 uses SNV + PCA(30) + hand features = ~60 total features.
But all CV metrics are now anti-correlated. Maybe the feature engineering
itself is overfitting. What if we go to the other extreme: raw spectra
with minimal processing?

Approach: Use raw spectra (7305 dims) with Ridge, which does implicit
feature selection through regularization. This is the simplest possible
model — no SNV, no PCA, no hand features.

But 7305 features with ~100-700 samples = massive overfitting risk.
So we also try:
  A. Raw spectra + PCA(10/20/30) + Ridge
  B. Binned spectra (bin 10/20/50 points -> 730/365/146 dims) + Ridge  
  C. Selected wavelength regions (only around key lines, ~500 dims) + Ridge

All use V39's two-stage architecture and time weighting.
"""
import os, sys, re, glob, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
import zipfile

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.3,  15.0),
    'O':   (777.2,  15.0), 'N':   (742.4,  10.0),
    'Ca':  (422.7,  2.0),  'Ca2': (393.4,  2.0),
    'Mg':  (285.2,  2.0),  'Al':  (308.2,  2.0),
    'Si':  (288.2,  2.0),  'Fe':  (438.4,  3.0),
    'Na':  (589.0,  1.5),
}

RIDGE_ALPHA = 0.1
N_ENSEMBLE_SEEDS = 100
SMALL_BATCH_THRESHOLD = 11
TEST_MONTH = 12
TIME_WEIGHT_TAU = {
    '九里山矿中煤矿': 20,
    '煤场混煤':       30,
}

# ── Data loading ───────────────────────────────────────────────────────────

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5: continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except:
        return None, None
    if not wl: return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)

def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0

def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights

def load_labels():
    label_map, aux_map = {}, {}
    for coal in COAL_TYPES:
        fp = os.path.join(LABEL_DIR, f"{coal}.xlsx")
        if not os.path.exists(fp): continue
        df = pd.read_excel(fp)
        for _, row in df.iterrows():
            name = str(row['名称']).strip()
            q = float(row['发热量(Q)'])
            label_map[(coal, name)] = q
            aux = {
                '全水分': float(row.get('全水分', np.nan)),
                '灰分':   float(row.get('灰分', np.nan)),
                '氢':     float(row.get('氢', np.nan)),
                '硫':     float(row.get('硫', np.nan)),
            }
            aux_map[(coal, name)] = aux
    return label_map, aux_map

def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None, is_train=True):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir): return None
    spectra, names, targets, auxs, groups, months = [], [], [], [], [], []
    batch_idx = 0
    for batch_dir in sorted(os.listdir(coal_dir)):
        full = os.path.join(coal_dir, batch_dir)
        if not os.path.isdir(full): continue
        date_part = batch_dir.replace(coal_type, '').strip()
        month = extract_month(date_part)
        csvs = sorted(glob.glob(os.path.join(full, "*.csv")))
        if not csvs: continue
        for csv_path in csvs:
            wl, inten = read_spectrum_csv(csv_path)
            if wl is None: continue
            spectra.append((wl, inten))
            names.append(date_part)
            groups.append(batch_idx)
            months.append(month)
            if is_train and label_map:
                key = (coal_type, date_part)
                targets.append(label_map.get(key, np.nan))
                if aux_map and key in aux_map:
                    auxs.append(aux_map[key])
                else:
                    auxs.append({'全水分': np.nan, '灰分': np.nan, '氢': np.nan, '硫': np.nan})
        batch_idx += 1
    return {
        'spectra': spectra, 'names': names,
        'targets': np.array(targets, dtype=np.float64) if targets else None,
        'aux': auxs, 'groups': np.array(groups),
        'n_batches': batch_idx, 'months': np.array(months),
    }

# ── Feature extraction strategies ──────────────────────────────────────────

def extract_raw(spectra_list):
    """Raw spectra: total normalize + flatten. 7305 dims."""
    min_len = min(len(s[1]) for s in spectra_list)
    feats = []
    for wl, inten in spectra_list:
        i = inten[:min_len].copy()
        i = i / (i.sum() + 1e-8)  # total normalize
        feats.append(i)
    return np.array(feats, dtype=np.float32)

def extract_binned(spectra_list, bin_size=10):
    """Binned spectra: average every bin_size points. 7305/bin_size dims."""
    min_len = min(len(s[1]) for s in spectra_list)
    n_bins = min_len // bin_size
    feats = []
    for wl, inten in spectra_list:
        i = inten[:n_bins * bin_size].copy()
        i = i.reshape(n_bins, bin_size).mean(axis=1)
        i = i / (i.sum() + 1e-8)
        feats.append(i)
    return np.array(feats, dtype=np.float32)

def extract_key_regions(spectra_list, halfwin=15):
    """Key wavelength regions: extract +-halfwin nm around each KEY_LINE center.
    Concatenate all regions."""
    min_len = min(len(s[1]) for s in spectra_list)
    all_wl = spectra_list[0][0][:min_len]

    # Find indices for each key line region
    region_mask = np.zeros(min_len, dtype=bool)
    for name, (center, hw) in KEY_LINES.items():
        mask = (all_wl >= center - halfwin) & (all_wl <= center + halfwin)
        region_mask |= mask

    feats = []
    for wl, inten in spectra_list:
        i = inten[:min_len].copy()
        i = i / (i.sum() + 1e-8)
        feats.append(i[region_mask])
    return np.array(feats, dtype=np.float32)

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0

def extract_v39_features(spectra_list):
    """V39 pipeline: SNV for PCA + total norm for hand features."""
    min_len = min(len(s[1]) for s in spectra_list)
    N_PCA_MAX = 30

    snv_list, hand_list = [], []
    for wl, inten in spectra_list:
        inten_c = inten[:min_len].copy()
        wl_c = wl[:min_len].copy()

        total = inten_c.sum() + 1e-8
        inten_norm = inten_c / total
        snv = (inten_c - inten_c.mean()) / (inten_c.std() + 1e-8)

        d1 = np.diff(inten_norm)
        d2 = np.diff(d1)
        stats = np.array([
            inten_c.mean(), inten_c.std(), inten_c.max(), np.log1p(total),
            inten_norm.mean(), inten_norm.std(),
            float(skew(inten_norm)), float(kurtosis(inten_norm)),
            float(scipy_entropy(inten_norm + 1e-12)),
            np.percentile(inten_c, 10), np.percentile(inten_c, 25),
            np.percentile(inten_c, 75), np.percentile(inten_c, 90),
            d1.std(), np.abs(d1).mean(),
            d2.std(), np.abs(d2).mean(),
        ], dtype=np.float32)

        labs = np.array([line_integral(wl_c, inten_c, c, w) for c, w in KEY_LINES.values()],
                        dtype=np.float32)
        lrel = labs / (total + 1e-8)

        comb_sum = labs[[0, 1, 2, 3]].sum()
        ash_sum  = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
        rats = np.array([
            comb_sum / ash_sum, labs[1] / ash_sum,
            labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
        ], dtype=np.float32)

        snv = np.nan_to_num(snv, nan=0.0, posinf=0.0, neginf=0.0)
        hand = np.concatenate([stats, labs, lrel, rats])
        hand = np.nan_to_num(hand, nan=0.0, posinf=0.0, neginf=0.0)
        snv_list.append(snv)
        hand_list.append(hand)

    snv_mat = np.array(snv_list, dtype=np.float32)
    hand_feats = np.array(hand_list, dtype=np.float32)

    # PCA on SNV
    scaler = StandardScaler()
    snv_s = scaler.fit_transform(snv_mat)
    n_comp = min(N_PCA_MAX, snv_s.shape[0] - 1, snv_s.shape[1])
    pca = PCA(n_components=n_comp, random_state=42)
    snv_pca = pca.fit_transform(snv_s)
    X = np.hstack([snv_pca, hand_feats])
    return X

# ── Two-stage training ─────────────────────────────────────────────────────

def train_two_stage(X, y, aux_arr, groups, n_batches, sample_weights=None, seeds=[42]):
    coal_mean = float(np.mean(y))
    n = len(y)

    for j in range(aux_arr.shape[1]):
        col = aux_arr[:, j]
        mask = np.isnan(col)
        if mask.all():
            aux_arr[:, j] = 0.0
        elif mask.any():
            aux_arr[mask, j] = np.nanmean(col)

    all_runs = []
    for seed in seeds:
        np.random.seed(seed)
        if n_batches <= SMALL_BATCH_THRESHOLD:
            cv = LeaveOneGroupOut()
            splits = list(cv.split(X, y, groups))
        else:
            cv = GroupKFold(n_splits=5)
            splits = list(cv.split(X, y, groups))

        oof_preds = np.zeros(n)
        for tr_idx, val_idx in splits:
            # Stage 1: predict aux
            aux_oof_val = np.zeros((len(val_idx), aux_arr.shape[1]))
            for j in range(aux_arr.shape[1]):
                sc1 = StandardScaler()
                X_tr_s = sc1.fit_transform(X[tr_idx])
                X_val_s = sc1.transform(X[val_idx])
                m = Ridge(alpha=RIDGE_ALPHA)
                sw = sample_weights[tr_idx] if sample_weights is not None else None
                if sw is not None:
                    m.fit(X_tr_s, aux_arr[tr_idx, j], sample_weight=sw)
                else:
                    m.fit(X_tr_s, aux_arr[tr_idx, j])
                aux_oof_val[:, j] = m.predict(X_val_s)

            # Stage 2
            X_s2_tr = np.hstack([X[tr_idx], aux_arr[tr_idx]])
            X_s2_val = np.hstack([X[val_idx], aux_oof_val])
            sc = StandardScaler()
            X_s2_tr_s = sc.fit_transform(X_s2_tr)
            X_s2_val_s = sc.transform(X_s2_val)

            m2 = Ridge(alpha=RIDGE_ALPHA)
            sw = sample_weights[tr_idx] if sample_weights is not None else None
            if sw is not None:
                m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sw)
            else:
                m2.fit(X_s2_tr_s, y[tr_idx])
            oof_preds[val_idx] = m2.predict(X_s2_val_s)

        # Batch RMSE
        batch_preds, batch_trues = [], []
        for b in range(n_batches):
            mask = groups == b
            if mask.sum() == 0: continue
            batch_preds.append(np.median(oof_preds[mask]))
            batch_trues.append(y[mask][0])
        batch_preds = np.array(batch_preds)
        batch_trues = np.array(batch_trues)
        rmse = np.sqrt(np.mean((batch_preds - batch_trues) ** 2))

        # Shrinkage
        best_w, best_rmse = 1.0, rmse
        for w in np.linspace(0, 1, 21):
            blended = w * batch_preds + (1 - w) * coal_mean
            r = np.sqrt(np.mean((blended - batch_trues) ** 2))
            if r < best_rmse:
                best_rmse = r
                best_w = w

        # Final model
        sc_full = StandardScaler()
        X_s = sc_full.fit_transform(X)
        aux_full = np.zeros((n, aux_arr.shape[1]))
        for j in range(aux_arr.shape[1]):
            m = Ridge(alpha=RIDGE_ALPHA)
            sw = sample_weights if sample_weights is not None else None
            if sw is not None:
                m.fit(X_s, aux_arr[:, j], sample_weight=sw)
            else:
                m.fit(X_s, aux_arr[:, j])
            aux_full[:, j] = m.predict(X_s)

        X_s2_full = np.hstack([X_s, aux_full])
        sc_s2 = StandardScaler()
        X_s2_full_s = sc_s2.fit_transform(X_s2_full)
        m_final = Ridge(alpha=RIDGE_ALPHA)
        sw = sample_weights if sample_weights is not None else None
        if sw is not None:
            m_final.fit(X_s2_full_s, y, sample_weight=sw)
        else:
            m_final.fit(X_s2_full_s, y)

        all_runs.append({
            'scaler': sc_full,
            'scaler_s2': sc_s2,
            'final_model': m_final,
            'cv_rmse': best_rmse,
            'cv_rmse_raw': rmse,
            'shrink_w': best_w,
            'coal_mean': coal_mean,
        })

    return all_runs

def predict_test(X_test, test_groups, n_test_batches, runs):
    all_batch_preds = []
    for run in runs:
        X_test_s = run['scaler'].transform(X_test)
        n_test = len(X_test)
        aux_test = np.zeros((n_test, 4))
        X_s2_test = np.hstack([X_test_s, aux_test])
        X_s2_test_s = run['scaler_s2'].transform(X_s2_test)
        preds = run['final_model'].predict(X_s2_test_s)

        batch_preds = []
        for b in range(n_test_batches):
            mask = test_groups == b
            if mask.sum() == 0:
                batch_preds.append(run['coal_mean'])
            else:
                bp = np.median(preds[mask])
                bp = run['shrink_w'] * bp + (1 - run['shrink_w']) * run['coal_mean']
                batch_preds.append(bp)
        all_batch_preds.append(batch_preds)

    return np.mean(all_batch_preds, axis=0)

# ── Main ───────────────────────────────────────────────────────────────────

def run_strategy(name, extract_func, extract_kwargs={}):
    print(f"\n{'=' * 70}")
    print(f"  Strategy: {name}")
    print(f"{'=' * 70}")

    label_map, aux_map = load_labels()
    all_preds = {}
    cv_results = {}

    for coal in COAL_TYPES:
        print(f"\n  [{coal}]")
        train_data = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map, is_train=True)
        if train_data is None:
            print("    SKIP")
            continue

        n_batches = train_data['n_batches']
        n_orig = len(train_data['spectra'])
        y = train_data['targets']

        # Extract features
        X = extract_func(train_data['spectra'], **extract_kwargs)
        X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

        # Convert aux
        aux_list = []
        for a in train_data['aux']:
            aux_list.append([a.get(col, np.nan) for col in AUX_COLS])
        aux_arr = np.array(aux_list, dtype=np.float32)

        groups = train_data['groups']
        months = train_data['months']

        # Time weights
        sw = None
        if coal in TIME_WEIGHT_TAU:
            tw = compute_time_weights(months, TEST_MONTH, TIME_WEIGHT_TAU[coal])
            sw = tw

        is_small = n_batches <= SMALL_BATCH_THRESHOLD
        seeds = [42] if is_small else list(range(N_ENSEMBLE_SEEDS))
        runs = train_two_stage(X, y, aux_arr, groups, n_batches, sw, seeds)

        if is_small:
            r = runs[0]
            print(f"    N={n_orig}  dims={X.shape[1]}  "
                  f"CV-RMSE: raw={r['cv_rmse_raw']:.2f}  shrunk={r['cv_rmse']:.2f}  w={r['shrink_w']:.2f}")
        else:
            cv_rmses = [r['cv_rmse'] for r in runs]
            print(f"    N={n_orig}  dims={X.shape[1]}  "
                  f"CV-RMSE: {np.mean(cv_rmses):.2f} +/- {np.std(cv_rmses):.2f}")

        # Predict test
        test_data = load_coal_spectra(TEST_DIR, coal, is_train=False)
        if test_data is None:
            continue

        X_test = extract_func(test_data['spectra'], **extract_kwargs)
        X_test = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)

        preds = predict_test(X_test, test_data['groups'], test_data['n_batches'], runs)
        all_preds[coal] = preds
        cv_results[coal] = np.mean([r['cv_rmse'] for r in runs])

        test_names_arr = np.array(test_data['names'])
        for b in range(test_data['n_batches']):
            mask = test_data['groups'] == b
            if mask.sum() > 0:
                print(f"    {coal}{test_names_arr[mask][0]}: {preds[b]:.2f}")

    # Global CV
    all_cv = list(cv_results.values())
    global_cv = np.sqrt(np.mean([c**2 for c in all_cv]))
    print(f"\n  Global CV-RMSE: {global_cv:.2f}")

    # Pack submission
    template = pd.read_csv(SUBMIT_TEMPLATE)
    pred_map = {}
    for coal, preds in all_preds.items():
        test_data = load_coal_spectra(TEST_DIR, coal, is_train=False)
        test_names_arr = np.array(test_data['names'])
        for b in range(test_data['n_batches']):
            mask = test_data['groups'] == b
            if mask.sum() > 0:
                name = f"{coal}{test_names_arr[mask][0]}"
                pred_map[name] = preds[b]

    template['预测发热量_MJ_KG'] = template['名称'].map(pred_map).fillna(4000.0)

    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')

    out_zip = os.path.join(OUTPUT_DIR, f"submit_{name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")

    print(f"\n  [OK] {out_zip}")
    return out_zip

if __name__ == '__main__':
    # V49a: V39 baseline (for comparison — should match V39)
    # run_strategy('v49_v39baseline', extract_v39_features)

    # V49b: Binned spectra (bin_size=50, ~146 dims) — minimal feature engineering
    run_strategy('v49b_bin50', extract_binned, {'bin_size': 50})

    # V49c: Key wavelength regions only (~500 dims)
    run_strategy('v49c_keyreg', extract_key_regions, {'halfwin': 15})
