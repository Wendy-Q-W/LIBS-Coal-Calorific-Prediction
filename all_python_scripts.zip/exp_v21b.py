"""V21b: 精调新增谱线 — 哪些组合最优?
V21发现+5条新线双重CV改善(GK-3.89, TE-1.81)
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from all import KEY_LINES as KEY_LINES_V19
from exp_v20 import run_config_v20
from exp_v21 import make_extended_lines


if __name__ == "__main__":
    results = {}

    # 基线
    results['baseline'] = run_config_v20("V19基线", feature_mode='v19')

    # ── 逐条添加: 哪条新线贡献最大? ──
    new_lines = {
        'Ca3': (396.5, 2.0),
        'K':   (766.9, 2.0),
        'Mg2': (279.8, 2.0),
        'Ti':  (335.0, 2.0),
        'Sr':  (408.0, 2.0),
    }
    for name, (c, h) in new_lines.items():
        results[f'+{name}'] = run_config_v20(
            f"+{name}({c}nm)", key_lines=make_extended_lines({name: (c, h)}),
            feature_mode='v19')

    # ── 2条组合 ──
    combos_2 = [
        ('Ca3+Mg2', {'Ca3': (396.5, 2.0), 'Mg2': (279.8, 2.0)}),
        ('Ca3+Ti', {'Ca3': (396.5, 2.0), 'Ti': (335.0, 2.0)}),
        ('Ca3+Sr', {'Ca3': (396.5, 2.0), 'Sr': (408.0, 2.0)}),
        ('K+Mg2', {'K': (766.9, 2.0), 'Mg2': (279.8, 2.0)}),
        ('K+Ti', {'K': (766.9, 2.0), 'Ti': (335.0, 2.0)}),
        ('Mg2+Ti', {'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0)}),
        ('Mg2+Sr', {'Mg2': (279.8, 2.0), 'Sr': (408.0, 2.0)}),
        ('Ti+Sr', {'Ti': (335.0, 2.0), 'Sr': (408.0, 2.0)}),
    ]
    for name, lines in combos_2:
        results[f'+{name}'] = run_config_v20(
            f"+{name}", key_lines=make_extended_lines(lines),
            feature_mode='v19')

    # ── 3条组合 ──
    combos_3 = [
        ('Ca3+Mg2+Ti', {'Ca3': (396.5, 2.0), 'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0)}),
        ('Ca3+Mg2+Sr', {'Ca3': (396.5, 2.0), 'Mg2': (279.8, 2.0), 'Sr': (408.0, 2.0)}),
        ('Ca3+Ti+Sr', {'Ca3': (396.5, 2.0), 'Ti': (335.0, 2.0), 'Sr': (408.0, 2.0)}),
        ('Mg2+Ti+Sr', {'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0), 'Sr': (408.0, 2.0)}),
        ('K+Mg2+Ti', {'K': (766.9, 2.0), 'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0)}),
    ]
    for name, lines in combos_3:
        results[f'+{name}'] = run_config_v20(
            f"+{name}", key_lines=make_extended_lines(lines),
            feature_mode='v19')

    # ── 4条组合 ──
    results['+Ca3+Mg2+Ti+Sr'] = run_config_v20(
        "+Ca3+Mg2+Ti+Sr",
        key_lines=make_extended_lines({
            'Ca3': (396.5, 2.0), 'Mg2': (279.8, 2.0),
            'Ti': (335.0, 2.0), 'Sr': (408.0, 2.0),
        }), feature_mode='v19')

    # ── 全5条 (V21验证) ──
    results['+all5'] = run_config_v20(
        "+all5",
        key_lines=make_extended_lines({
            'Ca3': (396.5, 2.0), 'K': (766.9, 2.0),
            'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0), 'Sr': (408.0, 2.0),
        }), feature_mode='v19')

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V21b: 新增谱线精调")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':22s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:22s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
