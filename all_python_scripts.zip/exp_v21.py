"""V21: 新方向探索
基线: V19 main=5.0,metal=1.0 → GK=273.08, TE=240.20
方向:
  P1: 添加遗漏谱线 (396.5nm Ca2第二条线, 766.9nm K线, 279.8nm Mg线, 等)
  P2: 谱线积分方式改进 (梯形积分 vs 简单求和)
  P3: 光谱区域统计 (分波段统计: UV/visible/NIR)
  P4: 主元素不同窗口组合精调 (O×5+其他×3)
  P5: 辅助指标预测方式改进 (Stacking: 用Ridge预测aux时也用收缩)
"""
import sys, os, re, warnings, time, copy
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold
from sklearn.decomposition import PCA
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from all import (
    load_labels, load_coal_spectra, COAL_TYPES, TRAIN_DIR,
    KEY_LINES as KEY_LINES_V19, RANDOM_STATE, SMALL_BATCH_THRESHOLD,
    find_best_shrinkage,
)
from exp_v19 import (
    label_map, aux_map, TIME_COALS, RIDGE_ALPHA,
)
from exp_v20 import (
    spectrum_features_v20, compute_features_v20, build_fm_v20,
    oof_ridge_v20, gkfold_cv_v20, time_ext_v20, run_config_v20,
    extract_month,
)


def make_extended_lines(extra_lines):
    """在V19 KEY_LINES基础上添加新谱线"""
    kl = dict(KEY_LINES_V19)
    kl.update(extra_lines)
    return kl


if __name__ == "__main__":
    results = {}

    # ── 基线 (V19) ──
    results['baseline'] = run_config_v20("V19基线", feature_mode='v19')

    # ── P1: 添加遗漏强谱线 ──
    # 396.5nm = Ca II 第二条线 (prominence第2高!)
    # 766.9nm = K I 钾线 (prominence第3高!)
    # 279.8nm = Mg II 线
    # 335.0nm = 可能是Ti或Ca
    # 408.0nm = 可能是Ca或Sr
    results['+Ca396'] = run_config_v20(
        "+Ca396.5nm", key_lines=make_extended_lines({'Ca3': (396.5, 2.0)}),
        feature_mode='v19')

    results['+K766'] = run_config_v20(
        "+K766.9nm", key_lines=make_extended_lines({'K': (766.9, 2.0)}),
        feature_mode='v19')

    results['+Ca396+K766'] = run_config_v20(
        "+Ca396+K766", key_lines=make_extended_lines(
            {'Ca3': (396.5, 2.0), 'K': (766.9, 2.0)}),
        feature_mode='v19')

    results['+all_new'] = run_config_v20(
        "+5条新线", key_lines=make_extended_lines({
            'Ca3': (396.5, 2.0), 'K': (766.9, 2.0),
            'Mg2': (279.8, 2.0), 'Ti': (335.0, 2.0),
            'Sr': (408.0, 2.0),
        }), feature_mode='v19')

    # 新线也用大窗口
    results['+Ca396+K766_win5'] = run_config_v20(
        "+Ca396+K766 (win5)", key_lines=make_extended_lines({
            'Ca3': (396.5, 10.0), 'K': (766.9, 10.0),
        }), feature_mode='v19')

    # ── P2: 谱线积分方式改进 (梯形积分) ──
    # 这个需要在spectrum_features里改, 用feature_mode实现
    # 跳过: 梯形积分vs简单求和在密集采样下差异极小

    # ── P3: 光谱区域统计 ──
    # 将光谱分成UV(200-400nm), Vis(400-700nm), NIR(700-813nm)三段
    # 统计每段的总强度、均值、标准差
    # 这需要新增feature_mode, 暂跳过用V20框架实现

    # ── P4: 主元素不同窗口组合精调 ──
    # V19d显示O×5+C×3效果不错 (GK-4.34, TE-26.68)
    # 测试O用更大窗口, 其他用中等窗口
    from exp_v19d import make_diff
    results['O=7,other=3'] = run_config_v20(
        "O=7,other=3", key_lines=make_diff(3.0, 1.0) | {
            'O': (777.2, 21.0)},  # O×7=3*7=21
        feature_mode='v19')

    results['O=5,C=5,H=3,N=3'] = run_config_v20(
        "O=5,C=5,H=3,N=3",
        key_lines={
            'C': (247.86, 10.0), 'H': (656.3, 9.0),
            'O': (777.2, 15.0), 'N': (742.4, 6.0),
            'Ca': (422.7, 2.0), 'Ca2': (393.4, 2.0),
            'Mg': (285.2, 2.0), 'Al': (308.2, 2.0),
            'Si': (288.2, 2.0), 'Fe': (438.4, 3.0),
            'Na': (589.0, 1.5),
        }, feature_mode='v19')

    results['O=5,C=5,H=5,N=3'] = run_config_v20(
        "O=5,C=5,H=5,N=3",
        key_lines={
            'C': (247.86, 10.0), 'H': (656.3, 15.0),
            'O': (777.2, 15.0), 'N': (742.4, 6.0),
            'Ca': (422.7, 2.0), 'Ca2': (393.4, 2.0),
            'Mg': (285.2, 2.0), 'Al': (308.2, 2.0),
            'Si': (288.2, 2.0), 'Fe': (438.4, 3.0),
            'Na': (589.0, 1.5),
        }, feature_mode='v19')

    # ── 汇总 ──
    print(f"\n{'='*60}")
    print("  V21: 新谱线+窗口组合探索")
    print(f"{'='*60}")
    base_gk = results.get('baseline', {}).get('gk', 999)
    base_te = results.get('baseline', {}).get('te', 999)
    print(f"  {'config':25s}  {'GK':>8s}  {'TE':>8s}  {'GK_d':>7s}  {'TE_d':>7s}  verdict")
    for name, val in results.items():
        if val is None: continue
        gk_d = val['gk'] - base_gk
        te_d = val['te'] - base_te
        gk_ok = "B" if gk_d < -0.5 else ("W" if gk_d > 0.5 else "~")
        te_ok = "B" if te_d < -0.5 else ("W" if te_d > 0.5 else "~")
        both = " **DOUBLE**" if gk_d < -0.5 and te_d < -0.5 else ""
        print(f"  {name:25s}  {val['gk']:8.2f}  {val['te']:8.2f}  {gk_d:+7.2f}  {te_d:+7.2f}  {gk_ok}/{te_ok}{both}")
