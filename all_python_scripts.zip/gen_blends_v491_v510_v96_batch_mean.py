"""
gen_blends_v491_v510_v96_batch_mean.py
Build TRUE V96_batch_mean using batch_mean versions of V61, V63, V72.

V61_bm = V457 (a=0.05 linear + mean), CV=166.63
V63_bm = V485 (a=0.10 iso + mean), CV=172.58
V72_bm = V448 (a=0.05 iso + mean), CV=166.63

V74_bm = V61_bm + V63_bm 50/50
V96_bm = V74_bm + V72_bm 75/25

Also compute correlations for all new batch_mean models.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    # References
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    # batch_mean models
    V448 = 'submit_v448_batch_mean.zip'       # V72_bm (a=0.05 iso + mean), CV=166.63
    V457 = 'submit_v457_bmean_linear.zip'     # V61_bm (a=0.05 linear + mean), CV=166.63
    V481 = 'submit_v481_bm_a003_iso.zip'      # a=0.03 iso + mean, CV=162.02
    V482 = 'submit_v482_bm_a004_iso.zip'      # a=0.04 iso + mean, CV=164.65
    V483 = 'submit_v483_bm_a006_iso.zip'      # a=0.06 iso + mean, CV=168.22
    V484 = 'submit_v484_bm_a008_iso.zip'      # a=0.08 iso + mean, CV=170.66
    V485 = 'submit_v485_bm_a010_iso.zip'      # V63_bm (a=0.10 iso + mean), CV=172.58
    V486 = 'submit_v486_bm_a015_iso.zip'      # a=0.15 iso + mean, CV=176.46
    V487 = 'submit_v487_bm_a003_lin.zip'      # a=0.03 linear + mean, CV=162.02
    V488 = 'submit_v488_bm_a010_lin.zip'      # a=0.10 linear + mean, CV=172.58
    
    # Existing batch_mean blends from v460-v480
    V460 = 'submit_v460_blend_v448_v63_5050.zip'
    V461 = 'submit_v461_blend_v460_v72_7525.zip'
    V469 = 'submit_v469_blend_v448_v457_5050.zip'
    V470 = 'submit_v470_blend_v469_v72_7525.zip'
    
    # === Correlation analysis for all batch_mean models ===
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS - batch_mean models")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V448_V72bm', V448),
        ('V457_V61bm', V457),
        ('V481_a003iso', V481),
        ('V482_a004iso', V482),
        ('V483_a006iso', V483),
        ('V484_a008iso', V484),
        ('V485_V63bm', V485),
        ('V486_a015iso', V486),
        ('V487_a003lin', V487),
        ('V488_a010lin', V488),
    ]
    
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:25s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # === Generate V96_batch_mean and related blends ===
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === TRUE V96_batch_mean ===
        # V74_bm = V457(V61_bm) + V485(V63_bm) 50/50
        ('v491_v74bm_v457_v485_5050', [(V457, 0.5), (V485, 0.5)],
         "V74_batch_mean = V457(V61_bm linear) + V485(V63_bm iso) 50/50. True V74 with batch_mean."),
        
        # V96_bm = V74_bm + V448(V72_bm) 75/25
        ('v492_v96bm_v491_v448_7525', [('submit_v491_v74bm_v457_v485_5050.zip', 0.75), (V448, 0.25)],
         "V96_batch_mean = V491(V74_bm) + V448(V72_bm) 75/25. TRUE V96 with batch_mean. CV~168.9."),
        
        # V96_bm with 77/23 (V189 ratio)
        ('v493_v96bm_7723', [('submit_v491_v74bm_v457_v485_5050.zip', 0.77), (V448, 0.23)],
         "V96_batch_mean 77/23 (V189 ratio)."),
        
        # V96_bm with 80/20
        ('v494_v96bm_8020', [('submit_v491_v74bm_v457_v485_5050.zip', 0.80), (V448, 0.20)],
         "V96_batch_mean 80/20."),
        
        # === V96 + V96_bm blends (inject batch_mean into V96) ===
        ('v495_v96_v96bm_9010', [(V96, 0.9), ('submit_v492_v96bm_v491_v448_7525.zip', 0.1)],
         "V96(90%) + V96_bm(10%). Inject 10% batch_mean into V96."),
        ('v496_v96_v96bm_8020', [(V96, 0.8), ('submit_v492_v96bm_v491_v448_7525.zip', 0.2)],
         "V96(80%) + V96_bm(20%)."),
        ('v497_v96_v96bm_9505', [(V96, 0.95), ('submit_v492_v96bm_v491_v448_7525.zip', 0.05)],
         "V96(95%) + V96_bm(5%). Minimal injection."),
        
        # === V189 + V96_bm blends ===
        ('v498_v189_v96bm_9010', [(V189, 0.9), ('submit_v492_v96bm_v491_v448_7525.zip', 0.1)],
         "V189(90%) + V96_bm(10%). Current best + batch_mean V96."),
        ('v499_v189_v96bm_8020', [(V189, 0.8), ('submit_v492_v96bm_v491_v448_7525.zip', 0.2)],
         "V189(80%) + V96_bm(20%)."),
        
        # === V481 (lowest CV batch_mean) blends ===
        # V481 + V63 (median) 50/50 - V74 with a=0.03 batch_mean
        ('v500_v481_v63_5050', [(V481, 0.5), (V63, 0.5)],
         "V481(a=0.03 iso bm, CV=162) + V63(median) 50/50."),
        
        # V500 + V72 75/25 - V96 structure with a=0.03 batch_mean
        ('v501_v500_v72_7525', [('submit_v500_v481_v63_5050.zip', 0.75), (V72, 0.25)],
         "V500(75%) + V72(25%). V96 structure with a=0.03 batch_mean."),
        
        # V96 + V481
        ('v502_v96_v481_9010', [(V96, 0.9), (V481, 0.1)],
         "V96(90%) + V481(10%). Inject lowest CV batch_mean."),
        ('v503_v96_v481_9505', [(V96, 0.95), (V481, 0.05)],
         "V96(95%) + V481(5%)."),
        
        # === V485 (V63_bm) blends ===
        # V485 + V457 50/50 = V74_bm (same as V491, but verify)
        # V485 + V63 (median) 50/50 - blend batch_mean and median V63
        ('v504_v485_v63_5050', [(V485, 0.5), (V63, 0.5)],
         "V485(V63_bm) + V63(V63_median) 50/50. Same model, different batch agg."),
        
        # V504 + V72 75/25
        ('v505_v504_v72_7525', [('submit_v504_v485_v63_5050.zip', 0.75), (V72, 0.25)],
         "V504(75%) + V72(25%). V96 with V63 batch_mean+median blend."),
        
        # === Cross: V96_bm + V96 (different ratios) ===
        ('v506_v96bm_v96_5050', [('submit_v492_v96bm_v491_v448_7525.zip', 0.5), (V96, 0.5)],
         "V96_bm(50%) + V96(50%). Equal blend of batch_mean and median V96."),
        ('v507_v96bm_v96_7525', [('submit_v492_v96bm_v491_v448_7525.zip', 0.75), (V96, 0.25)],
         "V96_bm(75%) + V96(25%). More batch_mean weight."),
        
        # === V470 (already generated) + V96_bm ===
        ('v508_v470_v96bm_5050', [(V470, 0.5), ('submit_v492_v96bm_v491_v448_7525.zip', 0.5)],
         "V470(bmean V74+V72) + V96_bm(true V96 bmean) 50/50."),
        
        # === V481 + V485 50/50 (both batch_mean, low alpha + high alpha) ===
        ('v509_v481_v485_5050', [(V481, 0.5), (V485, 0.5)],
         "V481(a=0.03 bm) + V485(a=0.10 bm) 50/50. Both batch_mean, alpha spread."),
        
        # V509 + V448 75/25
        ('v510_v509_v448_7525', [('submit_v509_v481_v485_5050.zip', 0.75), (V448, 0.25)],
         "V509(75%) + V448(25%). V96 structure with a=0.03/0.10 batch_mean."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # === Final correlation summary ===
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v491', 'v492', 'v493', 'v494', 'v495', 'v496', 'v497',
                  'v498', 'v499', 'v500', 'v501', 'v502', 'v503',
                  'v504', 'v505', 'v506', 'v507', 'v508', 'v509', 'v510']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
