"""
exp_v34_batch_pls.py
批次级 + PLS + 多视角融合实验

基于V33发现:
  - 批次级聚合(70样本): GK爆炸(+112) 但 TE改善(-5.95)
  - 根因: PCA无监督降维在70样本上不稳定
  - 183分方案用PLS(有监督降维) + 多视角融合

实验矩阵:
  1. 批次级 PLS(不同n_components) 替代 PCA+Ridge
  2. 批次级 多视角: [原始均值光谱PLS] + [二阶导数PLS] 低权重融合
  3. 批次级 PLS + 二阶导数拼接
  4. 批次级 PLS on 只用二阶导数(不含原始光谱)

双重CV: GK-CV(10seed) + TE-CV(10/11月->1/2/3月)
"""
import os, re, glob, warnings, time, copy
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from scipy.signal import savgol_filter
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")
TEST_DIR  = os.path.join(_HERE, "test_data",  "赛题数据划分", "测试集")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")
OUTPUT_DIR = os.path.join(_HERE, "output")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 10.0), 'H':   (656.30, 15.0),
    'O':   (777.20, 15.0), 'N':   (742.40, 10.0),
    'Ca':  (422.70, 2.0),  'Ca2': (393.40, 2.0),
    'Mg':  (285.20, 2.0),  'Al':  (308.20, 2.0),
    'Si':  (288.20, 2.0),  'Fe':  (438.40, 3.0),
    'Na':  (589.00, 1.5),
}

RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 10
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


# ═══════════════════════════════════════════════════════════════════════════════
# Data loading (reuse from V33)
# ═══════════════════════════════════════════════════════════════════════════════

def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra_raw(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    batches = []
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_spectra = []
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is not None:
                batch_spectra.append((wl, inten))
        if batch_spectra:
            batches.append({
                'name': batch_folder,
                'spectra': batch_spectra,
                'q': q,
                'aux': aux,
                'month': extract_month(batch_folder),
            })
    if not batches:
        return None
    return batches


# ═══════════════════════════════════════════════════════════════════════════════
# Batch aggregation + feature extraction
# ═══════════════════════════════════════════════════════════════════════════════

def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def aggregate_batch_to_super(batch, mode='mean_norm'):
    """聚合批次光谱为超级光谱, 返回归一化强度矩阵."""
    spectra = batch['spectra']
    wl = spectra[0][0]
    norm_spectra = []
    for _, inten in spectra:
        total = inten.sum() + 1e-8
        norm_spectra.append(inten / total)
    norm_mat = np.array(norm_spectra)
    if mode == 'mean_norm':
        super_norm = norm_mat.mean(axis=0)
    elif mode == 'trim_mean_norm':
        n = norm_mat.shape[0]
        if n <= 2:
            super_norm = norm_mat.mean(axis=0)
        else:
            trim = max(1, n // 10)
            sorted_mat = np.sort(norm_mat, axis=0)
            super_norm = sorted_mat[trim:n-trim].mean(axis=0)
    elif mode == 'median_norm':
        super_norm = np.median(norm_mat, axis=0)
    else:
        super_norm = norm_mat.mean(axis=0)
    return wl, super_norm


def build_batch_matrix(batches, mode='mean_norm'):
    """构建批次级矩阵: 返回超级归一化光谱矩阵 + 手工特征 + 标签.
    
    Returns:
      inorm_mat: (n_batches, n_wavelength) 归一化超级光谱
      hand_feats: (n_batches, n_hand) 手工特征
      y, aux, months, names
    """
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    y_list, aux_list, months_list, names_list = [], [], [], []

    for batch in batches:
        wl, super_norm = aggregate_batch_to_super(batch, mode)
        # 从超级光谱提取手工特征
        # 用 super_norm * n_spectra 作为"伪原始强度"
        super_inten = super_norm * len(batch['spectra'])
        _, stats, labs, lrel, rats = spectrum_features(wl, super_inten)
        inorms.append(super_norm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
        if batch['q'] is not None:
            y_list.append(batch['q'])
        if batch['aux'] is not None:
            aux_list.append([batch['aux'][c] for c in AUX_COLS])
        months_list.append(batch['month'])
        names_list.append(batch['name'])

    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    hand_feats = np.hstack([
        np.array(stats_list), np.array(labs_list),
        np.array(lrel_list), np.array(rats_list),
    ])
    y = np.array(y_list) if y_list else None
    aux = np.array(aux_list) if aux_list else None
    months = np.array(months_list, dtype=int)
    return inorm_mat, hand_feats, y, aux, months, names_list


# ═══════════════════════════════════════════════════════════════════════════════
# CV infrastructure
# ═══════════════════════════════════════════════════════════════════════════════

def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def get_cv_splits(groups, n_batches, seed=None):
    dummy = np.zeros(len(groups))
    if n_batches <= SMALL_BATCH_THRESHOLD:
        return list(LeaveOneGroupOut().split(dummy, dummy, groups))
    else:
        k = min(5, n_batches)
        if seed is not None:
            gkf = GroupKFold(n_splits=k, shuffle=True, random_state=seed)
        else:
            gkf = GroupKFold(n_splits=k)
        return list(gkf.split(dummy, dummy, groups))


# ═══════════════════════════════════════════════════════════════════════════════
# Model training: PLS-based approaches
# ═══════════════════════════════════════════════════════════════════════════════

def _pls_pipeline(inorm_tr, y_tr, aux_tr, inorm_va, n_pls,
                  sample_weights_tr=None, sg_deriv=0, sg_win=0, sg_poly=2):
    """PLS pipeline: StandardScaler -> (optional SG) -> PLS -> Ridge Stage2.
    
    sg_deriv=0: no derivative, use raw normalized spectrum
    sg_deriv=1: 1st order SG derivative
    sg_deriv=2: 2nd order SG derivative
    """
    # Apply SG derivative if requested
    if sg_deriv > 0 and sg_win > 0:
        inorm_tr = savgol_filter(inorm_tr, window_length=sg_win, polyorder=sg_poly,
                                 deriv=sg_deriv, axis=1)
        inorm_va = savgol_filter(inorm_va, window_length=sg_win, polyorder=sg_poly,
                                 deriv=sg_deriv, axis=1)

    # StandardScaler
    sc = StandardScaler()
    spec_tr = sc.fit_transform(inorm_tr)
    spec_va = sc.transform(inorm_va)

    # PLS: supervised dimensionality reduction
    n_comp = min(n_pls, spec_tr.shape[0] - 1, spec_tr.shape[1])
    n_comp = max(1, n_comp)  # ensure at least 1 component
    pls = PLSRegression(n_components=n_comp, scale=False)
    # PLS doesn't support sample_weight
    pls.fit(spec_tr, y_tr)
    pls_tr = pls.transform(spec_tr)
    pls_va = pls.transform(spec_va)

    return pls_tr, pls_va


def _ridge_stage2(pls_tr, pls_va, y_tr, aux_tr, aux_va,
                  sample_weights_tr=None):
    """Two-stage Ridge on PLS features."""
    # Stage 1: aux OOF on train (in-sample for simplicity in batch-level)
    pa_tr = np.zeros_like(aux_tr, dtype=np.float32)
    pa_va = np.zeros_like(aux_va, dtype=np.float32)
    for ci in range(aux_tr.shape[1]):
        ya = aux_tr[:, ci]
        if np.isnan(ya).any():
            fill = float(np.nanmean(ya))
            pa_tr[:, ci] = fill
            pa_va[:, ci] = fill
            continue
        m1 = Ridge(alpha=RIDGE_ALPHA)
        m1.fit(pls_tr, ya)
        pa_tr[:, ci] = m1.predict(pls_tr)
        pa_va[:, ci] = m1.predict(pls_va)

    X2_tr = np.nan_to_num(np.hstack([pls_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([pls_va, pa_va]))
    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights_tr is not None:
        m2.fit(X2_tr, y_tr, sample_weight=sample_weights_tr)
    else:
        m2.fit(X2_tr, y_tr)
    pred = m2.predict(X2_va)
    return pred


def train_pls_gk(inorm_mat, hand_feats, y, aux, groups, months, n_batches,
                 coal_type, n_pls=20, sg_deriv=0, sg_win=0, sg_poly=2,
                 use_hand_feats=False):
    """GK-CV for PLS-based batch-level model."""
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    def _run_one(splits):
        oof_preds, oof_true, fold_rmses = [], [], []
        for tr, va in splits:
            inorm_tr = inorm_mat[tr]
            inorm_va = inorm_mat[va]

            pls_tr, pls_va = _pls_pipeline(
                inorm_tr, y[tr], aux[tr], inorm_va, n_pls,
                sample_weights_tr=sample_weights[tr] if sample_weights is not None else None,
                sg_deriv=sg_deriv, sg_win=sg_win, sg_poly=sg_poly)

            if use_hand_feats:
                pls_tr = np.nan_to_num(np.hstack([pls_tr, hand_feats[tr]]), nan=0.0, posinf=0.0, neginf=0.0)
                pls_va = np.nan_to_num(np.hstack([pls_va, hand_feats[va]]), nan=0.0, posinf=0.0, neginf=0.0)

            pred = _ridge_stage2(
                pls_tr, pls_va, y[tr], aux[tr], aux[va],
                sample_weights_tr=sample_weights[tr] if sample_weights is not None else None)

            for j, idx in enumerate(va):
                oof_preds.append(float(pred[j]))
                oof_true.append(float(y[idx]))
            fold_se = [(float(y[idx]) - float(pred[j])) ** 2 for j, idx in enumerate(va)]
            fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

        cv_raw = float(np.mean(fold_rmses))
        best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
        return {
            'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw,
            'shrink_w': best_w,
            'oof_preds': np.array(oof_preds),
            'oof_true': np.array(oof_true),
        }

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _run_one(splits)
        return run, is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run_one(splits))
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_pls_te(inorm_mat, hand_feats, y, aux, months, n_batches, coal_type,
                 n_pls=20, sg_deriv=0, sg_win=0, sg_poly=2, use_hand_feats=False):
    """TE-CV: 10/11月训练, 1/2/3月验证."""
    coal_mean = float(y.mean())
    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    # If too few training samples for PLS, fallback to coal mean
    if len(tr_idx) < 3:
        oof_preds = np.full(len(val_idx), coal_mean)
        oof_true = y[val_idx].copy()
        rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
        best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
        return {
            'oof_preds': oof_preds, 'oof_true': oof_true,
            'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
            'shrink_w': best_w,
        }

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)

    inorm_tr = inorm_mat[tr_idx]
    inorm_va = inorm_mat[val_idx]

    pls_tr, pls_va = _pls_pipeline(
        inorm_tr, y[tr_idx], aux[tr_idx], inorm_va, n_pls,
        sg_deriv=sg_deriv, sg_win=sg_win, sg_poly=sg_poly)

    if use_hand_feats:
        pls_tr = np.nan_to_num(np.hstack([pls_tr, hand_feats[tr_idx]]), nan=0.0, posinf=0.0, neginf=0.0)
        pls_va = np.nan_to_num(np.hstack([pls_va, hand_feats[val_idx]]), nan=0.0, posinf=0.0, neginf=0.0)

    pred = _ridge_stage2(
        pls_tr, pls_va, y[tr_idx], aux[tr_idx], aux[val_idx],
        sample_weights_tr=sample_weights)

    oof_preds = pred.tolist()
    oof_true = y[val_idx].tolist()
    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w,
    }


def gk_cv_rmse(runs_or_run, is_small):
    if is_small:
        return runs_or_run['cv_rmse']
    return float(np.mean([r['cv_rmse'] for r in runs_or_run]))


# ═══════════════════════════════════════════════════════════════════════════════
# Multi-view fusion
# ═══════════════════════════════════════════════════════════════════════════════

def train_multiview_gk(inorm_mat, hand_feats, y, aux, groups, months, n_batches,
                       coal_type, n_pls=15, sg_wins=(11, 15, 21)):
    """Multi-view: raw + SG2 derivatives at multiple windows, low-weight fusion.
    
    View 1: raw normalized spectrum -> PLS -> Ridge -> pred1 (main, weight=1.0)
    View 2: SG2 win=11 -> PLS -> Ridge -> pred2 (weight=alpha)
    View 3: SG2 win=15 -> PLS -> Ridge -> pred3 (weight=alpha)
    View 4: SG2 win=21 -> PLS -> Ridge -> pred4 (weight=alpha)
    
    Final pred = pred1 + alpha*(pred2+pred3+pred4)/3
    """
    coal_mean = float(y.mean())
    is_small = n_batches <= SMALL_BATCH_THRESHOLD
    sample_weights = None
    if not is_small and coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months, TEST_MONTH, tau=tau)

    def _run_one(splits, fusion_alpha=0.1):
        oof_preds, oof_true, fold_rmses = [], [], []
        for tr, va in splits:
            # View 1: raw
            pls_tr1, pls_va1 = _pls_pipeline(
                inorm_mat[tr], y[tr], aux[tr], inorm_mat[va], n_pls,
                sg_deriv=0, sg_win=0)
            pred1 = _ridge_stage2(
                pls_tr1, pls_va1, y[tr], aux[tr], aux[va],
                sample_weights_tr=sample_weights[tr] if sample_weights is not None else None)

            # Views 2-4: SG2 at different windows
            aux_views = []
            for w in sg_wins:
                if w > inorm_mat.shape[1]:
                    continue
                pls_tr_v, pls_va_v = _pls_pipeline(
                    inorm_mat[tr], y[tr], aux[tr], inorm_mat[va], n_pls,
                    sg_deriv=2, sg_win=w, sg_poly=2)
                pred_v = _ridge_stage2(
                    pls_tr_v, pls_va_v, y[tr], aux[tr], aux[va],
                    sample_weights_tr=sample_weights[tr] if sample_weights is not None else None)
                aux_views.append(pred_v)

            # Fusion: main + low-weight average of derivative views
            if aux_views:
                aux_mean = np.mean(aux_views, axis=0)
                pred = pred1 + fusion_alpha * (aux_mean - pred1)
            else:
                pred = pred1

            for j, idx in enumerate(va):
                oof_preds.append(float(pred[j]))
                oof_true.append(float(y[idx]))
            fold_se = [(float(y[idx]) - float(pred[j])) ** 2 for j, idx in enumerate(va)]
            fold_rmses.append(float(np.sqrt(np.mean(fold_se))))

        cv_raw = float(np.mean(fold_rmses))
        best_w, cv_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
        return {
            'cv_rmse': cv_shrunk, 'cv_rmse_raw': cv_raw,
            'shrink_w': best_w,
            'oof_preds': np.array(oof_preds),
            'oof_true': np.array(oof_true),
        }

    if is_small:
        splits = get_cv_splits(groups, n_batches)
        run = _run_one(splits)
        return run, is_small
    else:
        runs = []
        for seed in ENSEMBLE_SEEDS:
            splits = get_cv_splits(groups, n_batches, seed=seed)
            runs.append(_run_one(splits))
        avg_w = float(np.mean([r['shrink_w'] for r in runs]))
        for r in runs:
            r['shrink_w'] = avg_w
        return runs, is_small


def train_multiview_te(inorm_mat, hand_feats, y, aux, months, n_batches, coal_type,
                       n_pls=15, sg_wins=(11, 15, 21), fusion_alpha=0.1):
    """TE-CV for multi-view."""
    coal_mean = float(y.mean())
    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    # If too few training samples, fallback to coal mean
    if len(tr_idx) < 3:
        oof_preds = np.full(len(val_idx), coal_mean)
        oof_true = y[val_idx].copy()
        rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
        best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
        return {
            'oof_preds': oof_preds, 'oof_true': oof_true,
            'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
            'shrink_w': best_w,
        }

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sample_weights = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)

    # View 1: raw
    pls_tr1, pls_va1 = _pls_pipeline(
        inorm_mat[tr_idx], y[tr_idx], aux[tr_idx], inorm_mat[val_idx], n_pls,
        sg_deriv=0, sg_win=0)
    pred1 = _ridge_stage2(
        pls_tr1, pls_va1, y[tr_idx], aux[tr_idx], aux[val_idx],
        sample_weights_tr=sample_weights)

    # Views 2-4: SG2
    aux_views = []
    for w in sg_wins:
        if w > inorm_mat.shape[1]:
            continue
        pls_tr_v, pls_va_v = _pls_pipeline(
            inorm_mat[tr_idx], y[tr_idx], aux[tr_idx], inorm_mat[val_idx], n_pls,
            sg_deriv=2, sg_win=w, sg_poly=2)
        pred_v = _ridge_stage2(
            pls_tr_v, pls_va_v, y[tr_idx], aux[tr_idx], aux[val_idx],
            sample_weights_tr=sample_weights)
        aux_views.append(pred_v)

    if aux_views:
        aux_mean = np.mean(aux_views, axis=0)
        pred = pred1 + fusion_alpha * (aux_mean - pred1)
    else:
        pred = pred1

    oof_preds = pred.tolist()
    oof_true = y[val_idx].tolist()
    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)
    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)
    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Experiment runner
# ═══════════════════════════════════════════════════════════════════════════════

def run_experiment(label_map, aux_map, config_name, mode='mean_norm',
                   model_type='pls', n_pls=20, sg_deriv=0, sg_win=0,
                   use_hand_feats=False, sg_wins=(11,15,21), fusion_alpha=0.1):
    t0 = time.time()
    print(f"\n{'='*70}")
    print(f"  {config_name}")
    print(f"{'='*70}", flush=True)

    gk_results = {}
    te_results = {}
    for coal_type in COAL_TYPES:
        batches = load_coal_spectra_raw(TRAIN_DIR, coal_type, label_map, aux_map)
        if batches is None or len(batches) == 0:
            continue
        n_batches = len(batches)
        inorm_mat, hand_feats, y, aux, months, names = build_batch_matrix(batches, mode)
        n_spec_total = sum(len(b['spectra']) for b in batches)
        groups = np.arange(n_batches)

        if model_type == 'pls':
            runs, is_small = train_pls_gk(
                inorm_mat, hand_feats, y, aux, groups, months, n_batches,
                coal_type, n_pls=n_pls, sg_deriv=sg_deriv, sg_win=sg_win,
                use_hand_feats=use_hand_feats)
            gk_rmse = gk_cv_rmse(runs, is_small)
            te_result = train_pls_te(
                inorm_mat, hand_feats, y, aux, months, n_batches, coal_type,
                n_pls=n_pls, sg_deriv=sg_deriv, sg_win=sg_win,
                use_hand_feats=use_hand_feats)
        elif model_type == 'multiview':
            runs, is_small = train_multiview_gk(
                inorm_mat, hand_feats, y, aux, groups, months, n_batches,
                coal_type, n_pls=n_pls, sg_wins=sg_wins)
            gk_rmse = gk_cv_rmse(runs, is_small)
            te_result = train_multiview_te(
                inorm_mat, hand_feats, y, aux, months, n_batches, coal_type,
                n_pls=n_pls, sg_wins=sg_wins, fusion_alpha=fusion_alpha)
        else:
            continue

        gk_results[coal_type] = gk_rmse
        te_rmse = te_result['rmse_shrunk'] if te_result else None
        te_results[coal_type] = te_rmse

        tag = "LOOCV" if is_small else f"{N_ENSEMBLE_SEEDS}seed"
        te_str = f"TE={te_rmse:.2f}" if te_rmse else "TE=N/A"
        print(f"  [{coal_type}] {n_batches}b/{n_spec_total}s  "
              f"GK={gk_rmse:.2f}  {te_str}  ({tag})", flush=True)

    gk_avg = float(np.mean(list(gk_results.values())))
    te_vals = [v for v in te_results.values() if v is not None]
    te_avg = float(np.mean(te_vals)) if te_vals else 0
    print(f"\n  >> {config_name}")
    print(f"     GK-Avg={gk_avg:.2f}  TE-Avg={te_avg:.2f}  ({time.time()-t0:.0f}s)", flush=True)
    return gk_avg, te_avg


def main():
    print("=" * 70)
    print("V34: Batch-Level PLS + Multi-View Fusion")
    print("  Based on V33 finding: batch-level TE improved -5.95")
    print("  Try PLS (supervised) to fix GK explosion")
    print("=" * 70)

    label_map, aux_map = load_labels()
    results = {}

    # === Part 1: PLS direct (no hand feats, no derivative) ===
    for n_pls in [5, 10, 15, 20]:
        results[f'PLS_n{n_pls}'] = run_experiment(
            label_map, aux_map, f"Batch PLS direct n={n_pls}",
            model_type='pls', n_pls=n_pls)

    # === Part 2: PLS + hand feats ===
    for n_pls in [10, 15]:
        results[f'PLS_hf_n{n_pls}'] = run_experiment(
            label_map, aux_map, f"Batch PLS+handfeats n={n_pls}",
            model_type='pls', n_pls=n_pls, use_hand_feats=True)

    # === Part 3: PLS on SG2 derivative ===
    for n_pls in [10, 15]:
        for sg_win in [11, 15]:
            results[f'PLS_SG2_w{sg_win}_n{n_pls}'] = run_experiment(
                label_map, aux_map, f"Batch PLS SG2 w={sg_win} n={n_pls}",
                model_type='pls', n_pls=n_pls, sg_deriv=2, sg_win=sg_win)

    # === Part 4: Multi-view fusion ===
    for n_pls in [10, 15]:
        for alpha in [0.05, 0.1, 0.2]:
            results[f'MV_n{n_pls}_a{alpha}'] = run_experiment(
                label_map, aux_map, f"MultiView PLS n={n_pls} alpha={alpha}",
                model_type='multiview', n_pls=n_pls, fusion_alpha=alpha)

    # === Summary ===
    print(f"\n{'='*70}")
    print("SUMMARY (GK / TE)")
    print(f"{'='*70}")
    print(f"  {'V28 baseline (ref)':30s}  GK~163  TE~282")
    print(f"  {'V33 mean_norm (ref)':30s}  GK~276  TE~276")
    print(f"  {'config':30s}  {'GK':>8s}  {'TE':>8s}")
    for name, (gk, te) in results.items():
        print(f"  {name:30s}  {gk:8.2f}  {te:8.2f}")


if __name__ == "__main__":
    main()
