"""LOO validation of bias correction on TE-CV."""
import os, sys, re, glob, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew, kurtosis, entropy as scipy_entropy
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.model_selection import LeaveOneGroupOut, GroupKFold

warnings.filterwarnings('ignore')

_HERE = os.path.dirname(os.path.abspath(__file__))
TRAIN_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集")
LABEL_DIR = os.path.join(_HERE, "train_data", "赛题数据划分", "训练集标签")

COAL_TYPES = [
    '赵固一矿豫焦末煤', '赵固二矿中煤矿', '中马矿中煤矿',
    '九里山矿中煤矿', '煤场混煤',
]
AUX_COLS = ['全水分', '灰分', '氢', '硫']

KEY_LINES = {
    'C':   (247.86, 5.0), 'H':   (656.30, 7.5),
    'O':   (777.20, 7.5), 'N':   (742.40, 5.0),
    'Ca':  (422.70, 1.0), 'Ca2': (393.40, 1.0),
    'Mg':  (285.20, 1.0), 'Al':  (308.20, 1.0),
    'Si':  (288.20, 1.0), 'Fe':  (438.40, 1.5),
    'Na':  (589.00, 0.75),
}

N_PCA_MAX = 30
RANDOM_STATE = 42
RIDGE_ALPHA = 0.1
SMALL_BATCH_THRESHOLD = 11
N_ENSEMBLE_SEEDS = 100
ENSEMBLE_SEEDS = list(range(N_ENSEMBLE_SEEDS))
TIME_WEIGHT_TAU = {'九里山矿中煤矿': 20, '煤场混煤': 30}
TEST_MONTH = 12


def read_spectrum_csv(filepath):
    wl, inten = [], []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i < 5:
                    continue
                parts = line.strip().split(',')
                if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                    try:
                        wl.append(float(parts[0]))
                        inten.append(float(parts[1]))
                    except ValueError:
                        continue
    except Exception:
        return None, None
    if not wl:
        return None, None
    return np.array(wl, dtype=np.float32), np.array(inten, dtype=np.float32)


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def compute_time_weights(train_months, val_month, tau=30):
    diff = np.abs(train_months - val_month)
    diff = np.minimum(diff, 12 - diff)
    time_diff = diff * 30
    weights = np.exp(-time_diff / tau)
    weights = weights / weights.mean()
    return weights


def load_labels():
    label_map, aux_map = {}, {}
    for xlsx in glob.glob(os.path.join(LABEL_DIR, "*.xlsx")):
        coal_type = os.path.splitext(os.path.basename(xlsx))[0]
        df = pd.read_excel(xlsx)
        df.columns = [c.strip() for c in df.columns]
        df['名称'] = df['名称'].astype(str).str.strip()
        for _, row in df.iterrows():
            key = (coal_type, row['名称'])
            label_map[key] = float(row['发热量(Q)'])
            aux_map[key] = {c: float(row.get(c, np.nan)) for c in AUX_COLS}
    return label_map, aux_map


def load_coal_spectra(data_root, coal_type, label_map=None, aux_map=None):
    coal_dir = os.path.join(data_root, coal_type)
    if not os.path.isdir(coal_dir):
        return None
    raw_spectra, names, targets, aux_targets, groups = [], [], [], [], []
    batch_idx = 0
    for batch_folder in sorted(os.listdir(coal_dir)):
        batch_dir = os.path.join(coal_dir, batch_folder)
        if not os.path.isdir(batch_dir):
            continue
        date_str = batch_folder.replace(coal_type, '', 1).strip()
        q, aux = None, None
        if label_map is not None:
            key = (coal_type, date_str)
            if key not in label_map:
                continue
            q = label_map[key]
            aux = aux_map.get(key, {c: np.nan for c in AUX_COLS}) if aux_map else None
        csvs = glob.glob(os.path.join(batch_dir, "*.csv"))
        batch_has_data = False
        for f in csvs:
            wl, inten = read_spectrum_csv(f)
            if wl is None:
                continue
            raw_spectra.append((wl, inten))
            names.append(batch_folder)
            if q is not None:
                targets.append(q)
            if aux is not None:
                aux_targets.append([aux[c] for c in AUX_COLS])
            groups.append(batch_idx)
            batch_has_data = True
        if batch_has_data:
            batch_idx += 1
    if not raw_spectra:
        return None
    months = np.array([extract_month(n) for n in names], dtype=int)
    return {
        'spectra': raw_spectra, 'names': names,
        'targets': np.array(targets) if targets else None,
        'aux': np.array(aux_targets) if aux_targets else None,
        'groups': np.array(groups), 'n_batches': batch_idx,
        'months': months,
    }


def line_integral(wl, inten, center_nm, halfwin_nm):
    mask = (wl >= center_nm - halfwin_nm) & (wl <= center_nm + halfwin_nm)
    return float(inten[mask].sum()) if mask.sum() > 0 else 0.0


def spectrum_features(wl, inten):
    total = inten.sum() + 1e-8
    inten_norm = inten / total
    deriv = np.diff(inten_norm)
    deriv2 = np.diff(inten_norm, 2)
    stats = np.array([
        inten.mean(), inten.std(), inten.max(), np.log1p(total),
        inten_norm.mean(), inten_norm.std(),
        float(skew(inten_norm)), float(kurtosis(inten_norm)),
        float(scipy_entropy(inten_norm + 1e-12)),
        np.percentile(inten, 10), np.percentile(inten, 25),
        np.percentile(inten, 75), np.percentile(inten, 90),
        deriv.std(), float(np.abs(deriv).mean()),
        deriv2.std(), float(np.abs(deriv2).mean()),
    ], dtype=np.float32)
    labs = np.array(
        [line_integral(wl, inten, c, h) for _, (c, h) in KEY_LINES.items()],
        dtype=np.float32)
    lrel = labs / total
    comb_sum = labs[[0, 1, 2, 3]].sum()
    ash_sum = labs[[4, 5, 6, 7, 8, 9]].sum() + 1e-8
    rats = np.array([
        comb_sum / ash_sum, labs[1] / ash_sum,
        labs[0] / ash_sum, labs[1] / (labs[0] + 1e-8),
    ], dtype=np.float32)
    return inten_norm, stats, labs, lrel, rats


def compute_features(data):
    raw_spectra = data['spectra']
    inorms, stats_list, labs_list, lrel_list, rats_list = [], [], [], [], []
    for wl, inten in raw_spectra:
        inorm, stats, labs, lrel, rats = spectrum_features(wl, inten)
        inorms.append(inorm)
        stats_list.append(stats)
        labs_list.append(labs)
        lrel_list.append(lrel)
        rats_list.append(rats)
    min_len = min(len(s) for s in inorms)
    inorm_mat = np.array([s[:min_len] for s in inorms], dtype=np.float32)
    data['stats'] = np.array(stats_list)
    data['labs'] = np.array(labs_list)
    data['lrel'] = np.array(lrel_list)
    data['rats'] = np.array(rats_list)
    return inorm_mat


def build_feature_matrix(data, n_batches,
                         scaler_spec=None, pca=None, scaler_hand=None, fit=True):
    inorm_mat = compute_features(data)
    if fit:
        scaler_spec = StandardScaler()
        spec_scaled = scaler_spec.fit_transform(inorm_mat)
        n_pca = min(N_PCA_MAX, n_batches - 1, inorm_mat.shape[0] - 1)
        pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
        spec_pca = pca.fit_transform(spec_scaled)
    else:
        spec_pca = pca.transform(scaler_spec.transform(inorm_mat))
    hand_feats = np.hstack([data['stats'], data['labs'], data['lrel'], data['rats']])
    X = np.hstack([spec_pca, hand_feats])
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if fit:
        scaler_hand = StandardScaler()
        X = scaler_hand.fit_transform(X)
        return X, scaler_spec, pca, scaler_hand
    else:
        return scaler_hand.transform(X)


def find_best_shrinkage(oof_preds, oof_true, coal_mean):
    best_w, best_rmse = 1.0, float('inf')
    for w in np.linspace(0.0, 1.0, 21):
        blended = w * np.array(oof_preds) + (1 - w) * coal_mean
        rmse = float(np.sqrt(np.mean((blended - np.array(oof_true)) ** 2)))
        if rmse < best_rmse:
            best_rmse, best_w = rmse, w
    return best_w, best_rmse


def train_coal_te(coal_type, train_data):
    y = train_data['targets']
    aux = train_data['aux']
    groups = train_data['groups']
    n_batches = train_data['n_batches']
    coal_mean = float(y.mean())
    months = train_data['months']
    X_spec, _, _, _ = build_feature_matrix(train_data, n_batches, fit=True)

    val_mask = np.isin(months, [1, 2, 3])
    tr_mask = np.isin(months, [10, 11])
    if tr_mask.sum() == 0 or val_mask.sum() == 0:
        return None

    sample_weights = None
    if coal_type in TIME_WEIGHT_TAU:
        tau = TIME_WEIGHT_TAU[coal_type]
        sw = compute_time_weights(months[tr_mask], TEST_MONTH, tau=tau)
        sample_weights = sw

    tr_idx = np.where(tr_mask)[0]
    val_idx = np.where(val_mask)[0]

    aux_models = {}
    predicted_aux_val = np.zeros((len(val_idx), len(AUX_COLS)), dtype=np.float32)
    for col_idx, col_name in enumerate(AUX_COLS):
        y_aux = aux[:, col_idx]
        if np.isnan(y_aux).any():
            predicted_aux_val[:, col_idx] = float(np.nanmean(y_aux[tr_idx]))
            aux_models[col_name] = None
            continue
        m = Ridge(alpha=RIDGE_ALPHA)
        if sample_weights is not None:
            m.fit(X_spec[tr_idx], y_aux[tr_idx], sample_weight=sample_weights)
        else:
            m.fit(X_spec[tr_idx], y_aux[tr_idx])
        predicted_aux_val[:, col_idx] = m.predict(X_spec[val_idx])
        aux_models[col_name] = m

    X_s2_tr = np.nan_to_num(np.hstack([X_spec[tr_idx], aux[tr_idx, :]]))
    X_s2_val = np.nan_to_num(np.hstack([X_spec[val_idx], predicted_aux_val]))

    scaler_s2 = StandardScaler()
    X_s2_tr_s = scaler_s2.fit_transform(X_s2_tr)
    X_s2_val_s = scaler_s2.transform(X_s2_val)

    m2 = Ridge(alpha=RIDGE_ALPHA)
    if sample_weights is not None:
        m2.fit(X_s2_tr_s, y[tr_idx], sample_weight=sample_weights)
    else:
        m2.fit(X_s2_tr_s, y[tr_idx])

    val_pred = m2.predict(X_s2_val_s)
    val_groups = groups[val_idx]

    oof_preds, oof_true = [], []
    for bg in np.unique(val_groups):
        mask = val_groups == bg
        if mask.sum() == 0:
            continue
        true_q = float(y[val_idx][mask][0])
        pred_q = float(np.median(val_pred[mask]))
        oof_preds.append(pred_q)
        oof_true.append(true_q)

    oof_preds = np.array(oof_preds)
    oof_true = np.array(oof_true)

    rmse_raw = float(np.sqrt(np.mean((oof_preds - oof_true) ** 2)))
    best_w, rmse_shrunk = find_best_shrinkage(oof_preds, oof_true, coal_mean)

    return {
        'oof_preds': oof_preds, 'oof_true': oof_true,
        'rmse_raw': rmse_raw, 'rmse_shrunk': rmse_shrunk,
        'shrink_w': best_w, 'coal_mean': coal_mean,
    }


def main():
    print("=" * 70)
    print("LOO Validation of Bias Correction on TE-CV")
    print("=" * 70)

    label_map, aux_map = load_labels()

    te_data = {}
    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None:
            continue
        te_r = train_coal_te(coal_type, train_data)
        if te_r is not None:
            te_data[coal_type] = (te_r['oof_preds'], te_r['oof_true'])
            print(f"  [{coal_type}] {len(te_r['oof_preds'])} batches  "
                  f"raw={te_r['rmse_raw']:.2f}  shrunk={te_r['rmse_shrunk']:.2f}")

    all_pred = np.concatenate([v[0] for v in te_data.values()])
    all_true = np.concatenate([v[1] for v in te_data.values()])

    raw_rmse = np.sqrt(np.mean((all_pred - all_true) ** 2))
    print(f"\n  Total: {len(all_pred)} batches  raw RMSE={raw_rmse:.2f}")

    # Global LOO
    loo_c = np.zeros_like(all_pred)
    for i in range(len(all_pred)):
        mask = np.ones(len(all_pred), dtype=bool)
        mask[i] = False
        lr = LinearRegression()
        lr.fit(all_pred[mask].reshape(-1, 1), all_true[mask])
        loo_c[i] = float(lr.predict(np.array([[all_pred[i]]]))[0])
    loo_rmse = np.sqrt(np.mean((loo_c - all_true) ** 2))
    print(f"  Global LOO-BC: {loo_rmse:.2f}  (diff={loo_rmse - raw_rmse:.2f})")

    # Per-coal LOO
    print()
    for coal_type, (p, t) in te_data.items():
        if len(p) < 5:
            print(f"  [{coal_type}] {len(p)}b, skip (too few for LOO)")
            continue
        loo_c = np.zeros_like(p)
        for i in range(len(p)):
            mask = np.ones(len(p), dtype=bool)
            mask[i] = False
            lr = LinearRegression()
            lr.fit(p[mask].reshape(-1, 1), t[mask])
            loo_c[i] = float(lr.predict(np.array([[p[i]]]))[0])
        r_rmse = np.sqrt(np.mean((p - t) ** 2))
        c_rmse = np.sqrt(np.mean((loo_c - t) ** 2))
        print(f"  [{coal_type}] {len(p)}b  raw={r_rmse:.2f}  LOO-BC={c_rmse:.2f}  diff={c_rmse - r_rmse:.2f}")

    # Simple per-coal mean bias shift (no LOO needed - use training set mean)
    print()
    print("  Per-coal bias shift (using tr set):")
    for coal_type in COAL_TYPES:
        train_data = load_coal_spectra(TRAIN_DIR, coal_type, label_map, aux_map)
        if train_data is None:
            continue
        months = train_data['months']
        y = train_data['targets']
        tr_mask = np.isin(months, [10, 11])
        if tr_mask.sum() == 0:
            continue
        tr_mean_pred = float(y[tr_mask].mean())
        # The bias shift would need predictions on training set... skip
        # Just show the distribution stats
        tr_mean_q = float(y[tr_mask].mean())
        all_mean_q = float(y.mean())
        print(f"    [{coal_type}] tr(10/11) mean Q={tr_mean_q:.0f}  "
              f"all mean Q={all_mean_q:.0f}  "
              f"test(12) mean Q=?  "
              f"tr-vs-all diff={tr_mean_q - all_mean_q:.0f}")


if __name__ == "__main__":
    main()
