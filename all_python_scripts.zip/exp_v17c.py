"""V17c: Ridge alpha 网格在时间外推CV上的扫描
当前 ALPHAS=[1,10,50,100,500,1000,5000,10000]
测试: 固定单个alpha vs RidgeCV, 在无泄露时间外推CV上对比
"""
import sys, os, re, warnings, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.linear_model import RidgeCV, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from all import (
    load_labels, load_coal_spectra, TRAIN_DIR, AUX_COLS,
    N_PCA_MAX, RANDOM_STATE, ALPHAS, SMALL_BATCH_THRESHOLD,
    compute_features, find_best_shrinkage,
)

label_map, aux_map = load_labels()
TIME_COALS = ['赵固一矿豫焦末煤', '赵固二矿中煤矿', '煤场混煤']


def extract_month(name):
    m = re.search(r'(\d+)月', name)
    return int(m.group(1)) if m else 0


def time_ext_alpha(coal, fixed_alpha=None):
    """时间外推CV, 支持固定alpha或RidgeCV。"""
    td = load_coal_spectra(TRAIN_DIR, coal, label_map, aux_map)
    if td is None:
        return None
    y, groups, nb = td['targets'], td['groups'], td['n_batches']
    aux, names = td['aux'], td['names']

    inorm_mat = compute_features(data=td)
    hand_feats = np.hstack([td['stats'], td['labs'], td['lrel'], td['rats']])

    ub = np.unique(groups)
    bm = {}
    for g in ub:
        mk = groups == g; idx = np.where(mk)[0][0]
        bm[g] = extract_month(names[idx])
    tg = set(g for g in ub if bm[g] in {10, 11})
    vg = set(g for g in ub if bm[g] in {1, 2, 3})
    if len(tg) < 3 or len(vg) < 1:
        return None

    tm = np.array([g in tg for g in groups])
    vm = np.array([g in vg for g in groups])

    sc_spec = StandardScaler()
    spec_tr = sc_spec.fit_transform(inorm_mat[tm])
    spec_va = sc_spec.transform(inorm_mat[vm])

    n_pca = min(N_PCA_MAX, nb - 1, spec_tr.shape[0] - 1)
    pca = PCA(n_components=n_pca, random_state=RANDOM_STATE)
    sp_tr = pca.fit_transform(spec_tr)
    sp_va = pca.transform(spec_va)

    X_tr = np.hstack([sp_tr, hand_feats[tm]])
    X_va = np.hstack([sp_va, hand_feats[vm]])
    X_tr = np.nan_to_num(X_tr, nan=0.0, posinf=0.0, neginf=0.0)
    X_va = np.nan_to_num(X_va, nan=0.0, posinf=0.0, neginf=0.0)

    sc_all = StandardScaler()
    X_tr = sc_all.fit_transform(X_tr)
    X_va = sc_all.transform(X_va)

    coal_mean = float(y[tm].mean())

    def make_model():
        if fixed_alpha is not None:
            return Ridge(alpha=fixed_alpha)
        return RidgeCV(alphas=ALPHAS)

    # Stage1
    pa_tr = np.zeros((len(y[tm]), aux.shape[1]), dtype=np.float32)
    pa_va = np.zeros((len(y[vm]), aux.shape[1]), dtype=np.float32)
    for ci in range(aux.shape[1]):
        ya = aux[:, ci]
        if np.isnan(ya).any():
            pa_tr[:, ci] = float(np.nanmean(ya[tm]))
            pa_va[:, ci] = float(np.nanmean(ya[tm]))
            continue
        m1 = make_model()
        m1.fit(X_tr, ya[tm])
        pa_tr[:, ci] = m1.predict(X_tr)
        pa_va[:, ci] = m1.predict(X_va)

    X2_tr = np.nan_to_num(np.hstack([X_tr, pa_tr]))
    X2_va = np.nan_to_num(np.hstack([X_va, pa_va]))
    sc2 = StandardScaler()
    X2_tr = sc2.fit_transform(X2_tr)
    X2_va = sc2.transform(X2_va)

    m2 = make_model()
    m2.fit(X2_tr, y[tm])
    vp = m2.predict(X2_va)

    vg2 = groups[vm]; vy = y[vm]
    bp, bt = [], []
    for bg in np.unique(vg2):
        mk = vg2 == bg
        bp.append(float(np.median(vp[mk])))
        bt.append(float(vy[mk][0]))
    cv_raw = float(np.sqrt(np.mean([(t - p) ** 2 for t, p in zip(bt, bp)])))
    w, cv_sh = find_best_shrinkage(bp, bt, coal_mean)

    # 获取alpha信息
    if fixed_alpha is not None:
        alpha_info = f"a={fixed_alpha}"
    else:
        alpha_info = f"a={m2.alpha_:.1f}"

    return {
        'cv_raw': cv_raw, 'cv_sh': cv_sh, 'w': w,
        'alpha_info': alpha_info,
    }


def run(name, fixed_alpha=None):
    t0 = time.time()
    print(f"\n{'=' * 55}")
    print(f"  {name}")
    print(f"{'=' * 55}", flush=True)
    all_raw, all_sh = [], []
    for coal in TIME_COALS:
        r = time_ext_alpha(coal, fixed_alpha=fixed_alpha)
        if r is None:
            continue
        print(f"  [{coal}] raw={r['cv_raw']:.1f} shrunk={r['cv_sh']:.1f} "
              f"w={r['w']:.2f} ({r['alpha_info']})", flush=True)
        all_raw.append(r['cv_raw'])
        all_sh.append(r['cv_sh'])
    if all_sh:
        avg = np.mean(all_sh)
        print(f"  >> avg raw={np.mean(all_raw):.2f}  shrunk={avg:.2f}  "
              f"({time.time() - t0:.0f}s)", flush=True)
        return {'raw': np.mean(all_raw), 'shrunk': avg}
    return None


if __name__ == "__main__":
    results = {}

    # 基线: RidgeCV
    results['RidgeCV'] = run("基线: RidgeCV (auto alpha)")

    # 固定 alpha 扫描
    for a in [0.1, 0.5, 1.0, 5.0, 10.0, 50.0, 100.0, 500.0, 1000.0]:
        results[f'Ridge(a={a})'] = run(f"Ridge alpha={a}", fixed_alpha=a)

    # 汇总
    print(f"\n{'=' * 55}")
    print("  汇总 (无泄露时间外推CV)")
    print(f"{'=' * 55}")
    base = results.get('RidgeCV', {})
    base_sh = base.get('shrunk', 999) if base else 999
    for name, val in results.items():
        if val is None:
            continue
        mk = ""
        if name == 'RidgeCV':
            mk = "  <-- baseline"
        elif val['shrunk'] < base_sh:
            mk = "  BETTER"
        elif val['shrunk'] > base_sh:
            mk = "  WORSE"
        print(f"  {name:20s}: raw={val['raw']:.2f}  shrunk={val['shrunk']:.2f}{mk}")
