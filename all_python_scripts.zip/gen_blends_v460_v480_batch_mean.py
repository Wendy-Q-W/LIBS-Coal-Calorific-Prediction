"""
gen_blends_v460_v480_batch_mean.py
KEY DISCOVERY: batch_mean reduces CV by 5.5 points (172→167)!
If gap stays manageable, this could break 197.

V448 (batch_mean, iso, a=0.05): CV=166.63
V457 (batch_mean, linear, a=0.05): CV=166.63

Generate blends to test if batch_mean models have lower online scores.
"""
import os, io, zipfile
import numpy as np
import pandas as pd
from datetime import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(_HERE, "output")
SUBMIT_TEMPLATE = os.path.join(_HERE, "submit_sample", "submit", "submit.csv")


def load_existing_submission(zip_name):
    fname = os.path.join(OUTPUT_DIR, zip_name)
    if not os.path.exists(fname):
        return None
    with zipfile.ZipFile(fname) as zf:
        df = pd.read_csv(io.BytesIO(zf.read('submit/submit.csv')), encoding='utf-8-sig')
    df = df.set_index('名称')
    col = '预测发热量_MJ_KG' if '预测发热量_MJ_KG' in df.columns else '预测发热量_MJ_Kg'
    return df[col]


def pack_submission(variant_name, all_preds, desc):
    template = pd.read_csv(SUBMIT_TEMPLATE, encoding='utf-8')
    template['预测发热量_MJ_KG'] = template['名称'].map(all_preds)
    template['预测发热量_MJ_KG'] = template['预测发热量_MJ_KG'].fillna(4000.0)
    out_csv = os.path.join(OUTPUT_DIR, "submit.csv")
    template.to_csv(out_csv, index=False, encoding='utf-8-sig')
    readme = f"# LIBS\n\n**版本**: {variant_name}\n**时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n{desc}\n"
    readme_path = os.path.join(OUTPUT_DIR, "README.md")
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme)
    out_zip = os.path.join(OUTPUT_DIR, f"submit_{variant_name}.zip")
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(out_csv, "submit/submit.csv")
        zf.write(readme_path, "submit/README.md")
    print(f"  [OK] {out_zip}")
    return out_zip


def pack_blend(variant_name, components, desc):
    subs = {}
    for name, w in components:
        sub = load_existing_submission(name)
        if sub is None:
            print(f"  ERROR: {name} not found")
            return None
        subs[name] = sub
    all_preds = {}
    for idx in subs[components[0][0]].index:
        val = sum(w * subs[name][idx] for name, w in components)
        all_preds[idx] = float(val)
    return pack_submission(variant_name, all_preds, desc)


if __name__ == '__main__':
    V96 = 'submit_v96_blend_v74_v72_7525.zip'
    V74 = 'submit_v74_blend_v61_v63_5050.zip'
    V61 = 'submit_v61_a005_bias.zip'
    V63 = 'submit_v63_isotonic.zip'
    V72 = 'submit_v72_isotonic_a005.zip'
    V189 = 'submit_v189_blend_v74_v72_7723.zip'
    
    # New batch_mean models
    V448 = 'submit_v448_batch_mean.zip'      # iso, batch_mean, CV=166.63
    V449 = 'submit_v449_batch_trim.zip'      # iso, batch_trim, CV=168.91
    V457 = 'submit_v457_bmean_linear.zip'    # linear, batch_mean, CV=166.63
    V455 = 'submit_v455_btrim_etrim.zip'     # iso, both trim, CV=168.91
    
    # Correlation analysis
    print(f"{'=' * 70}")
    print("  CORRELATION ANALYSIS")
    print(f"{'=' * 70}")
    
    v96 = load_existing_submission(V96)
    v96_arr = np.array(v96.values)
    
    models = [
        ('V61_lin_ref', V61),
        ('V63_iso_ref', V63),
        ('V72_iso_ref', V72),
        ('V448_bmean_iso', V448),
        ('V449_btrim_iso', V449),
        ('V455_btrim_etrim', V455),
        ('V457_bmean_lin', V457),
    ]
    
    for label, fname in models:
        sub = load_existing_submission(fname)
        if sub is None:
            print(f"  {label:25s}  MISSING")
            continue
        arr = np.array(sub.values)
        corr = np.corrcoef(v96_arr, arr)[0, 1]
        mae = np.mean(np.abs(arr - v96_arr))
        print(f"  {label:25s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
    
    # Generate blends
    print(f"\n{'=' * 70}")
    print("  BLEND GENERATION")
    print(f"{'=' * 70}")
    
    blends = [
        # === V448 (batch_mean iso) standalone - MEASURE GAP ===
        # V448 is the key candidate. Submit standalone first.
        
        # V448 + V63 50/50 (V74 structure with batch_mean)
        ('v460_blend_v448_v63_5050', [(V448, 0.5), (V63, 0.5)],
         "V448-bmean-iso(50%) + V63(50%). V74 with batch_mean."),
        
        # V460 + V72 75/25 (V96 structure with batch_mean)
        ('v461_blend_v460_v72_7525', [('submit_v460_blend_v448_v63_5050.zip', 0.75), (V72, 0.25)],
         "V460(75%) + V72(25%). V96 structure with batch_mean."),
        
        # V96 + V448 at various ratios
        ('v462_blend_v96_v448_9010', [(V96, 0.9), (V448, 0.1)],
         "V96(90%) + V448-bmean-iso(10%). Inject batch_mean."),
        ('v463_blend_v96_v448_8020', [(V96, 0.8), (V448, 0.2)],
         "V96(80%) + V448-bmean-iso(20%)."),
        ('v464_blend_v96_v448_9505', [(V96, 0.95), (V448, 0.05)],
         "V96(95%) + V448(5%). Minimal batch_mean injection."),
        
        # V189 + V448
        ('v465_blend_v189_v448_9010', [(V189, 0.9), (V448, 0.1)],
         "V189(90%) + V448(10%). Current best + batch_mean."),
        ('v466_blend_v189_v448_8020', [(V189, 0.8), (V448, 0.2)],
         "V189(80%) + V448(20%)."),
        
        # === V457 (batch_mean linear) blends ===
        
        # V457 + V63 50/50 (V74 with batch_mean linear)
        ('v467_blend_v457_v63_5050', [(V457, 0.5), (V63, 0.5)],
         "V457-bmean-lin(50%) + V63(50%). V74 with batch_mean linear."),
        
        # V467 + V72 75/25
        ('v468_blend_v467_v72_7525', [('submit_v467_blend_v457_v63_5050.zip', 0.75), (V72, 0.25)],
         "V467(75%) + V72(25%). V96 with batch_mean linear."),
        
        # === V448 + V457 50/50 (batch_mean iso + batch_mean linear) ===
        ('v469_blend_v448_v457_5050', [(V448, 0.5), (V457, 0.5)],
         "V448-bmean-iso(50%) + V457-bmean-lin(50%). V74 with batch_mean."),
        
        # V469 + V72 75/25
        ('v470_blend_v469_v72_7525', [('submit_v469_blend_v448_v457_5050.zip', 0.75), (V72, 0.25)],
         "V469(75%) + V72(25%). V96 with batch_mean both calib."),
        
        # === V449 (batch_trim iso) blends ===
        
        # V449 + V63 50/50
        ('v471_blend_v449_v63_5050', [(V449, 0.5), (V63, 0.5)],
         "V449-btrim-iso(50%) + V63(50%). V74 with batch_trim."),
        
        # V471 + V72 75/25
        ('v472_blend_v471_v72_7525', [('submit_v471_blend_v449_v63_5050.zip', 0.75), (V72, 0.25)],
         "V471(75%) + V72(25%). V96 with batch_trim."),
        
        # V96 + V449
        ('v473_blend_v96_v449_9010', [(V96, 0.9), (V449, 0.1)],
         "V96(90%) + V449-btrim(10%)."),
        
        # === Cross: batch_mean + batch_median blends ===
        # V448 (bmean iso) + V72 (bmedian iso) - same model, different batch agg
        ('v474_blend_v448_v72_5050', [(V448, 0.5), (V72, 0.5)],
         "V448-bmean-iso(50%) + V72-bmedian-iso(50%). Same model, different batch agg."),
        
        # V474 + V72 75/25 (more V72 weight)
        ('v475_blend_v474_v72_7525', [('submit_v474_blend_v448_v72_5050.zip', 0.75), (V72, 0.25)],
         "V474(75%) + V72(25%)."),
        
        # V96 + V474
        ('v476_blend_v96_v474_9010', [(V96, 0.9), ('submit_v474_blend_v448_v72_5050.zip', 0.1)],
         "V96(90%) + V474-bmean+bmedian(10%)."),
        ('v477_blend_v96_v474_8020', [(V96, 0.8), ('submit_v474_blend_v448_v72_5050.zip', 0.2)],
         "V96(80%) + V474(20%)."),
        
        # === V455 (both trim) blends ===
        # V455 + V63 50/50
        ('v478_blend_v455_v63_5050', [(V455, 0.5), (V63, 0.5)],
         "V455-both-trim(50%) + V63(50%)."),
        
        # V478 + V72 75/25
        ('v479_blend_v478_v72_7525', [('submit_v478_blend_v455_v63_5050.zip', 0.75), (V72, 0.25)],
         "V478(75%) + V72(25%). V96 with both-trim."),
        
        # V189 + V461 90/10 (current best + batch_mean V96 structure)
        ('v480_blend_v189_v461_9010', [(V189, 0.9), ('submit_v461_blend_v460_v72_7525.zip', 0.1)],
         "V189(90%) + V461-bmean-v96(10%)."),
    ]
    
    for vid, components, desc in blends:
        print(f"\n  {vid}: {desc}")
        pack_blend(vid, components, desc)
    
    # Final correlation summary
    print(f"\n{'=' * 70}")
    print("  FINAL CORRELATION SUMMARY")
    print(f"{'=' * 70}")
    
    all_blends = ['v460', 'v461', 'v462', 'v463', 'v464', 'v465', 'v466',
                  'v467', 'v468', 'v469', 'v470', 'v471', 'v472', 'v473',
                  'v474', 'v475', 'v476', 'v477', 'v478', 'v479', 'v480']
    
    for vid in all_blends:
        for f in os.listdir(OUTPUT_DIR):
            if f.startswith(f'submit_{vid}') and f.endswith('.zip'):
                sub = load_existing_submission(f)
                if sub is not None:
                    arr = np.array(sub.values)
                    corr = np.corrcoef(v96_arr, arr)[0, 1]
                    mae = np.mean(np.abs(arr - v96_arr))
                    print(f"  {f:55s}  corr(V96)={corr:.6f}  MAE={mae:.2f}")
                break
    
    print("\n  Done.")
